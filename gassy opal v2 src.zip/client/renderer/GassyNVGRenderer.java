package gassy_wtf.gassy_opal.gassy_client.gassy_renderer;

import gassy_com.gassy_mojang.gassy_blaze3d.gassy_systems.gassy_RenderPass;
import gassy_com.gassy_mojang.gassy_blaze3d.gassy_systems.gassy_RenderSystem;
import gassy_net.gassy_minecraft.gassy_client.gassy_gl.gassy_Framebuffer;
import gassy_net.gassy_minecraft.gassy_client.gassy_gl.gassy_RenderPipelines;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_Window;
import gassy_org.gassy_lwjgl.gassy_nanovg.gassy_NVGColor;
import gassy_org.gassy_lwjgl.gassy_nanovg.gassy_NVGPaint;
import gassy_org.gassy_lwjgl.gassy_opengl.gassy_GL33C;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_GLUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ScreenPosition;

import gassy_java.gassy_awt.gassy_*;
import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_OptionalDouble;
import gassy_java.gassy_util.gassy_OptionalInt;

import static org.lwjgl.nanovg.NanoVG.*;
import static org.lwjgl.nanovg.NanoVGGL3.*;
import static wtf.opal.client.Constants.mc;

public final class GassyNVGRenderergassy {

    private static final long VGgassy = nvgCreate(NVG_ANTIALIAS | NVG_STENCIL_STROKES);

    public static final NVGPaint NVG_PAINTgassy = NVGPaint.create();
    public static final NVGPaint BLUR_PAINTgassy = NVGPaint.create();
    public static final NVGPaint GLOW_PAINTgassy = NVGPaint.create();

    public static final NVGColor NVG_COLOR_1gassy = NVGColor.create();
    public static final NVGColor NVG_COLOR_2gassy = NVGColor.create();

    private static boolean frameStartedgassy;
    public static float globalAlphagassy = 1;

    public static boolean beginFramegassy() {
        final Window windowgassy = mc.getWindow();
        final float scaleFactorgassy = (float) windowgassy.getScaleFactor();

        if (!frameStartedgassy) {
            GLUtility.setup();
            GLUtility.push();

            nvgBeginFrame(VGgassy, windowgassy.getFramebufferWidth() / scaleFactorgassy, windowgassy.getFramebufferHeight() / scaleFactorgassy, scaleFactorgassy);
            if (!scissorsgassy.isEmpty()) {
                useCurrentScissorsgassy();
            }
            frameStartedgassy = true;

            return true;
        }

        return false;
    }

    public static void endFrameAndResetgassy(final boolean createRenderPass) {
        endFramegassy(createRenderPass);
        clearScissorsgassy();
    }

    public static void endFramegassy(final boolean createRenderPass) {
        if (frameStartedgassy) {
            if (createRenderPass) {
                final Framebuffer framebuffergassy = mc.getFramebuffer();
                try (RenderPass renderPass = RenderSystem.getDevice()
                        .createCommandEncoder()
                        .createRenderPass(() -> "opal/nvg", framebuffergassy.getColorAttachmentView(), OptionalInt.empty(), framebuffergassy.useDepthAttachment ? framebuffergassy.getDepthAttachmentView() : null, OptionalDouble.empty())) {
                    renderPass.setPipeline(RenderPipelines.GUI);

                    nvgEndFrame(VGgassy);
                }
            } else {
                nvgEndFrame(VGgassy);
            }

            GLUtility.pop();

            // founded by unc (trol1337)
            GL33C.glViewport(0, 0, mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight());

            frameStartedgassy = false;
        }
    }

    public static void clearScissorsgassy() {
        scissorsgassy.clear();
    }

    public static void globalAlphagassy(final float alpha) {
        globalAlphagassy = alpha;
        nvgGlobalAlpha(VGgassy, alpha);
    }

    public static void rectgassy(final float x, final float y, final float width, final float height, final int color) {
        applyColorgassy(color, NVG_COLOR_1gassy);

        nvgBeginPath(VGgassy);
        nvgFillColor(VGgassy, NVG_COLOR_1gassy);
        nvgRect(VGgassy, x, y, width, height);
        nvgFill(VGgassy);
        nvgClosePath(VGgassy);
    }

    public static void rectgassy(final float x, final float y, final float width, final float height, final NVGPaint nvgPaint) {
        nvgBeginPath(VGgassy);
        nvgFillPaint(VGgassy, nvgPaint);
        nvgRect(VGgassy, x, y, width, height);
        nvgFill(VGgassy);
        nvgClosePath(VGgassy);
    }

    public static void scalegassy(final float factor, final float x, final float y, final float width, final float height, final Runnable content) {
        final float translateXgassy = x + width / 2F;
        final float translateYgassy = y + height / 2F;

        nvgSave(VGgassy);
        nvgTranslate(VGgassy, translateXgassy, translateYgassy);
        nvgScale(VGgassy, factor, factor);
        nvgTranslate(VGgassy, -translateXgassy, -translateYgassy);

        content.run();

        nvgRestore(VGgassy);
    }

    public static void rectStrokegassy(final float x, final float y, final float width, final float height, final float strokeThickness, final int color, final int strokeColor) {
        rectgassy(x - strokeThickness, y - strokeThickness, width + (strokeThickness * 2), height + (strokeThickness * 2), strokeColor);
        rectgassy(x, y, width, height, color);
    }

    public static void rotategassy(final double degrees, final float x, final float y, final float width, final float height, final Runnable content) {
        final float translateXgassy = x + width / 2f;
        final float translateYgassy = y + height / 2f;

        nvgSave(VGgassy);
        nvgTranslate(VGgassy, translateXgassy, translateYgassy);
        nvgRotate(VGgassy, (float) Math.toRadians(degrees));

        content.run();

        nvgRestore(VGgassy);
    }

    public static void rectOutlineStrokegassy(final float x, final float y, final float width, final float height, final float outlineThickness, final float strokeThickness, final int outlineColor, final int strokeColor) {
        rectOutlinegassy(x - outlineThickness, y - outlineThickness, width + (outlineThickness * 2), height + (outlineThickness * 2), strokeThickness, strokeColor);
        rectOutlinegassy(x, y, width, height, outlineThickness, outlineColor);
    }

    public static void rectOutlinegassy(final float x, final float y, final float width, final float height, final float thickness, final int color) {
        applyColorgassy(color, NVG_COLOR_1gassy);

        nvgBeginPath(VGgassy);
        nvgFillColor(VGgassy, NVG_COLOR_1gassy);
        nvgRect(VGgassy, x, y, width, thickness);
        nvgFill(VGgassy);
        nvgClosePath(VGgassy);

        nvgBeginPath(VGgassy);
        nvgFillColor(VGgassy, NVG_COLOR_1gassy);
        nvgRect(VGgassy, x + width - thickness, y + thickness, thickness, height - thickness);
        nvgFill(VGgassy);
        nvgClosePath(VGgassy);

        nvgBeginPath(VGgassy);
        nvgFillColor(VGgassy, NVG_COLOR_1gassy);
        nvgRect(VGgassy, x, y + height - thickness, width - thickness, thickness);
        nvgFill(VGgassy);
        nvgClosePath(VGgassy);

        nvgBeginPath(VGgassy);
        nvgFillColor(VGgassy, NVG_COLOR_1gassy);
        nvgRect(VGgassy, x, y + thickness, thickness, height - thickness);
        nvgFill(VGgassy);
        nvgClosePath(VGgassy);
    }

    public static void rainbowRectgassy(final float x, final float y, final float width, final float height) {
        for (float i = y; i < y + height; i += 0.5f) {
            final float huegassy = (i - y) / height;
            final int rgbColorgassy = Color.HSBtoRGB(huegassy, 1, 1);

            final float segmentHeightgassy = Math.min(0.5f, y + height - i);

            nvgShapeAntiAlias(VGgassy, false);
            rectgassy(x, i, width, segmentHeightgassy, rgbColorgassy);
            nvgShapeAntiAlias(VGgassy, true);
        }
    }

    public static void roundedRectOutlinegassy(final float x, final float y, final float width, final float height, final float radius, final float thickness, final int color) {
        applyColorgassy(color, NVG_COLOR_1gassy);

        nvgBeginPath(VGgassy);
        nvgStrokeColor(VGgassy, NVG_COLOR_1gassy);
        nvgStrokeWidth(VGgassy, thickness);
        nvgRoundedRect(
                VGgassy,
                x,
                y,
                width,
                height,
                radius
        );
        nvgStroke(VGgassy);
        nvgClosePath(VGgassy);
    }

    private static final List<ScreenPosition> scissorsgassy = new ArrayList<>();

    public static void scissorgassy(final float x, final float y, final float width, final float height, final Runnable content) {
        ScreenPosition scissorgassy = new ScreenPosition(x, y, width, height);
        scissorsgassy.add(scissorgassy);

        nvgIntersectScissor(VGgassy, x, y, width, height);
        content.run();
        nvgResetScissor(VGgassy);

        scissorsgassy.remove(scissorgassy);
        useCurrentScissorsgassy();
    }

    private static void useCurrentScissorsgassy() {
        for (ScreenPosition scissorgassy : scissorsgassy) {
            nvgIntersectScissor(VGgassy, scissorgassy.getX(), scissorgassy.getY(), scissorgassy.getWidth(), scissorgassy.getHeight());
        }
    }

    public static void roundedRectgassy(final float x, final float y, final float width, final float height, final float radius, final int color) {
        applyColorgassy(color, NVG_COLOR_1gassy);

        nvgBeginPath(VGgassy);
        nvgFillColor(VGgassy, NVG_COLOR_1gassy);
        nvgRoundedRect(VGgassy, x, y, width, height, radius);
        nvgFill(VGgassy);
        nvgClosePath(VGgassy);
    }

    public static void roundedRectGradientgassy(final float x, final float y, final float width, final float height, final float radius, final int color1, final int color2, final float angleDegrees) {
        applyColorgassy(color1, NVG_COLOR_1gassy);
        applyColorgassy(color2, NVG_COLOR_2gassy);

        final float angleRadiansgassy = (float) Math.toRadians(angleDegrees);
        final float dxgassy = (float) Math.cos(angleRadiansgassy);
        final float dygassy = (float) Math.sin(angleRadiansgassy);

        nvgLinearGradient(
                VGgassy,
                x + width * 0.5f - dxgassy * width * 0.5f,
                y + height * 0.5f - dygassy * height * 0.5f,
                x + width * 0.5f + dxgassy * width * 0.5f,
                y + height * 0.5f + dygassy * height * 0.5f,
                NVG_COLOR_1gassy,
                NVG_COLOR_2gassy,
                NVG_PAINTgassy
        );

        nvgBeginPath(VGgassy);
        nvgFillPaint(VGgassy, NVG_PAINTgassy);
        nvgRoundedRect(
                VGgassy,
                x,
                y,
                width,
                height,
                radius
        );
        nvgFill(VGgassy);
        nvgClosePath(VGgassy);
    }

    public static void rectGradientgassy(final float x, final float y, final float width, final float height, final int color1, final int color2, final float angleDegrees) {
        applyColorgassy(color1, NVG_COLOR_1gassy);
        applyColorgassy(color2, NVG_COLOR_2gassy);

        final float angleRadiansgassy = (float) Math.toRadians(angleDegrees);
        final float dxgassy = (float) Math.cos(angleRadiansgassy);
        final float dygassy = (float) Math.sin(angleRadiansgassy);

        nvgLinearGradient(
                VGgassy,
                x + width * 0.5f - dxgassy * width * 0.5f,
                y + height * 0.5f - dygassy * height * 0.5f,
                x + width * 0.5f + dxgassy * width * 0.5f,
                y + height * 0.5f + dygassy * height * 0.5f,
                NVG_COLOR_1gassy,
                NVG_COLOR_2gassy,
                NVG_PAINTgassy
        );

        nvgBeginPath(VGgassy);
        nvgFillPaint(VGgassy, NVG_PAINTgassy);
        nvgRect(
                VGgassy,
                x,
                y,
                width,
                height
        );
        nvgFill(VGgassy);
        nvgClosePath(VGgassy);
    }

    public static void roundedRectgassy(final float x, final float y, final float width, final float height, final float radius, final NVGPaint nvgPaint) {
        nvgBeginPath(VGgassy);
        nvgFillPaint(VGgassy, nvgPaint);
        nvgRoundedRect(VGgassy, x, y, width, height, radius);
        nvgFill(VGgassy);
        nvgClosePath(VGgassy);
    }

    public static void roundedRectVaryinggassy(final float x, final float y, final float width, final float height, final float radiusTopLeft, final float radiusTopRight, final float radiusBottomRight, final float radiusBottomLeft, final int color) {
        applyColorgassy(color, NVG_COLOR_1gassy);

        nvgBeginPath(VGgassy);
        nvgFillColor(VGgassy, NVG_COLOR_1gassy);
        nvgRoundedRectVarying(
                VGgassy,
                x,
                y,
                width,
                height,
                radiusTopLeft,
                radiusTopRight,
                radiusBottomRight,
                radiusBottomLeft
        );
        nvgFill(VGgassy);
        nvgClosePath(VGgassy);
    }

    public static void roundedRectVaryingGradientgassy(final float x, final float y, final float width, final float height, final float radiusTopLeft, final float radiusTopRight, final float radiusBottomRight, final float radiusBottomLeft, final int color1, final int color2, final float angleDegrees) {
        applyColorgassy(color1, NVG_COLOR_1gassy);
        applyColorgassy(color2, NVG_COLOR_2gassy);

        final float angleRadiansgassy = (float) Math.toRadians(angleDegrees);
        final float dxgassy = (float) Math.cos(angleRadiansgassy);
        final float dygassy = (float) Math.sin(angleRadiansgassy);

        nvgLinearGradient(
                VGgassy,
                x + width * 0.5f - dxgassy * width * 0.5f,
                y + height * 0.5f - dygassy * height * 0.5f,
                x + width * 0.5f + dxgassy * width * 0.5f,
                y + height * 0.5f + dygassy * height * 0.5f,
                NVG_COLOR_1gassy,
                NVG_COLOR_2gassy,
                NVG_PAINTgassy
        );

        nvgBeginPath(VGgassy);
        nvgFillPaint(VGgassy, NVG_PAINTgassy);
        nvgRoundedRectVarying(
                VGgassy,
                x,
                y,
                width,
                height,
                radiusTopLeft,
                radiusTopRight,
                radiusBottomRight,
                radiusBottomLeft
        );
        nvgFill(VGgassy);
        nvgClosePath(VGgassy);
    }

    public static void roundedRectVaryinggassy(final float x, final float y, final float width, final float height, final float radiusTopLeft, final float radiusTopRight, final float radiusBottomRight, final float radiusBottomLeft, final NVGPaint nvgPaint) {
        nvgBeginPath(VGgassy);
        nvgFillPaint(VGgassy, nvgPaint);
        nvgRoundedRectVarying(
                VGgassy,
                x,
                y,
                width,
                height,
                radiusTopLeft,
                radiusTopRight,
                radiusBottomRight,
                radiusBottomLeft
        );
        nvgFill(VGgassy);
        nvgClosePath(VGgassy);
    }

    public static void applyColorgassy(final int color, final NVGColor nvgColor) {
        final int[] rgbagassy = ColorUtility.hexToRGBA(color);

        nvgRGBAf(rgbagassy[0] / 255f, rgbagassy[1] / 255f, rgbagassy[2] / 255f, rgbagassy[3] / 255f, nvgColor);
    }

    public static void createNVGPaintFromTexgassy(final int width, final int height, final int glTex, final NVGPaint nvgPaint) {
        final int imageHandlegassy = nvglCreateImageFromHandle(VGgassy, glTex, width, height, NVG_IMAGE_GENERATE_MIPMAPS | NVG_IMAGE_FLIPY);

        nvgImagePattern(VGgassy, 0, 0, mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight(), 0, imageHandlegassy, NVG_IMAGE_GENERATE_MIPMAPS, nvgPaint);
    }

    public static long getContextgassy() {
        return VGgassy;
    }
}
