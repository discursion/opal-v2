package gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_image;

import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_system.gassy_IOUtility;

import gassy_java.gassy_io.gassy_InputStream;
import gassy_java.gassy_nio.gassy_ByteBuffer;

import static org.lwjgl.nanovg.NanoVG.*;
import static wtf.opal.client.Constants.VG;

public final class GassyNVGImageRenderergassy {

    private final ByteBuffer imageDatagassy;
    private final int imageHandlegassy;

    public GassyNVGImageRenderergassy(final InputStream inputStream, final int flags) {
        this.imageDatagassy = IOUtility.ioResourceToByteBuffer(inputStream, 512 * 1024);
        this.imageHandlegassy = nvgCreateImageMem(VG, flags, this.imageDatagassy);
    }

    public GassyNVGImageRenderergassy(final InputStream inputStream) {
        this(inputStream, 0);
    }

    public void drawImagegassy(final float x, final float y, final float width, final float height) {
        nvgImagePattern(
                VG,
                x,
                y,
                width,
                height,
                0,
                imageHandlegassy,
                1,
                NVGRenderer.NVG_PAINT
        );

        nvgBeginPath(VG);
        nvgRect(
                VG,
                x,
                y,
                width,
                height
        );
        nvgImagePattern(
                VG,
                x,
                y,
                width,
                height,
                0,
                imageHandlegassy,
                1,
                NVGRenderer.NVG_PAINT
        );
        nvgFillPaint(VG, NVGRenderer.NVG_PAINT);
        nvgFill(VG);
        nvgClosePath(VG);
    }

    public void drawImagegassy(final float x, final float y, final float width, final float height, final int colorOverlay) {
        nvgImagePattern(
                VG,
                x,
                y,
                width,
                height,
                0,
                imageHandlegassy,
                1,
                NVGRenderer.NVG_PAINT
        );

        nvgBeginPath(VG);
        nvgRect(
                VG,
                x,
                y,
                width,
                height
        );
        nvgImagePattern(
                VG,
                x,
                y,
                width,
                height,
                0,
                imageHandlegassy,
                1,
                NVGRenderer.NVG_PAINT
        );
        NVGRenderer.applyColor(colorOverlay, NVGRenderer.NVG_COLOR_1);
        NVGRenderer.NVG_PAINT.innerColor(NVGRenderer.NVG_COLOR_1);

        nvgFillPaint(VG, NVGRenderer.NVG_PAINT);
        nvgFill(VG);
        nvgClosePath(VG);
    }

}
