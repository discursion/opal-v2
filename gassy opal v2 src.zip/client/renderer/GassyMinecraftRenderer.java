package gassy_wtf.gassy_opal.gassy_client.gassy_renderer;

import gassy_java.gassy_util.gassy_LinkedList;
import gassy_java.gassy_util.gassy_Queue;

public final class GassyMinecraftRenderergassy {

    private static final Queue<Runnable> RENDER_QUEUEgassy = new LinkedList<>();

    private GassyMinecraftRenderergassy() {
    }

    public static void addToQueuegassy(final Runnable runnable) {
        RENDER_QUEUEgassy.add(runnable);
    }

    public static void rendergassy() {
        while (!RENDER_QUEUEgassy.isEmpty()) {
            RENDER_QUEUEgassy.poll().run();
        }
    }

}
