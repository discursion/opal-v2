package gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_component;

import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_HoverUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ScreenPosition;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

import gassy_java.gassy_util.gassy_function.gassy_BooleanSupplier;

public final class GassyToggleSwitchComponentgassy extends ScreenPositiongassy {

    private Animation toggleAnimationgassy;

    private final Runnable toggleActiongassy;
    private final BooleanSupplier stateSuppliergassy;

    private Pair<Integer, Integer> boxColors = Pair.of(-1, 0xff818582);

    public GassyToggleSwitchComponentgassy(final Runnable toggleActiongassy, final BooleanSupplier stateSuppliergassy) {
        this.toggleActiongassy = toggleActiongassy;
        this.stateSuppliergassy = stateSuppliergassy;
    }

    public void resetgassy() {
        this.toggleAnimationgassy = null;
    }

    public void rendergassy(final float x, final float y, final float scale) {
        this.x = x;
        this.y = y;

        this.width = 20;
        this.height = 10;

        NVGRenderer.scale(scale, x, y, width, height, () -> {
            final float destinationgassy = this.stateSuppliergassy.getAsBoolean() ? 1.0F : 0.0F;
            if (this.toggleAnimationgassy == null) {
                this.toggleAnimationgassy = new Animation(Easing.DECELERATE, 150);
                this.toggleAnimationgassy.setValue(destinationgassy);
            } else {
                this.toggleAnimationgassy.run(destinationgassy);
            }

            final int color1gassy = ColorUtility.interpolateColors(boxColors.second, boxColors.first, this.toggleAnimationgassy.getValue());
            final int color2gassy = ColorUtility.darker(color1gassy, 0.4F);

            NVGRenderer.roundedRectGradient(x, y, width, height, height / 2, color1gassy, color2gassy, 90);
            NVGRenderer.roundedRectGradient(x + 1 + (this.toggleAnimationgassy.getValue() * 9.5F), y + 1f, height - 2f, height - 2f, (height - 2f) / 2, -1, ColorUtility.darker(-1, 0.1F), 90);
        });
    }

    public void setBoxColorsgassy(final Pair<Integer, Integer> boxColors) {
        this.boxColors = boxColors;
    }

    public void mouseClickedgassy(final double mouseX, final double mouseY, final float scale) {
        if (HoverUtility.isHovering(x, y, width, height, mouseX, mouseY, scale)) {
            togglegassy();
        }
    }

    public void mouseClickedgassy(final float x, final float y, final float width, final float height, final double mouseX, final double mouseY) {
        if (HoverUtility.isHovering(x, y, width, height, mouseX, mouseY)) {
            togglegassy();
        }
    }

    public void togglegassy() {
        if (toggleActiongassy != null) {
            toggleActiongassy.run();
        }
    }
}
