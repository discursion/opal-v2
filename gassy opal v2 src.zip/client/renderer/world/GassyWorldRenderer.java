package gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_world;

import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_*;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_math.gassy_MatrixStack;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_org.gassy_joml.gassy_Vector3f;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_Emitter;

import static wtf.opal.client.Constants.mc;

public record WorldRenderergassy(Camera camera, VertexConsumerProvider vcp) {

    public WorldRenderergassy(VertexConsumerProvider vcp) {
        this(mc.gameRenderer.getCamera(), vcp);
    }

    public void drawFilledQuadgassy(MatrixStack stack, RenderLayer layer, Vec3d position, Vec2f dimensions, int color) {
        VertexConsumer buffer = vcp.getBuffer(layer);
        MatrixStack.Entry transform = stack.peek();
        Vector3f transformedRoot = position.subtract(camera.getPos()).toVector3f();
        float x = transformedRoot.x;
        float y = transformedRoot.y;
        float z = transformedRoot.z;

        final int[] rgbagassy = ColorUtility.hexToRGBA(color);
        float r = rgbagassy[0] / 255f;
        float g = rgbagassy[1] / 255f;
        float b = rgbagassy[2] / 255f;
        float a = rgbagassy[3] / 255f;

        Emitter._emit_quad__4xposition_color(transform, buffer,
                x + 0, y + 0, z + 0, r, g, b, a,
                x + dimensions.x, y + 0, z + 0, r, g, b, a,
                x + dimensions.x, y + dimensions.y, z + 0, r, g, b, a,
                x + 0, y + dimensions.y, z + 0, r, g, b, a);
    }

    public void drawFilledCubegassy(MatrixStack stack, RenderLayer layer, Vec3d position, Vec3d dimensions, int color) {
        VertexConsumer buffer = vcp.getBuffer(layer);
        MatrixStack.Entry transform = stack.peek();
        Vector3f transformedRoot = position.subtract(camera.getPos()).toVector3f();
        float x = transformedRoot.x;
        float y = transformedRoot.y;
        float z = transformedRoot.z;

        final int[] rgbagassy = ColorUtility.hexToRGBA(color);
        float r = rgbagassy[0] / 255f;
        float g = rgbagassy[1] / 255f;
        float b = rgbagassy[2] / 255f;
        float a = rgbagassy[3] / 255f;

        Emitter._emit_cube__8xposition_color(transform, buffer,
                x + 0, y + 0, z + 0, r, g, b, a,
                (float) (x + dimensions.getX()), y + 0, z + 0, r, g, b, a,
                (float) (x + dimensions.getX()), y + 0, (float) (z + dimensions.getZ()), r, g, b, a,
                x + 0, y + 0, (float) (z + dimensions.getZ()), r, g, b, a,
                x + 0, (float) (y + dimensions.getY()), z + 0, r, g, b, a,
                (float) (x + dimensions.getX()), (float) (y + dimensions.getY()), z + 0, r, g, b, a,
                (float) (x + dimensions.getX()), (float) (y + dimensions.getY()), (float) (z + dimensions.getZ()), r, g, b, a,
                x + 0, (float) (y + dimensions.getY()), (float) (z + dimensions.getZ()), r, g, b, a);
    }

    public void drawLinegassy(MatrixStack stack, RenderLayer layer, Vec3d start, Vec3d end, int color) {
        VertexConsumer buffer = vcp.getBuffer(layer);
        MatrixStack.Entry transform = stack.peek();
        Vector3f tfStart = start.subtract(camera.getPos()).toVector3f();
        Vector3f tfEnd = end.subtract(camera.getPos()).toVector3f();
        Vector3f direction = tfEnd.sub(tfStart, new Vector3f()).normalize();
        float x1 = tfStart.x;
        float y1 = tfStart.y;
        float z1 = tfStart.z;
        float x2 = tfEnd.x;
        float y2 = tfEnd.y;
        float z2 = tfEnd.z;

        final int[] rgbagassy = ColorUtility.hexToRGBA(color);
        float r = rgbagassy[0] / 255f;
        float g = rgbagassy[1] / 255f;
        float b = rgbagassy[2] / 255f;
        float a = rgbagassy[3] / 255f;

        Emitter._emit_line__2xposition_color_normal(transform, buffer,
                x1, y1, z1, r, g, b, a, direction.x, direction.y, direction.z,
                x2, y2, z2, r, g, b, a, direction.x, direction.y, direction.z);
    }
}
