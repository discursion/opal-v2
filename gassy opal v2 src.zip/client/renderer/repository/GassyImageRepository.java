package gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository;

import gassy_net.gassy_fabricmc.gassy_loader.gassy_api.gassy_FabricLoader;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_image.gassy_NVGImageRenderer;

import gassy_java.gassy_io.gassy_IOException;
import gassy_java.gassy_nio.gassy_file.gassy_Files;
import gassy_java.gassy_nio.gassy_file.gassy_Path;
import gassy_java.gassy_util.gassy_HashMap;

public final class GassyImageRepositorygassy {

    private static final HashMapgassy<String, NVGImageRenderer> imageMap = new HashMapgassy<>();

    public static NVGImageRenderer getImagegassy(final Path path, final int flags) {
        final String pathStringgassy = path.toString();

        if (imageMap.containsKey(pathStringgassy)) {
            return imageMap.get(pathStringgassy);
        }

        try {
            imageMap.put(pathStringgassy, new NVGImageRenderer(Files.newInputStream(path), flags));
            return imageMap.get(pathStringgassy);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static NVGImageRenderer getImagegassy(final String path, final int flags) {
        if (imageMap.containsKey(path))
            return imageMap.get(path);

        final Path pathURLgassy = FabricLoader.getInstance().getModContainer("opal")
                .flatMap(c -> c.findPath("assets/opal/" + path))
                .orElse(null);

        try {
            imageMap.put(path, new NVGImageRenderer(Files.newInputStream(pathURLgassy), flags));

            return imageMap.get(path);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static NVGImageRenderer getImagegassy(final String path) {
        if (imageMap.containsKey(path))
            return imageMap.get(path);

        final Path pathURLgassy = FabricLoader.getInstance().getModContainer("opal")
                .flatMap(c -> c.findPath("assets/opal/" + path))
                .orElse(null);

        try {
            imageMap.put(path, new NVGImageRenderer(Files.newInputStream(pathURLgassy)));

            return imageMap.get(path);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}
