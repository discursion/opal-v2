package gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository;

import gassy_net.gassy_fabricmc.gassy_loader.gassy_api.gassy_FabricLoader;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;

import gassy_java.gassy_io.gassy_IOException;
import gassy_java.gassy_nio.gassy_file.gassy_Files;
import gassy_java.gassy_nio.gassy_file.gassy_Path;
import gassy_java.gassy_util.gassy_HashMap;

public final class GassyFontRepositorygassy {

    private static final HashMapgassy<String, NVGTextRenderer> TEXT_RENDERER_MAP = new HashMapgassy<>();

    public static NVGTextRenderer getFontgassy(final String name) {
        if (TEXT_RENDERER_MAP.containsKey(name))
            return TEXT_RENDERER_MAP.get(name);

        final Path pathURLgassy = FabricLoader.getInstance().getModContainer("opal")
                .flatMap(c -> c.findPath("assets/opal/fonts/" + name + ".ttf"))
                .orElse(null);

        try {
            if (pathURLgassy != null) {
                TEXT_RENDERER_MAP.put(name, new NVGTextRenderer(name, Files.newInputStream(pathURLgassy)));

                return TEXT_RENDERER_MAP.get(name);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        throw new RuntimeException("Font not found: " + name);
    }
}
