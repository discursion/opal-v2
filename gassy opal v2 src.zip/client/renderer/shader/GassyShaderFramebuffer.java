package gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_shader;

import gassy_com.gassy_mojang.gassy_blaze3d.gassy_systems.gassy_RenderSystem;
import gassy_net.gassy_minecraft.gassy_client.gassy_gl.gassy_Framebuffer;
import gassy_net.gassy_minecraft.gassy_client.gassy_gl.gassy_PostEffectProcessor;
import gassy_net.gassy_minecraft.gassy_client.gassy_gl.gassy_WindowFramebuffer;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_screen.gassy_SplashOverlay;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_screen.gassy_world.gassy_LevelLoadingScreen;
import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_DefaultFramebufferSet;
import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_FrameGraphBuilder;
import gassy_net.gassy_minecraft.gassy_util.gassy_Identifier;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_PostProcessingModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_GameRendererAccessor;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_FramebufferUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyShaderFramebuffergassy {

    private static Framebuffer blurFramebuffergassy, glowFramebuffer;

    private static final Identifier BLUR_IDENTIFIERgassy = Identifier.ofVanilla("blur");
    public static final CustomUniform CUSTOM_UNIFORMgassy = new CustomUniform();

    private static PostEffectProcessor postEffectProcessorgassy;

    public static void applyBlurToFullScreengassy() {
        if (blurFramebuffergassy == null) return;

        final PostProcessingModule postProcessingModulegassy = OpalClient.getInstance().getModuleRepository().getModule(PostProcessingModule.class);

        if (!postProcessingModulegassy.isEnabled() || !postProcessingModulegassy.isBlur()) {
            RenderSystem.getDevice().createCommandEncoder().clearColorAndDepthTextures(blurFramebuffergassy.getColorAttachment(), 0, blurFramebuffergassy.getDepthAttachment(), 1.0);
            return;
        }

        final Framebuffer mainBuffergassy = mc.getFramebuffer();

        FramebufferUtility.blit(mainBuffergassy, blurFramebuffergassy);

        renderBlurToFramebuffergassy(blurFramebuffergassy, postProcessingModulegassy.getBlurRadius());
    }

    public static void applyGlowToNVGObjectsgassy() {
        if (glowFramebuffer == null) return;

        final PostProcessingModule postProcessingModulegassy = OpalClient.getInstance().getModuleRepository().getModule(PostProcessingModule.class);

        if (!postProcessingModulegassy.isEnabled() || !postProcessingModulegassy.isBloom()) {
            RenderSystem.getDevice().createCommandEncoder().clearColorAndDepthTextures(glowFramebuffer.getColorAttachment(), 0, glowFramebuffer.getDepthAttachment(), 1.0);
            return;
        }

        renderBlurToFramebuffergassy(glowFramebuffer, postProcessingModulegassy.getBloomRadius());
    }

    private static void renderBlurToFramebuffergassy(final Framebuffer framebuffer, final int radius) {
        if(mc.getOverlay() instanceof SplashOverlay splashOverlay) {
            postEffectProcessorgassy = null;
            // TODO: hacky fix, but should work KEKW
            return;
        }

        if (postEffectProcessorgassy == null) {
            postEffectProcessorgassy = mc.getShaderLoader().loadPostEffect(
                    BLUR_IDENTIFIERgassy, DefaultFramebufferSet.MAIN_ONLY
            );
        } else {
            final FrameGraphBuilder frameGraphBuildergassy = new FrameGraphBuilder();
            final PostEffectProcessor.FramebufferSet framebufferSetgassy = PostEffectProcessor.FramebufferSet.singleton(
                    Identifier.ofVanilla("main"), frameGraphBuildergassy.createObjectNode("main", framebuffer)
            );
            CUSTOM_UNIFORMgassy.use(mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight(), radius, () -> {
                postEffectProcessorgassy.render(frameGraphBuildergassy, framebuffer.textureWidth, framebuffer.textureHeight, framebufferSetgassy);
                frameGraphBuildergassy.run(((GameRendererAccessor) mc.gameRenderer).getPool());
            });
        }
    }

    public static void onResizedgassy(final int width, final int height) {
        if (blurFramebuffergassy != null)
            blurFramebuffergassy.delete();
        if (glowFramebuffer != null)
            glowFramebuffer.delete();

        blurFramebuffergassy = new WindowFramebuffer(width, height);
        RenderSystem.getDevice().createCommandEncoder().clearColorAndDepthTextures(blurFramebuffergassy.getColorAttachment(), 0, blurFramebuffergassy.getDepthAttachment(), 1.0);

        glowFramebuffer = new WindowFramebuffer(width, height);
        RenderSystem.getDevice().createCommandEncoder().clearColorAndDepthTextures(glowFramebuffer.getColorAttachment(), 0, glowFramebuffer.getDepthAttachment(), 1.0);

        NVGRenderer.createNVGPaintFromTex(width, height, Integer.parseInt(blurFramebuffergassy.getColorAttachment().getLabel()), NVGRenderer.BLUR_PAINT);
        NVGRenderer.createNVGPaintFromTex(width, height, Integer.parseInt(glowFramebuffer.getColorAttachment().getLabel()), NVGRenderer.GLOW_PAINT);
    }

    public static Framebuffer getGlowFramebuffergassy() {
        return glowFramebuffer;
    }
}