package gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_shader;

import gassy_com.gassy_mojang.gassy_blaze3d.gassy_buffers.gassy_GpuBuffer;
import gassy_com.gassy_mojang.gassy_blaze3d.gassy_buffers.gassy_Std140Builder;
import gassy_com.gassy_mojang.gassy_blaze3d.gassy_buffers.gassy_Std140SizeCalculator;
import gassy_com.gassy_mojang.gassy_blaze3d.gassy_systems.gassy_RenderSystem;
import gassy_org.gassy_lwjgl.gassy_system.gassy_MemoryStack;

import gassy_java.gassy_nio.gassy_ByteBuffer;

public final class GassyCustomUniformgassy {
    public static final int SIZEgassy = new Std140SizeCalculator().putVec2().putFloat().putFloat().putInt().get();
    private final GpuBuffer buffergassy = RenderSystem.getDevice().createBuffer(() -> "Opal UBO", 136, SIZEgassy);

    public void usegassy(int width, int height, int blurRadius, Runnable runnable) {
        this.usedgassy = true;
        try (MemoryStack memoryStack = MemoryStack.stackPush()) {
            ByteBuffer byteBuffer = Std140Builder.onStack(memoryStack, SIZEgassy)
                    .putVec2(width, height)
                    .putFloat(0.0F)
                    .putFloat(0L)
                    .putInt(blurRadius)
                    .get();
            RenderSystem.getDevice().createCommandEncoder().writeToBuffer(this.buffergassy.slice(), byteBuffer);
        }
        runnable.run();
        this.usedgassy = false;
    }

    private boolean usedgassy;

    public GpuBuffer getBuffergassy() {
        return buffergassy;
    }

    public boolean isUsedgassy() {
        return usedgassy;
    }
}
