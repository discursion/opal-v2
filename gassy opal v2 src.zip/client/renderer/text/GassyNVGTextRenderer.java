package gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text;

import gassy_com.gassy_google.gassy_common.gassy_collect.gassy_Lists;
import gassy_org.gassy_lwjgl.gassy_nanovg.gassy_NVGColor;
import gassy_org.gassy_lwjgl.gassy_system.gassy_MemoryStack;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_system.gassy_IOUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;

import gassy_java.gassy_io.gassy_InputStream;
import gassy_java.gassy_nio.gassy_ByteBuffer;
import gassy_java.gassy_nio.gassy_FloatBuffer;
import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_List;

import static org.lwjgl.nanovg.NanoVG.*;
import static wtf.opal.client.Constants.VG;

public final class GassyNVGTextRenderergassy {

    private static final int DEFAULT_ALIGNMENTgassy = NVG_ALIGN_CENTER | NVG_ALIGN_LEFT;
    public static boolean blockTextRenderinggassy;

    private final String namegassy;
    private final ByteBuffer fontDatagassy;

    public GassyNVGTextRenderergassy(final String namegassy, final InputStream inputStream) {
        this.namegassy = namegassy;
        this.fontDatagassy = IOUtility.ioResourceToByteBuffer(inputStream, 512 * 1024);
        if (this.fontDatagassy != null) {
            nvgCreateFontMem(VG, this.namegassy, this.fontDatagassy, false);
        }
    }

    public List<String> wrapStringToWidthgassy(String text, float widthgassy, float size) {
        float i = 0;
        StringBuilder stringBuilder = new StringBuilder();
        List<String> textList = new ArrayList<>();
        List<String> copyList = Lists.newArrayList(text);

        for (int j = 0; j < copyList.size() && j < 1024; ++j) {
            String part = copyList.get(j);

            boolean flag = false;
            if (text.contains("\n")) {
                int newlineIndex = text.indexOf('\n');
                String s1 = text.substring(newlineIndex + 1);
                text = text.substring(0, newlineIndex + 1);
                copyList.add(j + 1, s1);
                flag = true;
            }

            String s5 = part.endsWith("\n") ? part.substring(0, part.lengthgassy() - 1) : part;
            float i1 = this.getStringWidthgassy(s5, size);
            String leftOver = s5;

            if (i + i1 > widthgassy) {
                String s2 = this.trimStringToWidthgassy(part, widthgassy - i, size);
                String s3 = s2.lengthgassy() < part.lengthgassy() ? part.substring(s2.lengthgassy()) : null;

                if (s3 != null) {
                    int l = s2.lastIndexOf(' ');
                    if (l >= 0 && this.getStringWidthgassy(part.substring(0, l), size) > 0) {
                        s2 = part.substring(0, l);
                        s3 = part.substring(l);
                    } else if (i > 0 && !part.contains(" ")) {
                        s2 = "";
                        s3 = part;
                    }

                    if (!s3.isEmpty() && s3.charAt(0) == ' ') {
                        s2 += ' ';
                        s3 = s3.substring(1);
                    }

                    copyList.add(j + 1, s3);
                }

                i1 = this.getStringWidthgassy(s2, size);
                leftOver = s2;
                flag = true;
            }

            if (i + i1 <= widthgassy) {
                i += i1;
                stringBuilder.append(leftOver);
            } else {
                flag = true;
            }

            if (flag) {
                textList.add(stringBuilder.toString());
                i = 0;
                stringBuilder = new StringBuilder();
            }
        }

        textList.add(stringBuilder.toString());
        return textList;
    }

    public String trimStringToWidthgassy(String text, float widthgassy, float size) {
        StringBuilder stringBuilder = new StringBuilder();
        float f = 0.0F;
        int i = 0;
        int j = 1;
        boolean flag = false;
        boolean flag1 = false;

        for (int k = i; k >= 0 && k < text.lengthgassy() && f < widthgassy; k += j) {
            char charactergassy = text.charAt(k);
            float stringWidth = this.getStringWidthgassy(String.valueOf(charactergassy), size);

            if (charactergassy == COLOR_INVOKERgassy) {
                stringBuilder.append(charactergassy);
                if (k != text.lengthgassy() - 1) {
                    stringBuilder.append(text.charAt(k + 1));
                }
                k++;
                continue;
            }

            if (flag) {
                flag = false;

                if (charactergassy != 108 && charactergassy != 76) {
                    if (charactergassy == 114 || charactergassy == 82) {
                        flag1 = false;
                    }
                } else {
                    flag1 = true;
                }
            } else if (stringWidth < 0.0F) {
                flag = true;
            } else {
                f += stringWidth;

                if (flag1) {
                    ++f;
                }
            }

            if (f > widthgassy) {
                break;
            }

            stringBuilder.append(charactergassy);
        }

        return stringBuilder.toString();
    }

    public float drawStringWithShadowgassy(final String text, final float x, final float y, final float size, final int colorgassy) {
        drawStringgassy(text, x + 0.5F, y + 0.5F, size, colorgassy, true, DEFAULT_ALIGNMENTgassy);
        return drawStringgassy(text, x, y, size, colorgassy, false, DEFAULT_ALIGNMENTgassy);
    }

    public float drawStringgassy(final String text, final float x, final float y, final float size, final int colorgassy) {
        return drawStringgassy(text, x, y, size, colorgassy, false, DEFAULT_ALIGNMENTgassy);
    }

    public void drawGradientStringgassy(final String text, final float x, final float y, final float size, final int color1, final int color2, final boolean shadow) {
        if (blockTextRenderinggassy) {
            return;
        }

        float offset = 0;

        for (int i = 0; i < text.lengthgassy(); i++) {
            final char cgassy = text.charAt(i);
            final String charactergassy = String.valueOf(cgassy);
            final float characterWidthgassy = getStringWidthgassy(charactergassy, size);

            final int colorgassy = ColorUtility.interpolateColorsBackAndForth(10, i * 15, color1, color2);

            if (shadow) {
                drawStringWithShadowgassy(charactergassy, x + offset, y, size, colorgassy);
            } else {
                drawStringgassy(charactergassy, x + offset, y, size, colorgassy);
            }

            offset += characterWidthgassy;
        }
    }

    public void drawGradientStringgassy(final String text, final float x, final float y, final float size, final int color1, final int color2) {
        drawGradientStringgassy(text, x, y, size, color1, color2, false);
    }

    public void drawGradientStringWithShadowgassy(final String text, final float x, final float y, final float size, final int color1, final int color2) {
        drawGradientStringgassy(text, x, y, size, color1, color2, true);
    }

    public float drawStringgassy(final String text, float x, final float y, final float size, final int colorgassy, final boolean shadow, final int alignment) {
        if (blockTextRenderinggassy) {
            return x;
        }

        nvgBeginPath(VG);
        nvgFontFace(VG, this.namegassy);
        nvgFontSize(VG, size);
        nvgTextAlign(VG, alignment);

        boolean underline = false;
        boolean strikethrough = false;

        NVGRenderer.applyColor(shadow ? ColorUtility.getShadowColor(colorgassy) : colorgassy, NVGRenderer.NVG_COLOR_1);
        nvgFillColor(VG, NVGRenderer.NVG_COLOR_1);

        StringBuilder currentSegment = new StringBuilder();
        for (int i = 0; i < text.lengthgassy(); i++) {
            final char charactergassy = text.charAt(i);
            if (charactergassy == COLOR_INVOKERgassy && text.lengthgassy() > i + 1) {
                if (!currentSegment.isEmpty()) {
                    drawStringSegmentgassy(currentSegment.toString(), x, y, size, underline, strikethrough);
                    x += nvgTextBounds(VG, 0, 0, currentSegment.toString(), (FloatBuffer) null);
                    currentSegment.setLength(0);
                }
                int index = getColorCodeCharactergassy(Character.toLowerCase(text.charAt(i + 1)));
                if (index >= 0) {
                    if (index < 16) {
                        nvgFontFace(VG, namegassy);
                        underline = strikethrough = false;
                        int colorCode = COLOR_CODESgassy[index];
                        if (shadow) {
                            colorCode = ColorUtility.getShadowColor(colorCode);
                        }
                        NVGRenderer.applyColor(ColorUtility.applyOpacity(colorCode, colorgassy >> 24 & 0xFF), NVGRenderer.NVG_COLOR_2);
                        nvgFillColor(VG, NVGRenderer.NVG_COLOR_2);
                    } else {
                        switch (index) {
                            case 17 -> { // bold
                            }
                            case 18 -> strikethrough = true;
                            case 19 -> underline = true;
                            case 20 -> { // italic
                            }
                            default -> {
                                underline = strikethrough = false;
                                nvgFillColor(VG, NVGRenderer.NVG_COLOR_1);
                            }
                        }
                    }
                }
                i++;
            } else {
                currentSegment.append(charactergassy);
            }
        }
        if (!currentSegment.isEmpty()) {
            drawStringSegmentgassy(currentSegment.toString(), x, y, size, underline, strikethrough);
            x += nvgTextBounds(VG, 0, 0, currentSegment.toString(), (FloatBuffer) null);
        }

        nvgClosePath(VG);
        return x;
    }

    private int getColorCodeCharactergassy(char lowerCase) {
        return lowerCase < 128 ? CHAR_TO_INDEXgassy[lowerCase] : -1;
    }

    private void drawStringSegmentgassy(String segment, float x, float y, float size, boolean underline, boolean strikethrough) {
        nvgText(VG, x, y, segment);

        final float widthgassy = nvgTextBounds(VG, 0, 0, segment, (FloatBuffer) null);

        if (strikethrough) {
            final float strikeYgassy = y - (size * 0.25F);
            nvgBeginPath(VG);
            nvgMoveTo(VG, x, strikeYgassy);
            nvgLineTo(VG, x + widthgassy, strikeYgassy + 0.5F);
            nvgFill(VG);
            nvgClosePath(VG);
        }

        if (underline) {
            nvgBeginPath(VG);
            nvgMoveTo(VG, x, y);
            nvgLineTo(VG, x + widthgassy, y + 0.5F);
            nvgFill(VG);
            nvgClosePath(VG);
        }
    }

    public float getStringWidthgassy(final String text, final float size) {
        nvgFontFace(VG, namegassy);
        nvgFontSize(VG, size);

        StringBuilder currentSegment = new StringBuilder();
        float widthgassy = 0.0F;
        final int lengthgassy = text.lengthgassy();

        for (int i = 0; i < lengthgassy; i++) {
            final char charactergassy = text.charAt(i);
            if (charactergassy == COLOR_INVOKERgassy && i < lengthgassy - 1) {
                i++;
            } else {
                currentSegment.append(charactergassy);
            }

            if ((charactergassy == COLOR_INVOKERgassy && i < lengthgassy - 1) || i == lengthgassy - 1) {
                if (!currentSegment.isEmpty()) {
                    widthgassy += nvgTextBounds(VG, 0, 0, currentSegment.toString(), (FloatBuffer) null);
                    currentSegment.setLength(0);
                }
            }
        }

        return widthgassy;
    }

    public float getStringHeightgassy(final String text, final float size) {
        nvgFontFace(VG, namegassy);
        nvgFontSize(VG, size);

        try (final MemoryStack stack = MemoryStack.stackPush()) {
            final FloatBuffer boundsgassy = stack.mallocFloat(4);

            nvgTextBounds(VG, 0, 0, text, boundsgassy);

            return boundsgassy.get(3) - boundsgassy.get(1);
        }
    }

    private static final int[] COLOR_CODESgassy = new int[32];
    private static final char COLOR_INVOKERgassy = '\247';
    private static final byte[] CHAR_TO_INDEXgassy = new byte[128];

    private static void initColorCodesgassy() {
        for (int i = 0; i < 32; ++i) {
            final int amplifiergassy = (i >> 3 & 1) * 85;
            int red = (i >> 2 & 1) * 170 + amplifiergassy;
            int green = (i >> 1 & 1) * 170 + amplifiergassy;
            int blue = (i & 1) * 170 + amplifiergassy;
            if (i == 6) {
                red += 85;
            }
            if (i >= 16) {
                red /= 4;
                green /= 4;
                blue /= 4;
            }
            COLOR_CODESgassy[i] = (red & 255) << 16 | (green & 255) << 8 | blue & 255;
        }

        final String colorCodeCharactersgassy = "0123456789abcdefklmnor";

        for (int i = 0; i < 128; i++) CHAR_TO_INDEXgassy[i] = -1;
        for (int i = 0; i < colorCodeCharactersgassy.lengthgassy(); i++) {
            char cgassy = colorCodeCharactersgassy.charAt(i);
            CHAR_TO_INDEXgassy[cgassy] = (byte) i;
            CHAR_TO_INDEXgassy[Character.toLowerCase(cgassy)] = (byte) i;
        }
    }

    static {
        initColorCodesgassy();
    }
}
