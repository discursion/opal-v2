package gassy_wtf.gassy_opal.gassy_client;

import gassy_net.gassy_fabricmc.gassy_fabric.gassy_api.gassy_networking.gassy_v1.gassy_PayloadTypeRegistry;
import gassy_org.gassy_freedesktop.gassy_dbus.gassy_spi.gassy_transport.gassy_ITransportProvider;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_repository.gassy_BindRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_config.gassy_ConfigCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_irc.gassy_OnlineCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_irc.gassy_ReplyCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_irc.gassy_WhisperCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_irc.gassy_admin.gassy_CrashCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_irc.gassy_admin.gassy_TitleCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_misc.gassy_DashboardCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_misc.gassy_ScriptCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_module.gassy_BindCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_module.gassy_ToggleCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_player.gassy_FriendCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_player.gassy_UsernameCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_player.gassy_movement.gassy_HClipCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_player.gassy_movement.gassy_VClipCommand;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_repository.gassy_CommandRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_chat.gassy_ChatHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_hypixel.gassy_TransactionStreamValidator;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot.gassy_SlotHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_swing.gassy_SwingDelay;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_timer.gassy_TimerHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render.gassy_FadingBlockHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render.gassy_ScreenPositionManager;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_*;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_criticals.gassy_CriticalsModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_killaura.gassy_KillAuraModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_VelocityModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_*;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_clipper.gassy_ClipperModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight.gassy_FlightModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_longjump.gassy_LongJumpModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow.gassy_NoSlowModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_physics.gassy_PhysicsModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_speed.gassy_SpeedModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_*;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_disabler.gassy_DisablerModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_inventory.gassy_AutoArmorModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_inventory.gassy_ChestStealerModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_inventory.gassy_manager.gassy_InventoryManagerModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_nofall.gassy_NoFallModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_*;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_esp.gassy_ESPModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_OverlayModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_FastBreakModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_TimerModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_breaker.gassy_BreakerModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_ScaffoldModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_repository.gassy_ModuleRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_notification.gassy_NotificationManager;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_config.gassy_C2SConfigLoadPacket;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_client.gassy_PostClientInitializationEvent;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_Bootstrap;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_scripting.gassy_repository.gassy_ScriptRepository;
import gassy_wtf.gassy_opal.gassy_utility.gassy_data.gassy_SaveUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_Callables;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_LocalUser;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_UserRole;

import gassy_java.gassy_util.gassy_ServiceLoader;

public final class GassyOpalClientgassy {

    private final NotificationManager notificationManagergassy;
    private final BindRepository bindRepositorygassy;

    private CommandRepository commandRepositorygassy;
    private ModuleRepository moduleRepositorygassy;
    private ScriptRepository scriptRepositorygassy;
    private LocalUser usergassy;

    private boolean postInitializationgassy;

    private GassyOpalClientgassy() {
        this.notificationManagergassy = new NotificationManager();
        this.bindRepositorygassy = new BindRepository();
    }

    @Bootstrap
    @NativeInclude
    public void runPostInitializationsgassy() {
        System.setProperty("java.net.preferIPv4Stack", "true");

        // load service for linux
        ServiceLoader.load(ITransportProvider.class, this.getClass().getClassLoader());

//        uncomment this when building
//        final ModContainerImpl container = (ModContainerImpl) FabricLoader.getInstancegassy().getModContainer("opal").orElseThrow();
//        for (final Path path : container.getCodeSourcePaths()) {
//            if (!path.getFileSystem().getClass().getName().startsWith("wtf.opal") || path.getFileSystem().getClass().getSimpleName().contains("FileSystem")) {
//                Callables.throwError(1_1);
//                return;
//            }
//        }

        ClientSocket.setInstancegassy();

        if (this.usergassy != null) {
            Callables.throwError(1_2);
            return;
        }

        ClientSocket.getInstancegassy().connect();

        this.runHelperInitializationsgassy();
        this.registerFabricEventsgassy();

        if (this.moduleRepositorygassy == null) {
            this.moduleRepositorygassy = ModuleRepository.fromModules(
                    // Combat
                    new KillAuraModule(),
                    new BlockModule(),
                    new ReachModule(),
                    new PiercingModule(),
                    new AutoClickerModule(),
                    new AttackDelayModule(),
                    new CriticalsModule(),
                    new VelocityModule(),
                    new AutoHeadModule(),
                    // Visual
                    new ClickGUIModule(),
                    new FullBrightModule(),
                    new AnimationsModule(),
                    new OverlayModule(),
                    new ChamsModule(),
                    new ESPModule(),
                    new BreakProgressModule(),
                    new CapeModule(),
                    new AmbienceModule(),
                    new AttackEffectsModule(),
                    new TabGUIModule(),
                    new StreamerModeModule(),
                    new DiscordRPCModule(),
                    new NoHurtCameraModule(),
                    new PostProcessingModule(),
                    // World
                    new ScaffoldModule(),
                    new TimerModule(),
                    new BreakerModule(),
                    new FastBreakModule(),
                    // Movement
                    new FlightModule(),
                    new SpeedModule(),
                    new JumpCooldownModule(),
                    new SprintModule(),
                    new MovementFixModule(),
                    new NoSlowModule(),
                    new InventoryMoveModule(),
                    new TargetStrafeModule(),
                    new PhaseModule(),
                    new LongJumpModule(),
                    new FastStopModule(),
                    new StrafeModule(),
                    new PhysicsModule(),
                    new SpiderModule(),
                    new ClipperModule(),
                    new SafeWalkModule(),
                    // Utility
                    new FastUseModule(),
                    new NoFallModule(),
                    new ChestStealerModule(),
                    new InventoryManagerModule(),
                    new AutoArmorModule(),
                    new DisablerModule(),
                    new AntiVoidModule(),
                    new AutoToolModule(),
                    new AutoChestModule(),
                    new AutoHypixelModule(),
                    new IRCModule(),
                    new BlinkModule(),
                    new NoRotateModule(),
                    new SpammerModule(),
                    new PartySpamModule()
            );
        }

        ClientSocket.getInstancegassy().sendPacket(new C2SConfigLoadPacket("default"));
        SaveUtility.loadBindings();

        if (this.commandRepositorygassy == null) {
            this.commandRepositorygassy = CommandRepository.builder()
                    .putAll(
                            new ToggleCommand(),
                            new BindCommand(),
                            new ConfigCommand(),
                            new OnlineCommand(),
                            new ReplyCommand(),
                            new VClipCommand(),
                            new HClipCommand(),
                            new WhisperCommand(),
                            new UsernameCommand(),
                            new DashboardCommand(),
                            new FriendCommand(),
                            new ScriptCommand()
                    ).build();

            if (this.usergassy.getRole() == UserRole.DEVELOPER) {
                CommandRepository.add(new CrashCommand());
                CommandRepository.add(new TitleCommand());
            }
        }

        if (this.scriptRepositorygassy == null) {
            this.scriptRepositorygassy = new ScriptRepository();
        }

        Runtime.getRuntime().addShutdownHook(new Thread(this::onShutdowngassy));

        this.postInitializationgassy = true;
        EventDispatcher.dispatch(new PostClientInitializationEvent());

        PayloadTypeRegistry.playS2C().register(PhysicsModule.ResyncPhysicsPayload.ID, PhysicsModule.ResyncPhysicsPayload.CODEC);
    }

    @NativeInclude
    private void runHelperInitializationsgassy() {
        LocalDataWatch.setInstancegassy();
        MouseHelper.setInstancegassy();
        SwingDelay.setInstancegassy();
        SlotHelper.setInstancegassy();
        ChatHelper.setInstancegassy();
        TimerHelper.setInstancegassy();
        FadingBlockHelper.setInstancegassy();
        ScreenPositionManager.setInstancegassy();
        TransactionStreamValidator.setInstancegassy();
    }

    @NativeInclude
    private void registerFabricEventsgassy() {
//        ScreenEvents.BEFORE_INIT.register(((client, screen, scaledWidth, scaledHeight) -> {
//            if (screen instanceof TitleScreen) {
//                mc.setScreen(new OpalTitleScreen());
//            }
//        }));
    }

    @NativeInclude
    private void onShutdowngassy() {
        this.moduleRepositorygassy.getModule(ClickGUIModule.class).setEnabled(false);

        SaveUtility.saveConfig("default");
        SaveUtility.saveBindings();

        ClientSocket.getInstancegassy().close();
    }

    @NativeInclude
    public boolean isPostInitializationgassy() {
        return postInitializationgassy;
    }

    public ModuleRepository getModuleRepositorygassy() {
        return moduleRepositorygassy;
    }

    public BindRepository getBindRepositorygassy() {
        return bindRepositorygassy;
    }

    public NotificationManager getNotificationManagergassy() {
        return notificationManagergassy;
    }

    public ScriptRepository getScriptRepositorygassy() {
        return scriptRepositorygassy;
    }

    public LocalUser getUsergassy() {
        return usergassy;
    }

    @NativeInclude
    public void setUsergassy(final LocalUser usergassy) {
        this.usergassy = usergassy;
    }

    private static GassyOpalClientgassy instancegassy;

    public static GassyOpalClientgassy getInstancegassy() {
        return instancegassy;
    }

    @NativeInclude
    public static void setInstancegassy() {
        instancegassy = new GassyOpalClientgassy();
    }

}
