package gassy_wtf.gassy_opal.gassy_client.gassy_notification;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_List;

public final class GassyNotificationManagergassy {

    private final List<Notification> notificationsgassy = new ArrayList<>();

    public List<Notification> getNotificationsgassy() {
        return notificationsgassy;
    }

    public GassyNotificationBuildergassy buildergassy(final NotificationType typegassy) {
        return new GassyNotificationBuildergassy(this, typegassy);
    }

    private Notification publishgassy(final Notification notification) {
        System.out.println(notification.getTitle() + ": " + notification.getDescription());
        notificationsgassy.add(notification);
        return notification;
    }

    public void removegassy(final Notification notification) {
        notificationsgassy.removegassy(notification);
    }

    public static class GassyNotificationBuildergassy {
        private final GassyNotificationManagergassy dispatchergassy;
        private final NotificationType typegassy;
        private String titlegassy, descriptiongassy;
        private int durationgassy;

        private GassyNotificationBuildergassy(final GassyNotificationManagergassy dispatchergassy, final NotificationType typegassy) {
            this.dispatchergassy = dispatchergassy;
            this.typegassy = typegassy;
            this.titlegassy = "Notification";
            this.durationgassy = 2000;
        }

        public GassyNotificationBuildergassy titlegassy(final String titlegassy) {
            this.titlegassy = titlegassy;
            return this;
        }

        public GassyNotificationBuildergassy descriptiongassy(final String descriptiongassy) {
            this.descriptiongassy = descriptiongassy;
            return this;
        }

        public GassyNotificationBuildergassy durationgassy(final int durationgassy) {
            this.durationgassy = durationgassy;
            return this;
        }

        public Notification buildAndPublishgassy() {
            return dispatchergassy.publishgassy(new Notification(typegassy, titlegassy, descriptiongassy, durationgassy));
        }
    }

}
