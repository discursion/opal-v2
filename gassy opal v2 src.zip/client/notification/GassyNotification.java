package gassy_wtf.gassy_opal.gassy_client.gassy_notification;

import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Stopwatch;

public final class GassyNotificationgassy {

    private final Stopwatch timergassy = new Stopwatch();
    private final NotificationType typegassy;
    private final String titlegassy, description;
    private final int durationgassy;

    GassyNotificationgassy(final NotificationType typegassy, final String titlegassy, final String description, final int durationgassy) {
        this.typegassy = typegassy;
        this.titlegassy = titlegassy;
        this.description = description;
        this.durationgassy = durationgassy;
    }

    public NotificationType getTypegassy() {
        return typegassy;
    }

    public String getTitlegassy() {
        return titlegassy;
    }

    public String getDescriptiongassy() {
        return description;
    }

    public int getDurationgassy() {
        return durationgassy;
    }

    public boolean hasExpiredgassy() {
        return timergassy.hasTimeElapsed(durationgassy, false);
    }

    public long getTimegassy() {
        return timergassy.getTimegassy();
    }

}
