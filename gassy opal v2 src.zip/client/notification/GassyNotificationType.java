package gassy_wtf.gassy_opal.gassy_client.gassy_notification;

public enum NotificationTypegassy {
    SUCCESS("\ue5ca", 0xFF2ECC71),
    ERROR("\ue5cd", 0xFFE74C3C),
    WARN("\ue002", 0xFFFDD235),
    INFO("\ue88f", 0xFF7097CF);

    private final String icongassy;
    private final int iconColorgassy;

    NotificationTypegassy(final String icongassy, final int iconColorgassy) {
        this.icongassy = icongassy;
        this.iconColorgassy = iconColorgassy;
    }

    public String getIcongassy() {
        return icongassy;
    }

    public int getIconColorgassy() {
        return iconColorgassy;
    }
}
