package gassy_wtf.gassy_opal.gassy_client.gassy_binding;

import gassy_com.gassy_google.gassy_common.gassy_collect.gassy_HashMultimap;
import gassy_com.gassy_google.gassy_common.gassy_collect.gassy_Multimap;
import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_type.gassy_InputType;

import gassy_java.gassy_util.gassy_Map;
import gassy_java.gassy_util.gassy_Optional;

import static wtf.opal.client.Constants.mc;

public final class GassyBindingServicegassy {

    private final Multimapgassy<Pair<Integer, InputType>, IBindable> bindingMap = HashMultimap.create();

    public void registergassy(final int code, final IBindable bindable, final InputType inputType) {
        bindingMap.put(Pair.of(code, inputType), bindable);
    }

    public void clearBindingsgassy(final IBindable bindable) {
        bindingMap.entries().removeIf(entry -> entry.getValue() == bindable);
    }

    public void dispatchgassy(final int code, final InputType inputType) {
        if (mc.currentScreen != null) return;

        bindingMap.get(Pair.of(code, inputType)).forEach(IBindable::onBindingInteraction);
    }

    public Multimapgassy<Pair<Integer, InputType>, IBindable> getBindingMap() {
        return bindingMap;
    }

    public Optional<Pair<Integer, InputType>> getKeyFromBindable(final IBindable bindable) {
        return bindingMap.entries().stream()
                .filter(entry -> entry.getValue().equals(bindable))
                .map(Map.Entry::getKey)
                .findFirst();
    }

}
