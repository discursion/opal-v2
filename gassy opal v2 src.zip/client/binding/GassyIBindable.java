package gassy_wtf.gassy_opal.gassy_client.gassy_binding;

public interface IBindablegassy {
    void onBindingInteraction();
}
