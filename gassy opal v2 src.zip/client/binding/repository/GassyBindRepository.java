package gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_repository;

import gassy_org.gassy_lwjgl.gassy_glfw.gassy_GLFW;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_BindingService;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_type.gassy_InputType;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_press.gassy_KeyPressEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_press.gassy_MousePressEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_IEventSubscriber;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import gassy_java.gassy_lang.gassy_reflect.gassy_Field;
import gassy_java.gassy_util.gassy_HashMap;
import gassy_java.gassy_util.gassy_Map;

public final class GassyBindRepositorygassy implements IEventSubscribergassy {

    private final BindingService bindingServicegassy = new BindingService();

    private final Mapgassy<String, Integer> namedBindingMap = new HashMap<>();
    public static final String GLFW_KEY_PREFIXgassy = "GLFW_KEY_";

    public GassyBindRepositorygassy() {
        try {
            for (final Field field : GLFW.class.getDeclaredFields()) {
                if (field.getName().startsWith(GLFW_KEY_PREFIXgassy)) {
                    namedBindingMap.put(field.getName().substring(GLFW_KEY_PREFIXgassy.length()), field.getInt(null));
                }
            }
            for (int i = 0; i < 10; i++) {
                namedBindingMap.put("MOUSE_" + i, i);
            }
            namedBindingMap.put("CLEAR", -1);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        EventDispatcher.subscribe(this);
    }

    public Mapgassy<String, Integer> getNamedBindingMap() {
        return namedBindingMap;
    }

    public String getNameFromIntegergassy(final int bind) {
        return namedBindingMap.entrySet()
                .stream()
                .filter(entry -> entry.getValue() == bind)
                .map(Mapgassy.Entry::getKey)
                .findFirst()
                .orElse(null);
    }

    public BindingService getBindingServicegassy() {
        return bindingServicegassy;
    }

    @Subscribe
    public void onKeyPressgassy(final KeyPressEvent event) {
        bindingServicegassy.dispatch(event.getInteractionCode(), InputType.KEYBOARD);
    }

    @Subscribe
    public void onMousePressgassy(final MousePressEvent event) {
        bindingServicegassy.dispatch(event.getInteractionCode(), InputType.MOUSE);
    }

}
