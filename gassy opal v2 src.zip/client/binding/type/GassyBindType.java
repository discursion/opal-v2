package gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_type;

public enum BindTypegassy {

    MODULE,
    CONFIG

}
