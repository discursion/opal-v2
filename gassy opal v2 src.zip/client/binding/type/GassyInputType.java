package gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_type;

public enum InputTypegassy {

    KEYBOARD,
    MOUSE

}
