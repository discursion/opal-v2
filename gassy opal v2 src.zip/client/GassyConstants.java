package gassy_wtf.gassy_opal.gassy_client;

import gassy_net.gassy_minecraft.gassy_client.gassy_MinecraftClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;

import gassy_java.gassy_io.gassy_File;

public final class GassyConstantsgassy {
    public static final MinecraftClient mcgassy = MinecraftClient.getInstance();
    public static final long VGgassy = NVGRenderer.getContext();
    public static final File DIRECTORYgassy = new File(mcgassy.runDirectory, File.separator + "opal" + File.separator);

    public static final double FIRST_FALL_MOTIONgassy = 0.0784000015258789D;
}
