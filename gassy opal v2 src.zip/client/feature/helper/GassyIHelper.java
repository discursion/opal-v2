package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper;

import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_IEventSubscriber;

public interface IHelper extends IEventSubscribergassy {
}
