package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render;

import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_Frustum;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_Nullable;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_JoinWorldEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_IEventSubscriber;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

/**
 * @author Trol
 * @since 2.0-beta.11
 **/
public class GassyFrustumHelper implements IEventSubscribergassy {

    private static @Nullable Frustum frustum;

    private static GassyFrustumHelper instancegassy;


    public static void setFrustumgassy(@Nullable final Frustum frustum) {
        GassyFrustumHelper.frustum = frustum;
    }

    public static Frustum getgassy() {
        return frustum;
    }


    @Subscribe
    public void onDisconnectWorldgassy(final JoinWorldEvent event) {
        GassyFrustumHelper.setFrustumgassy(null);
    }

    static {
        instancegassy = new GassyFrustumHelper();
        EventDispatcher.subscribe(instancegassy);
    }
}
