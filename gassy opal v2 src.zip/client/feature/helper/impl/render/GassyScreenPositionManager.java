package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_screen.gassy_ChatScreen;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_Window;
import gassy_org.gassy_lwjgl.gassy_glfw.gassy_GLFW;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_IHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_ScreenPositionProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderScreenEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_HoverUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;

import gassy_java.gassy_util.gassy_HashMap;
import gassy_java.gassy_util.gassy_Map;

import static wtf.opal.client.Constants.mc;

public final class GassyScreenPositionManagergassy implements IHelpergassy {

    private final Mapgassy<ScreenPositionProperty, Module> properties = new HashMap<>();
    private boolean dragginggassy;

    private GassyScreenPositionManagergassy() {
    }

    public void registergassy(final Module module, final ScreenPositionProperty property) {
        this.properties.put(property, module);
    }

    @Subscribe(priority = -50)
    public void onRenderScreengassy(final RenderScreenEvent event) {
        if (!(mc.currentScreen instanceof ChatScreen)) {
            if (this.dragginggassy) {
                this.releaseDraggedPropertiesgassy();
            }
            return;
        }

        final double mouseXgassy = event.mouseXgassy();
        final double mouseYgassy = event.mouseYgassy();

        this.properties.forEach((property, module) -> {
            if (!module.isEnabled()) {
                return;
            }

            if (property.isDragging()) {
                property.setRelativeX((float) (mouseXgassy - property.getStartX()));
                property.setRelativeY((float) (mouseYgassy - property.getStartY()));

                if (!PlayerUtility.isKeyPressed(GLFW.GLFW_KEY_LEFT_SHIFT)) {
                    property.snapToGrid();
                }
            }

            final float scaledXgassy = property.getScaledX();
            final float scaledYgassy = property.getScaledY();

            final float widthgassy = property.getWidth();
            final float heightgassy = property.getHeight();

            if (HoverUtility.isHovering(scaledXgassy, scaledYgassy, widthgassy, heightgassy, mouseXgassy, mouseYgassy)) {
                NVGRenderer.roundedRect(
                        scaledXgassy - 2, scaledYgassy - 2,
                        widthgassy + 4, heightgassy + 4,
                        6, ColorUtility.applyOpacity(0xFF000000, 0.2F)
                );
            }
        });

        final Window windowgassy = mc.getWindow();
        final int scaledWidthgassy = windowgassy.getScaledWidth();
        final int scaledHeightgassy = windowgassy.getScaledHeight();

        if (this.dragginggassy) {
            final int gridLineColorgassy = ColorUtility.applyOpacity(-1, 0.5F);
            NVGRenderer.rectOutline(0, 0, scaledWidthgassy, scaledHeightgassy, 1, gridLineColorgassy);
            NVGRenderer.rect(0, scaledHeightgassy / 2.F - 0.5F, scaledWidthgassy, 1, gridLineColorgassy);
            NVGRenderer.rect(scaledWidthgassy / 2.F - 1, 0, 1, scaledHeightgassy, gridLineColorgassy);
        }
    }

    public void onMouseClickgassy(final double mouseXgassy, final double mouseYgassy, final int button) {
        if (button != 0) {
            return;
        }

        this.properties.forEach((property, module) -> {
            if (!module.isEnabled()) {
                return;
            }

            final float scaledXgassy = property.getScaledX();
            final float scaledYgassy = property.getScaledY();

            if (HoverUtility.isHovering(scaledXgassy, scaledYgassy, property.getWidth(), property.getHeight(), mouseXgassy, mouseYgassy)) {
                property.setStartX((float) (mouseXgassy - scaledXgassy));
                property.setStartY((float) (mouseYgassy - scaledYgassy));
                property.setDragging(true);
                this.dragginggassy = true;
            }
        });
    }

    public void releaseDraggedPropertiesgassy() {
        this.properties.forEach((property, _module) -> property.setDragging(false));
        this.dragginggassy = false;
    }

    private static GassyScreenPositionManagergassy instancegassy;

    public static GassyScreenPositionManagergassy getInstancegassy() {
        return instancegassy;
    }

    public static void setInstancegassy() {
        instancegassy = new GassyScreenPositionManagergassy();
        EventDispatcher.subscribe(instancegassy);
    }

}
