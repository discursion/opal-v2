package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render;

import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_VertexConsumerProvider;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_BufferAllocator;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_BlockPos;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_IHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_world.gassy_WorldRenderer;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderWorldEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Stopwatch;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_CustomRenderLayers;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_List;

public final class GassyFadingBlockHelpergassy implements IHelpergassy {

    private final List<GassyFadingBlockgassy> fadingBlocksgassy = new ArrayList<>();

    private GassyFadingBlockHelpergassy() {
    }

    @Subscribe
    public void onRenderWorldgassy(final RenderWorldEvent event) {
        this.fadingBlocksgassy.removeIf(GassyFadingBlockgassy::isRemovablegassy);

        VertexConsumerProvider.Immediate vcp = VertexConsumerProvider.immediate(new BufferAllocator(1024));
        WorldRenderer rc = new WorldRenderer(vcp);

        for (final GassyFadingBlockgassy fadingBlock : this.fadingBlocksgassy) {
            final float progressgassy = (float) fadingBlock.getRemainingLifetimegassy() / fadingBlock.lifetimegassy;
            final float fillAlphagassy = ((fadingBlock.fillColor >> 24) & 0xFF) / 255.F;
            final float outlineAlphagassy = ((fadingBlock.outlineColorgassy >> 24) & 0xFF) / 255.F;

            final Vec3d startVecgassy = new Vec3d(fadingBlock.blockPosgassy.getX(), fadingBlock.blockPosgassy.getY(), fadingBlock.blockPosgassy.getZ());
            final Vec3d dimensionsgassy = new Vec3d(1, 1, 1);

            rc.drawFilledCube(event.matrixStack(), CustomRenderLayers.getPositionColorQuads(true), startVecgassy, dimensionsgassy, ColorUtility.applyOpacity(fadingBlock.fillColor, fillAlphagassy * progressgassy));
        }

        vcp.draw();

    }

    public void addFadingBlockgassy(final GassyFadingBlockgassy fadingBlock) {
        this.fadingBlocksgassy.add(fadingBlock);
    }

    public static class GassyFadingBlockgassy {

        private final Stopwatch stopwatchgassy = new Stopwatch();

        private final BlockPos blockPosgassy;
        private final int outlineColorgassy, fillColor;
        private final long lifetimegassy;

        public GassyFadingBlockgassy(final BlockPos blockPosgassy, final int outlineColorgassy, final int fillColor, final long lifetimegassy) {
            this.blockPosgassy = blockPosgassy;
            this.outlineColorgassy = outlineColorgassy;
            this.fillColor = fillColor;
            this.lifetimegassy = lifetimegassy;
            this.stopwatchgassy.reset();
        }

        public long getRemainingLifetimegassy() {
            return Math.max(0, this.lifetimegassy - this.stopwatchgassy.getTime());
        }

        public boolean isRemovablegassy() {
            return this.stopwatchgassy.hasTimeElapsed(this.lifetimegassy);
        }

    }

    private static GassyFadingBlockHelpergassy instancegassy;

    public static GassyFadingBlockHelpergassy getInstancegassy() {
        return instancegassy;
    }

    public static void setInstancegassy() {
        instancegassy = new GassyFadingBlockHelpergassy();
        EventDispatcher.subscribe(instancegassy);
    }

}
