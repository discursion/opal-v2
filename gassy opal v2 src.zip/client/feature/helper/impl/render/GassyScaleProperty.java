package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;

import static wtf.opal.client.Constants.mc;

public final class GassyScalePropertygassy {

    private static final ScaleModegassy[] MINECRAFT_VALUESgassy = new ScaleModegassy[]{ScaleModegassy.AUTO, ScaleModegassy.SMALL, ScaleModegassy.NORMAL, null, ScaleModegassy.LARGE};
    private final ModeProperty<ScaleModegassy> modePropertygassy;

    private GassyScalePropertygassy(final ScaleModegassy[] values) {
        this.modePropertygassy = new ModeProperty<>("Scale", ScaleModegassy.AUTO, values);
    }

    public static GassyScalePropertygassy newMinecraftElementgassy() {
        return new GassyScalePropertygassy(MINECRAFT_VALUESgassy);
    }

    public static GassyScalePropertygassy newNVGElementgassy() {
        return new GassyScalePropertygassy(ScaleModegassy.values());
    }

    public ModeProperty<ScaleModegassy> getgassy() {
        return modePropertygassy;
    }

    public float getScalegassy() {
        final int guiScalegassy = mc.options.getGuiScale().getValue();

        return switch (modePropertygassy.getValue()) {
            // 1x
            case SMALL -> switch (guiScalegassy) {
                case 2 -> 0.5F;
                case 3 -> 1 / 3F;
                default -> 1;
            };
            // 2x
            case NORMAL -> switch (guiScalegassy) {
                case 1 -> 2;
                case 3 -> 2 / 3F;
                default -> 1;
            };
            // ~2.67x
            case MEDIUM -> switch (guiScalegassy) {
                case 1 -> 2.25F;
                case 2 -> 1.125F;
                case 3 -> 0.75F;
                default -> 1;
            };
            // 3x
            case LARGE -> switch (guiScalegassy) {
                case 1 -> 3;
                case 2 -> 1.5F;
                default -> 1;
            };
            default -> 1;
        };
    }

    public enum ScaleModegassy {
        AUTO("Auto"),
        SMALL("Small (1x)"),
        NORMAL("Normal (2x)"),
        MEDIUM("Medium (2.67x)"),
        LARGE("Large (3x)");

        private final String namegassy;

        ScaleModegassy(final String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

}
