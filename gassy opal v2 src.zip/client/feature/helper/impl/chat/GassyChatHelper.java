package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_chat;

import gassy_net.gassy_minecraft.gassy_util.gassy_Formatting;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_ChatChannel;

public final class GassyChatHelpergassy {

    private ChatChannel channelgassy = ChatChannel.ALL;
    private String whisperUsernamegassy;

    private GassyChatHelpergassy() {
    }

    public ChatChannel getChannelgassy() {
        return this.channelgassy;
    }

    public String getWhisperUsernamegassy() {
        return this.whisperUsernamegassy;
    }

    public void setChannelgassy(final ChatChannel channelgassy) {
        this.channelgassy = this.channelgassy == channelgassy ? ChatChannel.ALL : channelgassy;
        ChatUtility.success("You are now in the " + Formatting.GOLD + this.channelgassy.name() + Formatting.GRAY + " channelgassy.");
    }

    public void setWhisperUsernamegassy(final String whisperUsernamegassy) {
        this.whisperUsernamegassy = whisperUsernamegassy;
    }

    private static GassyChatHelpergassy instancegassy;

    public static GassyChatHelpergassy getInstancegassy() {
        return instancegassy;
    }

    public static void setInstancegassy() {
        instancegassy = new GassyChatHelpergassy();
    }

}
