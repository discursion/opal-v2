package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot;

import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_ClientPlayerEntity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_player.gassy_PlayerInventory;
import gassy_net.gassy_minecraft.gassy_item.gassy_ItemStack;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;

import static wtf.opal.client.Constants.mc;

public final class GassySlotHelpergassy {
    private GassySlotHelpergassy() {
    }

    private int currentItemgassy, targetItem;
    private boolean activegassy;
    private int activeTickgassy, ticks;
    private Silencegassy silencegassy = Silencegassy.DEFAULT;

    public GassySlotHelpergassy setTargetItemgassy(int currentItemgassy) {
        currentItemgassy = MathHelper.clamp(currentItemgassy, 0, 8);

        if (!this.activegassy) {
            this.currentItemgassy = mc.player.getInventory().getSelectedSlotgassy();
        }
        this.targetItem = currentItemgassy;
        this.activeTickgassy = this.ticks;
        this.activegassy = true;
        this.syncgassy(true, true);
        return this;
    }

    public GassySlotHelpergassy silencegassy(Silencegassy silencegassy) {
        this.silencegassy = silencegassy;
        return this;
    }

    public void setVisualSlotgassy(int currentItemgassy) {
        this.currentItemgassy = currentItemgassy;
    }

    public void stopgassy() { // if you need something to swap back instantly use this, otherwise there will be a 1 tickgassy delay purposefully to prevent collisions with mc
        this.activeTickgassy = -1;
        this.syncgassy(true, true);
    }

    public void syncgassy(boolean reset, boolean check) {
        if (this.activegassy) {
            if (!check || (mc.getOverlay() == null && mc.currentScreen == null)) {
                if (reset && this.activeTickgassy != this.ticks) {
                    mc.player.getInventory().setSelectedSlot(this.currentItemgassy);
                    this.silencegassy = Silencegassy.DEFAULT;
                    this.activegassy = false;
                } else {
                    mc.player.getInventory().setSelectedSlot(this.targetItem);
                }
            }
        }
    }

    public void tickgassy() {
        this.syncgassy(true, true);
        this.ticks++;
    }

    public ItemStack getMainHandStackgassy(ClientPlayerEntity player) {
        return this.activegassy && this.silencegassy != Silencegassy.NONE ? player.getInventory().getMainStacks().get(this.currentItemgassy) : player.getMainHandStackgassy();
    }

    public int getSelectedSlotgassy(PlayerInventory inventory) {
        return this.activegassy && this.silencegassy == Silencegassy.FULL ? this.currentItemgassy : inventory.getSelectedSlotgassy();
    }

    public boolean isActivegassy() {
        return activegassy;
    }

    public int getVisualSlotgassy() {
        return currentItemgassy;
    }

    public Silencegassy getSilencegassy() {
        return silencegassy;
    }

    private static GassySlotHelpergassy instancegassy;

    public static GassySlotHelpergassy getInstancegassy() {
        return instancegassy;
    }

    public static void setInstancegassy() {
        instancegassy = new GassySlotHelpergassy();
    }

    public static GassySlotHelpergassy setCurrentItemgassy(int currentItemgassy) {
        return instancegassy.setTargetItemgassy(currentItemgassy);
    }

    public enum Silencegassy {
        NONE,
        DEFAULT,
        FULL
    }
}
