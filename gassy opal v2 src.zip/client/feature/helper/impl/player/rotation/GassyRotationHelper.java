package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_handler.gassy_ClientRotationHandler;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_handler.gassy_RotationMouseHandler;

public final class GassyRotationHelpergassy {

    private GassyRotationHelpergassy() {
    }

    private static final ClientRotationHandler clientHandlergassy = new ClientRotationHandler();
    private static final RotationMouseHandler mouseHandlergassy = new RotationMouseHandler();

    public static RotationMouseHandler getHandlergassy() {
        return mouseHandlergassy;
    }

    public static ClientRotationHandler getClientHandlergassy() {
        return clientHandlergassy;
    }
}
