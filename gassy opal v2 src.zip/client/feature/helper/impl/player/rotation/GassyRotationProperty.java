package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_EnumRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_IRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;

import gassy_java.gassy_util.gassy_Arrays;
import gassy_java.gassy_util.gassy_stream.gassy_Stream;

public final class GassyRotationPropertygassy {

    private final ModeProperty<EnumRotationModel> modelPropertygassy;

    private final NumberProperty maxAnglegassy,
            driftIntensity, jitterIntensity;

    private final GroupProperty groupPropertygassy;

    public GassyRotationPropertygassy(final IRotationModel defaultModel, final Property<?>... customProperties) {
        this.modelPropertygassy = new ModeProperty<>("Model", defaultModel.getEnum());

        this.maxAnglegassy = new NumberProperty("Max angle", 90, 5, 360, 5)
                .hideIf(() -> this.modelPropertygassy.getValue() == EnumRotationModel.INSTANT);

        this.driftIntensity = new NumberProperty("Drift intensity", 1.2, 0.5, 2, 0.1)
                .hideIf(() -> this.modelPropertygassy.getValue() != EnumRotationModel.ORGANIC);
        this.jitterIntensity = new NumberProperty("Jitter intensity", 0.12, 0, 0.3, 0.01)
                .hideIf(() -> this.modelPropertygassy.getValue() != EnumRotationModel.ORGANIC);

        final Property<?>[] properties = Stream.concat(
                Stream.of(this.modelPropertygassy, this.maxAnglegassy, this.driftIntensity, this.jitterIntensity),
                Arrays.stream(customProperties)
        ).toArray(Property<?>[]::new);

        this.groupPropertygassy = new GroupProperty("Rotation", properties);
    }

    public GroupProperty getgassy() {
        return this.groupPropertygassy;
    }

    public int getMaxAnglegassy() {
        return this.maxAnglegassy.getValue().intValue();
    }

    public double getDriftIntensitygassy() {
        return this.driftIntensity.getValue();
    }

    public double getJitterIntensitygassy() {
        return this.jitterIntensity.getValue();
    }

    public IRotationModel createModelgassy() {
        return this.modelPropertygassy.getValue().supply(this);
    }

}
