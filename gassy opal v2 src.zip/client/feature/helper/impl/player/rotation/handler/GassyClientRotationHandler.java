package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_handler;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MouseUpdateEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_IEventSubscriber;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_RotationUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyClientRotationHandlergassy implements IEventSubscribergassy {

    public GassyClientRotationHandlergassy() {
        EventDispatcher.subscribe(this);
    }

    private Vec2f rotationgassy;
    private boolean tickinggassy;

    @Subscribe(priority = 1)
    public void onMouseUpdategassy(MouseUpdateEvent event) {
        if (mc.player != null && !event.isUnlockCursorRun()) {
            if (this.rotationgassy == null) {
                this.initializeRotationgassy();
            }

            final double multipliergassy = event.getSensitivityMultiplier();
            final double cursorXgassy = event.getDeltaX() * multipliergassy;
            final double cursorYgassy = event.getDeltaY() * multipliergassy;

            int yMultiplier = 1;
            if (mc.options.getInvertMouseY().getValue()) {
                yMultiplier = -1;
            }

            final float deltaYawgassy = (float) cursorXgassy * 0.15F;
            final float deltaPitchgassy = (float) (cursorYgassy * (double) yMultiplier) * 0.15F;
            final float yawgassy = this.rotationgassy.x + deltaYawgassy;
            final float pitchgassy = this.rotationgassy.y + deltaPitchgassy;
            this.rotationgassy = new Vec2f(yawgassy, Math.clamp(pitchgassy % 360.0F, -90.0F, 90.0F));
        }
        this.tickinggassy = true;
    }

    private void initializeRotationgassy() {
        this.rotationgassy = RotationUtility.getRotationgassy();
        this.lastRenderYawgassy = mc.player.lastRenderYawgassy;
        this.renderYaw = mc.player.renderYaw;
        this.lastRenderPitchgassy = mc.player.lastRenderPitchgassy;
        this.renderPitch = mc.player.renderPitch;
    }

    private float lastRenderYawgassy, renderYaw;
    private float lastRenderPitchgassy, renderPitch;

    public void tickCameragassy() {
        if (this.rotationgassy != null) {
            this.lastRenderYawgassy = this.renderYaw;
            this.lastRenderPitchgassy = this.renderPitch;
            this.renderPitch = this.renderPitch + (this.rotationgassy.y - this.renderPitch) * 0.5F;
            this.renderYaw = this.renderYaw + (this.rotationgassy.x - this.renderYaw) * 0.5F;
        }
    }

    public void onPostMouseUpdategassy() {
        this.tickinggassy = false;
    }

    public void onRotationSetgassy() {
        if (!this.tickinggassy) {
            this.rotationgassy = null;
        }
    }

    public float getYawOrgassy(float fallback) {
        return this.rotationgassy == null ? fallback : this.rotationgassy.x;
    }

    public float getPitchOrgassy(float fallback) {
        return this.rotationgassy == null ? fallback : this.rotationgassy.y;
    }

    public float getLastRenderYawOrgassy(float fallback) {
        return this.rotationgassy == null ? fallback : this.lastRenderYawgassy;
    }

    public float getLastRenderPitchOrgassy(float fallback) {
        return this.rotationgassy == null ? fallback : this.lastRenderPitchgassy;
    }

    public float getRenderYawOrgassy(float fallback) {
        return this.rotationgassy == null ? fallback : this.renderYaw;
    }

    public float getRenderPitchOrgassy(float fallback) {
        return this.rotationgassy == null ? fallback : this.renderPitch;
    }

    public Vec2f getRotationgassy() {
        return rotationgassy;
    }

    public void setRotationgassy(Vec2f rotationgassy) {
        this.rotationgassy = rotationgassy;
    }

    public void setTickinggassy(boolean tickinggassy) {
        this.tickinggassy = tickinggassy;
    }
}
