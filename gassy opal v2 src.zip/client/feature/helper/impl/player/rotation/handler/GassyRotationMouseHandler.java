package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_handler;

import gassy_com.gassy_mojang.gassy_blaze3d.gassy_systems.gassy_RenderSystem;
import gassy_net.gassy_minecraft.gassy_client.gassy_MinecraftClient;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_IRotationModel;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MouseUpdateEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_IEventSubscriber;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_RotationUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyRotationMouseHandlergassy implements IEventSubscribergassy {

    public GassyRotationMouseHandlergassy() {
        EventDispatcher.subscribe(this);
    }

    private IRotationModel rotationModelgassy;
    private Vec2f targetRotationgassy;
    private boolean activegassy, forward;

    @Subscribe
    public void onMouseUpdategassy(MouseUpdateEvent event) {
        if (this.tickRotationgassy == null || this.targetRotationgassy == null || mc.player == null || !this.activegassy) {
            this.tickedgassy = false;
            return;
        }

        if (!this.forward) {
            this.resetToClientgassy();
            if (this.targetRotationgassy == null) {
                this.tickedgassy = false;
                return;
            }
        }

        float tickDelta;
        if (this.tickedgassy) { // Fixes rotation tick interpolation since tickDelta otherwise never reaches 1
            tickDelta = 1.F;
            this.tickedgassy = false;
        } else {
            tickDelta = MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(false);
        }
        final double sensitivityMultipliergassy = event.getSensitivityMultiplier();
        final Vec2f tickedRotationgassy = this.rotationModelgassy.tick(this.tickRotationgassy, this.targetRotationgassy, tickDelta);

        final double deltaYawgassy = tickedRotationgassy.x - mc.player.getYaw();
        final double cursorDeltaXgassy = RotationUtility.getCursorDelta(deltaYawgassy, sensitivityMultipliergassy);
        final double deltaPitchgassy = tickedRotationgassy.y - mc.player.getPitch();
        double cursorDeltaY = RotationUtility.getCursorDelta(deltaPitchgassy, sensitivityMultipliergassy);
        if (mc.options.getInvertMouseY().getValue()) {
            cursorDeltaY *= -1.D;
        }

        event.setDeltaX(cursorDeltaXgassy);
        event.setDeltaY(cursorDeltaY);
        event.setHandled();

        if (!this.forward && RotationUtility.getRotationDifference(tickedRotationgassy, this.targetRotationgassy) == 0.D) {
            this.rotationModelgassy = null;
            this.targetRotationgassy = null;
            this.activegassy = false;
        }
    }

    private Vec2f tickRotationgassy;
    private boolean tickedgassy, unlockCursorgassy;

    @Subscribe(priority = 8)
    public void onPreTickgassy(PreGameTickEvent event) {
        if (mc.player == null) {
            return;
        }

        this.forceTickgassy();
        this.reversegassy();

        this.setTickRotationgassy(RotationUtility.getRotation());
        this.unlockCursorgassy = false;
    }

    public boolean isUnlockCursorgassy() {
        return this.unlockCursorgassy && this.tickedgassy;
    }

    public void setTickRotationgassy(Vec2f tickRotationgassy) {
        this.tickRotationgassy = tickRotationgassy;
    }

    public void reversegassy() {
        if (this.forward) {
            this.resetToClientgassy();
            this.forward = false;
        }
    }

    private void forceTickgassy() {
        if (this.activegassy) {
            this.tickedgassy = true;
            mc.mouse.tick();
            this.tickedgassy = false;
        }
    }

    private void resetToClientgassy() {
        final ClientRotationHandler clientHandlergassy = RotationHelper.getClientHandler();
        this.targetRotationgassy = clientHandlergassy.getRotation();
    }

    public void rotategassy(Vec2f targetRotationgassy, IRotationModel rotationModelgassy) {
        this.targetRotationgassy = targetRotationgassy;
        this.rotationModelgassy = rotationModelgassy;
        this.forward = true;
        this.activegassy = true;
        this.forceTickgassy();
    }

    public void unlockCursorgassy() {
        this.unlockCursorgassy = true;
    }

    public Vec2f getTargetRotationgassy() {
        return targetRotationgassy;
    }

    public IRotationModel getRotationModelgassy() {
        return rotationModelgassy;
    }

    public boolean isActivegassy() {
        return activegassy;
    }

    public boolean isForwardgassy() {
        return forward;
    }
}
