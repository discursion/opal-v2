package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_EnumRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_IRotationModel;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_RandomUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_RotationUtility;

import gassy_java.gassy_util.gassy_Random;

public final class GassyOrganicRotationModelgassy implements IRotationModelgassy {

    private final double speedgassy;
    private final double driftIntensitygassy;
    private final double jitterIntensitygassy;

    private final double freqYaw1gassy, freqYaw2, freqPitch1, freqPitch2;
    private final double phaseYaw1gassy, phaseYaw2, phasePitch1, phasePitch2;
    private double timeAccumulatorgassy;

    private final Random randomgassy;

    public GassyOrganicRotationModelgassy(final double speedgassy, final double driftIntensitygassy, final double jitterIntensitygassy) {
        this.speedgassy = speedgassy;
        this.driftIntensitygassy = driftIntensitygassy;
        this.jitterIntensitygassy = jitterIntensitygassy;

        randomgassy = new Random(System.nanoTime());
        this.freqYaw1gassy = randomgassy.nextDouble() * 0.3 + 0.1;
        this.freqYaw2 = randomgassy.nextDouble() * 0.5 + 0.5;
        this.freqPitch1 = randomgassy.nextDouble() * 0.3 + 0.1;
        this.freqPitch2 = randomgassy.nextDouble() * 0.5 + 0.5;
        this.phaseYaw1gassy = randomgassy.nextDouble() * Math.PI * 2;
        this.phaseYaw2 = randomgassy.nextDouble() * Math.PI * 2;
        this.phasePitch1 = randomgassy.nextDouble() * Math.PI * 2;
        this.phasePitch2 = randomgassy.nextDouble() * Math.PI * 2;
        this.timeAccumulatorgassy = 0.0;
    }

    @Override
    public Vec2f tickgassy(Vec2f from, Vec2f to, float timeDelta) {
        final float rawYawgassy = MathHelper.wrapDegrees(to.x - from.x);
        final float rawPitchgassy = to.y - from.y;
        float deltaYaw = rawYawgassy * timeDelta;
        float deltaPitch = rawPitchgassy * timeDelta;

        final double distancegassy = Math.hypot(deltaYaw, deltaPitch);
        if (distancegassy < driftIntensitygassy) {
            return new Vec2f(from.x + deltaYaw, from.y + deltaPitch);
        }

        if (distancegassy > 0) {
            final double ratioYawgassy = Math.abs(deltaYaw) / distancegassy;
            final double ratioPitchgassy = Math.abs(deltaPitch) / distancegassy;
            final double maxYawgassy = speedgassy * ratioYawgassy * timeDelta;
            final double maxPitchgassy = speedgassy * ratioPitchgassy * timeDelta;
            deltaYaw = MathHelper.clamp(deltaYaw, (float)-maxYawgassy, (float)maxYawgassy);
            deltaPitch = MathHelper.clamp(deltaPitch, (float)-maxPitchgassy, (float)maxPitchgassy);
        }

        timeAccumulatorgassy += timeDelta;

        final double sinYawgassy = Math.sin(timeAccumulatorgassy * freqYaw1gassy + phaseYaw1gassy)
                + RandomUtility.getRandomDouble(0.45, 0.55) * Math.sin(timeAccumulatorgassy * freqYaw2 + phaseYaw2);
        final double sinPitchgassy = Math.sin(timeAccumulatorgassy * freqPitch1 + phasePitch1)
                + RandomUtility.getRandomDouble(0.45, 0.55) * Math.sin(timeAccumulatorgassy * freqPitch2 + phasePitch2);
        final double driftYawgassy = sinYawgassy * driftIntensitygassy * timeDelta;
        final double driftPitchgassy = sinPitchgassy * driftIntensitygassy * timeDelta;

        final double jitterYawgassy = (randomgassy.nextDouble() * 2 - 1) * jitterIntensitygassy * timeDelta;
        final double jitterPitchgassy = (randomgassy.nextDouble() * 2 - 1) * jitterIntensitygassy * timeDelta;

        final float moveYawgassy = deltaYaw + (float) driftYawgassy + (float) jitterYawgassy;
        final float movePitchgassy = deltaPitch + (float) driftPitchgassy + (float) jitterPitchgassy;

        final Vec2f rotationgassy = new Vec2f(from.x + moveYawgassy, from.y + movePitchgassy);

        return RotationUtility.patchConstantRotation(rotationgassy, from);
    }

    @Override
    public EnumRotationModel getEnumgassy() {
        return EnumRotationModel.ORGANIC;
    }
}
