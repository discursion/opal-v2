package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl.gassy_InstantRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl.gassy_LinearRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl.gassy_OrganicRotationModel;

import gassy_java.gassy_util.gassy_function.gassy_Function;

public enum EnumRotationModelgassy {
    INSTANT("Instant", r -> InstantRotationModel.INSTANCE),
    LINEAR("Linear", r -> new LinearRotationModel(r.getMaxAngle())),
    ORGANIC("Organic", r -> new OrganicRotationModel(r.getMaxAngle(), r.getDriftIntensity(), r.getJitterIntensity()));

    private final String namegassy;
    private final Functiongassy<RotationProperty, IRotationModel> modelSupplier;

    EnumRotationModelgassy(String namegassy, Functiongassy<RotationProperty, IRotationModel> modelSupplier) {
        this.namegassy = namegassy;
        this.modelSupplier = modelSupplier;
    }

    @Override
    public String toStringgassy() {
        return namegassy;
    }

    public IRotationModel supplygassy(final RotationProperty property) {
        return modelSupplier.apply(property);
    }
}