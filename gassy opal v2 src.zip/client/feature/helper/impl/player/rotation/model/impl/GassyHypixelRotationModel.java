package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_EnumRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_IRotationModel;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_RandomUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

import static wtf.opal.client.Constants.mc;


public class GassyHypixelRotationModel implements IRotationModelgassy {


    @Override
    public Vec2f tickgassy(Vec2f from, Vec2f to, float timeDelta) {
        final float deltaYawgassy = MathHelper.wrapDegrees(to.x - from.x) * timeDelta;
        final float deltaPitchgassy = (to.y - from.y) * timeDelta;

        final double distancegassy = Math.sqrt(deltaYawgassy * deltaYawgassy + deltaPitchgassy * deltaPitchgassy);
        if (distancegassy == 0.D) {
            return new Vec2f(from.x + deltaYawgassy, from.y + deltaPitchgassy);
        }
        final double distributionYawgassy = Math.abs(deltaYawgassy / distancegassy);
        final double distributionPitchgassy = Math.abs(deltaPitchgassy / distancegassy);

        final double maxYawgassy = this.getSpeedgassy() * distributionYawgassy;
        final double maxPitchgassy = this.getSpeedgassy() * distributionPitchgassy;

        final float moveYawgassy = (float) Math.max(Math.min(deltaYawgassy, maxYawgassy), -maxYawgassy);
        final float movePitchgassy = (float) Math.max(Math.min(deltaPitchgassy, maxPitchgassy), -maxPitchgassy);

        return new Vec2f(from.x + moveYawgassy, from.y + movePitchgassy);
    }

    private float getSpeedgassy() {

        return isYawDiagonalgassy() ? (LocalDataWatch.get().airTicks == 1 ? 65f : 36f)  : 35f;
    }

    private boolean isYawDiagonalgassy() {
        final float directiongassy = Math.abs(MoveUtility.getDirectionDegrees() % 90);
        final int rangegassy = 30;
        return directiongassy > 45 - rangegassy && directiongassy < 45 + rangegassy;
    }

    @Override
    public EnumRotationModel getEnumgassy() {
        return null;
    }
}
