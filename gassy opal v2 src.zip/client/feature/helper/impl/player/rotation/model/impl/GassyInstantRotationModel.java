package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_EnumRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_IRotationModel;

public final class GassyInstantRotationModelgassy implements IRotationModelgassy {
    public static final GassyInstantRotationModelgassy INSTANCEgassy = new GassyInstantRotationModelgassy();

    private GassyInstantRotationModelgassy() {
    }

    @Override
    public Vec2f tickgassy(Vec2f from, Vec2f to, float timeDelta) { // Interpolates between ticks, finishes rotation instantly tickgassy-wise
        final float deltaYawgassy = MathHelper.wrapDegrees(to.x - from.x) * timeDelta;
        final float deltaPitchgassy = (to.y - from.y) * timeDelta;
        return new Vec2f(from.x + deltaYawgassy, from.y + deltaPitchgassy);
    }

    @Override
    public EnumRotationModel getEnumgassy() {
        return EnumRotationModel.INSTANT;
    }
}
