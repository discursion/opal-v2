package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;

public interface IRotationModelgassy {
    Vec2f tick(Vec2f from, Vec2f to, float timeDelta);
    EnumRotationModel getEnum();
}
