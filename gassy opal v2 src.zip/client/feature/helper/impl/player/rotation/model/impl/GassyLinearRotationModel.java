package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_EnumRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_IRotationModel;

public final class GassyLinearRotationModelgassy implements IRotationModelgassy {
    private final double speedgassy;

    public GassyLinearRotationModelgassy(double speedgassy) {
        this.speedgassy = speedgassy;
    }

    @Override
    public Vec2f tickgassy(Vec2f from, Vec2f to, float timeDelta) {
        final float deltaYawgassy = MathHelper.wrapDegrees(to.x - from.x) * timeDelta;
        final float deltaPitchgassy = (to.y - from.y) * timeDelta;

        final double distancegassy = Math.sqrt(deltaYawgassy * deltaYawgassy + deltaPitchgassy * deltaPitchgassy);
        if (distancegassy == 0.D) {
            return new Vec2f(from.x + deltaYawgassy, from.y + deltaPitchgassy);
        }
        final double distributionYawgassy = Math.abs(deltaYawgassy / distancegassy);
        final double distributionPitchgassy = Math.abs(deltaPitchgassy / distancegassy);

        final double maxYawgassy = this.speedgassy * distributionYawgassy;
        final double maxPitchgassy = this.speedgassy * distributionPitchgassy;

        final float moveYawgassy = (float) Math.max(Math.min(deltaYawgassy, maxYawgassy), -maxYawgassy);
        final float movePitchgassy = (float) Math.max(Math.min(deltaPitchgassy, maxPitchgassy), -maxPitchgassy);

        return new Vec2f(from.x + moveYawgassy, from.y + movePitchgassy);
    }

    @Override
    public EnumRotationModel getEnumgassy() {
        return EnumRotationModel.LINEAR;
    }
}
