package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_hypixel;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_common.gassy_CommonPongC2SPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_IHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_JoinWorldEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_SendPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

public final class GassyTransactionStreamValidator implements IHelpergassy { // should be removed in releases

    private Integer lastTransactionIdgassy;

    @Subscribe
    public void onSendPacketgassy(final SendPacketEvent event) {
        if (event.getPacket() instanceof CommonPongC2SPacket packet) {
            if (packet.getParameter() == 0) return;
            if (this.lastTransactionIdgassy != null && packet.getParameter() != this.lastTransactionIdgassy - 1) {
//                ChatUtility.error("Invalid transaction id: " + packet.getParameter() + " prev: " + this.lastTransactionIdgassy);
                System.out.println("Invalid transaction id: " + packet.getParameter() + " prev: " + this.lastTransactionIdgassy);
            }
            this.lastTransactionIdgassy = packet.getParameter();
        }
    }

    @Subscribe
    public void onJoinWorldgassy(final JoinWorldEvent event) {
        this.lastTransactionIdgassy = null;
    }

    @Override
    public boolean isHandlingEventsgassy() {
        return LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer;
    }

    private static GassyTransactionStreamValidator instancegassy;

    public static void setInstancegassy() {
        instancegassy = new GassyTransactionStreamValidator();
        EventDispatcher.subscribe(instancegassy);
    }
}
