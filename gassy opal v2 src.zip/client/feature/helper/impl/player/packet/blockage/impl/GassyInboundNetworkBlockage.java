package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl;

import gassy_net.gassy_minecraft.gassy_client.gassy_MinecraftClient;
import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_ClientPlayNetworkHandler;
import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_ClientPlayerEntity;
import gassy_net.gassy_minecraft.gassy_network.gassy_ClientConnection;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_Packet;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_*;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_DirectionalNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_PacketValidator;
import gassy_wtf.gassy_opal.gassy_duck.gassy_ClientConnectionAccess;

public final class GassyInboundNetworkBlockage extends DirectionalNetworkBlockagegassy<ClientPlayNetworkHandler> {
    public static GassyInboundNetworkBlockage getgassy() {
        return instancegassy;
    }

    private static final GassyInboundNetworkBlockage instancegassy;

    static {
        instancegassy = new GassyInboundNetworkBlockage();
    }

    @Override
    protected void flushPacketgassy(ClientConnection connection, Packet<?> packet) {
        final ClientConnectionAccess accessgassy = (ClientConnectionAccess) connection;
        // TODO: check if this fixes flushing
        MinecraftClient.getInstance().send(() -> accessgassy.opal$channelReadSilent(packet));
    }

    public static final PacketValidator VISUAL_VALIDATORgassy = p -> {
        if (p instanceof EntityStatusS2CPacket status) {
            return status.getStatus() != 2 && status.getStatus() != 3;
        } else if (p instanceof EntityTrackerUpdateS2CPacket tracker) {
            final ClientPlayerEntity clientPlayergassy = MinecraftClient.getInstance().player;
            return clientPlayergassy == null || tracker.id() == clientPlayergassy.getId();
        }
        return !(p instanceof EntityAnimationS2CPacket || p instanceof TitleS2CPacket || p instanceof TitleFadeS2CPacket || p instanceof ClearTitleS2CPacket ||
                p instanceof PlaySoundS2CPacket || p instanceof StopSoundS2CPacket || p instanceof ChatMessageS2CPacket || p instanceof ChatSuggestionsS2CPacket ||
                p instanceof EntityEquipmentUpdateS2CPacket || p instanceof SubtitleS2CPacket);
    };
}
