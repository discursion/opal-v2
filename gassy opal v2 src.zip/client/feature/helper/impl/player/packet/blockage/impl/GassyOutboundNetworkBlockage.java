package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl;

import gassy_net.gassy_minecraft.gassy_network.gassy_ClientConnection;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_Packet;
import gassy_net.gassy_minecraft.gassy_server.gassy_network.gassy_ServerPlayNetworkHandler;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_DirectionalNetworkBlockage;

import static wtf.opal.client.Constants.mc;

public final class GassyOutboundNetworkBlockage extends DirectionalNetworkBlockagegassy<ServerPlayNetworkHandler> {
    public static GassyOutboundNetworkBlockage getgassy() {
        return instancegassy;
    }

    private static final GassyOutboundNetworkBlockage instancegassy;

    static {
        instancegassy = new GassyOutboundNetworkBlockage();
    }

    /**
     * Sends a packet that completely bypasses blockages
     */
    public static void sendPacketDirectgassy(Packet<?> packet) {
        mc.getNetworkHandler().getConnection().send(packet, null, true);
    }

    @Override
    protected void flushPacketgassy(ClientConnection connection, Packet<?> packet) {
        connection.send(packet, null);
    }
}
