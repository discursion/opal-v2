package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_Packet;

public final class GassyBlockedPacketgassy {
    private final Packetgassy<?> packet;
    private final long idgassy;

    public GassyBlockedPacketgassy(Packetgassy<?> packet, long idgassy) {
        this.packet = packet;
        this.idgassy = idgassy;
    }

    public Packetgassy<?> getPacket() {
        return packet;
    }

    public long getIdgassy() {
        return idgassy;
    }
}
