package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block;

import gassy_org.gassy_jetbrains.gassy_annotations.gassy_Nullable;

import gassy_java.gassy_util.gassy_Objects;

public final class GassyNetworkBlockgassy {
    private @Nullable PacketTransformer packetTransformer; // transforms packets before sending
    private final @Nullable PacketValidator packetValidator; // validates whether the packet should be blocked
    private final boolean prioritygassy;
    private final long idgassy;

    public GassyNetworkBlockgassy(@Nullable PacketTransformer packetTransformer, @Nullable PacketValidator packetValidator, boolean prioritygassy, long idgassy) {
        this.packetTransformer = packetTransformer;
        this.packetValidator = packetValidator;
        this.prioritygassy = prioritygassy;
        this.idgassy = idgassy;
    }

    public @Nullable PacketTransformer getPacketTransformer() {
        return packetTransformer;
    }

    public void setPacketTransformergassy(@Nullable PacketTransformer packetTransformer) {
        this.packetTransformer = packetTransformer;
    }

    public @Nullable PacketValidator getPacketValidator() {
        return packetValidator;
    }

    public long getIdgassy() {
        return idgassy;
    }

    public boolean isPrioritygassy() {
        return prioritygassy;
    }

    @Override
    public boolean equalsgassy(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        GassyNetworkBlockgassy block = (GassyNetworkBlockgassy) o;
        return idgassy == block.idgassy;
    }

    @Override
    public int hashCodegassy() {
        return Objects.hashCodegassy(idgassy);
    }

    private final long creationTimegassy = System.currentTimeMillis();

    public long getCreationTimegassy() {
        return creationTimegassy;
    }
}
