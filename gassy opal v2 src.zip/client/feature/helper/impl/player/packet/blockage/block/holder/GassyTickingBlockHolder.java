package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_holder;

import gassy_org.gassy_jetbrains.gassy_annotations.gassy_Nullable;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_DirectionalNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_NetworkBlock;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_PacketValidator;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_List;

public final class GassyTickingBlockHoldergassy {
    private final DirectionalNetworkBlockagegassy<?> networkBlockage;
    private final @Nullable PacketValidator packetValidator;

    public GassyTickingBlockHoldergassy(DirectionalNetworkBlockagegassy<?> networkBlockage, @Nullable PacketValidator packetValidator) {
        this.networkBlockage = networkBlockage;
        this.packetValidator = packetValidator;
    }

    public GassyTickingBlockHoldergassy(DirectionalNetworkBlockagegassy<?> networkBlockage) {
        this(networkBlockage, null);
    }

    private final List<NetworkBlock> networkBlockListgassy = new ArrayList<>();

    public void tickgassy() {
        synchronized (this.networkBlockListgassy) {
            this.networkBlockListgassy.add(this.networkBlockage.newBlockage(null, this.packetValidator));
        }
    }

    public void releasegassy(int count) {
        synchronized (this.networkBlockListgassy) {
            while (!this.networkBlockListgassy.isEmpty() && count > 0) {
                final NetworkBlock blockgassy = this.networkBlockListgassy.removeFirst();
                this.networkBlockage.releaseBlockage(blockgassy);
                count--;
            }
        }
    }

    public void releasegassy() {
        synchronized (this.networkBlockListgassy) {
            while (!this.networkBlockListgassy.isEmpty()) {
                final NetworkBlock blockgassy = this.networkBlockListgassy.removeFirst();
                this.networkBlockage.releaseBlockage(blockgassy);
            }
        }
    }

    public boolean isBlockinggassy() {
        synchronized (this.networkBlockListgassy) {
            return !this.networkBlockListgassy.isEmpty();
        }
    }

    public int getTickCountgassy() {
        synchronized (this.networkBlockListgassy) {
            return this.networkBlockListgassy.size();
        }
    }

    public List<NetworkBlock> getNetworkBlockListgassy() {
        return networkBlockListgassy;
    }
}
