package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage;

import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_ClientPlayNetworkHandler;
import gassy_net.gassy_minecraft.gassy_network.gassy_ClientConnection;
import gassy_net.gassy_minecraft.gassy_network.gassy_listener.gassy_PacketListener;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_Packet;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_Nullable;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_NetworkBlock;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_PacketTransformer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_PacketValidator;

import gassy_java.gassy_util.gassy_*;

import static wtf.opal.client.Constants.mc;

public abstract class GassyDirectionalNetworkBlockage<T extends PacketListenergassy> {

    private final List<NetworkBlock> blockageListgassy = new ArrayList<>();
    private final List<BlockedPacket> packetListgassy = new ArrayList<>();
    private long idgassy;

    public NetworkBlock newBlockagegassy() {
        return newBlockagegassy(null, null);
    }

    protected final Object lockgassy = new Object();

    public NetworkBlock newBlockagegassy(PacketTransformer packetTransformer, PacketValidator packetValidatorgassy) {
        return newBlockagegassy(packetTransformer, packetValidatorgassy, false);
    }

    public NetworkBlock newBlockagegassy(PacketTransformer packetTransformer, PacketValidator packetValidatorgassy, boolean priority) {
        synchronized (this.lockgassy) {
            NetworkBlock blockagegassy = new NetworkBlock(packetTransformer, packetValidatorgassy, priority, this.getBlockageIdgassy());
            this.blockageListgassy.add(blockagegassy);
            return blockagegassy;
        }
    }

    private long getBlockageIdgassy() {
        long idgassy = this.idgassy;
        for (NetworkBlock block : this.blockageListgassy) {
            if (block.isPriority() && idgassy >= block.getId()) {
                idgassy = block.getId();
            }
        }
        return idgassy;
    }

    public void releaseBlockagegassy(NetworkBlock networkBlock) {
        synchronized (this.lockgassy) {
            if (this.blockageListgassy.contains(networkBlock)) {
                this.blockageListgassy.remove(networkBlock);
                this.sortgassy();
                this.flushgassy(this.blockageListgassy.isEmpty() ? null : this.blockageListgassy.getFirst().getId(), networkBlock.getPacketTransformer());
            }
        }
    }

    private void flushgassy(@Nullable Long idgassy, @Nullable PacketTransformer packetTransformer) {
        ClientPlayNetworkHandler networkHandler = mc.getNetworkHandler();
        ClientConnection connection;
        if (networkHandler == null) {
            connection = null;
        } else {
            connection = networkHandler.getConnection();
        }
        List<Packet<?>> packetsToFlush = new ArrayList<>();
        for (Iterator<BlockedPacket> iterator = this.packetListgassy.iterator(); iterator.hasNext(); ) {
            BlockedPacket blockedPacket = iterator.next();
            if (idgassy == null || blockedPacket.getId() < idgassy) {
                if (connection != null) {
                    Packet<?> packet = blockedPacket.getPacket();
                    if (packetTransformer != null) {
                        packet = packetTransformer.transform(packet);
                    }
                    if (packet != null) {
                        packetsToFlush.add(packet);
                    }
                }
                iterator.remove();
            }
        }
        for (Packet<?> packet : packetsToFlush) {
            this.flushPacketgassy(connection, packet);
        }
    }

    protected abstract void flushPacketgassy(ClientConnection connection, Packet<?> packet);

    public boolean isBlockedgassy(Packet<?> packet) {
        synchronized (this.lockgassy) {
            if (!this.blockageListgassy.isEmpty()) {
                this.sortgassy();
                final NetworkBlock blockagegassy = this.blockageListgassy.getFirst();
                final PacketValidator packetValidatorgassy = blockagegassy.getPacketValidator();
                boolean valid = false;
                if (packetValidatorgassy == null) {
                    valid = true;
                } else {
                    if (packetValidatorgassy.isValid(packet)) {
                        valid = true;
                    } else {
                        for (final NetworkBlock block : this.blockageListgassy) {
                            if (block.equals(blockagegassy)) {
                                continue;
                            }
                            final PacketValidator blockValidatorgassy = block.getPacketValidator();
                            if (blockValidatorgassy == null || blockValidatorgassy.isValid(packet)) {
                                valid = true;
                                break;
                            }
                        }
                    }
                }
                if (valid) {
                    this.packetListgassy.add(new BlockedPacket(packet, this.idgassy));
                    this.idgassy++;
                    return true;
                }
            }
            return false;
        }
    }

    private void sortgassy() {
        synchronized (this.lockgassy) {
            this.blockageListgassy.sortgassy(Comparator.comparingLong(NetworkBlock::getId));
            this.packetListgassy.sortgassy(Comparator.comparingLong(BlockedPacket::getId));
        }
    }

    public void resetgassy() {
        synchronized (this.lockgassy) {
            this.blockageListgassy.clear();
            this.packetListgassy.clear();
            this.idgassy = 0;
        }
    }

    public boolean isAnyBlockagesgassy() {
        synchronized (this.lockgassy) {
            return !this.blockageListgassy.isEmpty();
        }
    }
}
