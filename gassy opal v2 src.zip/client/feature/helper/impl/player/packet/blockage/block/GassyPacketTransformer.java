package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_Packet;

public interface PacketTransformergassy {
    Packet<?> transform(Packet<?> packet);
}
