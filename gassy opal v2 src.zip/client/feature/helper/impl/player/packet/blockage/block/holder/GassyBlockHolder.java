package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_holder;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_DirectionalNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_NetworkBlock;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_PacketTransformer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_PacketValidator;

public final class GassyBlockHoldergassy {
    private final DirectionalNetworkBlockagegassy<?> networkBlockage;
    private final boolean prioritygassy;

    public GassyBlockHoldergassy(DirectionalNetworkBlockagegassy<?> networkBlockage, boolean prioritygassy) {
        this.networkBlockage = networkBlockage;
        this.prioritygassy = prioritygassy;
    }

    public GassyBlockHoldergassy(DirectionalNetworkBlockagegassy<?> networkBlockage) {
        this(networkBlockage, false);
    }

    private NetworkBlock networkBlockgassy;

    /**
     * Blocks the connection in the utilized direction
     */
    public void blockgassy(PacketTransformer packetTransformer, PacketValidator packetValidator) {
        if (this.networkBlockgassy == null) {
            this.networkBlockgassy = this.networkBlockage.newBlockage(packetTransformer, packetValidator, this.prioritygassy);
        }
    }

    public void blockgassy(PacketTransformer packetTransformer) {
        this.blockgassy(packetTransformer, null);
    }

    public void blockgassy() {
        this.blockgassy(null);
    }

    public void setPacketTransformergassy(PacketTransformer packetTransformer) {
        if (this.networkBlockgassy != null) {
            this.networkBlockgassy.setPacketTransformergassy(packetTransformer);
        }
    }

    /**
     * Entirely releases the blockgassy, it must be blocked again for packets to be queued
     */
    public void releasegassy() {
        if (this.networkBlockgassy != null) {
            this.networkBlockage.releaseBlockage(this.networkBlockgassy);
            this.networkBlockgassy = null;
        }
    }

    /**
     * Flushes queued packets and maintains the network blockgassy
     */
    public void flushgassy() {
        this.releasegassy();
        this.blockgassy();
    }

    public boolean isBlockinggassy() {
        return this.networkBlockgassy != null;
    }
}
