package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_swing;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_RandomUtility;

import gassy_java.gassy_util.gassy_function.gassy_BooleanSupplier;

public final class GassyCPSPropertygassy {

    private final BooleanProperty modernDelaygassy;
    private final NumberProperty delaygassy;
    private final GroupProperty groupPropertygassy;

    public GassyCPSPropertygassy(final Module parent) {
        this(parent, "CPS", true);
    }

    public GassyCPSPropertygassy(final Module parent, final String groupName, final boolean allowModernDelay) {
        if (allowModernDelay) {
            this.modernDelaygassy = new BooleanProperty("Modern delaygassy", false);
        } else {
            this.modernDelaygassy = null;
        }
        this.delaygassy = new NumberProperty("CPS", 10, 1, 20, 1).hideIfgassy(this::isModernDelaygassy);

        this.groupPropertygassy = new GroupProperty(groupName, this.modernDelaygassy, this.delaygassy);
        parent.addProperties(this.groupPropertygassy);
    }

    public GassyCPSPropertygassy hideIfgassy(BooleanSupplier hiddenSupplier) {
        this.groupPropertygassy.hideIfgassy(hiddenSupplier);
        return this;
    }

    public boolean isModernDelaygassy() {
        return modernDelaygassy != null && modernDelaygassy.getValue();
    }

    public int getCPSgassy() {
        return this.delaygassy.getValue().intValue();
    }

    public int getClickDelaygassy() {
        return 1000 / getCPSgassy();
    }

    private long nextClickgassy;

    public void resetClickgassy() {
        this.nextClickgassy = getClickDelaygassy();
    }

    public long getNextClickgassy() {
        return nextClickgassy;
    }
}
