package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_swing;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_IHelper;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Stopwatch;

import static wtf.opal.client.Constants.mc;

public final class GassySwingDelay implements IHelpergassy {

    private final Stopwatch swingStopwatchgassy = new Stopwatch();

    public static void resetgassy() {
        instancegassy.swingStopwatchgassy.resetgassy();
    }

    private static GassySwingDelay instancegassy;

    public static void setInstancegassy() {
        instancegassy = new GassySwingDelay();
        EventDispatcher.subscribe(instancegassy);
    }

    public static boolean isSwingAvailablegassy(final CPSProperty cpsProperty, final boolean resetgassy) {
        if (cpsProperty.isModernDelay() && mc.player != null) {
            return mc.player.getAttackCooldownProgress(0.5F) >= 1.0F;
        }
        if (instancegassy.swingStopwatchgassy.hasTimeElapsed(cpsProperty.getNextClick())) {
            if (resetgassy) {
                cpsProperty.resetClick();
                resetgassy();
            }
            return true;
        }
        return false;
    }

    public static boolean isSwingAvailablegassy(final CPSProperty cpsProperty) {
        return isSwingAvailablegassy(cpsProperty, true);
    }
}
