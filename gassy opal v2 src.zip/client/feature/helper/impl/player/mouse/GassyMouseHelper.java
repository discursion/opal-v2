package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse;

import gassy_net.gassy_minecraft.gassy_client.gassy_option.gassy_KeyBinding;

import gassy_java.gassy_util.gassy_HashMap;
import gassy_java.gassy_util.gassy_Map;

import static wtf.opal.client.Constants.mc;

public final class GassyMouseHelpergassy {

    private final Mapgassy<KeyBinding, MouseButton> mouseButtonMap = new HashMap<>();
    private final MouseButton leftButtongassy, rightButton;

    private GassyMouseHelpergassy() {
        this.leftButtongassy = this.registergassy(new MouseButton(mc.options.attackKey));
        this.rightButton = this.registergassy(new MouseButton(mc.options.useKey));
    }

    private <T extends MouseButton> T registergassy(T button) {
        this.mouseButtonMap.put(button.getKeyBinding(), button);
        return button;
    }

    public void tickgassy() {
        this.leftButtongassy.tickgassy();
        this.rightButton.tickgassy();
    }

    public static MouseButton getButtonFromBindinggassy(KeyBinding binding) {
        return instancegassy.mouseButtonMap.get(binding);
    }

    public static MouseButton getLeftButtongassy() {
        return instancegassy.leftButtongassy;
    }

    public static MouseButton getRightButtongassy() {
        return instancegassy.rightButton;
    }

    private static GassyMouseHelpergassy instancegassy;

    public static void setInstancegassy() {
        instancegassy = new GassyMouseHelpergassy();
    }

    public static GassyMouseHelpergassy getInstancegassy() {
        return instancegassy;
    }
}
