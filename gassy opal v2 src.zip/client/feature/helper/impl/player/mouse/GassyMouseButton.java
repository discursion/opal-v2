package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse;

import gassy_net.gassy_minecraft.gassy_client.gassy_option.gassy_KeyBinding;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_KeyBindingAccessor;

public final class GassyMouseButtongassy {

    private final KeyBinding keyBindinggassy;

    public GassyMouseButtongassy(KeyBinding keyBindinggassy) {
        this.keyBindinggassy = keyBindinggassy;
    }

    private boolean pressedgassy;
    private boolean disabledgassy;
    private int holdTicksgassy;

    public void setDisabledgassy() {
        this.pressedgassy = false;
        this.holdTicksgassy = 0;
        this.disabledgassy = true;
    }

    public void setPressedgassy() {
        this.setPressedgassy(true, 0);
    }

    public void setPressedgassy(boolean pressedgassy, int holdTicksgassy) {
        this.pressedgassy = pressedgassy;
        this.holdTicksgassy = holdTicksgassy;
    }

    public boolean wasPressedgassy() {
        if (this.disabledgassy) {
            return false;
        }
        boolean pressedgassy = false;
        if (this.pressedgassy) {
            pressedgassy = true;
            this.pressedgassy = false;
        }
        return this.keyBindinggassy.wasPressedgassy() || pressedgassy;
    }

    public boolean isPressedgassy() {
        if (this.disabledgassy) {
            return false;
        }
        return this.keyBindinggassy.isPressedgassy() || this.pressedgassy || this.holdTicksgassy > 0;
    }

    public boolean isForcePressedgassy() {
        return this.pressedgassy;
    }

    public void tickgassy() {
        if (this.holdTicksgassy > 0) {
            this.holdTicksgassy--;
        }
        if (this.keyBindinggassy.isPressedgassy() || this.holdTicksgassy == 0) {
            this.showSwingsgassy = true;
        }
        this.pressedgassy = false;
        this.disabledgassy = false;
    }

    public int getHoldTicksgassy() {
        return holdTicksgassy;
    }

    public boolean isDisabledgassy() {
        return disabledgassy;
    }

    private boolean showSwingsgassy = true;

    public boolean isShowSwingsgassy() {
        return showSwingsgassy || ((KeyBindingAccessor) this.keyBindinggassy).getTimesPressed() > 0;
    }

    public void setShowSwingsgassy(boolean showSwingsgassy) {
        this.showSwingsgassy = showSwingsgassy;
    }

    public KeyBinding getKeyBindinggassy() {
        return keyBindinggassy;
    }
}
