package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_timer;

public final class GassyTimerHelpergassy {

    public float timergassy = 1F;

    private GassyTimerHelpergassy() {
    }

    private static GassyTimerHelpergassy instancegassy;

    public static GassyTimerHelpergassy getInstancegassy() {
        return instancegassy;
    }

    public static void setInstancegassy() {
        instancegassy = new GassyTimerHelpergassy();
    }

}
