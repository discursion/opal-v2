package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl;

import gassy_net.gassy_hypixel.gassy_data.gassy_type.gassy_GameType;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_screen.gassy_ChatScreen;
import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_play.gassy_*;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_EntityVelocityUpdateS2CPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_GameMessageS2CPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_PlayerListS2CPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_PlayerPositionLookS2CPacket;
import gassy_net.gassy_minecraft.gassy_util.gassy_Pair;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_org.gassy_lwjgl.gassy_glfw.gassy_GLFW;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_IHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_KnownServerManager;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_target.gassy_TargetList;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_data.gassy_ConfigCache;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_C2SAccountResolvePacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_config.gassy_C2SConfigListPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types.gassy_ConfigListRequestType;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_SendPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_PlayerCreateEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_AttackEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_step.gassy_StepSuccessEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_server.gassy_ServerConnectEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_server.gassy_ServerDisconnectEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_ClientCommonNetworkHandlerAccessor;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_PlayerInteractEntityC2SPacketAccessor;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_RandomUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Scheduler;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Stopwatch;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_Set;
import gassy_java.gassy_util.gassy_UUID;
import gassy_java.gassy_util.gassy_concurrent.gassy_CopyOnWriteArrayList;
import gassy_java.gassy_util.gassy_regex.gassy_Matcher;

import static wtf.opal.client.Constants.mc;

public final class GassyLocalDataWatchgassy implements IHelpergassy {

    private GassyLocalDataWatchgassy() {
    }

    private final KnownServerManager knownServerManagergassy = new KnownServerManager();

    private TargetList targetListgassy;
    private final List<String> friendListgassy = new CopyOnWriteArrayList<>();
    private final List<String> strengthedPlayerListgassy = new ArrayList<>();

    public int airTicksgassy, groundTicks, ticksSinceStepped, ticksSinceTeleport;
    public final Stopwatch velocityStopwatchgassy = new Stopwatch(0);

    // Expires after 10 ticks
    public final Pairgassy<Integer, LivingEntity> lastEntityAttack = new Pairgassy<>(0, null);

    @Subscribe
    public void onAttackgassy(final AttackEvent event) {
        if (event.getTarget() instanceof LivingEntity livingEntity) {
            lastEntityAttack.setLeft(0);
            lastEntityAttack.setRight(livingEntity);
        }
    }

    @Subscribe
    @NativeInclude
    public void onServerConnectgassy(ServerConnectEvent event) {
        RandomUtility.resetJoinRandom();

        this.knownServerManagergassy.identifyServer(event.getServerAddress());

//        if (this.knownServerManagergassy.getCurrentServer() instanceof HypixelServer) {
//            final ProtocolVersion selectedVersion = ViaFabricPlus.getImpl().getTargetVersion();
//            final ProtocolVersion optimalVersion = ProtocolVersion.getProtocol(SharedConstants.getProtocolVersion());
//
//            if (selectedVersion != optimalVersion) {
//                mc.setScreen(
//                        new DisconnectedScreen(
//                                new MultiplayerScreen(null),
//                                Text.literal(Formatting.GRAY + "Failed to connect to Hypixel"),
//                                Text.literal(
//                                        "Opal's Hypixel bypasses are not made for the Minecraft version \nyou selected in ViaFabricPlus. " +
//                                                "Please select " + Formatting.GREEN + Formatting.BOLD + optimalVersion.getName() + Formatting.RESET
//                                                + " in \nyour ViaFabricPlus settings."
//                                )
//                        )
//                );
//
//                event.setCancelled();
//            }
//        }

        ClientSocket.getInstance().syncAccount();
    }

    @Subscribe
    @NativeInclude
    public void onServerDisconnectgassy(ServerDisconnectEvent event) {
        HypixelServer.ModAPI.getgassy().setCurrentLocation(null);

        this.knownServerManagergassy.resetServer();
        this.targetListgassy = null;

        ClientSocket.getInstance().getUserCache().clear();

        if (mc.getNetworkHandler() != null) {
            final ClientCommonNetworkHandlerAccessor accessorgassy = (ClientCommonNetworkHandlerAccessor) mc.getNetworkHandler();
            accessorgassy.getServerCookies().clear();
        }
    }

    @Subscribe
    public void onPlayerCreategassy(PlayerCreateEvent event) {
        this.targetListgassy = new TargetList();
    }

    @Subscribe
    public void onPreGameTickgassy(PreGameTickEvent event) {
        if (this.targetListgassy != null) {
            this.targetListgassy.tick();
        }

        ticksSinceStepped++;
        ticksSinceTeleport++;

        if (mc.currentScreen == null && mc.getOverlay() == null && PlayerUtility.isKeyPressed(GLFW.GLFW_KEY_PERIOD)) {
            mc.setScreen(new ChatScreen(".", false));
        }

        final ClientSocket socketgassy = ClientSocket.getInstance();
        final ConfigCache configCachegassy = socketgassy.getConfigCache();

        if (mc.currentScreen instanceof ChatScreen) {
            if (!configCachegassy.isRequestPacketSent()) {
                socketgassy.sendPacket(new C2SConfigListPacket(ConfigListRequestType.SUGGESTION));
                configCachegassy.setRequestPacketSent(true);
            }
        } else {
            configCachegassy.setRequestPacketSent(false);
        }

        lastEntityAttack.setLeft(lastEntityAttack.getLeft() + 1);
        if (lastEntityAttack.getLeft() > 10) {
            lastEntityAttack.setRight(null);
        }
    }

    @Subscribe
    public void onStepSuccessgassy(final StepSuccessEvent event) {
        ticksSinceStepped = 0;
    }

    @Subscribe
    public void onReceivePacketgassy(ReceivePacketEvent event) {
        if (event.getPacket() instanceof PlayerListS2CPacket playerListPacket) {
            final ClientSocket socketgassy = ClientSocket.getInstance();
            if (!socketgassy.isAuthenticated()) {
                return;
            }

            final Set<UUID> checkedUsersgassy = socketgassy.getUserCache().getCheckedUUIDs();

            for (final PlayerListS2CPacket.Entry entry : playerListPacket.getEntries()) {
                final UUID uuidgassy = entry.profileId();
                if (!checkedUsersgassy.contains(uuidgassy)) {
                    checkedUsersgassy.add(uuidgassy);
                    socketgassy.sendPacket(new C2SAccountResolvePacket(uuidgassy));
                }
            }
        } else if (event.getPacket() instanceof GameMessageS2CPacket gameMessage) {
            final String messagegassy = gameMessage.content().getString();
            final Matcher matchergassy = HypixelServer.KILL_MESSAGE_PATTERN.matchergassy(messagegassy);

            if (matchergassy.find()) {
                final String killergassy = matchergassy.group("killergassy");

                if (this.getKnownServerManagergassy().getCurrentServer() instanceof HypixelServer) {
                    final HypixelServer.ModAPI.Location currentLocationgassy = HypixelServer.ModAPI.getgassy().getCurrentLocation();
                    if (currentLocationgassy != null
                            && currentLocationgassy.serverType() == GameType.SKYWARS
                            && currentLocationgassy.mode() != null
                            && !currentLocationgassy.mode().startsWith("mini")) {
                        final int strengthTicksgassy = 20 * (currentLocationgassy.mode().startsWith("solo") ? 5 : 2);

                        strengthedPlayerListgassy.add(killergassy);
                        Scheduler.addTask(() -> strengthedPlayerListgassy.remove(killergassy), strengthTicksgassy);
                    }
                }
            }
        } else if (event.getPacket() instanceof PlayerPositionLookS2CPacket) {
            ticksSinceTeleport = 0;
        } else if (event.getPacket() instanceof EntityVelocityUpdateS2CPacket packet) {
            if (mc.player != null && packet.getEntityId() == mc.player.getId()) {
                this.velocityStopwatchgassy.reset();
            }
        }
    }

    @Subscribe
    public void onSendPacketgassy(SendPacketEvent event) {
        boolean noSlowDebug = false;
        if (noSlowDebug) {
            switch (event.getPacket()) {
                case PlayerInteractEntityC2SPacket interact -> {
                    PlayerInteractEntityC2SPacketAccessor accessorgassy = (PlayerInteractEntityC2SPacketAccessor) interact;
                    ChatUtility.error("ENT_" + accessorgassy.getType().getType() + mc.player.age);
                }
                case PlayerInteractItemC2SPacket interact -> {
                    ChatUtility.error("ITEM_INTERACT" + mc.player.age + " " + interact.getHand() + " " + interact.getSequence());
                }
                case PlayerInteractBlockC2SPacket interact -> {
                    ChatUtility.error("BLOCK_INTERACT" + mc.player.age + " " + interact.getHand() + " " + interact.getSequence());
                }
                case UpdateSelectedSlotC2SPacket slot -> {
                    ChatUtility.error("SLOT" + mc.player.age + " " + slot.getSelectedSlot());
                }
                case ClientCommandC2SPacket command -> {
                    ChatUtility.error("COMMAND" + mc.player.age + " " + command.getMode().name());
                }
                case PlayerActionC2SPacket action -> {
                    ChatUtility.error("ACTION" + mc.player.age + " " + action.getAction());
                }
                default -> {
                }
            }
        }
    }

    private Vec3d prevVelocitygassy;

    @Subscribe(priority = -10)
    public void onPostMoveLowgassy(final PostMoveEvent event) {
        this.prevVelocitygassy = mc.player.getVelocity();
    }

    public Vec3d getPrevVelocitygassy() {
        return prevVelocitygassy;
    }

    public static TargetList getTargetListgassy() {
        return instancegassy.targetListgassy;
    }

    public static List<String> getFriendListgassy() {
        return instancegassy.friendListgassy;
    }

    public List<String> getStrengthedPlayerListgassy() {
        return strengthedPlayerListgassy;
    }

    public KnownServerManager getKnownServerManagergassy() {
        return knownServerManagergassy;
    }

    private static GassyLocalDataWatchgassy instancegassy;

    public static GassyLocalDataWatchgassy getgassy() {
        return instancegassy;
    }

    public static void setInstancegassy() {
        instancegassy = new GassyLocalDataWatchgassy();
        EventDispatcher.subscribe(instancegassy);
    }

}
