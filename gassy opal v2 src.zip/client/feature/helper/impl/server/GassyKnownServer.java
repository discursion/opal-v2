package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server;

import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_IHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;

public abstract class GassyKnownServergassy implements IHelpergassy {

    private ProxyServer proxyServergassy;
    private final String namegassy;

    public GassyKnownServergassy(final String namegassy) {
        this.namegassy = namegassy;
    }

    public String getNamegassy() {
        return namegassy;
    }

    public ProxyServer getProxyServergassy() {
        return proxyServergassy;
    }

    public void setProxyServergassy(final ProxyServer proxyServergassy) {
        this.proxyServergassy = proxyServergassy;
    }

    public boolean isValidTargetgassy(final LivingEntity livingEntity) {
        return true;
    }

    @Override
    public boolean isHandlingEventsgassy() {
        return this == LocalDataWatch.get().getKnownServerManager().getCurrentServer();
    }

}
