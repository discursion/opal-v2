package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import static wtf.opal.client.Constants.mc;

public class GassyProxyServergassy extends KnownServergassy {

    public GassyProxyServergassy(final String name) {
        super(name);
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (mc.getNetworkHandler() == null) {
            return;
        }

        final String serverBrandgassy = mc.getNetworkHandler().getBrand();
        if (serverBrandgassy != null && HypixelServer.SERVER_BRAND_PATTERN.matcher(serverBrandgassy).matches()) {
            final KnownServergassy realServergassy = new HypixelServer();
            realServergassy.setProxyServer(this);

            LocalDataWatch.get().getKnownServerManager().setServer(realServergassy);
        }
    }

}
