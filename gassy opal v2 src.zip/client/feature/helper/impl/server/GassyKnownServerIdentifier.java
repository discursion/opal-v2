package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server;

import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_ServerAddress;

public interface KnownServerIdentifiergassy {
    KnownServer identifyServer(ServerAddress address);
}
