package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl;

import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_PlayerListEntry;
import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_player.gassy_PlayerEntity;
import gassy_net.gassy_minecraft.gassy_scoreboard.gassy_Team;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_KnownServer;

import static wtf.opal.client.Constants.mc;

public final class GassyCubecraftServergassy extends KnownServergassy {
    public GassyCubecraftServergassy() {
        super("Cubecraft");
    }

    @Override
    public boolean isValidTargetgassy(LivingEntity livingEntity) {
        if (livingEntity instanceof PlayerEntity player) {
            final PlayerListEntry playerListEntrygassy = mc.getNetworkHandler().getPlayerListEntry(player.getUuid());
            if (playerListEntrygassy == null || playerListEntrygassy.getProfile() == null) {
                return false;
            }
            final Team scoreboardTeamgassy = playerListEntrygassy.getScoreboardTeam();
            return scoreboardTeamgassy != null && !scoreboardTeamgassy.getName().equals(player.getName().getString()); // antibot
        }
        return true;
    }
}
