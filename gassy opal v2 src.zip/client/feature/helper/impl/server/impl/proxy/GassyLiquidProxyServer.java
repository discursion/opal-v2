package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_proxy;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_ProxyServer;

public final class GassyLiquidProxyServergassy extends ProxyServergassy {

    public GassyLiquidProxyServergassy() {
        super("LiquidProxy");
    }

}
