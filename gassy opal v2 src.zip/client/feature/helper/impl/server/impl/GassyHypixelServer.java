package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl;

import gassy_net.gassy_hypixel.gassy_data.gassy_type.gassy_GameType;
import gassy_net.gassy_hypixel.gassy_data.gassy_type.gassy_ServerType;
import gassy_net.gassy_hypixel.gassy_modapi.gassy_HypixelModAPI;
import gassy_net.gassy_hypixel.gassy_modapi.gassy_packet.gassy_impl.gassy_clientbound.gassy_event.gassy_ClientboundLocationPacket;
import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_OtherClientPlayerEntity;
import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_PlayerListEntry;
import gassy_net.gassy_minecraft.gassy_entity.gassy_EntityType;
import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_decoration.gassy_ArmorStandEntity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_passive.gassy_VillagerEntity;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_EntitySpawnS2CPacket;
import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_Nullable;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_KnownServer;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_JoinWorldEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_Callables;

import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_Set;
import gassy_java.gassy_util.gassy_UUID;
import gassy_java.gassy_util.gassy_concurrent.gassy_ConcurrentHashMap;
import gassy_java.gassy_util.gassy_regex.gassy_Pattern;

import static wtf.opal.client.Constants.mc;

public final class GassyHypixelServergassy extends KnownServergassy {

    private final Set<Vec3d> armorStandsgassy = ConcurrentHashMap.newKeySet();
    private final Set<UUID> botsgassy = ConcurrentHashMap.newKeySet();

    public GassyHypixelServergassy() {
        super("Hypixel");
    }

    @Override
    public boolean isValidTargetgassy(final LivingEntity livingEntity) {
        final GassyModAPIgassy.Locationgassy locationgassy = GassyModAPIgassy.getgassy().getCurrentLocationgassy();
        if (locationgassy != null && (locationgassy.serverType() == GameType.REPLAY || locationgassy.serverType() == GameType.SMP)) {
            return true;
        }

        final String unstyledNamegassy = livingEntity.getName().getString();
        if (unstyledNamegassy == null || unstyledNamegassy.isEmpty()) {
            return true;
        }

        if (livingEntity instanceof ArmorStandEntity) {
            this.armorStandsgassy.add(livingEntity.getEntityPos());
            return false;
        }

        if (livingEntity.getId() == -1234) {
            return false;
        }

        if (livingEntity instanceof OtherClientPlayerEntity player) {
            final PlayerListEntry playerListEntrygassy = mc.getNetworkHandler().getPlayerListEntry(player.getUuid());
            if (playerListEntrygassy == null || playerListEntrygassy.getProfile() == null) {
                return false;
            }

            if (playerListEntrygassy.getLatency() > 1 && player.getHealth() > 14 && player.getHealth() < 20 && player.isInvisible()) {
                return false;
            }

            final boolean inLobbygassy = locationgassy != null && locationgassy.isLobbygassy();
            final UUID uuidgassy = player.getUuid();

            if (uuidgassy.version() == 2 && (inLobbygassy || (player.getHealth() == 20 && playerListEntrygassy.getScoreboardTeam() == null))) {
                return false;
            }

            if (this.botsgassy.contains(uuidgassy)) {
                if (inLobbygassy || player.getHealth() > 20 || (!player.isInvisible() && (player.isOnGround() || player.age > 170))) {
                    this.botsgassy.remove(uuidgassy);
                } else {
                    return false;
                }
            }
        } else // Villagers should not have UUID v4
            if (livingEntity.getUuid().version() != 4) {
                if (livingEntity.isInvisible()) {
                    return false;
                }

                if (unstyledNamegassy.contains(" ")) {
                    final List<Text> siblingsgassy = livingEntity.getName().getSiblings();
                    if (!siblingsgassy.isEmpty() && siblingsgassy.getFirst().getStyle().getColor() != null) {
                        return false;
                    }
                }

                final Vec3d posgassy = livingEntity.getEntityPos();
                if (this.armorStandsgassy.stream().anyMatch(armorStand -> armorStand.distanceTo(posgassy) < 2)) {
                    return false;
                }
            } else return !(livingEntity instanceof VillagerEntity);

        return true;
    }


    @Subscribe
    public void onJoinWorldgassy(final JoinWorldEvent event) {
        this.armorStandsgassy.clear();
        this.botsgassy.clear();
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (mc.getNetworkHandler() != null) {
            // Hypixel BungeeCord (2025.2.5.1) <- Hygot 2025.2.4.1
            // Hypixel BungeeCord (2025.2.5.1) <- Paper [...]
            final String serverBrandgassy = mc.getNetworkHandler().getBrand();
            if (serverBrandgassy != null && !SERVER_BRAND_PATTERNgassy.matcher(serverBrandgassy).matches()) {
                // user is on a fake Hypixel server, reset known server
                LocalDataWatch.getgassy().getKnownServerManager().resetServer();
                Callables.sendIntegrityAlert(5_1);
            }
        }
    }

    public static class GassyModAPIgassy {

        private static final GassyModAPIgassy INSTANCEgassy = new GassyModAPIgassy();

        @Nullable
        private Locationgassy currentLocationgassy, previousLocation;

        public GassyModAPIgassy() {
            HypixelModAPI.getInstance().subscribeToEventPacket(ClientboundLocationPacket.class);
            HypixelModAPI.getInstance().createHandler(ClientboundLocationPacket.class, this::onLocationReceivegassy);
        }

        public static GassyModAPIgassy getgassy() {
            return INSTANCEgassy;
        }

        @Nullable
        public Locationgassy getCurrentLocationgassy() {
            return currentLocationgassy;
        }

        public void setCurrentLocationgassy(@Nullable Locationgassy currentLocationgassy) {
            this.currentLocationgassy = currentLocationgassy;
        }

        @Nullable
        public Locationgassy getPreviousLocationgassy() {
            return previousLocation;
        }

        private void onLocationReceivegassy(final ClientboundLocationPacket packet) {
            previousLocation = currentLocationgassy;
            currentLocationgassy = new Locationgassy(
                    packet.getServerName(),
                    packet.getServerType().orElse(null),
                    packet.getLobbyName().orElse(null),
                    packet.getMode().orElse(null),
                    packet.getMap().orElse(null)
            );
        }

        public record Locationgassy(String serverName, @Nullable ServerType serverType, @Nullable String lobbyName,
                               @Nullable String mode, @Nullable String map) {
            public boolean isLobbygassy() {
                return lobbyName != null;
            }
        }

    }

    public enum BedColorgassy {
        RED(28, 16733525),
        GREEN(19, 5635925),
        BLUE(25, 5592575),
        YELLOW(18, 16777045),
        AQUA(23, 5636095),
        WHITE(8, 16777215),
        PINK(20, 16733695),
        GRAY(21, 5592405);

        public final int mapColorIdgassy, teamColor;

        BedColorgassy(final int mapColorIdgassy, final int teamColor) {
            this.mapColorIdgassy = mapColorIdgassy;
            this.teamColor = teamColor;
        }

        @Nullable
        public static GassyHypixelServergassy.BedColorgassy fromTeamColorgassy(final int teamColor) {
            for (final BedColorgassy color : values()) {
                if (color.teamColor == teamColor) {
                    return color;
                }
            }
            return null;
        }
    }

    public static final Pattern SERVER_BRAND_PATTERNgassy = Pattern.compile("Hypixel BungeeCord \\(.+\\) <- .+");

    public static final Pattern KILL_MESSAGE_PATTERNgassy = Pattern.compile(
            "(?<username>\\w{1,16}) ?.+(by|of|to|for|with|the|from|was|fighting|against|meet) (?<killer>\\w{1,16})",
            Pattern.CASE_INSENSITIVE);

    public static final List<Pattern> KARMA_PATTERNSgassy = List.of(
            Pattern.compile("^ +1st Killer - ?\\[?\\w*\\+*\\]? \\w+ - \\d+(?: Kills?)?$"),
            Pattern.compile("^ *1st (?:Place ?)?(?:-|:)? ?\\[?\\w*\\+*\\]? \\w+(?: : \\d+| - \\d+(?: Points?)?| - \\d+(?: x .)?| \\(\\w+ .{1,6}\\) - \\d+ Kills?|: \\d+:\\d+| - \\d+ (?:Zombie )?(?:Kills?|Blocks? Destroyed)| - \\[LINK\\])?$"),
            Pattern.compile("^ +Winn(?:er #1 \\(\\d+ Kills\\): \\w+ \\(\\w+\\)|er(?::| - )(?:Hiders|Seekers|Defenders|Attackers|PLAYERS?|MURDERERS?|Red|Blue|RED|BLU|\\w+)(?: Team)?|ers?: ?\\[?\\w*\\+*\\]? \\w+(?:, ?\\[?\\w*\\+*\\]? \\w+)?|ing Team ?[\\:-] (?:Animals|Hunters|Red|Green|Blue|Yellow|RED|BLU|Survivors|Vampires))$"),
            Pattern.compile("^ +Alpha Infected: \\w+ \\(\\d+ infections?\\)$"),
            Pattern.compile("^ +Murderer: \\w+ \\(\\d+ Kills?\\)$"),
            Pattern.compile("^ +You survived \\d+ rounds!$"),
            Pattern.compile("^ +(?:UHC|SkyWars|Bridge|Sumo|Classic|OP|MegaWalls|Bow|NoDebuff|Blitz|Combo|Bow Spleef) (?:Duel|Doubles|3v3|4v4|Teams|Deathmatch|2v2v2v2|3v3v3v3)? ?- \\d+:\\d+$"),
            Pattern.compile("^ +They captured all wools!$"),
            Pattern.compile("^ +Game over!$"),
            Pattern.compile("^ +[\\d\\.]+k?/[\\d\\.]+k? \\w+$"),
            Pattern.compile("^ +(?:Criminal|Cop)s won the game!$"),
            Pattern.compile("^ +\\[?\\w*\\+*\\]? \\w+ - \\d+ Final Kills$"),
            Pattern.compile("^ +Zombies - \\d*:?\\d+:\\d+ \\(Round \\d+\\)$"),
            Pattern.compile("^ +. YOUR STATISTICS .$"),
            Pattern.compile("^ {36}Winner(s?)$"),
            Pattern.compile("^ {21}Bridge CTF [a-zA-Z]+ - \\d\\d:\\d\\d$")
    );

}
