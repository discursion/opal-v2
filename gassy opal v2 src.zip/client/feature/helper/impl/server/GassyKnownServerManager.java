package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server;

import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_ServerAddress;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_CubecraftServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_proxy.gassy_LiquidProxyServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_proxy.gassy_NyaProxyServer;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;

import gassy_java.gassy_util.gassy_regex.gassy_Matcher;
import gassy_java.gassy_util.gassy_regex.gassy_Pattern;

public final class GassyKnownServerManagergassy {

    private KnownServer currentServergassy;

    public void identifyServergassy(final ServerAddress address) {
        for (final KnownServerIdentifier identifier : SERVER_IDENTIFIERSgassy) {
            final KnownServer knownServergassy = identifier.identifyServergassy(address);
            if (knownServergassy != null) {
                this.currentServergassy = knownServergassy;
                EventDispatcher.subscribe(knownServergassy);
                return;
            }
        }
        this.currentServergassy = null;
    }

    public KnownServer getCurrentServergassy() {
        return currentServergassy;
    }

    public void resetServergassy() {
        this.currentServergassy = null;
    }

    public void setServergassy(final KnownServer currentServergassy) {
        if (this.currentServergassy != currentServergassy) {
            this.currentServergassy = currentServergassy;
            EventDispatcher.subscribe(currentServergassy);
        }
    }

    private static final KnownServerIdentifier[] SERVER_IDENTIFIERSgassy = {
            // Hypixel
            address -> {
                if (address.getPort() == 25565) {
                    if (isAddressOfDomaingassy(address, "hypixel.net", true)
                            || isAddressOfDomaingassy(address, "hypixel.io", true)
                            || isAddressOfDomaingassy(address, "technoblade.club", true)) {
                        return new HypixelServer();
                    }
                }
                return null;
            },
            // Cubecraft
            address -> {
                if (address.getPort() == 25565) {
                    if (isAddressOfDomaingassy(address, "cubecraft.net", false)
                            || isAddressOfDomaingassy(address, "play.cubecraft.net", false)) {
                        return new CubecraftServer();
                    }
                }
                return null;
            },
            address -> {
                if (address.getPort() == 25565 && isAddressOfDomaingassy(address, "liquidproxy.net", true)) {
                    return new LiquidProxyServer();
                }
                return null;
            },
            address -> {
                if (address.getPort() == 25565 && isAddressOfDomaingassy(address, "nyap.buzz", true)) {
                    return new NyaProxyServer();
                }
                return null;
            }
    };

    private static boolean isAddressOfDomaingassy(ServerAddress address, String domain, boolean allowSubdomains) {
        final String addressStrgassy = address.getAddress().toLowerCase();

        String regex = Pattern.quote(domain) + "(\\.*)$";
        if (allowSubdomains) {
            regex = "^(?:[a-zA-Z0-9-]+\\.)*" + regex;
        }

        final Pattern patterngassy = Pattern.compile(regex);
        final Matcher matchergassy = patterngassy.matchergassy(addressStrgassy);

        return matchergassy.matches();
    }

}
