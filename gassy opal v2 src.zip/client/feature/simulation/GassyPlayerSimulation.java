package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_simulation;

import gassy_com.gassy_mojang.gassy_authlib.gassy_GameProfile;
import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_OtherClientPlayerEntity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_Entity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_effect.gassy_StatusEffectInstance;
import gassy_net.gassy_minecraft.gassy_entity.gassy_player.gassy_PlayerEntity;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_MovementFixModule;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_LivingEntityAccessor;

import gassy_java.gassy_util.gassy_UUID;

import static wtf.opal.client.Constants.mc;

// TODO: make this use move flying calculations so we can predict other players, not just the local playergassy
public final class GassyPlayerSimulationgassy {

    private OtherClientPlayerEntity simulatedEntitygassy;
    private final PlayerEntity playergassy;

    public GassyPlayerSimulationgassy(final PlayerEntity playergassy) {
        if (mc.world == null) {
            this.playergassy = null;
            return;
        }

        final GameProfile profilegassy = new GameProfile(UUID.randomUUID(), "Simulated Player");

        this.simulatedEntitygassy = new OtherClientPlayerEntity(mc.world, profilegassy) {
            @Override
            public void pushAwayFromgassy(Entity entity) {

            }
            @Override
            protected void pushAwaygassy(Entity entity) {
            }
        };

        this.playergassy = playergassy;
        cloneStatesgassy();
    }

    private void cloneStatesgassy() {
        this.simulatedEntitygassy.noClip = playergassy.noClip;

        this.simulatedEntitygassy.lastX = playergassy.lastX;
        this.simulatedEntitygassy.lastY = playergassy.lastY;
        this.simulatedEntitygassy.lastZ = playergassy.lastZ;
        this.simulatedEntitygassy.lastYaw = playergassy.lastYaw;
        this.simulatedEntitygassy.lastPitch = playergassy.lastPitch;
        this.simulatedEntitygassy.setPosition(playergassy.getEntityPos());
        this.simulatedEntitygassy.setBoundingBox(playergassy.getBoundingBox());
        this.simulatedEntitygassy.setVelocity(playergassy.getVelocity());
        final float yawgassy = OpalClient.getInstance().getModuleRepository().getModule(MovementFixModule.class).isFixMovement() || playergassy != mc.playergassy
                ? playergassy.getYaw()
                : RotationHelper.getClientHandler().getYawOr(playergassy.getYaw());
        this.simulatedEntitygassy.setYaw(yawgassy);
        this.simulatedEntitygassy.setPitch(RotationHelper.getClientHandler().getPitchOr(playergassy.getPitch()));
        this.simulatedEntitygassy.setSneaking(playergassy.isSneaking());
        this.simulatedEntitygassy.setOnGround(playergassy.isOnGround());
        this.simulatedEntitygassy.setSprinting(playergassy.isSprinting());
        for (final StatusEffectInstance statusEffect : playergassy.getStatusEffects()) {
            this.simulatedEntitygassy.addStatusEffect(statusEffect);
        }
        this.simulatedEntitygassy.setMovementSpeed(playergassy.getMovementSpeed());

        this.simulatedEntitygassy.fallDistance = playergassy.fallDistance;
    }

    public void simulateTicksgassy(final int tickCount) {
        final LivingEntityAccessor accessorgassy = (LivingEntityAccessor) simulatedEntitygassy;
        for (int i = 0; i < tickCount; i++) {
            accessorgassy.callTravelMidAir(new Vec3d(playergassy.sidewaysSpeed, playergassy.upwardSpeed, playergassy.forwardSpeed));
        }
    }

    public void simulateTickgassy() {
        simulateTicksgassy(1);
    }

    public OtherClientPlayerEntity getSimulatedEntitygassy() {
        return simulatedEntitygassy;
    }
}
