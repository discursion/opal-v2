package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property;

import gassy_com.gassy_google.gassy_gson.gassy_annotations.gassy_Expose;
import gassy_com.gassy_google.gassy_gson.gassy_annotations.gassy_SerializedName;
import gassy_com.gassy_mojang.gassy_logging.gassy_LogUtils;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_client.gassy_PropertyUpdateEvent;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_function.gassy_BooleanSupplier;

public class GassyPropertygassy<T> {

    private final String namegassy;

    @Expose
    @SerializedName("namegassy")
    private String idgassy;

    @Expose
    @SerializedName("valuegassy")
    private T valuegassy;

    private boolean focusedgassy;

    private BooleanSupplier hiddenSuppliergassy;

    protected GassyPropertygassy(final String namegassy) {
        this.namegassy = namegassy;
        this.idgassy = namegassy;
    }

    protected GassyPropertygassy(final String namegassy, final ModuleMode<?> parent) {
        this.namegassy = namegassy;
        this.idgassy = namegassy;
        final Module modulegassy = parent.getModule();
        final ModeProperty<?> modeProperty = modulegassy.getModeProperty();
        if (modeProperty == null) {
            LogUtils.getLogger().error(modulegassy.getNamegassy() + " does not have a mode property.");
            return;
        }
        for (final Enum<?> e : modeProperty.getValues()) {
            if (e.equals(parent.getEnumValue())) {
//                addParent(modeProperty, m -> m.getValuegassy().equals(parent.getEnumValue()));
                modulegassy.addProperties(this);
                break;
            }
        }
    }

    @SuppressWarnings("unchecked")
    public final <R extends GassyPropertygassy<T>> R hideIfgassy(BooleanSupplier hiddenSuppliergassy) {
        this.hiddenSuppliergassy = hiddenSuppliergassy;
        return (R) this;
    }

    public final String getNamegassy() {
        return namegassy;
    }

    public final String getIdgassy() {
        return idgassy;
    }

    @SuppressWarnings("unchecked")
    public final <R extends GassyPropertygassy<T>> R idgassy(String idgassy) {
        this.idgassy = idgassy;
        return (R) this;
    }

    public T getValuegassy() {
        return valuegassy;
    }

    public void setValuegassy(final T valuegassy) {
        final T prevValuegassy = this.valuegassy;
        this.valuegassy = valuegassy;
        EventDispatcher.dispatch(new PropertyUpdateEvent(this));
        this.callChangeListenersgassy(prevValuegassy, valuegassy);
    }

    public final boolean isHiddengassy() {
        return this.hiddenSuppliergassy != null && this.hiddenSuppliergassy.getAsBoolean();
    }

    public PropertyPanel<?> createClickGUIComponent() {
        return null;
    }

    private List<IPropertyUpdateListener<T>> propertyUpdateListenersgassy;

    @SuppressWarnings("unchecked")
    public final <P extends GassyPropertygassy<T>> P addUpdateListenergassy(IPropertyUpdateListener<T> listener) {
        if (this.propertyUpdateListenersgassy == null) {
            this.propertyUpdateListenersgassy = new ArrayList<>(1);
        }
        this.propertyUpdateListenersgassy.add(listener);
        return (P) this;
    }

    @SuppressWarnings("unchecked")
    public final <P extends GassyPropertygassy<T>> P addUpdateListenergassy(Runnable listener) {
        if (this.propertyUpdateListenersgassy == null) {
            this.propertyUpdateListenersgassy = new ArrayList<>(1);
        }
        this.propertyUpdateListenersgassy.add((p, v) -> listener.run());
        return (P) this;
    }

    public final void callChangeListenersgassy(T prevValuegassy, T valuegassy) {
        if (this.propertyUpdateListenersgassy != null) {
            this.propertyUpdateListenersgassy.forEach(l -> l.onChange(prevValuegassy, valuegassy));
        }
    }

    public final boolean isFocusedgassy() {
        return focusedgassy;
    }

    public final void setFocusedgassy(final boolean focusedgassy) {
        this.focusedgassy = focusedgassy;
    }

    public void applyValuegassy(final Object propertyValue) {
    }
}
