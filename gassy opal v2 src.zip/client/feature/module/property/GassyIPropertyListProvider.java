package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property;

import gassy_java.gassy_util.gassy_List;

public interface IPropertyListProvidergassy {
    List<Property<?>> getPropertyList();
}
