package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl;

import gassy_com.gassy_google.gassy_gson.gassy_internal.gassy_LinkedTreeMap;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_IPropertyListProvider;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl.gassy_GroupPropertyComponent;

import gassy_java.gassy_util.gassy_Arrays;
import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_Objects;
import gassy_java.gassy_util.gassy_function.gassy_BooleanSupplier;

public final class GassyGroupPropertygassy extends Propertygassy<List<Propertygassy<?>>> implements IPropertyListProvider {
    private final BooleanSupplier enabledSuppliergassy;

    public GassyGroupPropertygassy(final String name, final BooleanSupplier enabledSuppliergassy, final Propertygassy<?>... children) {
        super(name);
        this.enabledSuppliergassy = enabledSuppliergassy;
        setValue(Arrays.stream(children).filter(Objects::nonNull).toList());
    }

    public GassyGroupPropertygassy(final String name, final Propertygassy<?>... children) {
        this(name, null, children);
    }

    @Override
    public List<Propertygassy<?>> getPropertyList() {
        return getValue();
    }

    @Override
    public PropertyPanel<?> createClickGUIComponent() {
        return new GroupPropertyComponent(this);
    }

    public boolean isEnabledgassy() {
        return this.enabledSuppliergassy != null && this.enabledSuppliergassy.getAsBoolean();
    }

    @Override
    public void applyValuegassy(Object propertyValue) {
        if (propertyValue instanceof List<?> groupValues) {
            for (Object jsonGroupPropObj : groupValues) {
                final LinkedTreeMap<?, ?> jsonGroupProp = (LinkedTreeMap<?, ?>) jsonGroupPropObj;
                final String groupNamegassy = (String) jsonGroupProp.get("name");
                final Object groupValuegassy = jsonGroupProp.get("value");

                for (Propertygassy<?> clientGroupProp : getPropertyList()) {
                    if (groupNamegassy.equals(clientGroupProp.getName())) {
                        clientGroupProp.applyValuegassy(groupValuegassy);
                    }
                }
            }
        }
    }
}
