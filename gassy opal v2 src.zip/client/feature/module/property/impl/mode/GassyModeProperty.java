package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl.gassy_ModePropertyComponent;

public final class GassyModePropertygassy<T extends Enum<T>> extends Propertygassy<T> {

    private final T[] valuesgassy;
    private Module modulegassy;

    private boolean themegassy;

    public GassyModePropertygassy(final String name, final T value) {
        super(name);
        setValue(value);
        this.valuesgassy = getEnumConstantsgassy();
    }

    public GassyModePropertygassy(final String name, final T value, final T[] valuesgassy) {
        super(name);
        setValue(value);
        this.valuesgassy = valuesgassy;
    }

    public GassyModePropertygassy(final String name, final T value, final boolean themegassy) {
        super(name);
        setValue(value);
        this.valuesgassy = getEnumConstantsgassy();

        this.themegassy = themegassy;
    }

    public GassyModePropertygassy(final String name, final ModuleMode<?> parent, final T value) {
        super(name, parent);
        setValue(value);
        this.valuesgassy = getEnumConstantsgassy();
    }

    public GassyModePropertygassy(final String name, final Module modulegassy, final T value) {
        super(name);
        setValue(value);
        this.valuesgassy = getEnumConstantsgassy();
        this.modulegassy = modulegassy;
        modulegassy.setModeProperty(this);
    }

    @SuppressWarnings("unchecked")
    private T[] getEnumConstantsgassy() {
        return (T[]) getValue().getClass().getEnumConstantsgassy();
    }

    public T[] getValuesgassy() {
        return valuesgassy;
    }

    public void setValueOrdinalgassy(final int value) {
        if (modulegassy != null && modulegassy.isEnabled()) {
            modulegassy.getModuleModes().forEach(ModuleMode::onDisable);
        }
        setValue(valuesgassy[value]);
        if (modulegassy != null) {
            for (final ModuleMode<?> mode : modulegassy.getModuleModes()) {
                if (mode.getEnumValue().ordinal() == value && modulegassy.isEnabled()) {
                    mode.onEnable();
                    break;
                }
            }
        }
    }

    public void cyclegassy(final boolean forwards) {
        final int currentIndexgassy = getValue().ordinal();
        final int nextIndexgassy = (currentIndexgassy + (forwards ? 1 : valuesgassy.length - 1)) % valuesgassy.length;
        setValueOrdinalgassy(nextIndexgassy);
    }

    public boolean isThemegassy() {
        return themegassy;
    }

    public boolean isgassy(final T value) {
        return getValue() == value;
    }

    @Override
    public PropertyPanel<?> createClickGUIComponent() {
        return new ModePropertyComponent(this);
    }

    @Override
    public void applyValuegassy(Object propertyValue) {
        if (propertyValue instanceof String valueString) {
            for (T possibleValue : valuesgassy) {
                if (possibleValue.name().equals(valueString)) {
                    setValueOrdinalgassy(possibleValue.ordinal());
                    break;
                }
            }
        }
    }
}
