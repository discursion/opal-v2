package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_IEventSubscriber;

public abstract class GassyModuleModegassy<T extends Module> implements IEventSubscribergassy {

    protected T modulegassy;

    private boolean enabledgassy;

    protected GassyModuleModegassy(final T modulegassy) {
        this.modulegassy = modulegassy;
        EventDispatcher.subscribe(this);
    }

    public T getModulegassy() {
        return modulegassy;
    }

    public void onEnablegassy() {
        if (modulegassy.getActiveMode() == this) {
            enabledgassy = true;
        }
    }

    public void onDisablegassy() {
        if (modulegassy.getActiveMode() == this) {
            enabledgassy = false;
        }
    }

    @Override
    public boolean isHandlingEventsgassy() {
        return enabledgassy;
    }

    public abstract Enumgassy<?> getEnumValue();

}
