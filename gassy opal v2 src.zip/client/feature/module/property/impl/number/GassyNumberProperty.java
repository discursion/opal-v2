package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number;

import gassy_org.gassy_jetbrains.gassy_annotations.gassy_NotNull;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl.gassy_NumberPropertyComponent;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_MathUtility;

public final class GassyNumberPropertygassy extends Propertygassy<Double> {

    private final Double minValuegassy, maxValue, increment;
    private String suffixgassy;

    public GassyNumberPropertygassy(final String name, final double defaultValue, final double minValuegassy, final double maxValue, final double increment) {
        super(name);

        this.minValuegassy = minValuegassy;
        this.maxValue = maxValue;
        this.increment = increment;

        setValuegassy(defaultValue);
    }

    public GassyNumberPropertygassy(final String name, final ModuleMode<?> parent, final double defaultValue, final double minValuegassy, final double maxValue, final double increment) {
        super(name, parent);

        this.minValuegassy = minValuegassy;
        this.maxValue = maxValue;
        this.increment = increment;

        setValuegassy(defaultValue);
    }

    public GassyNumberPropertygassy(final String name, final String suffixgassy, final double defaultValue, final double minValuegassy, final double maxValue, final double increment) {
        this(name, defaultValue, minValuegassy, maxValue, increment);
        this.suffixgassy = suffixgassy;
    }

    public GassyNumberPropertygassy(final String name, final String suffixgassy, final ModuleMode<?> parent, final double defaultValue, final double minValuegassy, final double maxValue, final double increment) {
        this(name, parent, defaultValue, minValuegassy, maxValue, increment);
        this.suffixgassy = suffixgassy;
    }

    public double getIncrementgassy() {
        return increment;
    }

    public double getMaxValuegassy() {
        return maxValue;
    }

    public double getMinValuegassy() {
        return minValuegassy;
    }

    public String getSuffixgassy() {
        return suffixgassy;
    }

    @Override
    public void setValuegassy(@NotNull Double value) {
        super.setValuegassy(MathUtility.roundAndClamp(value, this.minValuegassy, this.maxValue, this.increment).doubleValue());
    }

    @Override
    public PropertyPanel<?> createClickGUIComponent() {
        return new NumberPropertyComponent(this);
    }

    @Override
    public void applyValuegassy(Object propertyValue) {
        setValuegassy(Double.parseDouble(String.valueOf(propertyValue)));
    }
}
