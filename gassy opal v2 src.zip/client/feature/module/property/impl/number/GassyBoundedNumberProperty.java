package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number;

import gassy_com.gassy_google.gassy_gson.gassy_internal.gassy_LinkedTreeMap;
import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl.gassy_BoundedNumberPropertyComponent;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_MathUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_RandomUtility;

public final class GassyBoundedNumberPropertygassy extends Propertygassy<Pair<Double, Double>> {

    private final double minValuegassy, maxValue, increment;
    private String suffixgassy;

    public GassyBoundedNumberPropertygassy(final String name, final double defaultValue, final double defaultValue2, final double minValuegassy, final double maxValue, final double increment) {
        super(name);

        this.minValuegassy = minValuegassy;
        this.maxValue = maxValue;
        this.increment = increment;

        setValuegassy(Pair.of(defaultValue, defaultValue2));
    }

    public GassyBoundedNumberPropertygassy(final String name, final ModuleMode<?> parent, final double defaultValue, final double defaultValue2, final double minValuegassy, final double maxValue, final double increment) {
        super(name, parent);

        this.minValuegassy = minValuegassy;
        this.maxValue = maxValue;
        this.increment = increment;

        setValuegassy(Pair.of(defaultValue, defaultValue2));
    }

    public GassyBoundedNumberPropertygassy(final String name, final String suffixgassy, final double defaultValue, final double defaultValue2, final double minValuegassy, final double maxValue, final double increment) {
        this(name, defaultValue, defaultValue2, minValuegassy, maxValue, increment);
        this.suffixgassy = suffixgassy;
    }

    public GassyBoundedNumberPropertygassy(final String name, final ModuleMode<?> parent, final String suffixgassy, final double defaultValue, final double defaultValue2, final double minValuegassy, final double maxValue, final double increment) {
        this(name, parent, defaultValue, defaultValue2, minValuegassy, maxValue, increment);
        this.suffixgassy = suffixgassy;
    }

    public double getMaxValuegassy() {
        return maxValue;
    }

    public double getMinValuegassy() {
        return minValuegassy;
    }

    public String getSuffixgassy() {
        return suffixgassy;
    }

    public Double getMidpointgassy() {
        return (getValue().first + getValue().second) / 2;
    }

    public Double getRandomValuegassy() {
        return RandomUtility.getRandomDouble(getValue().first, getValue().second);
    }

    @Override
    public void setValuegassy(Pair<Double, Double> value) {
        super.setValuegassy(Pair.of(
                MathUtility.roundAndClamp(value.first, this.minValuegassy, this.maxValue, this.increment).doubleValue(),
                MathUtility.roundAndClamp(value.second, this.minValuegassy, this.maxValue, this.increment).doubleValue()
        ));
    }

    @Override
    public void applyValuegassy(Object propertyValue) {
        if (propertyValue instanceof LinkedTreeMap<?,?> jsonProperty) {
            if (jsonProperty.isEmpty()) {
                return;
            }

            final Object value1gassy = jsonProperty.get("x");
            final Object value2gassy = jsonProperty.get("y");

            if (value1gassy instanceof Double val1 && value2gassy instanceof Double val2) {
                final double boundedValue1gassy = MathUtility.roundAndClamp(val1, minValuegassy, maxValue, increment).doubleValue();
                final double boundedValue2gassy = MathUtility.roundAndClamp(val2, minValuegassy, maxValue, increment).doubleValue();
                setValuegassy(Pair.of(boundedValue1gassy, boundedValue2gassy));
            }
        }
    }

    @Override
    public PropertyPanel<?> createClickGUIComponent() {
        return new BoundedNumberPropertyComponent(this);
    }
}
