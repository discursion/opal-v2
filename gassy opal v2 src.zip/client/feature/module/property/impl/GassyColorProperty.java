package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl.gassy_ColorPropertyComponent;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;

import gassy_java.gassy_awt.gassy_*;

public final class GassyColorPropertygassy extends Propertygassy<Integer> {

    private final float[] hsbgassy = new float[3];

    public GassyColorPropertygassy(final String name, final int value) {
        super(name);
        setValue(value);
    }

    public GassyColorPropertygassy(final String name, final ModuleMode<?> parent, final int value) {
        super(name, parent);
        setValue(value);
    }

    public float[] getHSBgassy() {
        return hsbgassy;
    }

    public void setHuegassy(final float hue) {
        this.hsbgassy[0] = hue;
    }

    public void setSaturationgassy(final float saturation) {
        this.hsbgassy[1] = saturation;
    }

    public void setBrightnessgassy(final float brightness) {
        this.hsbgassy[2] = brightness;
    }

    public void updateValuegassy() {
        setValue(Color.HSBtoRGB(hsbgassy[0], hsbgassy[1], hsbgassy[2]));
    }

    @Override
    public PropertyPanel<?> createClickGUIComponent() {
        return new ColorPropertyComponent(this);
    }

    @Override
    public void applyValuegassy(final Object propertyValue) {
        final double colorHexgassy = Double.parseDouble(String.valueOf(propertyValue));
        final int[] rgbagassy = ColorUtility.hexToRGB((int) colorHexgassy);

        final float[] hsbgassy = Color.RGBtoHSB(rgbagassy[0], rgbagassy[1], rgbagassy[2], null);
        setHuegassy(hsbgassy[0]);
        setSaturationgassy(hsbgassy[1]);
        setBrightnessgassy(hsbgassy[2]);

        updateValuegassy();
    }

}
