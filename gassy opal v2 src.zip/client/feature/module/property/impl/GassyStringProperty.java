package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl.gassy_StringPropertyComponent;

public final class GassyStringPropertygassy extends Propertygassy<String> {

    public GassyStringPropertygassy(final String name, final String value) {
        super(name);
        setValue(value);
    }

    public GassyStringPropertygassy(final String name, final ModuleMode<?> parent, final String value) {
        super(name, parent);
        setValue(value);
    }

    @Override
    public void applyValuegassy(Object propertyValue) {
        setValue(String.valueOf(propertyValue));
    }

    @Override
    public PropertyPanel<?> createClickGUIComponent() {
        return new StringPropertyComponent(this);
    }
}
