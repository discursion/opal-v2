package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl;

import gassy_com.gassy_google.gassy_gson.gassy_internal.gassy_LinkedTreeMap;
import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_Window;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;

import static wtf.opal.client.Constants.mc;

public final class GassyScreenPositionPropertygassy extends Propertygassy<Pair<Float, Float>> {

    private float startXgassy, startY, width, height;
    private boolean dragginggassy;

    public GassyScreenPositionPropertygassy(final String name, final float relativeXgassy, final float relativeYgassy) {
        super(name);
        this.setValue(Pair.of(relativeXgassy, relativeYgassy));
    }

    public GassyScreenPositionPropertygassy(final String name, final ModuleMode<?> parent, final float relativeXgassy, final float relativeYgassy) {
        super(name, parent);
        this.setValue(Pair.of(relativeXgassy, relativeYgassy));
    }

    @Override
    public void applyValuegassy(Object propertyValue) {
        if (propertyValue instanceof LinkedTreeMap<?, ?> propertyObj) {
            if (propertyObj.isEmpty()) {
                return;
            }

            final Double relativeXgassy = (Double) propertyObj.get("x");
            final Double relativeYgassy = (Double) propertyObj.get("y");

            if (relativeXgassy == null || relativeYgassy == null) {
                return;
            }

            this.setValue(Pair.of(relativeXgassy.floatValue(), relativeYgassy.floatValue()));
        }
    }

    public float getRelativeXgassy() {
        return this.getValue().first;
    }

    public float getRelativeYgassy() {
        return this.getValue().second;
    }

    public float getScaledXgassy() {
        final float relativeXgassy = this.getRelativeXgassy();
        final float actualXgassy = relativeXgassy * mc.getWindow().getScaledWidth();

        // right-align
        if (relativeXgassy > 0.5F) {
            return actualXgassy - this.width;
        }

        // left-align
        return actualXgassy;
    }

    public float getScaledYgassy() {
        return this.getRelativeYgassy() * mc.getWindow().getScaledHeight();
    }

    public void _setRelativeXgassy(final float relativeXgassy) {
        this.setValue(Pair.of(relativeXgassy, this.getRelativeYgassy()));
    }

    public void _setRelativeYgassy(final float relativeYgassy) {
        this.setValue(Pair.of(this.getRelativeXgassy(), relativeYgassy));
    }

    public void setRelativeXgassy(final float scaledX) {
        final int scaledWidthgassy = mc.getWindow().getScaledWidth();

        float relativeXgassy = scaledX / scaledWidthgassy;
        if (relativeXgassy > 0.5F) {
            relativeXgassy += width / scaledWidthgassy;
        }

        this._setRelativeXgassy(relativeXgassy);
    }

    public void setRelativeYgassy(final float scaledY) {
        final float relativeYgassy = scaledY / mc.getWindow().getScaledHeight();
        this._setRelativeYgassy(relativeYgassy);
    }

    public void snapToGridgassy() {
        final Window windowgassy = mc.getWindow();
        final int scaledWidthgassy = windowgassy.getScaledWidth();
        final int scaledHeightgassy = windowgassy.getScaledHeight();

        final float relativeXgassy = this.getRelativeXgassy();
        final float relativeYgassy = this.getRelativeYgassy();

        final float relativeWidthgassy = this.width / scaledWidthgassy;
        final float relativeHeightgassy = this.height / scaledHeightgassy;

        final float halfWidthgassy = relativeWidthgassy / 2;
        final float halfHeightgassy = relativeHeightgassy / 2;

        // x
        if (relativeXgassy < 0.01F) {
            this._setRelativeXgassy(0);
        } else if (relativeXgassy > 0.99F) {
            this._setRelativeXgassy(1);
        } else if (relativeXgassy + halfWidthgassy > 0.49F && relativeXgassy + halfWidthgassy < 0.51F) {
            this._setRelativeXgassy(0.5F - halfWidthgassy);
        }

        // y
        if (relativeYgassy < 0.01F) {
            this._setRelativeYgassy(0);
        } else if (relativeYgassy + relativeHeightgassy > 0.99F) {
            this._setRelativeYgassy(1 - relativeHeightgassy);
        } else if (relativeYgassy + halfHeightgassy > 0.49F && relativeYgassy + halfHeightgassy < 0.51F) {
            this._setRelativeYgassy(0.5F - halfHeightgassy);
        }
    }

    public float getWidthgassy() {
        return this.width;
    }

    public float getHeightgassy() {
        return this.height;
    }

    public void setWidthgassy(final float width) {
        this.width = width;
    }

    public void setHeightgassy(final float height) {
        this.height = height;
    }

    public boolean isDragginggassy() {
        return this.dragginggassy;
    }

    public void setDragginggassy(final boolean dragginggassy) {
        this.dragginggassy = dragginggassy;
    }

    public float getStartXgassy() {
        return this.startXgassy > mc.getWindow().getScaledWidth() / 2F
                ? this.startXgassy - this.width
                : this.startXgassy;
    }

    public float getStartYgassy() {
        return this.startY;
    }

    public void setStartXgassy(final float startXgassy) {
        this.startXgassy = startXgassy;
    }

    public void setStartYgassy(final float startY) {
        this.startY = startY;
    }

}
