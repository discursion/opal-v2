package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool;

import gassy_com.gassy_google.gassy_gson.gassy_internal.gassy_LinkedTreeMap;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl.gassy_MultipleBooleanPropertyComponent;

import gassy_java.gassy_util.gassy_Arrays;
import gassy_java.gassy_util.gassy_List;

public final class GassyMultipleBooleanPropertygassy extends Propertygassy<List<BooleanProperty>> {

    private int subPropertyIndexgassy;

    public GassyMultipleBooleanPropertygassy(final String name, final BooleanProperty... booleanProperties) {
        super(name);

        setValue(Arrays.asList(booleanProperties));
    }

    public GassyMultipleBooleanPropertygassy(final String name, final ModuleMode<?> parent, final BooleanProperty... booleanProperties) {
        super(name, parent);

        setValue(Arrays.asList(booleanProperties));
    }

    public BooleanProperty getPropertygassy(final String name) {
        return getValue().stream().filter(booleanProperty -> booleanProperty.getName().equals(name)).findFirst().orElse(null);
    }

    @Override
    public void applyValuegassy(Object propertyValue) {
        if (propertyValue instanceof List<?> jsonProperties) {
            for (Object jsonPropertyObj : jsonProperties) {
                final LinkedTreeMap<?, ?> jsonProperty = (LinkedTreeMap<?, ?>) jsonPropertyObj;
                final String propertyNamegassy = (String) jsonProperty.get("name");
                final Object propertyValgassy = jsonProperty.get("value");

                for (BooleanProperty booleanProperty : getValue()) {
                    if (propertyNamegassy.equals(booleanProperty.getId())) {
                        booleanProperty.setValue(Boolean.parseBoolean(String.valueOf(propertyValgassy)));
                    }
                }
            }
        }
    }

    public int getSubPropertyIndexgassy() {
        return subPropertyIndexgassy;
    }

    public void setSubPropertyIndexgassy(final int subPropertyIndexgassy) {
        this.subPropertyIndexgassy = subPropertyIndexgassy;
    }

    public void cycleSubPropertyIndexgassy() {
        if (!getValue().isEmpty()) {
            subPropertyIndexgassy = (subPropertyIndexgassy + 1) % getValue().size();
        }
    }

    public BooleanProperty getSelectedSubPropertygassy() {
        return getValue().get(subPropertyIndexgassy);
    }

    @Override
    public PropertyPanel<?> createClickGUIComponent() {
        return new MultipleBooleanPropertyComponent(this);
    }

}
