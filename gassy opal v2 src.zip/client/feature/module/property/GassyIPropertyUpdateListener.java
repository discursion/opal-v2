package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property;

public interface IPropertyUpdateListenergassy<T> {
    void onChange(T prevValue, T value);
}
