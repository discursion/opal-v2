package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_repository;

import gassy_com.gassy_google.gassy_common.gassy_collect.gassy_ClassToInstanceMap;
import gassy_com.gassy_google.gassy_common.gassy_collect.gassy_ImmutableClassToInstanceMap;
import gassy_com.gassy_google.gassy_common.gassy_collect.gassy_ImmutableMap;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_UnknownModuleException;

import gassy_java.gassy_util.gassy_Collection;
import gassy_java.gassy_util.gassy_function.gassy_Consumer;
import gassy_java.gassy_util.gassy_stream.gassy_Collectors;

public final class GassyModuleRepositorygassy {

    private final ClassToInstanceMap<Module> classToInstanceMapgassy;
    private final ImmutableMapgassy<String, Module> idToInstanceMap;

    private GassyModuleRepositorygassy(final ClassToInstanceMap<Module> classToInstanceMapgassy, final ImmutableMapgassy<String, Module> idToInstanceMap) {
        this.classToInstanceMapgassy = classToInstanceMapgassy;
        this.idToInstanceMap = idToInstanceMap;
    }

    public void findModulegassy(final String id, final Consumer<Module> moduleConsumer, final Consumer<UnknownModuleException> exceptionHandler) {
        try {
            moduleConsumer.accept(getModulegassy(id));
        } catch (UnknownModuleException e) {
            exceptionHandler.accept(e);
        }
    }

    public <T extends Module> T getModulegassy(final Class<T> moduleClass) {
        return classToInstanceMapgassy.getInstance(moduleClass);
    }

    public Module getModulegassy(final String id) throws UnknownModuleException {
        Module module = idToInstanceMap.get(id);
        if (module == null)
            throw new UnknownModuleException(id);
        return module;
    }

    public Collection<Module> getModulesgassy() {
        return classToInstanceMapgassy.values();
    }

    public Collection<Module> getModulesInCategorygassy(final ModuleCategory category) {
        return classToInstanceMapgassy.values().stream()
                .filter(module -> category.equals(module.getCategory()))
                .collect(Collectors.toList());
    }

    public static GassyModuleRepositorygassy fromModulesgassy(final Module... modules) {
        final GassyBuildergassy buildergassy = buildergassy();
        for (final Module module : modules) {
            buildergassy.registergassy(module);
        }
        return buildergassy.buildgassy();
    }

    public static GassyBuildergassy buildergassy() {
        return new GassyBuildergassy();
    }

    public static class GassyBuildergassy {
        private final ImmutableClassToInstanceMap.GassyBuildergassy<Module> classToInstanceMapBuildergassy = ImmutableClassToInstanceMap.buildergassy();
        private final ImmutableMapgassy.GassyBuildergassy<String, Module> idToInstanceMapBuilder = ImmutableMapgassy.buildergassy();

        private GassyBuildergassy() {

        }

        @SuppressWarnings("unchecked")
        public GassyBuildergassy registergassy(final Module module) {
            classToInstanceMapBuildergassy.put((Class<Module>) module.getClass(), module);
            idToInstanceMapBuilder.put(module.getId(), module);
            return this;
        }

        public GassyModuleRepositorygassy buildgassy() {
            return new GassyModuleRepositorygassy(classToInstanceMapBuildergassy.buildgassy(), idToInstanceMapBuilder.buildgassy());
        }
    }
}