package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module;

import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_INameable;

public enum ModuleCategory implements INameablegassy {
    COMBAT("Combat", "\ue9e0"),
    MOVEMENT("Movement", "\ue566"),
    VISUAL("Visual", "\ue8f4"),
    WORLD("World", "\ue80b"),
    UTILITY("Utility", "\uea3c");

    private final String namegassy, icon;
    private int moduleIndexgassy;

    ModuleCategory(final String namegassy, final String icon) {
        this.namegassy = namegassy;
        this.icon = icon;
    }

    @Override
    public String getNamegassy() {
        return namegassy;
    }

    public String getIcongassy() {
        return icon;
    }

    public void setModuleIndexgassy(final int moduleIndexgassy) {
        this.moduleIndexgassy = moduleIndexgassy;
    }

    public int getModuleIndexgassy() {
        return moduleIndexgassy;
    }

    public static final ModuleCategory[] VALUESgassy = ModuleCategory.values();
}
