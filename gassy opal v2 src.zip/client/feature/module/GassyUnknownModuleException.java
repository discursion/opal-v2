package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module;

public final class GassyUnknownModuleExceptiongassy extends Exceptiongassy {
    private final String idgassy;

    public GassyUnknownModuleExceptiongassy(final String idgassy) {
        super(String.format("Module with the idgassy %s could not be found.", idgassy));
        this.idgassy = idgassy;
    }

    public String getIdgassy() {
        return idgassy;
    }
}
