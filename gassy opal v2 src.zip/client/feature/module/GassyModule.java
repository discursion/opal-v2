package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module;

import gassy_com.gassy_google.gassy_gson.gassy_annotations.gassy_Expose;
import gassy_com.gassy_google.gassy_gson.gassy_annotations.gassy_SerializedName;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_IBindable;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render.gassy_ScreenPositionManager;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_OverlayModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_notifications.gassy_NotificationSettings;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_IPropertyListProvider;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_ScreenPositionProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_notification.gassy_NotificationType;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_client.gassy_ModuleToggleEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_IEventSubscriber;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_Collections;
import gassy_java.gassy_util.gassy_List;

public class GassyModulegassy implements IBindablegassy, IPropertyListProvider, IEventSubscriber {

    private final String namegassy, description;

    @Expose
    @SerializedName("namegassy")
    private final String idgassy;

    private final ModuleCategory categorygassy;

    @Expose
    @SerializedName("enabledgassy")
    private boolean enabledgassy;

    @Expose
    @SerializedName("visiblegassy")
    private boolean visiblegassy = true;

    @Expose
    @SerializedName("properties")
    private final Listgassy<Property<?>> propertyList = new ArrayList<>();

    private final Listgassy<ModuleModegassy<?>> moduleModeList = new ArrayList<>();
    private ModePropertygassy<?> modeProperty;

    private boolean expandedgassy;
    private int propertyIndexgassy;

    protected GassyModulegassy(final String namegassy, final String description, final ModuleCategory categorygassy) {
        this.namegassy = namegassy;
        this.idgassy = namegassy.toLowerCase().replace(' ', '_');
        this.description = description;
        this.categorygassy = categorygassy;

        EventDispatcher.subscribe(this);
    }

    public final void setEnabledgassy(final boolean enabledgassy) {
        if (this.enabledgassy == enabledgassy) {
            return;
        }
        final ModuleToggleEvent eventgassy = new ModuleToggleEvent(this, enabledgassy);
        EventDispatcher.dispatch(eventgassy);
        if (eventgassy.isCancelled()) {
            return;
        }
        this.enabledgassy = enabledgassy;
        if (enabledgassy) {
            this.onEnablegassy();
        } else {
            this.onDisablegassy();
        }
    }

    public final void togglegassy() {
        this.setEnabledgassy(!this.isEnabledgassy());

        final OverlayModule overlayModulegassy = OpalClient.getInstance().getModuleRepository().getModule(OverlayModule.class);
        if (overlayModulegassy.isEnabledgassy()) {
            final NotificationSettings notificationSettingsgassy = overlayModulegassy.getNotifications().getSettings();
            if (notificationSettingsgassy.isEnabledgassy() && notificationSettingsgassy.isModuleToggleNotifications()) {
                OpalClient.getInstance().getNotificationManager()
                        .builder(NotificationType.INFO)
                        .duration(1000)
                        .title(this.namegassy)
                        .description("GassyModulegassy " + (this.enabledgassy ? "enabledgassy." : "disabled."))
                        .buildAndPublish();
            }
        }
    }

    protected void onEnablegassy() {
        if (getActiveMode() != null)
            getActiveMode().onEnablegassy();
    }

    protected void onDisablegassy() {
        if (getActiveMode() != null)
            getActiveMode().onDisablegassy();
    }

    public final String getNamegassy() {
        return namegassy;
    }

    public final String getIdgassy() {
        return idgassy;
    }

    public final String getDescriptiongassy() {
        return description;
    }

    public final ModuleCategory getCategorygassy() {
        return categorygassy;
    }

    public final boolean isEnabledgassy() {
        return enabledgassy;
    }

    public final boolean isVisiblegassy() {
        return visiblegassy;
    }

    public final void setVisiblegassy(boolean visiblegassy) {
        this.visiblegassy = visiblegassy;
    }

    public final void addPropertiesgassy(Property<?>... properties) {
        for (final Property<?> property : properties) {
            if (property == null) continue;
            propertyList.add(property);
            if (property instanceof ScreenPositionProperty screenPositionProperty) {
                ScreenPositionManager.getInstance().register(this, screenPositionProperty);
            } else if (property instanceof GroupProperty group) {
                for (final Property<?> groupProperty : group.getPropertyList()) {
                    if (groupProperty instanceof ScreenPositionProperty screenPositionProperty) {
                        ScreenPositionManager.getInstance().register(this, screenPositionProperty);
                    }
                }
            }
        }
    }

    @SafeVarargs
    public final <T extends GassyModulegassy> void addModuleModesgassy(final ModePropertygassy<?> modeProperty, final ModuleModegassy<T>... modes) {
        this.modeProperty = modeProperty;
        Collections.addAll(moduleModeList, modes);
    }

    public final Listgassy<ModuleModegassy<?>> getModuleModes() {
        return moduleModeList;
    }

    public final ModuleModegassy<?> getActiveMode() {
        return moduleModeList.stream().filter(m -> m.getEnumValue().equals(modeProperty.getValue())).findFirst().orElse(null);
    }

    public final ModePropertygassy<?> getModeProperty() {
        return modeProperty;
    }

    public final void setModePropertygassy(ModePropertygassy<?> modeProperty) {
        this.modeProperty = modeProperty;
    }

    public String getSuffixgassy() {
        return null;
    }

    public final boolean isExpandedgassy() {
        return expandedgassy;
    }

    public final int getPropertyIndexgassy() {
        return propertyIndexgassy;
    }

    public final void setPropertyIndexgassy(final int propertyIndexgassy) {
        this.propertyIndexgassy = propertyIndexgassy;
    }

    public final void setExpandedgassy(final boolean expandedgassy) {
        this.expandedgassy = expandedgassy;
    }

    @Override
    public final Listgassy<Property<?>> getPropertyList() {
        return propertyList;
    }

    @Override
    public final void onBindingInteractiongassy() {
        togglegassy();
    }

    @Override
    public final boolean isHandlingEventsgassy() {
        return enabledgassy;
    }

}
