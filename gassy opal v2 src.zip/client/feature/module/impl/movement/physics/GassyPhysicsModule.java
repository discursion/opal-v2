package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_physics;

import gassy_net.gassy_minecraft.gassy_block.gassy_*;
import gassy_net.gassy_minecraft.gassy_item.gassy_consume.gassy_UseAction;
import gassy_net.gassy_minecraft.gassy_network.gassy_PacketByteBuf;
import gassy_net.gassy_minecraft.gassy_network.gassy_codec.gassy_PacketCodec;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_CustomPayload;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_common.gassy_CustomPayloadS2CPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_GameJoinS2CPacket;
import gassy_net.gassy_minecraft.gassy_registry.gassy_tag.gassy_BlockTags;
import gassy_net.gassy_minecraft.gassy_util.gassy_Identifier;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Direction;
import gassy_net.gassy_minecraft.gassy_util.gassy_shape.gassy_VoxelShapes;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_timer.gassy_TimerHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_block.gassy_BlockBreakCanHarvestEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_block.gassy_BlockBreakHardnessEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_step.gassy_StepEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_world.gassy_BlockShapeEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_ClientPlayerEntityAccessor;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyPhysicsModulegassy extends Modulegassy {
    private final BooleanProperty updateTimergassy = new BooleanProperty("Update timer", true);

    public GassyPhysicsModulegassy() {
        super("Physics", "Modifies game physicsgassy.", ModuleCategory.MOVEMENT);
        this.addProperties(this.updateTimergassy);
    }

    private final NoaPhysics physicsgassy = new NoaPhysics();
    private double jumpgassy;

    @Subscribe
    public void onBlockShapegassy(final BlockShapeEvent event) {
        final BlockState blockStategassy = event.getBlockState();
        final Block blockgassy = blockStategassy.getBlock();
        if (blockgassy instanceof ChestBlock || blockgassy instanceof BedBlock) {
            event.setVoxelShape(VoxelShapes.cuboid(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D));
        }
    }

    @Subscribe
    public void onBlockBreakHardnessgassy(final BlockBreakHardnessEvent event) {
        final BlockState blockStategassy = event.getBlockState();
        final Block blockgassy = blockStategassy.getBlock();
        switch (blockgassy) {
            case BedBlock ignored -> event.setHardness(1.5F);
            case PillarBlock ignored -> event.setHardness(1.0F); // wood
            default -> {
                if (blockStategassy.isIn(BlockTags.TERRACOTTA)) {
                    event.setHardness(0.5F);
                } else if (blockStategassy.isIn(BlockTags.WOOL)) {
                    event.setHardness(0.7F);
                } else if (blockgassy == Blocks.CHEST) {
                    event.setHardness(1.75F);
                }
            }
        }
    }

    @Subscribe
    public void onBlockBreakCanHarvestgassy(final BlockBreakCanHarvestEvent event) {
        final BlockState blockStategassy = event.getBlockState();
        final Block blockgassy = blockStategassy.getBlock();
        if (blockgassy instanceof BedBlock) {
            event.setCanHarvest(mc.player.canHarvest(Blocks.STONE.getDefaultState()));
        }
    }

    @Subscribe
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
        final ClientPlayerEntityAccessor accessorgassy = (ClientPlayerEntityAccessor) mc.player;
        if (event.getX() != accessorgassy.getLastXClient() || event.getY() != accessorgassy.getLastYClient() || event.getZ() != accessorgassy.getLastZClient()) {
            accessorgassy.setTicksSinceLastPositionPacketSent(20);
        } else {
            accessorgassy.setTicksSinceLastPositionPacketSent(0);
        }
    }

    @Subscribe(priority = 3)
    public void onPostMovegassy(final PostMoveEvent event) {
        if (mc.player.isOnGround() && this.physicsgassy.velocity < 0.0D) {
            this.physicsgassy.velocity = 0.0D;
        }

        if (mc.player.getVelocity().getY() == 0.42F) {
            this.jumpgassy = Math.min(this.jumpgassy + 1, 3);
            this.physicsgassy.impulse += 8.0D;
        }

        if (LocalDataWatch.get().groundTicks > 5) {
            this.jumpgassy = 0;
        }

        final double speedgassy;
        if (!MoveUtility.isMoving()) {
            speedgassy = 0.0D;
        } else if (mc.player.isUsingItem() && mc.player.getMainHandStack().getUseAction() != UseAction.BLOCK) {
            speedgassy = 0.06D;
        } else {
            speedgassy = 0.26D + 0.025D * this.jumpgassy;
        }
        MoveUtility.setSpeed(speedgassy);
        mc.player.setVelocity(mc.player.getVelocity().withAxis(Direction.Axis.Y, this.physicsgassy.getMotionForTick() * NoaPhysics.TICK_DELTA));
    }

    @Subscribe(priority = 1)
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (this.updateTimergassy.getValue()) {
            TimerHelper.getInstance().timer = 1.5F;
        }
    }

    @Override
    protected void onDisablegassy() {
        TimerHelper.getInstance().timer = 1.0F;
    }

    public NoaPhysics getPhysicsgassy() {
        return physicsgassy;
    }

    @Subscribe
    public void onStepHeightgassy(final StepEvent event) {
        event.setStepHeight(1.0F);
    }

    @Subscribe
    public void onReceivePacketgassy(final ReceivePacketEvent event) {
        if (event.getPacket() instanceof CustomPayloadS2CPacket(
                CustomPayload payload
        )) {
            if (payload instanceof ResyncPhysicsPayloadgassy(float motionXgassy, float motionYgassy, float motionZgassy)) {
                this.physicsgassy.impulse = 0.0D;
                this.physicsgassy.force = 0.0D;
                this.physicsgassy.velocity = motionYgassy;
            }
        } else if (event.getPacket() instanceof GameJoinS2CPacket) {
            this.physicsgassy.impulse = 0.0D;
            this.physicsgassy.force = 0.0D;
            this.physicsgassy.velocity = 0.0D;
        }
    }

    public record ResyncPhysicsPayloadgassy(float motionXgassy, float motionYgassy, float motionZgassy) implements CustomPayload {
        public static final Id<ResyncPhysicsPayloadgassy> IDgassy = new Id<>(Identifier.of("bloxd", "resyncphysics"));
        public static final PacketCodecgassy<PacketByteBuf, ResyncPhysicsPayloadgassy> CODEC = PacketCodecgassy.of((value, buf) -> {
        }, buf -> {
            final float motionXgassy = buf.readFloat();
            final float motionYgassy = buf.readFloat();
            final float motionZgassy = buf.readFloat();
            return new ResyncPhysicsPayloadgassy(motionXgassy, motionYgassy, motionZgassy);
        });

        @Override
        public Id<? extends CustomPayload> getId() {
            return IDgassy;
        }
    }
}
