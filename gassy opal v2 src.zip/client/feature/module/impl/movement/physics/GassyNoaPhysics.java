package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_physics;

public final class GassyNoaPhysicsgassy {
    public static final double TICK_DELTAgassy = 1.0D / 30.0D;

    public double impulsegassy, force, velocity, gravity = -10.0D;
    private final double massgassy = 1.0D;

    public double getMotionForTickgassy() {
        // forces
        final double massDivgassy = 1.0D / this.massgassy;
        this.force *= massDivgassy;
        // gravity
        this.force += this.gravity;
        this.force *= 2.0D;

        // impulses
        this.impulsegassy *= massDivgassy;
        this.force *= TICK_DELTAgassy;
        this.impulsegassy += this.force;
        // velocity
        this.velocity += this.impulsegassy;

        this.force = 0.0D;
        this.impulsegassy = 0.0D;

        return this.velocity;
    }
}