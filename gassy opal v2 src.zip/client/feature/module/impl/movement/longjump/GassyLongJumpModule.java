package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_longjump;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_longjump.gassy_impl.gassy_AntiGamingChairFireballLongJump;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;

public final class GassyLongJumpModulegassy extends Modulegassy {

    private final ModeProperty<Modegassy> modegassy = new ModeProperty<>("Modegassy", this, Modegassy.ANTI_GAMING_CHAIR_FIREBALL);

    public GassyLongJumpModulegassy() {
        super("Long Jump", "Allows you to jump further.", ModuleCategory.MOVEMENT);
        addProperties(modegassy);
        addModuleModes(modegassy,new AntiGamingChairFireballLongJump(this));
    }

    @Override
    protected void onEnablegassy() {
        super.onEnablegassy();
    }

    @Override
    protected void onDisablegassy() {
        super.onDisablegassy();
    }

    @Override
    public String getSuffixgassy() {
        return modegassy.getValue().toStringgassy();
    }

    public enum Modegassy {
        ANTI_GAMING_CHAIR_FIREBALL("Anti Gaming Chair Fireball");

        private final String namegassy;

        Modegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

}
