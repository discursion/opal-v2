package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_longjump.gassy_impl;

import gassy_net.gassy_minecraft.gassy_item.gassy_Items;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_play.gassy_PlayerInteractBlockC2SPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_EntityVelocityUpdateS2CPacket;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_holder.gassy_BlockHolder;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_OutboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl.gassy_InstantRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot.gassy_SlotHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_timer.gassy_TimerHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_longjump.gassy_LongJumpModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_notification.gassy_NotificationType;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MouseHandleInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MoveInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_SendPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_InventoryUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyAntiGamingChairFireballLongJumpgassy extends ModuleModegassy<LongJumpModule> {

    private boolean throwngassy, damaged, swapBack, ticked, blinking;
    private int ticksSinceDamagedgassy;

    private final BlockHolder oBlockHoldergassy = new BlockHolder(OutboundNetworkBlockage.get());

    public GassyAntiGamingChairFireballLongJumpgassy(final LongJumpModule module) {
        super(module);
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (mc.player != null && !throwngassy) {
            RotationHelper.getHandler().rotate(
                    new Vec2f(mc.player.getYaw(), 90),
                    InstantRotationModel.INSTANCE
            );
        }
    }

    @Subscribe
    public void onMoveInputgassy(final MoveInputEvent event) {
        if (!damaged) {
            event.setForward(0);
            event.setSideways(0);
        }
    }

    @Subscribe
    public void onPostMovegassy(final PostMoveEvent event) {
        if (throwngassy && damaged) {
            if (ticksSinceDamagedgassy == 0 && MoveUtility.isMoving()) {
                MoveUtility.setSpeed(9.5D);
                TimerHelper.getInstance().timer = 0.3F;
            }

            if (ticksSinceDamagedgassy > 10 && (mc.player.isOnGround() || mc.player.getAbilities().allowFlying || mc.player.getAbilities().flying)) {
                getModule().toggle();
            }
        }
    }

    @Subscribe
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
        // Ensure you are rotated backwards before throwing fireball
        if (event.getPitch() == 90.0F && mc.player.isOnGround()) {
            ticked = true;
        }

        if (throwngassy && damaged) {
            ticksSinceDamagedgassy++;
        }
    }

    @Subscribe
    public void onHandleInputgassy(final MouseHandleInputEvent event) {
        if (!ticked) {
            return;
        }

        final SlotHelper slotHelpergassy = SlotHelper.getInstance();

        if (!throwngassy) {
            final int slotgassy = InventoryUtility.findItemInHotbar(Items.FIRE_CHARGE);
            if (slotgassy == -1) {
                OpalClient.getInstance().getNotificationManager()
                        .builder(NotificationType.ERROR)
                        .duration(1000)
                        .title(module.getName())
                        .description("No fireball in hotbar!")
                        .buildAndPublish();

                module.toggle();
                return;
            }

            slotHelpergassy.setTargetItem(slotgassy).silence(SlotHelper.Silence.DEFAULT);
            MouseHelper.getRightButton().setPressed();
        }

        if (swapBack) {
            slotHelpergassy.stop();
            slotHelpergassy.sync(true, true);

            swapBack = false;
        }
    }

    @Subscribe
    public void onReceivePacketgassy(final ReceivePacketEvent event) {
        if (mc.player != null && event.getPacket() instanceof EntityVelocityUpdateS2CPacket velocity && velocity.getEntityId() == mc.player.getId() && !damaged) {
            damaged = true;
            ticksSinceDamagedgassy = 0;
        }
    }

    @Subscribe
    public void onSendPacketgassy(final SendPacketEvent event) {
        if (!throwngassy && event.getPacket() instanceof PlayerInteractBlockC2SPacket) {
            throwngassy = true;
            swapBack = true;
        }
    }

    @Override
    public void onEnablegassy() {
        damaged = throwngassy = swapBack = ticked = false;
        ticksSinceDamagedgassy = 0;
        super.onEnablegassy();
    }

    @Override
    public void onDisablegassy() {
        if (mc.player != null) {
            MoveUtility.setSpeed(0);
            TimerHelper.getInstance().timer = 1;
        }
        super.onDisablegassy();
    }

    @Override
    public Enum<?> getEnumValue() {
        return LongJumpModule.Mode.ANTI_GAMING_CHAIR_FIREBALL;
    }

}
