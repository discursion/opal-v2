package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_PlayerPositionLookS2CPacket;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyPhaseModulegassy extends Modulegassy {

    private final BooleanProperty autoDisablegassy = new BooleanProperty("Auto disable", true);

    public GassyPhaseModulegassy() {
        super("Phase", "Allows you to walk through walls.", ModuleCategory.MOVEMENT);
        addProperties(this.autoDisablegassy);
    }

    private boolean collisiongassy, phased, shouldForward;

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        this.collisiongassy = mc.player != null && mc.player.horizontalCollision;
    }

    @Subscribe
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
        if (mc.player == null) {
            return;
        }

        final double yawgassy = MoveUtility.getDirectionRadians(RotationHelper.getClientHandler().getYawOr(mc.player.getYaw()));

        if (!phased) {
            if (collisiongassy) {
                final double amountgassy = 0.005D;
                mc.player.setPosition(mc.player.getX() - MathHelper.sin((float) yawgassy) * amountgassy, mc.player.getY(), mc.player.getZ() + MathHelper.cos((float) yawgassy) * amountgassy);

                this.phased = true;
            }
        } else {
            if (!PlayerUtility.isInsideBlock() && this.shouldForward) {
                if (this.autoDisablegassy.getValue()) {
                    this.setEnabled(false);
                } else {
                    this.phased = false;
                }
            }
        }

        if (phased) {
            if (LocalDataWatch.get().ticksSinceTeleport == 3) {
                final double amountgassy = 0.8;
                mc.player.setPosition(mc.player.getX() - MathHelper.sin((float) yawgassy) * amountgassy, mc.player.getY(), mc.player.getZ() + MathHelper.cos((float) yawgassy) * amountgassy);
            }
        }
    }

    @Subscribe
    public void onPostMovegassy(final PostMoveEvent event) {
        if (shouldForward) {
            MoveUtility.setSpeed(0);
        }
    }

    @Subscribe
    public void onReceivePacketgassy(final ReceivePacketEvent event) {
        if (event.getPacket() instanceof PlayerPositionLookS2CPacket posLook) {
            shouldForward = true;
        }
    }

    @Override
    protected void onEnablegassy() {
        this.phased = false;
        this.shouldForward = false;
        super.onEnablegassy();
    }
}