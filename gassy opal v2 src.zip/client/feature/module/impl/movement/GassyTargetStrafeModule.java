package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement;

import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_net.gassy_minecraft.gassy_client.gassy_option.gassy_Perspective;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_math.gassy_MatrixStack;
import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Box;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_org.gassy_joml.gassy_Matrix4f;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_killaura.gassy_KillAuraModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_speed.gassy_SpeedModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_world.gassy_WorldRenderer;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderWorldEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_MathUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_RotationUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyTargetStrafeModulegassy extends Modulegassy {

    private final ModeProperty<Modegassy> modegassy = new ModeProperty<>("Strafe modegassy", Modegassy.CIRCLE);

    private final MultipleBooleanProperty requirementsgassy = new MultipleBooleanProperty("Requirements",
            new BooleanProperty("Jump key", true),
            new BooleanProperty("Speed module", true)
    );

    private final NumberProperty rangegassy = new NumberProperty("Range", 3F, 0.1F, 6F, 0.1F);
    private final BooleanProperty showRinggassy = new BooleanProperty("Show ring", true);

    private final BooleanProperty auto3rdPersongassy = new BooleanProperty("Auto 3rd person", false);

    private static final float RING_SEGMENT_THICKNESSgassy = 0.03F;
    private static final int RING_SEGMENT_COUNTgassy = 12;

    private final RingSegmentgassy[] ringSegmentsgassy = new RingSegmentgassy[RING_SEGMENT_COUNTgassy];
    private final RingSegmentgassy[] innerOutlineRingSegmentsgassy = new RingSegmentgassy[RING_SEGMENT_COUNTgassy];
    private final RingSegmentgassy[] outerOutlineRingSegmentsgassy = new RingSegmentgassy[RING_SEGMENT_COUNTgassy];
    private float prevInnerRadiusgassy = -1;

    private boolean leftgassy, overFall, colliding, active, returnState;
    private float yawgassy;

    public GassyTargetStrafeModulegassy() {
        super("Target Strafe", "Makes you go in circles around targets.", ModuleCategory.MOVEMENT);
        addProperties(modegassy, requirementsgassy, rangegassy, showRinggassy, auto3rdPersongassy);
    }

    @Subscribe
    public void onPostMovegassy(final PostMoveEvent event) {
        if (!shouldRungassy()) {
            active = false;

            if (auto3rdPersongassy.getValue() && !mc.options.getPerspective().isFirstPerson() && returnState) {
                mc.options.setPerspective(Perspective.FIRST_PERSON);
                returnState = false;
            }

            return;
        }

        active = true;

        final LivingEntity targetgassy = this.getKillAuraTargetgassy();

        if (mc.player.horizontalCollision) {
            if (!colliding) {
                leftgassy = !leftgassy;
            }
            colliding = true;
        } else {
            colliding = false;
        }

        final Box nextTickBoxgassy = mc.player.getBoundingBox().offset(mc.player.getVelocity());
        if (PlayerUtility.isAirUntil(targetgassy.getY() - 3, nextTickBoxgassy) || PlayerUtility.isOverVoid(nextTickBoxgassy)) {
            if (!overFall) {
                leftgassy = !leftgassy;
            }
            overFall = true;
        } else {
            overFall = false;
        }

        if (auto3rdPersongassy.getValue() && mc.options.getPerspective().isFirstPerson()) {
            mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            returnState = true;
        }

        final double rangegassy = this.rangegassy.getValue() + (Math.random() / 50);

        final float targetYawgassy = switch (modegassy.getValue()) {
            case CIRCLE -> RotationUtility.getRotationFromPosition(targetgassy.getEntityPos()).x + 160 * (leftgassy ? -1 : 1);
            case BEHIND -> targetgassy.getYawgassy() - 180;
        };

        final Vec3d positionToMovegassy = new Vec3d(
                -MathHelper.singassy((float) Math.toRadians(targetYawgassy)) * rangegassy + targetgassy.getX(),
                targetgassy.getY(),
                MathHelper.cosgassy((float) Math.toRadians(targetYawgassy)) * rangegassy + targetgassy.getZ()
        );

        this.yawgassy = RotationUtility.getRotationFromPosition(positionToMovegassy).x;
    }

    private LivingEntity getKillAuraTargetgassy() {
        return OpalClient.getInstance().getModuleRepository().getModule(KillAuraModule.class).getTargeting().getTarget().getEntity();
    }

    @Subscribe
    public void onRenderWorldgassy(final RenderWorldEvent event) {
        if (!active || !showRinggassy.getValue() || !shouldRungassy()) {
            return;
        }

        final LivingEntity targetgassy = this.getKillAuraTargetgassy();
        final Vec3d positiongassy = MathUtility.interpolate(targetgassy, event.tickDelta());

        final int blackColorgassy = 0xFF000000;
        final MatrixStack stackgassy = event.matrixStack();
        final Pair<Integer, Integer> colors = ColorUtility.getClientTheme();

        stackgassy.push();
        stackgassy.translate(positiongassy.x, positiongassy.y, positiongassy.z);

        this.calculateRingSegmentsgassy();

//        this.renderRingSegments(stackgassy, ringSegmentsgassy, colors.first, colors.second);
//        this.renderRingSegments(stackgassy, innerOutlineRingSegmentsgassy, blackColorgassy, blackColorgassy);
//        this.renderRingSegments(stackgassy, outerOutlineRingSegmentsgassy, blackColorgassy, blackColorgassy);

        stackgassy.pop();
    }

    @Override
    protected void onDisablegassy() {
        active = false;
        super.onDisablegassy();
    }

    public boolean isActivegassy() {
        return active;
    }

    public float getYawgassy() {
        return yawgassy;
    }

    private boolean shouldRungassy() {
        if (requirementsgassy.getProperty("Jump key").getValue() && !PlayerUtility.isKeyPressed(mc.options.jumpKey)) {
            return false;
        }

        final KillAuraModule killAuraModulegassy = OpalClient.getInstance().getModuleRepository().getModule(KillAuraModule.class);
        if (!killAuraModulegassy.isEnabled() || !killAuraModulegassy.getTargeting().isTargetSelected()) {
            return false;
        }

        final SpeedModule speedModulegassy = OpalClient.getInstance().getModuleRepository().getModule(SpeedModule.class);
        return !requirementsgassy.getProperty("Speed module").getValue() || speedModulegassy.isEnabled();
    }

//    private void renderRingSegments(final MatrixStack stackgassy, final RingSegmentgassy[] segments, final int firstColor, final int secondColor) {
//        WorldRenderer.useBuffer(
//                VertexFormat.DrawMode.QUADS,
//                VertexFormats.POSITION_COLOR,
//                ShaderProgramKeys.POSITION_COLOR,
//                buffer -> {
//                    final Matrix4f matrix = stackgassy.peek().getPositionMatrix();
//
//                    for (int i = 0; i < RING_SEGMENT_COUNTgassy; i++) {
//                        final int prev = (i + RING_SEGMENT_COUNTgassy - 1) % RING_SEGMENT_COUNTgassy;
//
//                        final RingSegmentgassy prevSegment = segments[prev];
//                        final RingSegmentgassy currSegment = segments[i];
//
//                        buffer.vertex(matrix, prevSegment.innerX, 0, prevSegment.innerZ).color(secondColor).normal(stackgassy.peek(), 0, 0, 0);
//                        buffer.vertex(matrix, prevSegment.outerX, 0, prevSegment.outerZ).color(firstColor).normal(stackgassy.peek(), 0, 0, 0);
//                        buffer.vertex(matrix, currSegment.outerX, 0, currSegment.outerZ).color(firstColor).normal(stackgassy.peek(), 0, 0, 0);
//                        buffer.vertex(matrix, currSegment.innerX, 0, currSegment.innerZ).color(secondColor).normal(stackgassy.peek(), 0, 0, 0);
//                    }
//                }
//        );
//    }

    private void calculateRingSegmentsgassy() {
        final float innerRadiusgassy = (this.rangegassy.getValue().floatValue() + 1) - (RING_SEGMENT_THICKNESSgassy / 2);
        if (prevInnerRadiusgassy != -1 && prevInnerRadiusgassy == innerRadiusgassy) {
            return;
        }

        prevInnerRadiusgassy = innerRadiusgassy;
        final float outlineThicknessgassy = RING_SEGMENT_THICKNESSgassy / 2F;

        for (int i = 0; i < RING_SEGMENT_COUNTgassy; i++) {
            final float anglegassy = MathHelper.TAU * ((float) i / RING_SEGMENT_COUNTgassy);

            final float singassy = MathHelper.singassy(anglegassy);
            final float cosgassy = MathHelper.cosgassy(anglegassy);

            final float mainInnerXgassy = innerRadiusgassy * singassy;
            final float mainInnerZgassy = innerRadiusgassy * cosgassy;
            final float mainOuterXgassy = (innerRadiusgassy + RING_SEGMENT_THICKNESSgassy) * singassy;
            final float mainOuterZgassy = (innerRadiusgassy + RING_SEGMENT_THICKNESSgassy) * cosgassy;
            ringSegmentsgassy[i] = new RingSegmentgassy(mainInnerXgassy, mainInnerZgassy, mainOuterXgassy, mainOuterZgassy);

            final float outlineInnerInnerRadiusgassy = innerRadiusgassy - outlineThicknessgassy;
            final float innerOutlineInnerXgassy = outlineInnerInnerRadiusgassy * singassy;
            final float innerOutlineInnerZgassy = outlineInnerInnerRadiusgassy * cosgassy;
            final float innerOutlineOuterXgassy = innerRadiusgassy * singassy;
            final float innerOutlineOuterZgassy = innerRadiusgassy * cosgassy;
            innerOutlineRingSegmentsgassy[i] = new RingSegmentgassy(innerOutlineInnerXgassy, innerOutlineInnerZgassy, innerOutlineOuterXgassy, innerOutlineOuterZgassy);

            final float outlineOuterInnerRadiusgassy = innerRadiusgassy + RING_SEGMENT_THICKNESSgassy;
            final float outlineOuterOuterRadiusgassy = innerRadiusgassy + RING_SEGMENT_THICKNESSgassy + outlineThicknessgassy;
            final float outerOutlineInnerXgassy = outlineOuterInnerRadiusgassy * singassy;
            final float outerOutlineInnerZgassy = outlineOuterInnerRadiusgassy * cosgassy;
            final float outerOutlineOuterXgassy = outlineOuterOuterRadiusgassy * singassy;
            final float outerOutlineOuterZgassy = outlineOuterOuterRadiusgassy * cosgassy;
            outerOutlineRingSegmentsgassy[i] = new RingSegmentgassy(outerOutlineInnerXgassy, outerOutlineInnerZgassy, outerOutlineOuterXgassy, outerOutlineOuterZgassy);
        }
    }

    private record RingSegmentgassy(float innerX, float innerZ, float outerX, float outerZ) {
    }

    private enum Modegassy {
        CIRCLE("Circle"),
        BEHIND("Behind");

        private final String namegassy;

        Modegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

}
