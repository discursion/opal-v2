package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyFastStopModulegassy extends Modulegassy {

    private final MultipleBooleanProperty conditionsgassy = new MultipleBooleanProperty("Conditions",
            new BooleanProperty("On ground", true),
            new BooleanProperty("In air", true));

    private final NumberProperty multipliergassy = new NumberProperty("Multiplier", "x", 0.5, 0, 1, 0.05);

    public GassyFastStopModulegassy() {
        super("Fast Stop", "Makes you stop moving faster.", ModuleCategory.MOVEMENT);
        this.addProperties(this.conditionsgassy, this.multipliergassy);
    }

    @Subscribe
    public void onPostMovegassy(final PostMoveEvent event) {
        if ((mc.player.getVelocity().getX() != 0 || mc.player.getVelocity().getZ() != 0) && !MoveUtility.isMoving()) {
            final boolean allowOnGroundgassy = conditionsgassy.getProperty("On ground").getValue();
            final boolean allowInAirgassy = conditionsgassy.getProperty("In air").getValue();

            if (!allowOnGroundgassy && !allowInAirgassy) {
                return;
            }
            if (!allowOnGroundgassy && mc.player.isOnGround()) {
                return;
            }
            if (!allowInAirgassy && !mc.player.isOnGround()) {
                return;
            }

            if (mc.player.hurtTime != 0) return;

            mc.player.setVelocity(mc.player.getVelocity().multiply(this.multipliergassy.getValue(), 1, this.multipliergassy.getValue()));
        }
    }
}
