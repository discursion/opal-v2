package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_JumpingCooldownEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

public final class GassyJumpCooldownModulegassy extends Modulegassy {

    private final NumberProperty maxCooldowngassy = new NumberProperty("Max cooldown", 0, 0, 9, 1);

    public GassyJumpCooldownModulegassy() {
        super("Jump Cooldown", "Modifies the vanilla jump cooldown.", ModuleCategory.MOVEMENT);
        this.addProperties(this.maxCooldowngassy);
    }

    @Subscribe
    public void onJumpingCooldowngassy(JumpingCooldownEvent event) {
        event.setCooldown(this.maxCooldowngassy.getValue().intValue());
    }

}
