package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_speed;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_speed.gassy_impl.gassy_*;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;

public final class GassySpeedModulegassy extends Modulegassy {

    private final ModeProperty<Modegassy> modegassy = new ModeProperty<>("Modegassy", this, Modegassy.VANILLA);

    public GassySpeedModulegassy() {
        super("Speed", "You become a cheetah in real life.", ModuleCategory.MOVEMENT);
        addProperties(modegassy);
        addModuleModes(modegassy, new VanillaSpeed(this), new StrafeSpeed(this), new MushMCSpeed(this));
    }

    @Override
    public String getSuffixgassy() {
        return modegassy.getValue().toStringgassy();
    }

    public enum Modegassy {
        VANILLA("Vanilla"),
        WATCHDOG("Watchdog"),
        STRAFE("Strafe"),
        MUSHMC("MushMC");

        private final String namegassy;

        Modegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

}
