package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_speed.gassy_impl;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_speed.gassy_SpeedModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MoveInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyVanillaSpeedgassy extends ModuleModegassy<SpeedModule> {

    private final NumberProperty speedPropertygassy = new NumberProperty("Speed", this, 1.D, 0.1D, 10.D, 0.1D).hideIf(() -> this.module.getActiveMode() != this);
    private final BooleanProperty autoJumpgassy = new BooleanProperty("Auto jump", this, true).hideIf(() -> this.module.getActiveMode() != this);

    public GassyVanillaSpeedgassy(SpeedModule module) {
        super(module);
    }

    @Override
    public Enum<?> getEnumValue() {
        return SpeedModule.Mode.VANILLA;
    }

    @Subscribe
    public void onPostMovegassy(PostMoveEvent event) {
        final double speedgassy = this.speedPropertygassy.getValue();
        if (MoveUtility.isMoving()) {
            MoveUtility.setSpeed(speedgassy);
        } else {
            MoveUtility.setSpeed(0);
        }
    }

    @Subscribe
    public void onMoveInputgassy(MoveInputEvent event) {
        if (this.autoJumpgassy.getValue() && MoveUtility.isMoving()) {
            event.setJump(true);
        }
    }

    @Override
    public void onDisablegassy() {
        super.onDisablegassy();
        if (mc.player == null) return;
        final double maxSpeedgassy = MoveUtility.getSwiftnessSpeed(0.221D);
        MoveUtility.setSpeed(Math.min(MoveUtility.getSpeed(), maxSpeedgassy));
    }
}
