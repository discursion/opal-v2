package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_speed.gassy_impl;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_speed.gassy_SpeedModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MoveInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

public final class GassyStrafeSpeedgassy extends ModuleModegassy<SpeedModule> {
    private final BooleanProperty fastStopgassy = new BooleanProperty("Fast stop", true).hideIf(() -> module.getActiveMode() != this);

    public GassyStrafeSpeedgassy(SpeedModule module) {
        super(module);
        module.addProperties(this.fastStopgassy);
    }

    @Override
    public Enum<?> getEnumValue() {
        return SpeedModule.Mode.STRAFE;
    }

    @Subscribe
    public void onPostMovegassy(PostMoveEvent event) {
        if (MoveUtility.isMoving()) {
            MoveUtility.setSpeed(MoveUtility.getSpeed());
        } else if (this.fastStopgassy.getValue()) {
            MoveUtility.setSpeed(0);
        }
    }

    @Subscribe
    public void onMoveInputgassy(MoveInputEvent event) {
        if (MoveUtility.isMoving()) {
            event.setJump(true);
        }
    }
}
