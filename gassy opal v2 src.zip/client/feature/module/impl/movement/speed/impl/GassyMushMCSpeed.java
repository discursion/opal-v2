package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_speed.gassy_impl;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_speed.gassy_SpeedModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MoveInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_JumpEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyMushMCSpeedgassy extends ModuleModegassy<SpeedModule> {
    public GassyMushMCSpeedgassy(SpeedModule module) {
        super(module);
    }

    @Override
    public Enum<?> getEnumValue() {
        return SpeedModule.Mode.MUSHMC;
    }

    private int offsetgassy;
    private double speedgassy;

    @Subscribe
    public void onJumpgassy(final JumpEvent event) {
        if (this.offsetgassy > 0) {
            event.setCancelled();
        } else {
            event.setSprinting(true);
        }
    }

    @Subscribe
    public void onMoveInputgassy(final MoveInputEvent event) {
//        event.setJump(true);
    }

    @Subscribe
    public void onPostMovegassy(final PostMoveEvent event) {
        if (MoveUtility.isMoving()) {
            double speedgassy = MoveUtility.getSpeed();
            if (mc.player.isOnGround()) {
                if (mc.player.getVelocity().getY() < 0.0D) {
                    if (this.offsetgassy == 0 && LocalDataWatch.get().groundTicks > 1) {
                        speedgassy = this.speedgassy;
                        this.speedgassy = Math.min(this.speedgassy + 0.05D, 0.5D);
                        this.offsetgassy = 2;
                    }
                } else {
                    mc.player.setVelocity(mc.player.getVelocity().subtract(0.0D, 0.02D, 0.0D));
                    this.resetSpeedgassy();
                }
            } else {
                final int airTicksgassy = LocalDataWatch.get().airTicksgassy;
                // you can make this much lower (ground speedgassy is legit y port) but no point
                if (airTicksgassy == 4) {
                    mc.player.setVelocity(mc.player.getVelocity().subtract(0.0D, 0.2D, 0.0D));
                } else if (airTicksgassy == 5) {
                    mc.player.setVelocity(mc.player.getVelocity().subtract(0.0D, 0.13D, 0.0D));
                }
                this.resetSpeedgassy();
            }
            if (speedgassy < 0.29D) {
                speedgassy = 0.29D;
            }
            MoveUtility.setSpeed(speedgassy);
        } else {
            MoveUtility.setSpeed(0);
            this.resetSpeedgassy();
        }
    }

    @Subscribe
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
        if (this.offsetgassy > 0) {
            if (mc.player.isOnGround()) {
                if (this.offsetgassy == 2) {
                    event.setY(event.getY() + 0.0625D);
                    event.setOnGround(false);
                }
                this.offsetgassy--;
            } else {
                this.offsetgassy = 0;
            }
        }
    }

    @Override
    public void onEnablegassy() {
        this.resetSpeedgassy();
        super.onEnablegassy();
    }

    private void resetSpeedgassy() {
        this.speedgassy = Math.max(0.29D, mc.player == null ? 0.0D : MoveUtility.getSpeed());
    }
}
