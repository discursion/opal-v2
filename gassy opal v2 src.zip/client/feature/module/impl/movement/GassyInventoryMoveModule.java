package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_screen.gassy_ChatScreen;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_DropdownClickGUI;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyInventoryMoveModulegassy extends Modulegassy {

    public GassyInventoryMoveModulegassy() {
        super("Inventory Move", "Allows you to move while in inventories.", ModuleCategory.MOVEMENT);
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (this.isBlockedgassy()) {
            return;
        }
        PlayerUtility.updateMovementKeyStates();
    }

    public boolean isBlockedgassy() {
        return mc.currentScreen instanceof ChatScreen || mc.currentScreen instanceof DropdownClickGUI;
    }
}
