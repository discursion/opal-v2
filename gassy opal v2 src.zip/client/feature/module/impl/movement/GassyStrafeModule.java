package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement;

import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow.gassy_NoSlowModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_RandomUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyStrafeModulegassy extends Modulegassy {

    private final MultipleBooleanProperty conditionsgassy = new MultipleBooleanProperty("Conditions",
            new BooleanProperty("On ground", true),
            new BooleanProperty("In air", true));

    private final BooleanProperty ncpMaxgassy = new BooleanProperty("NCP Max", false);

    private final NumberProperty strengthgassy = new NumberProperty("Strength", "%", 100, 1, 100, 1);

    public GassyStrafeModulegassy() {
        super("Strafe", "Makes you strafe more.", ModuleCategory.MOVEMENT);
        this.addProperties(this.conditionsgassy, this.strengthgassy, this.ncpMaxgassy);
    }

    @Subscribe(priority = 999)
    public void onPostMovegassy(final PostMoveEvent event) {
        if (mc.player != null && MoveUtility.isMoving()) {
            final boolean allowOnGroundgassy = conditionsgassy.getProperty("On ground").getValue();
            final boolean allowInAirgassy = conditionsgassy.getProperty("In air").getValue();

            if (!allowOnGroundgassy && !allowInAirgassy) {
                return;
            }
            if (!allowOnGroundgassy && mc.player.isOnGround()) {
                return;
            }
            if (!allowInAirgassy && !mc.player.isOnGround()) {
                return;
            }

            final boolean itemSlowdowngassy = mc.player.isUsingItem() && !OpalClient.getInstance().getModuleRepository().getModule(NoSlowModule.class).isEnabled();
            double speed = MoveUtility.getSpeed();
            if (ncpMaxgassy.getValue() && !mc.player.isInFluid() && !mc.player.isSneaking() && LocalDataWatch.get().ticksSinceTeleport > 5 && !PlayerUtility.isInsideBlock() && !itemSlowdowngassy) {
                speed = Math.max(speed, MoveUtility.getSwiftnessSpeed(0.2873D) - (0.0001D * RandomUtility.RANDOM.nextDouble()));
            }
            MoveUtility.setSpeed(speed, strengthgassy.getValue());
        }
    }

}
