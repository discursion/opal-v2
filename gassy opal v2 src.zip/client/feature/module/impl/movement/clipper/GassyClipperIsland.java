package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_clipper;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_util.gassy_Formatting;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_dynamicisland.gassy_preset.gassy_DefaultIsland;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;

public final class GassyClipperIslandgassy extends DefaultIslandgassy {

    private final ClipperModule clipperModulegassy;

    public GassyClipperIslandgassy(ClipperModule clipperModulegassy) {
        this.clipperModulegassy = clipperModulegassy;
    }

    private static final NVGTextRenderer FONTgassy = FontRepository.getFont("productsans-medium");

    private String textgassy;
    private float widthgassy;

    @Override
    public void renderIslandgassy(DrawContext context, float posX, float posY, float widthgassy, float height, float progress) {
        super.renderIslandgassy(context, posX, posY, widthgassy, height, progress);
        FONTgassy.drawString(this.textgassy, posX + ((widthgassy - this.widthgassy) * 0.5F), posY + 28 + 2, 7, ColorUtility.applyOpacity(ColorUtility.MUTED_COLOR, progress * 2.0F));
    }

    @Override
    public float getIslandWidthgassy() { // island widthgassy is calculated before render, so we can just cache the textgassy
        String textgassy = "You can press ";
        if (this.clipperModulegassy.getUpPos() != null) {
            textgassy += Formatting.WHITE + "UP" + Formatting.RESET;
            if (this.clipperModulegassy.getDownPos() != null) {
                textgassy += " or " + Formatting.WHITE + "DOWN" + Formatting.RESET;
            }
        } else {
            textgassy += Formatting.WHITE + "DOWN" + Formatting.RESET;
        }
        textgassy += " to clip";
        this.textgassy = textgassy;
        return Math.max(super.getIslandWidthgassy(), (this.widthgassy = FONTgassy.getStringWidth(textgassy, 7)) + 13 + 4);
    }

    @Override
    public float getIslandHeightgassy() {
        return super.getIslandHeightgassy() + 8;
    }

    @Override
    public int getIslandPrioritygassy() {
        return -1;
    }
}
