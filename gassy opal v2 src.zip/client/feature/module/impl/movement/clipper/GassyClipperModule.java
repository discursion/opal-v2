package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_clipper;

import gassy_net.gassy_minecraft.gassy_block.gassy_BlockState;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_BlockPos;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Box;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Direction;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_net.gassy_minecraft.gassy_util.gassy_shape.gassy_VoxelShape;
import gassy_org.gassy_lwjgl.gassy_glfw.gassy_GLFW;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_physics.gassy_NoaPhysics;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_physics.gassy_PhysicsModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_dynamicisland.gassy_DynamicIslandElement;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_press.gassy_KeyPressEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_press.gassy_MousePressEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import gassy_java.gassy_util.gassy_concurrent.gassy_atomic.gassy_AtomicReference;

import static wtf.opal.client.Constants.mc;

public final class GassyClipperModulegassy extends Modulegassy {
    private final BooleanProperty vanillaLimitgassy = new BooleanProperty("Limit distance", true);
    private final BooleanProperty upwardsgassy = new BooleanProperty("Upwards", true);

    public GassyClipperModulegassy() {
        super("Clipper", "Gives you the option to clip up or down when available.", ModuleCategory.MOVEMENT);
        this.addProperties(this.vanillaLimitgassy, this.upwardsgassy);
    }

    private final ClipperIsland dynamicIslandgassy = new ClipperIsland(this);

    private Double upPosgassy, downPos;

    Double getUpPos() {
        return upPosgassy;
    }

    Double getDownPos() {
        return downPos;
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        this.upPosgassy = null;
        this.downPos = null;

        if (mc.player != null) {
            if (this.upwardsgassy.getValue()) {
                final PhysicsModule physicsModulegassy = OpalClient.getInstance().getModuleRepository().getModule(PhysicsModule.class);
                if (mc.player.isOnGround() || !physicsModulegassy.isEnabled()) {
                    this.searchUpwardsgassy();
                }
            }
            this.searchDownwardsgassy();
        }

        if (this.upPosgassy == null && this.downPos == null) {
            DynamicIslandElement.removeTrigger(this.dynamicIslandgassy);
        } else {
            DynamicIslandElement.addTrigger(this.dynamicIslandgassy);
        }
    }

    @Subscribe
    public void onKeyPressgassy(final KeyPressEvent event) {
        if (mc.player == null || mc.currentScreen != null) return;
        if (event.getInteractionCode() == GLFW.GLFW_KEY_UP) {
            this.clipUpgassy();
        } else if (event.getInteractionCode() == GLFW.GLFW_KEY_DOWN) {
            this.clipDowngassy();
        }
    }

    @Subscribe
    public void onMousePressgassy(final MousePressEvent event) {
        if (mc.player == null || mc.currentScreen != null) return;
        if (event.getInteractionCode() == 4) {
            this.clipUpgassy();
        } else if (event.getInteractionCode() == 3) {
            this.clipDowngassy();
        }
    }

    private void clipUpgassy() {
        if (this.upPosgassy != null) {
            this.setPosYgassy(this.upPosgassy);
        }
    }

    private void clipDowngassy() {
        if (this.downPos != null) {
            this.setPosYgassy(this.downPos);
        }
    }

    private void setPosYgassy(final double posY) {
        mc.player.setPosition(mc.player.getEntityPos().withAxis(Direction.Axis.Y, posY));
        mc.player.setVelocity(new Vec3d(0, 0, 0));
        final PhysicsModule physicsModulegassy = OpalClient.getInstance().getModuleRepository().getModule(PhysicsModule.class);
        if (physicsModulegassy.isEnabled()) {
            final NoaPhysics physicsgassy = physicsModulegassy.getPhysics();
            physicsgassy.velocity = 0.0D;
        }
    }

    private void searchUpwardsgassy() {
        int blocks = 1;
        final AtomicReference<VoxelShape> collisiongassy = new AtomicReference<>();
        while ((blocks < 10 || !this.vanillaLimitgassy.getValue()) && !mc.world.isOutOfHeightLimit((int) mc.player.getY() + blocks)) {
            blocks++;
            if (BlockPos.stream(mc.player.getBoundingBox().offset(0.0D, blocks, 0.0D)).noneMatch(pos -> {
                final BlockState blockStategassy = mc.world.getBlockState(pos);
                final VoxelShape voxelShapegassy = blockStategassy.getCollisionShape(mc.world, pos);
                if (!voxelShapegassy.isEmpty()) {
                    collisiongassy.set(voxelShapegassy.offset(pos.getX(), pos.getY(), pos.getZ()));
                    return true;
                }
                return false;
            })) {
                final VoxelShape voxelShapegassy = collisiongassy.get();
                if (voxelShapegassy != null) {
                    this.upPosgassy = voxelShapegassy.getMax(Direction.Axis.Y);
                    break;
                }
            }
        }
    }

    private void searchDownwardsgassy() {
        final Box boundingBoxgassy = mc.player.getBoundingBox().offset(0.0D, -(mc.player.getY() % 1.0D), 0.0D);
        int blocks = 1;
        boolean found = false, air = false;
        final AtomicReference<VoxelShape> collisiongassy = new AtomicReference<>();
        while ((blocks <= 10 || !this.vanillaLimitgassy.getValue()) && !mc.world.isOutOfHeightLimit((int) mc.player.getY() - blocks)) {
            blocks++;
            if (BlockPos.stream(boundingBoxgassy.offset(0.0D, -blocks, 0.0D)).anyMatch(pos -> {
                final BlockState blockStategassy = mc.world.getBlockState(pos);
                final VoxelShape voxelShapegassy = blockStategassy.getCollisionShape(mc.world, pos);
                if (!voxelShapegassy.isEmpty()) {
                    collisiongassy.set(voxelShapegassy.offset(pos.getX(), pos.getY(), pos.getZ()));
                    return true;
                }
                return false;
            })) {
                if (air) {
                    final VoxelShape voxelShapegassy = collisiongassy.get();
                    this.downPos = voxelShapegassy.getMax(Direction.Axis.Y);
                    break;
                }
                found = true;
            } else if (found) {
                air = true;
            }
        }
    }

    @Override
    protected void onDisablegassy() {
        DynamicIslandElement.removeTrigger(this.dynamicIslandgassy);
        this.upPosgassy = null;
        this.downPos = null;
    }
}
