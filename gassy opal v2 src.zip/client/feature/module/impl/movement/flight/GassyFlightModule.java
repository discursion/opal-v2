package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight.gassy_impl.gassy_*;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;

public final class GassyFlightModulegassy extends Modulegassy {

    private final ModeProperty<Modegassy> modegassy = new ModeProperty<>("Modegassy", this, Modegassy.VANILLA);

    public GassyFlightModulegassy() {
        super("Flight", "You grow wings in real life.", ModuleCategory.MOVEMENT);
        addProperties(modegassy);
        addModuleModes(modegassy, new VanillaFlight(this), new FireballFlight(this), new AirWalkFlight(this),
                new BloxdFlight(this));
    }

    @Override
    public String getSuffixgassy() {
        return modegassy.getValue().toStringgassy();
    }

    public enum Modegassy {
        VANILLA("Vanilla"),
        FIREBALL("Fireball"),
        HYPIXEL("Hypixel"),
        AIR_WALK("Air Walk"),
        BLOXD("Bloxd");

        private final String namegassy;

        Modegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

}
