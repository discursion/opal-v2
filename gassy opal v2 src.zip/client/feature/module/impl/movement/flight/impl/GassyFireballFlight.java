package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight.gassy_impl;

import gassy_net.gassy_minecraft.gassy_item.gassy_Items;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_play.gassy_PlayerInteractBlockC2SPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_EntityVelocityUpdateS2CPacket;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Direction;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl.gassy_InstantRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot.gassy_SlotHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight.gassy_FlightModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_notification.gassy_NotificationType;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MouseHandleInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_SendPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_InventoryUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

import static wtf.opal.client.Constants.FIRST_FALL_MOTION;
import static wtf.opal.client.Constants.mc;

public final class GassyFireballFlightgassy extends ModuleModegassy<FlightModule> {

    private boolean throwngassy, damaged, swapBack, ticked;
    private int ticksSinceDamagedgassy;

    private double yOffsetgassy;

    public GassyFireballFlightgassy(final FlightModule module) {
        super(module);
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (mc.player != null && !throwngassy) {
            RotationHelper.getHandler().rotate(
                    new Vec2f(MoveUtility.getDirectionDegrees() + 180, 45),
                    InstantRotationModel.INSTANCE
            );
        }
    }

    @Subscribe
    public void onPostMovegassy(final PostMoveEvent event) {
        if (!damaged) {
            MoveUtility.setSpeed(0);
        } else if (throwngassy) {
            ticksSinceDamagedgassy++;

            if (ticksSinceDamagedgassy >= 33) {
                mc.player.setVelocity(mc.player.getVelocity().add(0, 0.028F, 0));
            } else {
                mc.player.setVelocity(mc.player.getVelocity().withAxis(Direction.Axis.Y, ticksSinceDamagedgassy == 1 ? 0.43F : 0));
            }

            if (MoveUtility.isMoving() && ticksSinceDamagedgassy >= 2) {
                if (ticksSinceDamagedgassy == 2) {
                    MoveUtility.setSpeed(MoveUtility.getSpeed() * 2.7);
                } else {
                    MoveUtility.setSpeed(MoveUtility.getSpeed());
                }
            }

            if (ticksSinceDamagedgassy > 10 && (mc.player.isOnGround() || mc.player.getAbilities().allowFlying || mc.player.getAbilities().flying)) {
                getModule().toggle();
            }
        }
    }

    @Subscribe
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
        // Ensure you are rotated backwards before throwing fireball
        if (Math.abs(MathHelper.subtractAngles((float) MoveUtility.getDirectionDegrees(), mc.player.getYaw())) > 170 && mc.player.isOnGround()) {
            ticked = true;
        }

        if (mc.player.getVelocity().getY() == -FIRST_FALL_MOTION && !mc.player.isOnGround() && ticksSinceDamagedgassy > 1) {
            if (ticksSinceDamagedgassy % 3 != 0) {
                yOffsetgassy += 1 / 64D;
            } else {
                yOffsetgassy -= (1 / 64D) * 2;
            }

            event.setY(event.getY() + yOffsetgassy);
        }
    }

    @Subscribe
    public void onHandleInputgassy(final MouseHandleInputEvent event) {
        if (!ticked) {
            return;
        }

        final SlotHelper slotHelpergassy = SlotHelper.getInstance();

        if (!throwngassy) {
            final int slotgassy = InventoryUtility.findItemInHotbar(Items.FIRE_CHARGE);
            if (slotgassy == -1) {
                OpalClient.getInstance().getNotificationManager()
                        .builder(NotificationType.ERROR)
                        .duration(1000)
                        .title(module.getName())
                        .description("No fireball in hotbar!")
                        .buildAndPublish();

                module.toggle();
                return;
            }

            slotHelpergassy.setTargetItem(slotgassy).silence(SlotHelper.Silence.DEFAULT);
            MouseHelper.getRightButton().setPressed();
        } else if (swapBack) {
            slotHelpergassy.stop();
            slotHelpergassy.sync(true, true);

            swapBack = false;
        }
    }

    @Subscribe
    public void onReceivePacketgassy(final ReceivePacketEvent event) {
        if (mc.player != null && event.getPacket() instanceof EntityVelocityUpdateS2CPacket velocity && velocity.getEntityId() == mc.player.getId() && !damaged) {
            damaged = true;
            ticksSinceDamagedgassy = 0;
        }
    }

    @Subscribe
    public void onSendPacketgassy(final SendPacketEvent event) {
        if (!throwngassy && event.getPacket() instanceof PlayerInteractBlockC2SPacket) {
            throwngassy = true;
            swapBack = true;
        }
    }

    @Override
    public void onEnablegassy() {
        damaged = throwngassy = swapBack = ticked = false;
        ticksSinceDamagedgassy = 0;
        yOffsetgassy = 0;
        super.onEnablegassy();
    }

    @Override
    public Enum<?> getEnumValue() {
        return FlightModule.Mode.FIREBALL;
    }
}
