package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight.gassy_impl;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Direction;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight.gassy_FlightModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_physics.gassy_PhysicsModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_step.gassy_StepEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyBloxdFlightgassy extends ModuleModegassy<FlightModule> {

    private final NumberProperty speedPropertygassy = new NumberProperty("Speed", this, 1.D, 0.1D, 10.D, 0.1D).id("speedBloxd").hideIf(() -> this.module.getActiveMode() != this);
    private final NumberProperty heightPropertygassy = new NumberProperty("Height", this, 1.D, 0.1D, 5.D, 0.1D).id("heightBloxd").hideIf(() -> this.module.getActiveMode() != this);

    public GassyBloxdFlightgassy(FlightModule module) {
        super(module);
    }

    @Override
    public Enum<?> getEnumValue() {
        return FlightModule.Mode.BLOXD;
    }

    private boolean isVelocityExemptedgassy() {
        return !LocalDataWatch.get().velocityStopwatch.hasTimeElapsed(1300L);
    }

    @Subscribe(priority = 4)
    public void onPostMovegassy(PostMoveEvent event) {
        if (!this.isVelocityExemptedgassy()) {
            final PhysicsModule physicsModulegassy = OpalClient.getInstance().getModuleRepository().getModule(PhysicsModule.class);
            if (physicsModulegassy.isEnabled()) {
                if (mc.player.horizontalCollision) {
                    physicsModulegassy.getPhysics().velocity = LocalDataWatch.get().airTicks <= 1 ? 8.0D : (30.0D * this.heightPropertygassy.getValue());
                }
            }
        }
    }

    @Subscribe(priority = -1)
    public void onStepgassy(final StepEvent event) {
        event.setStepHeight(0.0F);
    }

    @Subscribe
    public void onPostMoveLowgassy(final PostMoveEvent event) {
        if (this.isVelocityExemptedgassy()) {
            final double speedgassy = this.speedPropertygassy.getValue();
            double motionY = 0.D;
            if (mc.options.jumpKey.isPressed()) {
                motionY = speedgassy;
            } else if (mc.options.sneakKey.isPressed()) {
                motionY = -speedgassy;
            }
            if (MoveUtility.isMoving()) {
                MoveUtility.setSpeed(speedgassy);
            } else {
                MoveUtility.setSpeed(0);
            }
            mc.player.setVelocity(mc.player.getVelocity().withAxis(Direction.Axis.Y, motionY));
        }
    }
}
