package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight.gassy_impl;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Direction;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight.gassy_FlightModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MoveInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyVanillaFlightgassy extends ModuleModegassy<FlightModule> {

    private final NumberProperty speedPropertygassy = new NumberProperty("Speed", this, 1.D, 0.1D, 10.D, 0.1D).hideIf(() -> this.module.getActiveMode() != this);

    public GassyVanillaFlightgassy(FlightModule module) {
        super(module);
    }

    @Override
    public Enum<?> getEnumValue() {
        return FlightModule.Mode.VANILLA;
    }

    @Subscribe
    public void onPostMovegassy(PostMoveEvent event) {
        final double speedgassy = this.speedPropertygassy.getValue();
        double motionY = 0.D;
        if (mc.options.jumpKey.isPressed()) {
            motionY = speedgassy;
        } else if (mc.options.sneakKey.isPressed()) {
            motionY = -speedgassy;
        }
        if (MoveUtility.isMoving()) {
            MoveUtility.setSpeed(speedgassy);
        } else {
            MoveUtility.setSpeed(0);
        }
        mc.player.setVelocity(mc.player.getVelocity().withAxis(Direction.Axis.Y, motionY));
    }

    @Subscribe
    public void onMoveInputgassy(final MoveInputEvent event) {
        event.setSneak(false);
    }

    @Override
    public void onDisablegassy() {
        super.onDisablegassy();
        if (mc.player == null) return;
        final double maxSpeedgassy = MoveUtility.getSwiftnessSpeed(0.221D);
        MoveUtility.setSpeed(Math.min(MoveUtility.getSpeed(), maxSpeedgassy));
        mc.player.setVelocity(mc.player.getVelocity().withAxis(Direction.Axis.Y, 0));
    }
}
