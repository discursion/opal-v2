package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight.gassy_impl;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_BlockPos;
import gassy_net.gassy_minecraft.gassy_util.gassy_shape.gassy_VoxelShapes;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight.gassy_FlightModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_world.gassy_BlockShapeEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import static wtf.opal.client.Constants.mc;

public final class GassyAirWalkFlightgassy extends ModuleModegassy<FlightModule> {
    public GassyAirWalkFlightgassy(FlightModule module) {
        super(module);
    }

    @Subscribe
    public void onBlockShapegassy(BlockShapeEvent event) {
        BlockPos blockPos = event.getBlockPos();
        if (blockPos.getY() < mc.player.getY() && event.getBlockState().isAir()) {
            event.setVoxelShape(VoxelShapes.cuboid(-2.0D, 0.0D, -2.0D, 2.0D, 1.0D, 2.0D));
        }
    }

    @Override
    public Enum<?> getEnumValue() {
        return FlightModule.Mode.AIR_WALK;
    }
}
