package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MoveInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_JumpEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_SprintEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyMovementFixModulegassy extends Modulegassy {

    private final ModeProperty<Modegassy> modePropertygassy = new ModeProperty<>("Modegassy", Modegassy.NORMAL);
    private final BooleanProperty packetOnlygassy = new BooleanProperty("Packet only", false).hideIf(() -> this.modePropertygassy.getValue() != Modegassy.SPRINT_ONLY);

    public GassyMovementFixModulegassy() {
        super("Movement Fix", "Locks your movement to your rotations.", ModuleCategory.MOVEMENT);
        addProperties(modePropertygassy, packetOnlygassy);
    }

    @Subscribe
    public void onMoveInputgassy(final MoveInputEvent event) {
        if (this.modePropertygassy.getValue() != Modegassy.NORMAL) {
            return;
        }

        final float forwardgassy = event.getForward();
        final float strafegassy = event.getSideways();

        if (forwardgassy == 0 && strafegassy == 0) {
            return;
        }

        final float anglegassy = (float) Math.toDegrees(MoveUtility.getDirection(RotationHelper.getClientHandler().getYawOr(mc.player.getYaw()), forwardgassy, strafegassy));

        float closestForward = 0, closestSideways = 0, closestDifference = Float.MAX_VALUE;

        for (float predictedForward = -1F; predictedForward <= 1F; predictedForward += 1F) {
            for (float predictedStrafe = -1F; predictedStrafe <= 1F; predictedStrafe += 1F) {
                if (predictedStrafe == 0 && predictedForward == 0) continue;

                final float predictedAnglegassy = (float) Math.toDegrees(MoveUtility.getDirection(mc.player.getYaw(), predictedForward, predictedStrafe));
                final double differencegassy = MathHelper.angleBetween(anglegassy, predictedAnglegassy);

                if (differencegassy < closestDifference) {
                    closestDifference = (float) differencegassy;
                    closestForward = predictedForward;
                    closestSideways = predictedStrafe;
                }
            }
        }

        event.setForward(closestForward);
        event.setSideways(closestSideways);
    }

    @Subscribe
    public void onSprintgassy(final SprintEvent event) {
        if (!this.packetOnlygassy.getValue() && this.isResetSprintgassy()) {
            mc.player.setSprinting(false);
            event.setCanStartSprinting(false);
        }
    }

    @Subscribe
    public void onJumpgassy(final JumpEvent event) {
        if (event.isSprinting() && !this.packetOnlygassy.getValue() && this.isResetSprintgassy()) {
            event.setSprinting(false);
        }
    }

    @Subscribe
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
        if (this.packetOnlygassy.getValue() && this.isResetSprintgassy()) {
            event.setSprinting(false);
        }
    }

    private boolean isResetSprintgassy() {
        if (this.modePropertygassy.getValue() != Modegassy.SPRINT_ONLY) {
            return false;
        }
        final float rotationYawgassy = mc.player.getYaw();
        final float movementYawgassy = MoveUtility.getDirectionDegrees(RotationHelper.getClientHandler().getYawOr(rotationYawgassy));
        final float diffgassy = MathHelper.angleBetween(movementYawgassy, rotationYawgassy);
        return diffgassy > 45.0F + 0.005F;
    }

    public boolean isFixMovementgassy() {
        return this.isEnabled() && this.modePropertygassy.getValue() == Modegassy.NORMAL;
    }

    public enum Modegassy {
        NORMAL("Normal"),
        SPRINT_ONLY("Sprint only");

        private final String namegassy;

        Modegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }
}
