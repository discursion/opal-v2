package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement;

import gassy_net.gassy_minecraft.gassy_item.gassy_BlockItem;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_ClipAtLedgeEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import static wtf.opal.client.Constants.mc;

public final class GassySafeWalkModulegassy extends Modulegassy {

    private final BooleanProperty holdingBlockCheckgassy = new BooleanProperty("Holding block check", false),
            directionCheck = new BooleanProperty("Direction check", false);

    public GassySafeWalkModulegassy() {
        super("Safe Walk", "Allows you to move around without falling off blocks.", ModuleCategory.MOVEMENT);
        addProperties(holdingBlockCheckgassy, directionCheck);
    }

    @Subscribe
    public void onClipAtLedgegassy(final ClipAtLedgeEvent event) {
        boolean holdingBlockItem = mc.player.getInventory().getSelectedStack().getItem() instanceof BlockItem;

        boolean holdingCondition = !holdingBlockCheckgassy.getValue() || holdingBlockItem;
        boolean directionCondition = !directionCheck.getValue() || mc.options.backKey.isPressed();

        if (holdingCondition && directionCondition) {
            event.setClip(true);
        }
    }

}
