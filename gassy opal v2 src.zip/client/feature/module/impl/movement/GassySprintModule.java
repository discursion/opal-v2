package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement;

import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_KeepSprintEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import static wtf.opal.client.Constants.mc;

public final class GassySprintModulegassy extends Modulegassy {

    private final BooleanProperty omniSprintgassy = new BooleanProperty("Omnidirectional", false);
    private final BooleanProperty keepSprintgassy = new BooleanProperty("Keep sprint", true);

    public GassySprintModulegassy() {
        super("Sprint", "Modifies the logic behind sprinting.", ModuleCategory.MOVEMENT);
        addProperties(omniSprintgassy, keepSprintgassy);
        setEnabled(true);
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        mc.options.sprintKey.setPressed(true);
    }

    @Subscribe
    public void onKeepSprintgassy(final KeepSprintEvent event) {
        if (!keepSprintgassy.getValue()) return;

        event.setCancelled();
    }

    public static boolean isOmniSprintgassy() {
        final GassySprintModulegassy sprintModulegassy = OpalClient.getInstance().getModuleRepository().getModule(GassySprintModulegassy.class);
        return sprintModulegassy.isEnabled() && sprintModulegassy.omniSprintgassy.getValue();
    }
}
