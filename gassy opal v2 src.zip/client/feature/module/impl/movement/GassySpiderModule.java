package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Direction;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_physics.gassy_PhysicsModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import static wtf.opal.client.Constants.mc;

public final class GassySpiderModulegassy extends Modulegassy {
    private final NumberProperty speedPropertygassy = new NumberProperty("Speed", 0.5D, 0.1D, 10.D, 0.1D).hideIf(this::isBloxdgassy);

    public GassySpiderModulegassy() {
        super("Spider", "Lets you climb walls.", ModuleCategory.MOVEMENT);
        this.addProperties(this.speedPropertygassy);
    }

    private boolean isBloxdgassy() {
        return OpalClient.getInstance().getModuleRepository().getModule(PhysicsModule.class).isEnabled();
    }

    @Subscribe(priority = 5)
    public void onPostMovegassy(final PostMoveEvent event) {
        if (mc.player.horizontalCollision && !mc.player.isClimbing()) {
            final PhysicsModule physicsModulegassy = OpalClient.getInstance().getModuleRepository().getModule(PhysicsModule.class);
            if (physicsModulegassy.isEnabled()) {
                physicsModulegassy.getPhysics().velocity = 8.0D;
            } else {
                mc.player.setVelocity(mc.player.getVelocity().withAxis(Direction.Axis.Y, this.speedPropertygassy.getValue()));
            }
        }
    }
}
