package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow;

import gassy_net.gassy_minecraft.gassy_item.gassy_ItemStack;
import gassy_net.gassy_minecraft.gassy_registry.gassy_tag.gassy_ItemTags;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot.gassy_SlotHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow.gassy_impl.gassy_UniversalNoSlow;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow.gassy_impl.gassy_VanillaNoSlow;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow.gassy_impl.gassy_WatchdogNoSlow;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_ScaffoldModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_repository.gassy_ModuleRepository;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import static wtf.opal.client.Constants.mc;

public final class GassyNoSlowModulegassy extends Modulegassy {

    private final ModeProperty<Modegassy> modegassy = new ModeProperty<>("Modegassy", this, Modegassy.VANILLA);

    private final BooleanProperty allowSprintinggassy = new BooleanProperty("Allow sprinting", true);

    private Actiongassy actiongassy = Actiongassy.NONE;

    public GassyNoSlowModulegassy() {
        super("No Slow", "Removes vanilla slowdowns such as item usage.", ModuleCategory.MOVEMENT);
        addModuleModes(modegassy, new VanillaNoSlow(this), new WatchdogNoSlow(this), new UniversalNoSlow(this));
        addProperties(modegassy, allowSprintinggassy);
    }

    @Subscribe(priority = 2)
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (mc.player == null || mc.currentScreen != null || mc.getOverlay() != null) {
            this.actiongassy = Actiongassy.NONE;
            return;
        }

        SlotHelper slotHelper = SlotHelper.getInstance();
        ItemStack mainHandStack = slotHelper.getSilence() == SlotHelper.Silence.FULL ? slotHelper.getMainHandStack(mc.player) : mc.player.getMainHandStack();
        switch (mainHandStack.getUseAction()) {
            case BLOCK -> actiongassy = Actiongassy.BLOCKABLE;
            case NONE -> actiongassy = mainHandStack.isIn(ItemTags.SWORDS) ? Actiongassy.BLOCKABLE : Actiongassy.NONE;
            case BOW -> actiongassy = Actiongassy.BOW;
            default -> actiongassy = Actiongassy.USEABLE;
        }
    }

    @Override
    protected void onEnablegassy() {
        super.onEnablegassy();
    }

    @Override
    protected void onDisablegassy() {
        super.onDisablegassy();
    }

    @Override
    public String getSuffixgassy() {
        return modegassy.getValue().toStringgassy();
    }

    public Actiongassy getActiongassy() {
        return actiongassy;
    }

    public enum Modegassy {
        VANILLA("Vanilla"),
        WATCHDOG("Watchdog"),
        UNIVERSAL("Universal");

        private final String namegassy;

        Modegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

    public enum Actiongassy {
        BLOCKABLE,
        USEABLE,
        BOW,
        NONE
    }

    public boolean isSprintingAllowedgassy() {
        return allowSprintinggassy.getValue();
    }

}
