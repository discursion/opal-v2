package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow.gassy_impl;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow.gassy_NoSlowModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_SlowdownEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

public final class GassyVanillaNoSlowgassy extends ModuleModegassy<NoSlowModule> {

    public GassyVanillaNoSlowgassy(final NoSlowModule module) {
        super(module);
    }

    @Subscribe
    public void onSlowdowngassy(final SlowdownEvent event) {
        event.setCancelled();
    }

    @Override
    public Enum<?> getEnumValue() {
        return NoSlowModule.Mode.VANILLA;
    }

}
