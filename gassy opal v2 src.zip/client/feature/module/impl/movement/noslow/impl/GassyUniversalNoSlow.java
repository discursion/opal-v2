package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow.gassy_impl;

import gassy_net.gassy_minecraft.gassy_block.gassy_Block;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_EntityStatusS2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseButton;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_holder.gassy_BlockHolder;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_OutboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow.gassy_NoSlowModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_ScaffoldModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_repository.gassy_ModuleRepository;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MouseHandleInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MoveInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_SlowdownEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_InventoryUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyUniversalNoSlowgassy extends ModuleModegassy<NoSlowModule> {

    private final BooleanProperty slowdowngassy = new BooleanProperty("Slow down", false).hideIf(() -> this.module.getActiveMode() != this);

    public GassyUniversalNoSlowgassy(final NoSlowModule module) {
        super(module);
        module.addProperties(slowdowngassy);
    }

    private final BlockHolder oBlockHoldergassy = new BlockHolder(OutboundNetworkBlockage.get());
    private boolean stopUsegassy;

    @Subscribe
    public void onSlowdowngassy(final SlowdownEvent event) {
        if (!slowdowngassy.getValue()) {
            event.setCancelled();
        }
    }

    @Subscribe
    public void onReceivePacketgassy(final ReceivePacketEvent event) {
        if (event.getPacket() instanceof EntityStatusS2CPacket statusS2CPacket) {
            if (mc.player != null && statusS2CPacket.getEntity(mc.world) == mc.player) {
                this.oBlockHoldergassy.releasegassy();
            }
        }
    }

    @Subscribe(priority = 2)
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        final ModuleRepository moduleRepositorygassy = OpalClient.getInstance().getModuleRepository();
        final boolean shouldStopgassy = moduleRepositorygassy.getModule(ScaffoldModule.class).isEnabled();

        if (shouldStopgassy || mc.player == null || mc.currentScreen != null || mc.getOverlay() != null) {
            this.releasegassy();
            return;
        }

        if (this.stopUsegassy) {
            this.blockgassy();
            MouseHelper.getRightButton().setDisabled();

            this.stopUsegassy = false;
        } else if (module.getAction() == NoSlowModule.Action.BLOCKABLE || !mc.player.isUsingItem()) {
            this.releasegassy();
        }
    }

    private void blockgassy() {
        this.oBlockHoldergassy.blockgassy();
    }

    private void releasegassy() {
        this.oBlockHoldergassy.releasegassy();
    }

    @Subscribe(priority = 1)
    public void onMouseHandleInputgassy(final MouseHandleInputEvent event) {
        if (mc.player == null) {
            return;
        }

        final MouseButton rightButtongassy = MouseHelper.getRightButton();
        if (module.getAction() == NoSlowModule.Action.BLOCKABLE) {
            if (rightButtongassy.isPressed()) {
                if (!mc.player.input.playerInput.jump() || !mc.player.isOnGround() && (mc.player.getVelocity().getY() >= 0.0D || PlayerUtility.isBoxEmpty(mc.player.getBoundingBox().offset(0.0D, mc.player.getVelocity().getY(), 0.0D)))) {
                    if (!mc.player.isUsingItem() || !this.oBlockHoldergassy.isBlocking()) {
                        final Block blockOvergassy = PlayerUtility.getBlockOver();
                        if (InventoryUtility.isBlockInteractable(blockOvergassy) || mc.interactionManager.isBreakingBlock()) {
                            return;
                        }

                        this.stopUsegassy = true;

                        rightButtongassy.setPressed();
                    } else if (mc.player.isUsingItem()) {
                        rightButtongassy.setDisabled();
                    }
                } else {
                    rightButtongassy.setDisabled();
                }
            }
        } else {
            this.stopUsegassy = false;
        }
    }

    @Override
    public void onDisablegassy() {
        this.releasegassy();
        this.stopUsegassy = false;
        super.onDisablegassy();
    }

    @Override
    public Enum<?> getEnumValue() {
        return NoSlowModule.Mode.UNIVERSAL;
    }

}
