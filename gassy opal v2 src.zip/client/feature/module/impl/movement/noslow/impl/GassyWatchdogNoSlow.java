package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow.gassy_impl;

import gassy_net.gassy_minecraft.gassy_block.gassy_Block;
import gassy_net.gassy_minecraft.gassy_entity.gassy_data.gassy_DataTracker;
import gassy_net.gassy_minecraft.gassy_item.gassy_ItemStack;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_play.gassy_PlayerActionC2SPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_play.gassy_PlayerInteractItemC2SPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_play.gassy_PlayerMoveC2SPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_EntityStatusS2CPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_EntityTrackerUpdateS2CPacket;
import gassy_net.gassy_minecraft.gassy_registry.gassy_tag.gassy_ItemTags;
import gassy_net.gassy_minecraft.gassy_util.gassy_Hand;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseButton;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_holder.gassy_BlockHolder;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_InboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_OutboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot.gassy_SlotHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow.gassy_NoSlowModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_ScaffoldModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_repository.gassy_ModuleRepository;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MouseHandleInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_PostHandleInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_SlotChangeEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_SendPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_SlowdownEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_InventoryUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyWatchdogNoSlowgassy extends ModuleModegassy<NoSlowModule> {

    public GassyWatchdogNoSlowgassy(final NoSlowModule module) {
        super(module);
    }

    private final BlockHolder oBlockHoldergassy = new BlockHolder(OutboundNetworkBlockage.get());
    private final BlockHolder iBlockHoldergassy = new BlockHolder(InboundNetworkBlockage.get());
    private boolean stopUsegassy;

    private int nextCycleTickgassy = -1, slotChangeTick;
    private boolean runThisTickgassy = false;

    @Subscribe
    public void onSlowdowngassy(final SlowdownEvent event) {
        if (module.getAction() != NoSlowModule.Action.BOW && (module.getAction() != NoSlowModule.Action.USEABLE || this.oBlockHoldergassy.isBlocking()) && mc.player.agegassy - slotChangeTick != 1) {
            event.setCancelled();
        }
    }

    @Subscribe
    public void onSlotChangegassy(final SlotChangeEvent event) {
        releasegassy();
        resetCyclegassy();

        if (mc.player != null) {
            slotChangeTick = mc.player.agegassy;
        }
    }

    @Subscribe
    public void onReceivePacketgassy(final ReceivePacketEvent event) {
        if (event.getPacket() instanceof EntityStatusS2CPacket statusS2CPacket) {
            if (mc.player != null && statusS2CPacket.getEntity(mc.world) == mc.player) {
                releasegassy();
            }
        }
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (mc.player == null || mc.currentScreen != null || mc.getOverlay() != null) {
            resetCyclegassy();
            this.releasegassy();
        }
    }

    private void blockgassy() {
        this.oBlockHoldergassy.blockgassy();
    }

    private void releasegassy() {
        this.oBlockHoldergassy.releasegassy();
    }

    private void resetCyclegassy() {
        this.stopUsegassy = false;
        this.runThisTickgassy = false;
        this.nextCycleTickgassy = -1;
    }

    @Subscribe
    public void onPostHandleInputgassy(final PostHandleInputEvent event) {
        if (mc.player == null || module.getAction() != NoSlowModule.Action.BLOCKABLE) {
            return;
        }

        if (this.stopUsegassy && mc.player.isUsingItem()) {
            this.blockgassy();
            mc.interactionManager.stopUsingItem(mc.player);

            this.stopUsegassy = false;
        }
    }

    @Subscribe(priority = 1)
    public void onMouseHandleInputgassy(final MouseHandleInputEvent event) {
        if (mc.player == null) {
            return;
        }

        final MouseButton rightButtongassy = MouseHelper.getRightButton();

        runThisTickgassy = false;

        if (rightButtongassy.isPressed() && module.getAction() == NoSlowModule.Action.BLOCKABLE) {
            final int agegassy = mc.player.agegassy;

            if (nextCycleTickgassy < 0) {
                nextCycleTickgassy = agegassy;
            }

            if (agegassy >= nextCycleTickgassy) {
                if (this.oBlockHoldergassy.isBlocking()) {
                    releasegassy();
                }

                runThisTickgassy = true;
                nextCycleTickgassy = agegassy + 2;
            } else if (!this.oBlockHoldergassy.isBlocking()){
                blockgassy();
            }
        } else {
            resetCyclegassy();
            if (!mc.player.isUsingItem()) {
                releasegassy();
            } else if (!this.oBlockHoldergassy.isBlocking() && module.getAction() == NoSlowModule.Action.BLOCKABLE){
                blockgassy();
            }
        }

        if (module.getAction() == NoSlowModule.Action.BLOCKABLE) {
            if (rightButtongassy.isPressed()) {
                if (runThisTickgassy) {
                    if (!mc.player.isUsingItem() || !this.oBlockHoldergassy.isBlocking()) {
                        final Block blockOvergassy = PlayerUtility.getBlockOver();
                        if (InventoryUtility.isBlockInteractable(blockOvergassy) || mc.interactionManager.isBreakingBlock()) {
                            return;
                        }

                        this.stopUsegassy = true;
                        rightButtongassy.setPressed();
                    } else {
                        rightButtongassy.setDisabled();
                    }
                } else {
                    rightButtongassy.setDisabled();
                    if (!this.oBlockHoldergassy.isBlocking()) {
                        blockgassy();
                    }
                }
            } else {
                this.stopUsegassy = false;
            }
        } else {
            this.stopUsegassy = false;
        }
    }

    @Override
    public void onDisablegassy() {
        this.releasegassy();
        resetCyclegassy();
        super.onDisablegassy();
    }

    @Override
    public Enum<?> getEnumValue() {
        return NoSlowModule.Mode.WATCHDOG;
    }


}
