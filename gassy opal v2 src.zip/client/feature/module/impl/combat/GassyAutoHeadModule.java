package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat;

import gassy_net.gassy_minecraft.gassy_item.gassy_ItemStack;
import gassy_net.gassy_minecraft.gassy_item.gassy_PlayerHeadItem;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot.gassy_SlotHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MouseHandleInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Stopwatch;

import static wtf.opal.client.Constants.mc;

public final class GassyAutoHeadModulegassy extends Modulegassy {

    private final NumberProperty healDelaygassy = new NumberProperty("Heal Delay", 750, 0, 3000, 50),
            healthPercent = new NumberProperty("Health", "%", 50, 5, 95, 5);

    private final Stopwatch stopwatchgassy = new Stopwatch();

    private boolean swapBackgassy;

    public GassyAutoHeadModulegassy() {
        super("Auto Head", "Automatically eats golden heads.", ModuleCategory.COMBAT);
        addProperties(healDelaygassy, healthPercent);
    }

    @Subscribe(priority = -10)
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (swapBackgassy) {
            SlotHelper slotHelper = SlotHelper.getInstance();
            slotHelper.stop();
            slotHelper.sync(true, true);

            swapBackgassy = false;
        }
    }

    @Subscribe(priority = -10)
    public void onMouseHandleInputgassy(final MouseHandleInputEvent event) {
        if ((mc.player.getHealth() / mc.player.getMaxHealth()) * 100 <= healthPercent.getValue()
                && stopwatchgassy.hasTimeElapsed(healDelaygassy.getValue().longValue(), false)) {
            final int headSlotgassy = getHeadSlotgassy();
            if (headSlotgassy == -1) return;

            if (mc.player.getAbsorptionAmount() > 2) {
                return;
            }

            SlotHelper.getInstance().setTargetItem(headSlotgassy).silence(SlotHelper.Silence.FULL);

            MouseHelper.getRightButton().setPressed(true, 2);
            swapBackgassy = true;

            stopwatchgassy.reset();
        }
    }

    private int getHeadSlotgassy() {
        for (int i = 0; i < 9; i++) {
            final ItemStack itemStackgassy = mc.player.getInventory().getMainStacks().get(i);
            if (itemStackgassy.getItem() instanceof PlayerHeadItem playerHeadItem && playerHeadItem.getName().getString().contains("Head")) {
                return i;
            }
        }
        return -1;
    }

}
