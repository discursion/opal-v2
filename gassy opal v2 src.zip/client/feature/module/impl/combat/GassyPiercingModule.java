package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;

public final class GassyPiercingModulegassy extends Modulegassy {

    // hooked in GameRendererMixin#redirectPassedThroughBlockDistance

    public GassyPiercingModulegassy() {
        super("Piercing", "Allows you to take players through blocks.", ModuleCategory.COMBAT);
    }

}
