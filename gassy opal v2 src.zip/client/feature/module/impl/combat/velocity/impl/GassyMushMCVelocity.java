package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_impl;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_common.gassy_CommonPingS2CPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_EntityVelocityUpdateS2CPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_GameJoinS2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_VelocityMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_VelocityModule;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import static wtf.opal.client.Constants.mc;

public final class GassyMushMCVelocitygassy extends VelocityModegassy {

    public GassyMushMCVelocitygassy(VelocityModule module) {
        super(module);
    }

    private boolean cancelgassy;

    @Subscribe
    public void onReceivePacketgassy(final ReceivePacketEvent event) {
        if (event.getPacket() instanceof EntityVelocityUpdateS2CPacket packet) {
            if (mc.player != null && packet.getEntityId() == mc.player.getId()) {
                event.setCancelled();
                this.cancelgassy = true;
            }
        } else if (event.getPacket() instanceof CommonPingS2CPacket) {
            if (this.cancelgassy) {
                event.setCancelled();
                this.cancelgassy = false;
            }
        } else if (event.getPacket() instanceof GameJoinS2CPacket) {
            this.cancelgassy = false;
        }
    }

    @Override
    public Enum<?> getEnumValue() {
        return VelocityModule.Mode.MUSHMC;
    }
}
