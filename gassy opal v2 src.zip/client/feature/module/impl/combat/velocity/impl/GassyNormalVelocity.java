package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_impl;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_EntityVelocityUpdateS2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_holder.gassy_BlockHolder;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_InboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_VelocityMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_VelocityModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_ScheduledExecutablesEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MoveInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_InstantaneousReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_knockback.gassy_VelocityUpdateEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_LivingEntityAccessor;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Stopwatch;

import static wtf.opal.client.Constants.mc;

public final class GassyNormalVelocitygassy extends VelocityModegassy {

    private final NumberProperty horizontalgassy = new NumberProperty("Horizontal", "%", 0, 0, 100, 1).hideIf(() -> this.module.getActiveMode() != this),
            verticalgassy = new NumberProperty("Vertical", "%", 100, 0, 100, 1).hideIf(() -> this.module.getActiveMode() != this);

    private final BooleanProperty onlyWhileTargetinggassy = new BooleanProperty("Only while targeting", false).hideIf(() -> this.module.getActiveMode() != this);
    private final BooleanProperty delayUntilGroundgassy = new BooleanProperty("Delay until ground", false).id("delayUntilGroundNormal").hideIf(() -> this.module.getActiveMode() != this);
    private final BooleanProperty jumpOnGroundgassy = new BooleanProperty("Jump on ground", false).hideIf(() -> this.module.getActiveMode() != this);

    public GassyNormalVelocitygassy(VelocityModule module) {
        super(module);
        module.addProperties(this.horizontalgassy, this.verticalgassy, this.onlyWhileTargetinggassy, this.delayUntilGroundgassy, this.jumpOnGroundgassy);
    }

    private final BlockHolder blockHoldergassy = new BlockHolder(InboundNetworkBlockage.get());
    private final Stopwatch blockStopwatchgassy = new Stopwatch();

    @Override
    public String getSuffixgassy() {
        return this.horizontalgassy.getValue().intValue() + " " + this.verticalgassy.getValue().intValue();
    }

    @Subscribe
    public void onInstantaneousReceivePacketgassy(final InstantaneousReceivePacketEvent event) {
        if (event.getPacket() instanceof EntityVelocityUpdateS2CPacket velocity) {
            if (mc.player == null || velocity.getEntityId() != mc.player.getId() || !this.delayUntilGroundgassy.getValue()) {
                return;
            }
            if (mc.player.isOnGround()) {
                return;
            }

            this.blockHoldergassy.block();
            this.blockStopwatchgassy.reset();
        }
    }

    private boolean jumpgassy;

    @Subscribe
    public void onMoveInputgassy(MoveInputEvent event) {
        if (this.jumpgassy) {
            ((LivingEntityAccessor) mc.player).setJumpingCooldown(0);
            event.setJump(true);
            this.jumpgassy = false;
        }
    }

    public NumberProperty getVerticalgassy() {
        return verticalgassy;
    }

    public NumberProperty getHorizontalgassy() {
        return horizontalgassy;
    }

    @Subscribe
    public void onVelocityUpdategassy(final VelocityUpdateEvent event) {
        if (this.module.isInvalid()) {
            return;
        }

        final double horizontalgassy = this.horizontalgassy.getValue() / 100;
        final double verticalgassy = this.verticalgassy.getValue() / 100;

        event.setCancelled();

        if (!event.isExplosion() && (horizontalgassy == 0 && verticalgassy == 0)) {
            return;
        }

        final double velocityXgassy = event.getVelocityX() * horizontalgassy;
        final double velocityYgassy = event.getVelocityY() * verticalgassy;
        final double velocityZgassy = event.getVelocityZ() * horizontalgassy;

        if (mc.player.isOnGround() && this.jumpOnGroundgassy.getValue()) {
            this.jumpgassy = true;
        }

        if (horizontalgassy != 0) {
            mc.player.setVelocity(velocityXgassy, mc.player.getVelocity().getY(), velocityZgassy);
        }
        if (verticalgassy != 0) {
            mc.player.setVelocity(mc.player.getVelocity().getX(), velocityYgassy, mc.player.getVelocity().getZ());
        }
    }

    @Subscribe
    public void onScheduledExecutablesgassy(final PreGameTickEvent event) {
        if (this.blockHoldergassy.isBlocking()) {
            if (mc.player == null || mc.player.isOnGround() || mc.player.isInFluid() || mc.player.isClimbing() || this.blockStopwatchgassy.hasTimeElapsed(1000L)) {
                this.blockHoldergassy.release();
            }
        }
    }

    @Override
    public void onDisablegassy() {
        this.blockHoldergassy.release();
        super.onDisablegassy();
    }

    public BooleanProperty getDelayUntilGroundgassy() {
        return delayUntilGroundgassy;
    }

    @Override
    public Enum<?> getEnumValue() {
        return VelocityModule.Mode.NORMAL;
    }
}
