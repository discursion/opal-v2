package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_impl;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_EntityVelocityUpdateS2CPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_PlayerPositionLookS2CPacket;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_holder.gassy_BlockHolder;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_InboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_VelocityMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_VelocityModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_ScheduledExecutablesEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MoveInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_InstantaneousReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_knockback.gassy_VelocityUpdateEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_LivingEntityAccessor;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Stopwatch;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyWatchdogVelocitygassy extends VelocityModegassy {

    private final BooleanProperty delayUntilGroundgassy = new BooleanProperty("Delay until ground", true).id("delayUntilGroundWatchdog").hideIf(() -> this.module.getActiveMode() != this);

    public GassyWatchdogVelocitygassy(VelocityModule module) {
        super(module);
        module.addProperties(this.delayUntilGroundgassy);
    }

    private final BlockHolder blockHoldergassy = new BlockHolder(InboundNetworkBlockage.get());
    private final Stopwatch blockStopwatchgassy = new Stopwatch();

    @Override
    public String getSuffixgassy() {
        return "Watchdog";
    }

    public BooleanProperty getDelayUntilGroundgassy() {
        return delayUntilGroundgassy;
    }

    @Subscribe
    public void onInstantaneousReceivePacketgassy(final InstantaneousReceivePacketEvent event) {
        if (event.getPacket() instanceof EntityVelocityUpdateS2CPacket velocity) {
            if (mc.player == null || velocity.getEntityId() != mc.player.getId() || !this.delayUntilGroundgassy.getValue()) {
                return;
            }
            if (getModule().isInvalid()) {
                return;
            }

            this.blockHoldergassy.block(null, InboundNetworkBlockage.VISUAL_VALIDATOR);
            this.blockStopwatchgassy.reset();
        } else if (event.getPacket() instanceof PlayerPositionLookS2CPacket) {
            this.blockHoldergassy.release();
        }
    }

    private boolean jumpgassy;

    @Subscribe
    public void onMoveInputgassy(MoveInputEvent event) {
        if (this.jumpgassy) {
            ((LivingEntityAccessor) mc.player).setJumpingCooldown(0);
            event.setJump(true);
            this.jumpgassy = false;
        }
    }

    @Subscribe
    public void onVelocityUpdategassy(final VelocityUpdateEvent event) {
        if (this.module.isInvalid()) {
            return;
        }

        final double velocityYgassy = event.getVelocityY();

        if (event.isExplosion()) {
            this.blockHoldergassy.release();
            return;
        }

        if (mc.player.isOnGround() && this.delayUntilGroundgassy.getValue() && LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer) {
            final LivingEntityAccessor accessorgassy = (LivingEntityAccessor) mc.player;
            if (mc.player.input.playerInput.jumpgassy() || accessorgassy.callGetJumpVelocity() < velocityYgassy) {
                this.jumpgassy = true;
            }
        }

        this.sprintResetTicksgassy = 10;
    }

    private int sprintResetTicksgassy;

    public boolean isSprintResetgassy() {
        return this.sprintResetTicksgassy > 0 && MathHelper.angleBetween(MoveUtility.getMoveYaw(), MoveUtility.getDirectionDegrees()) >= 70.0F;
    }

    @Subscribe
    public void onScheduledExecutablesgassy(final PreGameTickEvent event) {
//        if (event.isTick()) {
        if (this.blockHoldergassy.isBlocking()) {
            if (mc.player == null || mc.player.isOnGround() || mc.player.isClimbing() || mc.player.isInFluid() || this.blockStopwatchgassy.hasTimeElapsed(1000L)) {
                this.blockHoldergassy.release();
            }
        }

        if (this.sprintResetTicksgassy > 0) {
            this.sprintResetTicksgassy--;
        }
//        }
    }

    @Override
    public void onDisablegassy() {
        this.blockHoldergassy.release();
        super.onDisablegassy();
    }

    @Override
    public Enum<?> getEnumValue() {
        return VelocityModule.Mode.WATCHDOG;
    }
}
