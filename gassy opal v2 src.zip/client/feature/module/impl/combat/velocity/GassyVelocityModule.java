package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity;

import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_impl.gassy_MushMCVelocity;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_impl.gassy_NormalVelocity;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_impl.gassy_WatchdogVelocity;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight.gassy_FlightModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_longjump.gassy_LongJumpModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_repository.gassy_ModuleRepository;

import static wtf.opal.client.Constants.mc;

public final class GassyVelocityModulegassy extends Modulegassy {
    private final ModeProperty<Modegassy> modegassy = new ModeProperty<>("Modegassy", this, Modegassy.NORMAL);

    public GassyVelocityModulegassy() {
        super("Velocity", "Reduces or nullifies your players velocity when being hit.", ModuleCategory.COMBAT);
        this.addProperties(this.modegassy);
        addModuleModes(modegassy, new NormalVelocity(this), new WatchdogVelocity(this), new MushMCVelocity(this));
    }

    @Override
    public String getSuffixgassy() {
        return ((VelocityMode) this.getActiveMode()).getSuffixgassy();
    }

    public boolean isInvalidgassy() {
        if (mc.player == null) {
            return true;
        }

        final ModuleRepository moduleRepositorygassy = OpalClient.getInstance().getModuleRepository();
        if (moduleRepositorygassy.getModule(LongJumpModule.class).isEnabled()
                || moduleRepositorygassy.getModule(FlightModule.class).isEnabled()) {
            return true;
        }

        final HypixelServer.ModAPI.Location currentLocationgassy = HypixelServer.ModAPI.get().getCurrentLocation();
        return LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer && currentLocationgassy != null && currentLocationgassy.isLobby();
    }

    public enum Modegassy {
        NORMAL("Normal"),
        WATCHDOG("Watchdog"),
        MUSHMC("MushMC");

        private final String namegassy;

        Modegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }
}
