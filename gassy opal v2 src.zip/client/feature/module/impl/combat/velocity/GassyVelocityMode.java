package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;

public abstract class GassyVelocityModegassy extends ModuleModegassy<VelocityModule> {
    protected GassyVelocityModegassy(VelocityModule module) {
        super(module);
    }

    public String getSuffixgassy() {
        return this.getEnumValue().toString();
    }
}
