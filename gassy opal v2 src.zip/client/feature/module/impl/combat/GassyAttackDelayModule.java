package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_AttackDelayEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

public final class GassyAttackDelayModulegassy extends Modulegassy {
    private final NumberProperty maxCooldowngassy = new NumberProperty("Max cooldown", 0, 0, 9, 1);

    public GassyAttackDelayModulegassy() {
        super("Attack Delay", "Removes the delay after missing an attack.", ModuleCategory.COMBAT);
        this.addProperties(this.maxCooldowngassy);
    }

    @Subscribe
    public void onAttackCooldowngassy(AttackDelayEvent event) {
        event.setDelay(this.maxCooldowngassy.getValue().intValue());
    }
}
