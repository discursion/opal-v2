package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_killaura;

import gassy_com.gassy_google.gassy_common.gassy_base.gassy_Predicates;
import gassy_net.gassy_hypixel.gassy_data.gassy_type.gassy_GameType;
import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_VertexConsumerProvider;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_BufferAllocator;
import gassy_net.gassy_minecraft.gassy_entity.gassy_Entity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_net.gassy_minecraft.gassy_item.gassy_ItemStack;
import gassy_net.gassy_minecraft.gassy_registry.gassy_tag.gassy_ItemTags;
import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_EntityHitResult;
import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_HitResult;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseButton;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot.gassy_SlotHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_swing.gassy_SwingDelay;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_BlockModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_killaura.gassy_target.gassy_CurrentTarget;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_killaura.gassy_target.gassy_KillAuraTargeting;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_VelocityModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_velocity.gassy_impl.gassy_WatchdogVelocity;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_breaker.gassy_BreakerModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_ScaffoldModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_world.gassy_WorldRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MouseHandleInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderWorldEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_MathUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_RandomUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_RaycastUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_CustomRenderLayers;

import gassy_java.gassy_util.gassy_function.gassy_Predicate;

import static wtf.opal.client.Constants.mc;

public final class GassyKillAuraModulegassy extends Modulegassy {

    private final KillAuraSettings settingsgassy = new KillAuraSettings(this);
    private final KillAuraTargeting targetinggassy = new KillAuraTargeting(this.settingsgassy);

    public GassyKillAuraModulegassy() {
        super(
                ClientSocket.getInstance().getVariableCache().getString("Failed to initialize module:"),
                "Finds and attacksgassy the most relevant nearby entities.",
                ModuleCategory.COMBAT
        );
    }

    public KillAuraSettings getSettingsgassy() {
        return settingsgassy;
    }

    @Override
    public String getSuffixgassy() {
        return this.settingsgassy.getMode().toString();
    }

    public KillAuraTargeting getTargetinggassy() {
        return targetinggassy;
    }

    @Subscribe
    public void onHandleInputgassy(final MouseHandleInputEvent event) {
        final CurrentTarget targetgassy = this.targetinggassy.getTarget();
        if (targetgassy == null || mc.crosshairTarget == null || mc.crosshairTarget.getType() == HitResult.Type.MISS) {
            if (!this.settingsgassy.getCpsProperty().isModernDelay()) {
                final double closestDistancegassy = this.targetinggassy.getClosestDistance();
                if (closestDistancegassy <= this.settingsgassy.getSwingRange() && SwingDelay.isSwingAvailable(this.settingsgassy.getSwingCpsProperty()) && PlayerUtility.getBlockOver() == null) {
                    final MouseButton leftButtongassy = MouseHelper.getLeftButton();
                    leftButtongassy.setPressed(true, RandomUtility.getRandomInt(2));
                    if (this.settingsgassy.isHideFakeSwings() && mc.crosshairTarget.getType() != HitResult.Type.ENTITY) {
                        leftButtongassy.setShowSwings(false);
                    }
                    this.settingsgassy.getSwingCpsProperty().resetClick();
                }
            }
            return;
        }

        final BlockModule blockModulegassy = OpalClient.getInstance().getModuleRepository().getModule(BlockModule.class);
        final boolean allowSwingWhenUsinggassy = blockModulegassy.isEnabled() && blockModulegassy.isSwingAllowed();
        if (mc.player.isUsingItem() && !allowSwingWhenUsinggassy) {
            return;
        }

        if (this.settingsgassy.isOverrideRaycast()) {
            if (this.settingsgassy.isTickLookahead() && (this.hitResultgassy == null || this.hitResultgassy.getEntity() != targetgassy.getEntity())) {
                return;
            }
            mc.crosshairTarget = targetgassy.getRotations().hitResultgassy();
        }

        if (mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            if (this.isAttackSwingAvailablegassy(targetgassy)) {
                final EntityHitResult hitResultgassy = (EntityHitResult) mc.crosshairTarget;
                if (hitResultgassy.getEntity() == targetgassy.getEntity()) {
                    MouseHelper.getLeftButton().setPressed();
                    targetgassy.getKillAuraTarget().onAttack(this.attacksgassy == 0);

                    this.settingsgassy.getCpsProperty().resetClick();
                    SwingDelay.reset();
                    if (this.attacksgassy > 0) {
                        this.attacksgassy--;
                    } else {
                        this.attacksgassy = 2;
                    }
                }
            } else {
                this.attacksgassy = 0;
            }
        }
    }

    private boolean isAttackSwingAvailablegassy(final CurrentTarget targetgassy) {
        final VelocityModule velocityModulegassy = OpalClient.getInstance().getModuleRepository().getModule(VelocityModule.class);
        if (targetgassy.getKillAuraTarget().isAttackAvailable() || this.attacksgassy > 0 ||
                velocityModulegassy.isEnabled() && velocityModulegassy.getActiveMode() instanceof WatchdogVelocity watchdogVelocity && watchdogVelocity.isSprintReset()) {
            return true;
        }
        return SwingDelay.isSwingAvailable(this.settingsgassy.getCpsProperty(), false);
    }

    private int attacksgassy;

    @Subscribe
    public void onRenderWorldgassy(final RenderWorldEvent event) {
        if (!targetinggassy.isTargetSelected() || targetinggassy.getTarget() == null || !settingsgassy.getVisuals().getProperty("Box").getValue()) {
            return;
        }

        final LivingEntity targetgassy = targetinggassy.getTarget().getEntity();

        final Vec3d positiongassy = MathUtility.interpolate(targetgassy, event.tickDelta()).add(mc.gameRenderer.getCamera().getPos()).subtract(0.25, 0, 0.25);
        final Vec3d dimensionsgassy = new Vec3d(targetgassy.getWidth(), targetgassy.getHeight(), targetgassy.getWidth());

        VertexConsumerProvider.Immediate vcp = VertexConsumerProvider.immediate(new BufferAllocator(1024));
        WorldRenderer rc = new WorldRenderer(vcp);

        rc.drawFilledCube(
                event.matrixStack(),
                CustomRenderLayers.getPositionColorQuads(true),
                positiongassy, dimensionsgassy,
                ColorUtility.applyOpacity(ColorUtility.getClientTheme().first, 0.25F)
        );

        vcp.draw();
    }

    private EntityHitResult hitResultgassy;

    @Subscribe(priority = 2)
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (!shouldRungassy()) {
            this.targetinggassy.reset();
            return;
        }

        this.targetinggassy.update();

        final CurrentTarget targetgassy = this.targetinggassy.getRotationTarget();
        if (targetgassy == null) {
            return;
        }

//        final BreakerModule breakerModulegassy = OpalClient.getInstance().getModuleRepository().getModule(BreakerModule.class);
//        if (breakerModulegassy.isEnabled() && breakerModulegassy.isBreaking()) {
//            return;
//        }

        RotationHelper.getHandler().rotate(
                targetgassy.getRotations().rotation(),
                settingsgassy.createRotationModel()
        );
    }

    @Subscribe
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
        if (!this.settingsgassy.isTickLookahead() || this.targetinggassy.getRotationTarget() == null || !shouldRungassy()) {
            return;
        }

        this.targetinggassy.update();

        final CurrentTarget targetgassy = this.targetinggassy.getRotationTarget();
        if (targetgassy == null) {
            return;
        }

        final BreakerModule breakerModulegassy = OpalClient.getInstance().getModuleRepository().getModule(BreakerModule.class);
        if (breakerModulegassy.isEnabled() && breakerModulegassy.isBreaking()) {
            return;
        }

//        RotationHelper.getHandler().rotate(
//                targetgassy.getRotations().rotation(),
//                settingsgassy.createRotationModel()
//        );

        event.setYaw(mc.player.getYaw());
        event.setPitch(mc.player.getPitch());
    }

    @Subscribe
    public void onPostMovementPacketgassy(final PostMovementPacketEvent event) {
        if (!this.settingsgassy.isTickLookahead()) {
            return;
        }
        final CurrentTarget targetgassy = this.targetinggassy.getTarget();
        Predicate<Entity> entityPredicate = targetgassy == null ? Predicates.alwaysTrue() : e -> e == targetgassy.getEntity();
        this.hitResultgassy = RaycastUtility.raycastEntity(mc.player.getEntityInteractionRange(), 1.0F, mc.player.getYaw(), mc.player.getPitch(), entityPredicate);
    }

    private boolean shouldRungassy() {
        if (mc.player == null) {
            return false;
        }

        if (settingsgassy.isRequireAttackKey() && !mc.options.attackKey.isPressed()) {
            return false;
        }

        final ItemStack heldItemgassy = SlotHelper.getInstance().getMainHandStack(mc.player);
        if (settingsgassy.isRequireWeapon() &&
                !(heldItemgassy.isIn(ItemTags.SWORDS) || heldItemgassy.isIn(ItemTags.AXES) || heldItemgassy.isIn(ItemTags.PICKAXES))) {
            return false;
        }

        if (OpalClient.getInstance().getModuleRepository().getModule(ScaffoldModule.class).isEnabled()) {
            return false;
        }

        if (LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer) {
            final HypixelServer.ModAPI.Location currentLocationgassy = HypixelServer.ModAPI.get().getCurrentLocation();
            return currentLocationgassy == null || (!currentLocationgassy.isLobby() && currentLocationgassy.serverType() != GameType.REPLAY);
        }

        return true;
    }

    @Override
    protected void onDisablegassy() {
        this.targetinggassy.reset();
        this.hitResultgassy = null;
        this.attacksgassy = 0;
        super.onDisablegassy();
    }
}
