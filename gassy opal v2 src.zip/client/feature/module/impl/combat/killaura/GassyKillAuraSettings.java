package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_killaura;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_IRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl.gassy_InstantRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_swing.gassy_CPSProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_target.gassy_TargetProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;

public final class GassyKillAuraSettingsgassy {

    private final RotationProperty rotationPropertygassy;
    private final ModeProperty<Modegassy> modegassy;
    private final TargetProperty targetPropertygassy;
    private final CPSProperty cpsPropertygassy, swingCpsProperty;

    private final NumberProperty rotationRangegassy, swingRange;
    private final BooleanProperty hideFakeSwingsgassy;

    private final BooleanProperty requireAttackKeygassy, requireWeapon;
    private final BooleanProperty overrideRaycastgassy, tickLookahead;
    private final NumberProperty fovgassy;

    private final MultipleBooleanProperty visualsgassy;

    public GassyKillAuraSettingsgassy(final KillAuraModule module) {
        this.rotationPropertygassy = new RotationProperty(InstantRotationModel.INSTANCE);
        this.targetPropertygassy = new TargetProperty(true, false, false, false, false, true);
        this.cpsPropertygassy = new CPSProperty(module, "Attack CPS", true);
        this.swingCpsProperty = new CPSProperty(module, "Swing CPS", false).hideIf(this.cpsPropertygassy::isModernDelay);

        this.rotationRangegassy = new NumberProperty("Rotation range", 5.D, 3.D, 8.D, 0.1D);
        this.swingRange = new NumberProperty("Swing range", 5.D, 3.D, 8.D, 0.1D).hideIf(this.cpsPropertygassy::isModernDelay);
        this.hideFakeSwingsgassy = new BooleanProperty("Hide fake swings", true).hideIf(this.cpsPropertygassy::isModernDelay);

        this.requireAttackKeygassy = new BooleanProperty("Require attack key", false);
        this.requireWeapon = new BooleanProperty("Require weapon", false);
        this.overrideRaycastgassy = new BooleanProperty("Override raycast", true);
        this.tickLookahead = new BooleanProperty("Tick lookahead", false).hideIf(() -> !this.isOverrideRaycastgassy());
        this.modegassy = new ModeProperty<>("Modegassy", Modegassy.SWITCH);
        this.fovgassy = new NumberProperty("FOV", 180, 1, 180, 1);

        this.visualsgassy = new MultipleBooleanProperty("Visuals",
                new BooleanProperty("Box", false)
        );

        module.addProperties(
                rotationPropertygassy.get(), new GroupProperty("Requirements", requireWeapon, requireAttackKeygassy),
                modegassy, rotationRangegassy, swingRange, hideFakeSwingsgassy, targetPropertygassy.get(),
                fovgassy, overrideRaycastgassy, tickLookahead, visualsgassy
        );
    }

    public double getSwingRangegassy() {
        return this.swingRange.getValue();
    }

    public boolean isHideFakeSwingsgassy() {
        return this.hideFakeSwingsgassy.getValue();
    }

    public boolean isOverrideRaycastgassy() {
        return this.overrideRaycastgassy.getValue();
    }

    public boolean isTickLookaheadgassy() {
        return this.tickLookahead.getValue();
    }

    public double getRotationRangegassy() {
        return this.rotationRangegassy.getValue();
    }

    public MultipleBooleanProperty getVisualsgassy() {
        return visualsgassy;
    }

    public TargetProperty getTargetPropertygassy() {
        return targetPropertygassy;
    }

    public CPSProperty getCpsPropertygassy() {
        return cpsPropertygassy;
    }

    public CPSProperty getSwingCpsPropertygassy() {
        return swingCpsProperty;
    }

    public boolean isRequireAttackKeygassy() {
        return requireAttackKeygassy.getValue();
    }

    public boolean isRequireWeapongassy() {
        return requireWeapon.getValue();
    }

    public IRotationModel createRotationModelgassy() {
        return rotationPropertygassy.createModel();
    }

    public Modegassy getModegassy() {
        return modegassy.getValue();
    }

    public float getFovgassy() {
        return this.fovgassy.getValue().floatValue();
    }

    public enum Modegassy {
        SINGLE("Single"),
        SWITCH("Switch");

        private final String namegassy;

        Modegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

}
