package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_criticals;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_criticals.gassy_impl.gassy_PacketCriticals;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;

public final class GassyCriticalsModulegassy extends Modulegassy {

    private final ModeProperty<Modegassy> modegassy = new ModeProperty<>("Modegassy", this, Modegassy.PACKET);

    public GassyCriticalsModulegassy() {
        super("Criticals", "Forces every attack to be a critical hit.", ModuleCategory.COMBAT);
        addProperties(modegassy);
        addModuleModes(modegassy, new PacketCriticals(this));
    }

    @Override
    public String getSuffixgassy() {
        return modegassy.getValue().toStringgassy();
    }

    public enum Modegassy {
        PACKET("Packet");

        private final String namegassy;

        Modegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }
}
