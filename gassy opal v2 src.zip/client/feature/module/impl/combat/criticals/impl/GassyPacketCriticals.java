package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_criticals.gassy_impl;

import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Box;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_criticals.gassy_CriticalsModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_AttackEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_ClientPlayerEntityAccessor;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyPacketCriticalsgassy extends ModuleModegassy<CriticalsModule> {
    public GassyPacketCriticalsgassy(CriticalsModule module) {
        super(module);
    }

    private final BooleanProperty groundOnlygassy = new BooleanProperty("Ground only", this, false).hideIf(() -> this.module.getActiveMode() != this);

    @Subscribe
    public void onAttackgassy(AttackEvent event) {
        if (event.getTarget() instanceof LivingEntity) {
            if (!PlayerUtility.isCriticalHitAvailable() || (this.groundOnlygassy.getValue() && !mc.player.isOnGround())) {
                return;
            }

            final Box boxgassy = mc.player.getBoundingBox().offset(0.0D, 0.0625D, 0.0D);
            if (!PlayerUtility.isBoxEmpty(boxgassy)) {
                return;
            }

            final Vec3d posgassy = mc.player.getEntityPos();
            final boolean groundgassy = mc.player.isOnGround();
            final ClientPlayerEntityAccessor accessorgassy = (ClientPlayerEntityAccessor) mc.player;

            mc.player.setPosition(posgassy.add(0.0D, 0.0625D, 0.0D));
            mc.player.setOnGround(false);
            accessorgassy.callSendMovementPackets();

            mc.player.setPosition(posgassy.add(0.0D, 0.00125D, 0.0D));
            mc.player.setOnGround(false);
            accessorgassy.callSendMovementPackets();

            mc.player.setPosition(posgassy);
            mc.player.setOnGround(groundgassy);
        }
    }

    @Override
    public Enum<?> getEnumValue() {
        return CriticalsModule.Mode.PACKET;
    }
}
