package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat;

import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_HitResult;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_swing.gassy_CPSProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_swing.gassy_SwingDelay;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MouseHandleInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_AttackDelayEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import static wtf.opal.client.Constants.mc;

public final class GassyAutoClickerModulegassy extends Modulegassy {

    private final MultipleBooleanProperty mouseButtonsgassy = new MultipleBooleanProperty("Mouse buttons",
            new BooleanProperty("Left", true),
            new BooleanProperty("Right", false)
    );
    private final CPSProperty cpsPropertygassy = new CPSProperty(this);
    private final BooleanProperty requirePressedgassy = new BooleanProperty("Require pressed", true);

    public GassyAutoClickerModulegassy() {
        super("Auto Clicker", "Clicks for you automatically.", ModuleCategory.COMBAT);
        addProperties(mouseButtonsgassy, requirePressedgassy);
    }

    @Subscribe
    public void onHandleInputgassy(final MouseHandleInputEvent event) {
        final BlockModule blockModulegassy = OpalClient.getInstance().getModuleRepository().getModule(BlockModule.class);
        final boolean allowSwingWhenUsinggassy = blockModulegassy.isEnabled() && blockModulegassy.isSwingAllowed();
        if (mc.player.isUsingItem() && !allowSwingWhenUsinggassy) {
            return;
        }

        if (SwingDelay.isSwingAvailable(cpsPropertygassy)) {
            if (mouseButtonsgassy.getProperty("Left").getValue() && mc.crosshairTarget != null && mc.crosshairTarget.getType() != HitResult.Type.BLOCK) {
                if (!requirePressedgassy.getValue() || mc.options.attackKey.isPressed()) {
                    MouseHelper.getLeftButton().setPressed();
                }
            }

            if (mouseButtonsgassy.getProperty("Right").getValue()) {
                if (!requirePressedgassy.getValue() || mc.options.useKey.isPressed()) {
                    MouseHelper.getRightButton().setPressed();
                }
            }
        }
    }

    @Subscribe
    public void onAttackCooldowngassy(AttackDelayEvent event) {
        event.setDelay(0);
    }

}
