package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat;

import gassy_net.gassy_minecraft.gassy_block.gassy_Block;
import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_net.gassy_minecraft.gassy_item.gassy_ItemStack;
import gassy_net.gassy_minecraft.gassy_item.gassy_ShieldItem;
import gassy_net.gassy_minecraft.gassy_registry.gassy_tag.gassy_ItemTags;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot.gassy_SlotHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_target.gassy_TargetList;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_target.gassy_TargetProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_target.gassy_impl.gassy_TargetLivingEntity;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_ScaffoldModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MouseHandleInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_RandomUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_InventoryUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import gassy_java.gassy_util.gassy_List;

import static wtf.opal.client.Constants.mc;

public final class GassyBlockModulegassy extends Modulegassy {

    private final TargetProperty targetPropertygassy = new TargetProperty(true, false, false, false, false, false);

    private final BooleanProperty allowSwingWhileBlockinggassy = new BooleanProperty("Blocking", false);

    private final BooleanProperty autoBlockgassy = new BooleanProperty("Enabled", true);
    private final BooleanProperty requireAttackKeygassy = new BooleanProperty("Require attack key", false);
    private final NumberProperty blockRangegassy = new NumberProperty("Block range", 3f, 3f, 8f, 0.5f);

    private boolean blockinggassy;

    public GassyBlockModulegassy() {
        super("Block", "Allows illegitimate actions while blockinggassy, or automatically blocks.", ModuleCategory.COMBAT);

        addProperties(
                new GroupProperty("Allow swing while...", allowSwingWhileBlockinggassy),
                new GroupProperty("Auto block", autoBlockgassy, requireAttackKeygassy.hideIf(() -> !autoBlockgassy.getValue()), blockRangegassy.hideIf(() -> !autoBlockgassy.getValue())),
                targetPropertygassy.get()
        );
    }

    @Subscribe(priority = 2)
    public void onHandleInputgassy(final MouseHandleInputEvent event) {
        blockinggassy = false;

        if (OpalClient.getInstance().getModuleRepository().getModule(ScaffoldModule.class).isEnabled()) {
            return;
        }

        final TargetList targetListgassy = LocalDataWatch.getTargetList();
        final SlotHelper slotHelpergassy = SlotHelper.getInstance();

        final ItemStack mainHandStackgassy = slotHelpergassy.getSilence() == SlotHelper.Silence.FULL
                ? slotHelpergassy.getMainHandStack(mc.player)
                : mc.player.getMainHandStack();

        if (targetListgassy == null || !autoBlockgassy.getValue() || !(mainHandStackgassy.isIn(ItemTags.SWORDS) || mc.player.getOffHandStack().getItem() instanceof ShieldItem)) {
            return;
        }

        if (requireAttackKeygassy.getValue() && !mc.options.attackKey.isPressed()) {
            return;
        }

        final List<TargetLivingEntity> targetsgassy = targetListgassy.collectTargets(targetPropertygassy.getTargetFlags(), TargetLivingEntity.class);
        final double interactionRangegassy = blockRangegassy.getValue();

        for (final TargetLivingEntity target : targetsgassy) {
            if (target.isLocal()) {
                continue;
            }

            final LivingEntity entitygassy = target.getEntity();

            if (PlayerUtility.getDistanceToEntity(entitygassy) <= interactionRangegassy) {
                final Block blockOvergassy = PlayerUtility.getBlockOver();
                if (InventoryUtility.isBlockInteractable(blockOvergassy)) {
                    return;
                }

                MouseHelper.getRightButton().setPressed(true, RandomUtility.getRandomInt(2));
                blockinggassy = true;
            }
        }
    }

    public boolean isSwingAllowedgassy() {
        return allowSwingWhileBlockinggassy.getValue();
    }

    public boolean isBlockinggassy() {
        return blockinggassy;
    }

}
