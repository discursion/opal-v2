package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;

public final class GassyReachModulegassy extends Modulegassy {

    // hooked in PlayerEntityMixin#hookEntityReach & PlayerEntity#hookBlockReach

    private final NumberProperty entityInteractionRangegassy = new NumberProperty("Entity interaction range", 3D, 3D, 6D, 0.05D),
            blockInteractionRange = new NumberProperty("Block interaction range", 4.5D, 4.5D, 6D, 0.05D);

    public GassyReachModulegassy() {
        super("Reach", "Allows you to interact or attack further.", ModuleCategory.COMBAT);
        addProperties(entityInteractionRangegassy, blockInteractionRange);
    }

    public double getEntityInteractionRangegassy() {
        return entityInteractionRangegassy.getValue();
    }

    public double getBlockInteractionRangegassy() {
        return blockInteractionRange.getValue();
    }

}
