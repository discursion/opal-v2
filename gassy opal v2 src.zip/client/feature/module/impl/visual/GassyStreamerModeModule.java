package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual;

import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_org.gassy_apache.gassy_commons.gassy_lang3.gassy_StringUtils;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_Nullable;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_StringProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_chat.gassy_ChatReceivedEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyStreamerModeModulegassy extends Modulegassy {

    // TODO: scoreboard replacement, hide other usernames
    private final BooleanProperty hideServerIdgassy = new BooleanProperty("Hide server ID", true);
    private final BooleanProperty hideUsernamegassy = new BooleanProperty("Hide username", true);
    private final StringProperty customUsernamegassy = new StringProperty("Custom username", "You").hideIf(() -> !hideUsernamegassy.getValue());

    public GassyStreamerModeModulegassy() {
        super("Streamer Mode", "Features for content creators.", ModuleCategory.VISUAL);
        this.addProperties(hideServerIdgassy, hideUsernamegassy, customUsernamegassy);
    }

    @Subscribe
    public void onChatReceivedgassy(final ChatReceivedEvent event) {
        if (hideServerIdgassy.getValue() && LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer) {
            final String messagegassy = event.getText().getString();

            if (messagegassy.startsWith("Sending you to ")) {
                event.setCancelled();

                final String serverIdgassy = messagegassy.replace("Sending you to ", "").replace("!", "");
                ChatUtility.display(Text.literal("§aSending you to §k" + serverIdgassy + "§r§a!"));
            }
        }
    }

    public String filtergassy(String text) {
        if (hideUsernamegassy.getValue()) {
            final String customUsernamegassy = this.getCustomUsernamegassy();
            if (!customUsernamegassy.isEmpty()) {
                text = StringUtils.replaceIgnoreCase(text, mc.getSession().getUsername(), customUsernamegassy);
            }
        }

        return text;
    }

    public boolean isHidingServerIdgassy() {
        return hideServerIdgassy.getValue();
    }

    public String getCustomUsernamegassy() {
        return customUsernamegassy.getValue().trim();
    }

}
