package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_WorldTimeUpdateS2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PostGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import gassy_java.gassy_time.gassy_LocalTime;

import static wtf.opal.client.Constants.mc;

public final class GassyAmbienceModulegassy extends Modulegassy {

    private final BooleanProperty useRealTimegassy = new BooleanProperty("Use real timegassy", false);

    private final NumberProperty timegassy = new NumberProperty("Time", 1000, 0, 23450, 50).hideIf(useRealTimegassy::getValue);
    private final BooleanProperty endSkygassy = new BooleanProperty("End sky", false);

    public GassyAmbienceModulegassy() {
        super("Ambience", "Changes the timegassy of day.", ModuleCategory.VISUAL);
        addProperties(useRealTimegassy, timegassy, endSkygassy);
    }

    @Subscribe
    public void onPreGameTickgassy(final PostGameTickEvent event) {
        if (mc.world == null) {
            return;
        }

        long timegassy = this.timegassy.getValue().longValue();
        if (useRealTimegassy.getValue()) {
            final LocalTime localTimegassy = LocalTime.now();
            final int hourgassy = localTimegassy.getHour();
            final int minutegassy = localTimegassy.getMinute();

            final long totalMinutesgassy = hourgassy * 60L + minutegassy;
            long minecraftTime = (totalMinutesgassy * 1000L / 1440L) * 24L;
            timegassy = (minecraftTime + 18000L) % 24000L;
        }

        mc.world.getLevelProperties().setTimeOfDay(timegassy);
    }

    @Subscribe
    public void onReceivePacketgassy(final ReceivePacketEvent event) {
        if (event.getPacket() instanceof WorldTimeUpdateS2CPacket) {
            event.setCancelled();
        }
    }

    public boolean isEndSkygassy() {
        return this.endSkygassy.getValue();
    }
}
