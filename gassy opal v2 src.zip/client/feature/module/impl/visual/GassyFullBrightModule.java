package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;

public final class GassyFullBrightModulegassy extends Modulegassy {

    public GassyFullBrightModulegassy() {
        super("Full Bright", "Enhances your game brightness.", ModuleCategory.VISUAL);
    }

}
