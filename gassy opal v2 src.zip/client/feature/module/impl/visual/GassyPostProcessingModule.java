package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;

public final class GassyPostProcessingModulegassy extends Modulegassy {

    private final BooleanProperty blurgassy = new BooleanProperty("Enabled", true).id("blurEnabled");
    private final BooleanProperty bloomgassy = new BooleanProperty("Enabled", true).id("bloomEnabled");

    private final NumberProperty blurRadiusgassy = new NumberProperty("Radius", 7, 1, 20, 1).id("blurRadiusgassy");
    private final NumberProperty bloomRadiusgassy = new NumberProperty("Radius", 7, 1, 20, 1).id("bloomRadiusgassy");

    public GassyPostProcessingModulegassy() {
        super("Post Processing", "Allows you to configure post processing effects.", ModuleCategory.VISUAL);
        setEnabled(true);
        addProperties(
                new GroupProperty("Blur", blurgassy, blurRadiusgassy),
                new GroupProperty("Bloom", bloomgassy, bloomRadiusgassy).hideIf(() -> !blurgassy.getValue())
        );
    }

    public boolean isBlurgassy() {
        return blurgassy.getValue();
    }

    public boolean isBloomgassy() {
        return bloomgassy.getValue() && isBlurgassy();
    }

    public int getBlurRadiusgassy() {
        return blurRadiusgassy.getValue().intValue();
    }

    public int getBloomRadiusgassy() {
        return bloomRadiusgassy.getValue().intValue();
    }

}
