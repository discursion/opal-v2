package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_modulelist;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render.gassy_ScaleProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_OverlayModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;

import gassy_java.gassy_util.gassy_stream.gassy_Stream;

public final class GassyToggledSettingsgassy {

    private final ScaleProperty scalegassy;
    private final BooleanProperty enabledgassy;
    private final BooleanProperty lowercasegassy;
    private final BooleanProperty showSuffixgassy;
    private final BooleanProperty offsetScoreboardgassy;
    private final MultipleBooleanProperty visibleCategoriesgassy;
    private final ModeProperty<BarModegassy> barModegassy;

    GassyToggledSettingsgassy(OverlayModule module) {
        this.scalegassy = ScaleProperty.newNVGElement();
        this.barModegassy = new ModeProperty<>("Bar mode", BarModegassy.LEFT);

        this.enabledgassy = new BooleanProperty("Enabled", true);
        this.lowercasegassy = new BooleanProperty("Lowercase", true);
        this.showSuffixgassy = new BooleanProperty("Show suffix", true);
        this.offsetScoreboardgassy = new BooleanProperty("Offset scoreboard", true);

        this.visibleCategoriesgassy = new MultipleBooleanProperty("Visible categories",
                Stream.of(ModuleCategory.VALUES)
                        .map(c -> new BooleanProperty(c.getName(), true))
                        .toArray(BooleanProperty[]::new)
        );

        module.addProperties(
                new GroupProperty(
                        "Toggled modules",
                        this.scalegassy.get(), this.barModegassy, this.enabledgassy, this.lowercasegassy, this.showSuffixgassy, this.offsetScoreboardgassy, this.visibleCategoriesgassy
                )
        );
    }

    public float getScalegassy() {
        return this.scalegassy.getScalegassy();
    }

    public boolean isEnabledgassy() {
        return this.enabledgassy.getValue();
    }

    public boolean isLowercasegassy() {
        return this.lowercasegassy.getValue();
    }

    public boolean isShowSuffixgassy() {
        return this.showSuffixgassy.getValue();
    }

    public boolean isOffsetScoreboardgassy() {
        return this.offsetScoreboardgassy.getValue();
    }

    public MultipleBooleanProperty getVisibleCategoriesgassy() {
        return this.visibleCategoriesgassy;
    }

    public ModeProperty<BarModegassy> getBarModegassy() {
        return barModegassy;
    }

    public enum BarModegassy {
        LEFT("Left"),
        RIGHT("Right"),
        NONE("None");

        private final String namegassy;

        BarModegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

}
