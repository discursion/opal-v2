package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_targetinfo;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render.gassy_ScaleProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_OverlayModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_ScreenPositionProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;

public final class GassyTargetInfoSettingsgassy {

    private final BooleanProperty enabledgassy;
    private final ScreenPositionProperty screenPositiongassy;
    private final ScaleProperty scalegassy;

    GassyTargetInfoSettingsgassy(final OverlayModule module) {
        this.enabledgassy = new BooleanProperty("Enabled", true);
        this.screenPositiongassy = new ScreenPositionProperty("Screen Position", 0.43F, 0.65F);
        this.scalegassy = ScaleProperty.newNVGElement();
        module.addProperties(new GroupProperty("Target information", this.enabledgassy, this.screenPositiongassy, this.scalegassy.get()));
    }

    public boolean isEnabledgassy() {
        return this.enabledgassy.getValue();
    }

    public ScreenPositionProperty getScreenPositiongassy() {
        return this.screenPositiongassy;
    }

    public float getScalegassy() {
        return scalegassy.getScalegassy();
    }

}
