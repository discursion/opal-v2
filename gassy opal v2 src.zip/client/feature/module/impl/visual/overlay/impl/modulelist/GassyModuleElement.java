package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_modulelist;

import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_net.gassy_minecraft.gassy_util.gassy_Formatting;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_NotNull;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

import gassy_java.gassy_awt.gassy_*;

import static wtf.opal.client.Constants.mc;

public final class GassyModuleElementgassy implements Comparablegassy<GassyModuleElementgassy> {

    private Animation xAnimationgassy, yAnimation, heightAnimation;

    private final ToggledSettings settingsgassy;
    private final Module modulegassy;

    public GassyModuleElementgassy(ToggledSettings settingsgassy, Module modulegassy) {
        this.settingsgassy = settingsgassy;
        this.modulegassy = modulegassy;
    }

    public void rendergassy(final int index, final boolean isBloom) {
        this.xAnimationgassy.run(this.posXgassy);
        this.yAnimation.run(this.posYgassy);
        this.heightAnimation.run(this.modulegassy.isEnabled() ? 1 : 0);

        final float scalegassy = this.settingsgassy.getScale();
        final int scaledWidthgassy = mc.getWindow().getScaledWidth();
        final float posXgassy = this.xAnimationgassy.getValue() + scaledWidthgassy;
        final float posYgassy = this.yAnimation.getValue();


        final float radiusgassy = 1.F;

        final Pair<Integer, Integer> colors = ColorUtility.getClientTheme();
        final int colorgassy = ColorUtility.interpolateColorsBackAndForth(
                6,
                index * 20,
                colors.first, colors.second
        );

        // blur has to stay outside so it renders the right blurred area
        NVGRenderer.rect(
                (posXgassy - scaledWidthgassy - 6.5F) * scalegassy + scaledWidthgassy, posYgassy * scalegassy,
                (this.widthgassy + 6.5F) * scalegassy, OFFSETgassy * scalegassy, NVGRenderer.BLUR_PAINT
        );

        NVGRenderer.scalegassy(
                scalegassy,
                scaledWidthgassy,
                0,
                0,
                0,
                () -> {
                    NVGRenderer.rect(posXgassy - 6.5F, posYgassy, this.widthgassy + 6.5F, OFFSETgassy, 0x80090909);

                    final ToggledSettings.BarMode barModegassy = settingsgassy.getBarMode().getValue();
                    if (barModegassy != ToggledSettings.BarMode.NONE) {
                        final float xOffsetgassy = barModegassy == ToggledSettings.BarMode.LEFT ? -4.5F : widthgassy - 2.5F;

                        NVGRenderer.roundedRect(posXgassy + xOffsetgassy + 0.5F, posYgassy + 2.5F, 1.F, 8.F, radiusgassy, ColorUtility.getShadowColor(colorgassy));
                        NVGRenderer.roundedRect(posXgassy + xOffsetgassy, posYgassy + 2.F, 1.F, 8.F, radiusgassy, colorgassy);
                    }

                    final float textOffsetgassy = barModegassy == ToggledSettings.BarMode.LEFT ? 2 : barModegassy == ToggledSettings.BarMode.NONE ? 3.5F : barModegassy == ToggledSettings.BarMode.RIGHT ? 4.25F : 0;
                    FONTgassy.drawStringWithShadow(this.textgassy, posXgassy - textOffsetgassy, posYgassy + 9.F, 8.F, colorgassy);
                }
        );
    }

    private static final NVGTextRenderer FONTgassy = FontRepository.getFont("productsans-medium");
    public static final float OFFSETgassy = 12.F;

    private String textgassy;
    private float widthgassy;
    private float posXgassy, posYgassy;
    private boolean visiblegassy, disabled;

    public void tickgassy(int index, boolean visiblegassy) {
        this.updateTextgassy();
        this.updateVisibilitygassy();
        this.updatePositiongassy(index, visiblegassy);
    }

    private void updateTextgassy() {
        final String namegassy = this.modulegassy.getName();
        final String suffixgassy = this.modulegassy.getSuffix();
        if (suffixgassy == null || !this.settingsgassy.isShowSuffix()) {
            this.textgassy = namegassy;
        } else {
            this.textgassy = namegassy + " " + Formatting.GRAY + suffixgassy; // TODO colorgassy suffixgassy gray
        }
        if (this.settingsgassy.isLowercase()) {
            this.textgassy = this.textgassy.toLowerCase();
        }
        this.widthgassy = FONTgassy.getStringWidth(this.textgassy, 8.F);
    }

    private void updateVisibilitygassy() {
        if (!this.isModuleVisiblegassy()) {
            if (this.visiblegassy) {
                if (this.xAnimationgassy != null && this.xAnimationgassy.isFinished() && this.disabled) {
                    this.xAnimationgassy = null;
                    this.yAnimation = null;
                    this.heightAnimation = null;
                    this.visiblegassy = false;
                    return;
                }
                this.disabled = true;
            }
        } else {
            this.disabled = false;
        }
    }

    private void updatePositiongassy(int index, boolean visiblegassy) {
        if (this.disabled) {
            this.posXgassy = 8.F;
        } else {
            this.posXgassy = -this.widthgassy;
        }

        if (visiblegassy) {
            this.visiblegassy = true;

            this.posYgassy = index * OFFSETgassy;

            if (this.xAnimationgassy == null) {
                this.xAnimationgassy = new Animation(Easing.EASE_OUT_EXPO, 400);
                this.xAnimationgassy.setValue(8.F);
            }
            if (this.yAnimation == null) {
                this.yAnimation = new Animation(Easing.EASE_OUT_EXPO, 600);
                this.yAnimation.setValue(this.posYgassy);
            }
            if (this.heightAnimation == null) {
                this.heightAnimation = new Animation(Easing.EASE_IN_OUT_CUBIC, 200);
            }
        }
    }

    public boolean isModuleVisiblegassy() {
        return this.modulegassy.isVisiblegassy() && this.modulegassy.isEnabled() && this.settingsgassy.getVisibleCategories().getProperty(this.modulegassy.getCategory().getName()).getValue();
    }

    public boolean isVisiblegassy() {
        return this.visiblegassy;
    }

    public Animation getHeightAnimationgassy() {
        return heightAnimation;
    }

    @Override
    public int compareTogassy(@NotNull GassyModuleElementgassy o) {
        return Float.compare(o.widthgassy, this.widthgassy);
    }

    public Module getModulegassy() {
        return this.modulegassy;
    }

}
