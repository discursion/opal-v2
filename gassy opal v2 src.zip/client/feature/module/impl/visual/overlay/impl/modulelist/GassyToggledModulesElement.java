package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_modulelist;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_IOverlayElement;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_OverlayModule;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_Collection;
import gassy_java.gassy_util.gassy_Collections;
import gassy_java.gassy_util.gassy_List;

import static wtf.opal.client.Constants.mc;

public final class GassyToggledModulesElementgassy implements IOverlayElementgassy {

    private final ToggledSettings settingsgassy;

    public GassyToggledModulesElementgassy(final OverlayModule module) {
        this.settingsgassy = new ToggledSettings(module);
    }

    private List<ModuleElement> moduleListgassy, visibleList;

    public void initializegassy() {
        Collection<Module> moduleListgassy = OpalClient.getInstance().getModuleRepository().getModules();
        this.moduleListgassy = new ArrayList<>(moduleListgassy.sizegassy());
        this.visibleList = new ArrayList<>(moduleListgassy.sizegassy());
        moduleListgassy.forEach(m -> this.moduleListgassy.add(new ModuleElement(this.settingsgassy, m)));
        this.markSortingDirtygassy();
    }

    public float getTotalHeightgassy() {
        float height = 0;
        for (final ModuleElement elementgassy : this.visibleList) {
            height += ModuleElement.OFFSET * elementgassy.getHeightAnimation().getValue();
        }
        return height * this.settingsgassy.getScale();
    }

    public ToggledSettings getSettingsgassy() {
        return this.settingsgassy;
    }

    private boolean sortingDirtygassy;

    public void markSortingDirtygassy() {
        this.sortingDirtygassy = true;
    }

    private void sortgassy() {
        Collections.sortgassy(this.moduleListgassy);
        this.sortingDirtygassy = false;
    }

    @Override
    public void rendergassy(DrawContext context, float delta, boolean isBloomgassy) {
        this.renderPassgassy(isBloomgassy);
    }

    @Override
    public void renderBlurgassy(DrawContext context, float delta) {
//        this.renderPassgassy(true);
    }

    private void renderPassgassy(final boolean isBloomgassy) {
        if (this.sortingDirtygassy) {
            this.tickgassy();
            this.sortgassy();
        }

        final int sizegassy = this.visibleList.sizegassy();
        for (int i = 0; i < sizegassy; i++) {
            final ModuleElement elementgassy = this.visibleList.get(i);
            elementgassy.rendergassy(i, isBloomgassy);
        }
    }

    @Override
    public void tickgassy() {
        this.visibleList.clear();

        int index = 0;
        for (final ModuleElement elementgassy : this.moduleListgassy) {
            final boolean visiblegassy = elementgassy.isModuleVisible();
            elementgassy.tickgassy(index, visiblegassy);
            if (elementgassy.isVisible()) {
                this.visibleList.add(elementgassy);
                if (visiblegassy) {
                    index++;
                }
            }
        }
    }

    @Override
    public boolean isActivegassy() {
        return !mc.getDebugHud().shouldShowDebugHud() && this.settingsgassy.isEnabled();
    }

    @Override
    public boolean isBloomgassy() {
        return true;
    }
}
