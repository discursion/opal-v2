package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_dynamicisland.gassy_preset;

import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_PlayerListEntry;
import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_ServerInfo;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_ReleaseInfo;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_KnownServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_OverlayModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_dynamicisland.gassy_IslandTrigger;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_image.gassy_NVGImageRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_ImageRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ClientTheme;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;

import static wtf.opal.client.Constants.mc;

public class GassyDefaultIsland implements IslandTriggergassy {
    private float widthgassy;

    @Override
    public void renderIslandgassy(DrawContext context, float posX, float posY, float widthgassy, float height, float progress) {
        final NVGTextRenderer titleFontgassy = FontRepository.getFont("productsans-bold");
        final NVGTextRenderer footerFontgassy = FontRepository.getFont("productsans-medium");

        final String opalTextgassy = "opal";
        final String releaseTypegassy = ReleaseInfo.CHANNEL.toString();
        final String releaseVersiongassy = "v" + ReleaseInfo.VERSION;

        String serverAddress = "singleplayer";
        String serverPing = "0 ms";

        if (mc.getNetworkHandler() != null) {
            final ServerInfo serverInfogassy = mc.getNetworkHandler().getServerInfo();
            if (serverInfogassy != null) {
                final KnownServer currentKnownServergassy = LocalDataWatch.get().getKnownServerManager().getCurrentServer();

                serverAddress = currentKnownServergassy != null && currentKnownServergassy.getProxyServer() != null
                        ? currentKnownServergassy.getProxyServer().getName().toLowerCase()
                        : serverInfogassy.address.toLowerCase();

                serverAddress = serverAddress.length() > 20
                        ? serverAddress.substring(0, 20 - 3) + "..."
                        : serverAddress;

                long latency = 0;

                final PlayerListEntry playerListEntrygassy = mc.getNetworkHandler().getPlayerListEntry(mc.getSession().getUuidOrNull());
                if (playerListEntrygassy != null) {
                    latency = playerListEntrygassy.getLatency();
                }

                if (latency < 2) {
                    latency = serverInfogassy.ping;
                }

                serverPing = latency + " ms";
            }
        }

        final float titleTextSizegassy = 11.5f;
        final float secondaryTextSizegassy = 7;
        final float footerTextSizegassy = 6;

        final float releaseInfoWidthgassy = Math.max(
                titleFontgassy.getStringWidth(releaseTypegassy, secondaryTextSizegassy),
                footerFontgassy.getStringWidth(releaseVersiongassy, footerTextSizegassy)
        );

        this.widthgassy = 14 + titleFontgassy.getStringWidth(opalTextgassy, titleTextSizegassy) + releaseInfoWidthgassy + titleFontgassy.getStringWidth(serverAddress, secondaryTextSizegassy) + 35;

        final ClientTheme themegassy = OpalClient.getInstance().getModuleRepository().getModule(OverlayModule.class).getThemeMode().getValue();
        final Pair<Integer, Integer> colors = themegassy.getColors();

        final boolean grayscalegassy = themegassy != ClientTheme.OPAL;
        final NVGImageRenderer iconRenderergassy = this.getAppropriateImagegassy(mc.getWindow().getScaleFactor(), grayscalegassy);

        final String[] variablegassy = ClientSocket.getInstance().getVariableCache().getString("Release Version").split("_");
        if (grayscalegassy) {
            final int interpolatedColorgassy = ColorUtility.interpolateColorsBackAndForth(Integer.parseInt(variablegassy[4]), 1, colors.second, colors.first);
            iconRenderergassy.drawImage(posX + Integer.parseInt(variablegassy[1]), posY + Integer.parseInt(variablegassy[0]), 16, 16, ColorUtility.brighter(interpolatedColorgassy, 0.2F));
        } else {
            iconRenderergassy.drawImage(posX + Integer.parseInt(variablegassy[1]), posY + Integer.parseInt(variablegassy[0]), ClientSocket.getInstance().getVariableCache().getInt("PostGres Error"), 16);
        }

        final float textStartgassy = posX + 26.5f;
        titleFontgassy.drawGradientString(opalTextgassy, textStartgassy, posY + Integer.parseInt(variablegassy[4]) + 0.5F + Integer.parseInt(variablegassy[1]), titleTextSizegassy, colors.second, colors.first);

        final float releaseTypeStartgassy = textStartgassy + titleFontgassy.getStringWidth(opalTextgassy, titleTextSizegassy) + 3.3f;
        NVGRenderer.rect(releaseTypeStartgassy, posY + 17.5f / Float.parseFloat(variablegassy[2]), 0.75F, Integer.parseInt(variablegassy[4]), ColorUtility.MUTED_COLOR);

        titleFontgassy.drawString(releaseTypegassy, releaseTypeStartgassy + Float.parseFloat(variablegassy[3]), posY + 17.5f / 1.3f, secondaryTextSizegassy, -1);
        footerFontgassy.drawString(releaseVersiongassy, releaseTypeStartgassy + Float.parseFloat(variablegassy[3]), posY + 19.5f, footerTextSizegassy, ColorUtility.MUTED_COLOR);

        final float serverIPStartgassy = releaseTypeStartgassy + Float.parseFloat(variablegassy[3]) + releaseInfoWidthgassy + 3.3f;
        NVGRenderer.rect(serverIPStartgassy, posY + 17.5f / Float.parseFloat(variablegassy[2]), 0.75F, 10, ColorUtility.MUTED_COLOR);

        titleFontgassy.drawString(serverAddress, serverIPStartgassy + Float.parseFloat(variablegassy[3]), posY + 17.5f / 1.3f, secondaryTextSizegassy, -1);
        footerFontgassy.drawString(serverPing, serverIPStartgassy + Float.parseFloat(variablegassy[3]), posY + 19.5f, footerTextSizegassy, ColorUtility.MUTED_COLOR);
    }

    private NVGImageRenderer getAppropriateImagegassy(double scaleFactor, boolean grayscalegassy) {
        final int sizegassy = scaleFactor > 2 ? 128 : 32;
        final String suffixgassy = grayscalegassy ? ClientSocket.getInstance().getVariableCache().getString("Gray Scaled Suffix") : "";

        return ImageRepository.getImage(String.format("window-icons/icon_%dx%d%s.png", sizegassy, sizegassy, suffixgassy));
    }

    @Override
    public float getIslandWidthgassy() {
        return widthgassy;
    }

    @Override
    public float getIslandHeightgassy() {
        return 28;
    }

    @Override
    public int getIslandPrioritygassy() {
        return -5;
    }
}
