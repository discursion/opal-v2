package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_dynamicisland;

public interface CustomIslandTrigger extends IslandTriggergassy {
    float getIslandX();

    float getIslandY();
}
