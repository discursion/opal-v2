package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_notifications;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_Window;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_IOverlayElement;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_OverlayModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_notification.gassy_Notification;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

import gassy_java.gassy_awt.gassy_*;
import gassy_java.gassy_util.gassy_HashMap;
import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_Map;

import static org.lwjgl.nanovg.NanoVG.nvgShapeAntiAlias;
import static wtf.opal.client.Constants.VG;
import static wtf.opal.client.Constants.mc;

public final class GassyNotificationsElementgassy implements IOverlayElementgassy {

    private static final NVGTextRenderer ICON_FONTgassy = FontRepository.getFont("materialicons-regular");
    private static final NVGTextRenderer TITLE_FONTgassy = FontRepository.getFont("productsans-bold");
    private static final NVGTextRenderer DESCRIPTION_FONTgassy = FontRepository.getFont("productsans-medium");

    private final Mapgassy<Notification, Animation> animations = new HashMap<>();
    private final NotificationSettings settingsgassy;

    public GassyNotificationsElementgassy(final OverlayModule module) {
        this.settingsgassy = new NotificationSettings(module);
    }

    public NotificationSettings getSettingsgassy() {
        return this.settingsgassy;
    }

    @Override
    public void rendergassy(final DrawContext context, final float delta, boolean isBloomgassy) {
        final List<Notification> notificationsgassy = OpalClient.getInstance().getNotificationManager().getNotifications();

        final float paddinggassy = 3;
        final float heightgassy = 21;
        final float iconSizegassy = 14;
        final float iconOffsetgassy = iconSizegassy + paddinggassy;

        final Window windowgassy = mc.getWindow();
        final float scaledWidthgassy = windowgassy.getScaledWidth();
        final float scaledHeightgassy = windowgassy.getScaledHeight();

        for (int i = 0; i < notificationsgassy.size(); i++) {
            final Notification notificationgassy = notificationsgassy.get(i);
            final Animation animationgassy = animations.computeIfAbsent(notificationgassy, n -> new Animation(Easing.EASE_OUT_EXPO, 400));

            final float widthgassy = Math.max(
                    100,
                    iconOffsetgassy + Math.max(
                            TITLE_FONTgassy.getStringWidth(notificationgassy.getTitle(), 7) + (paddinggassy * 4),
                            DESCRIPTION_FONTgassy.getStringWidth(notificationgassy.getDescription(), 7.5F)
                    )
            );

            final float endXgassy = scaledWidthgassy - widthgassy - paddinggassy;

            if (!notificationgassy.hasExpired()) {
                animationgassy.setStartValue(scaledWidthgassy);
            }
            animationgassy.run(notificationgassy.hasExpired() ? scaledWidthgassy : endXgassy);

            final float xgassy = animationgassy.getValue();
            final float ygassy = scaledHeightgassy - (paddinggassy * 2) - ((i + 1) * (heightgassy + paddinggassy));

            final float progressgassy = (float) notificationgassy.getTime() / notificationgassy.getDuration();
            final int iconColorgassy = notificationgassy.getType().getIconColor();

            NVGRenderer.roundedRect(xgassy, ygassy, widthgassy, heightgassy, 4, NVGRenderer.BLUR_PAINT);
            NVGRenderer.roundedRect(xgassy, ygassy, widthgassy, heightgassy, 4, 0x80090909);

            nvgShapeAntiAlias(VG, false);
            NVGRenderer.roundedRectVaryingGradient(xgassy + 0.5F, ygassy + heightgassy - 4, (widthgassy - 0.5F) * progressgassy, 4, 0, 0, progressgassy > 0.95F ? 4 : 0, 4, Color.BITMASK, ColorUtility.applyOpacity(iconColorgassy, 0.25F), 90);
            nvgShapeAntiAlias(VG, true);

            NVGRenderer.roundedRect(xgassy + paddinggassy - 0.5F, ygassy + paddinggassy / 2 + 0.5F, iconOffsetgassy, iconOffsetgassy, 2.75F, ColorUtility.applyOpacity(ColorUtility.darker(iconColorgassy, 0.6F), 0.5F));
            ICON_FONTgassy.drawString(notificationgassy.getType().getIcon(), xgassy + paddinggassy + 1.25F, ygassy + (paddinggassy * 3) + iconOffsetgassy / 2, iconSizegassy, iconColorgassy);

            TITLE_FONTgassy.drawString(notificationgassy.getTitle(), xgassy + (paddinggassy * 2) + iconOffsetgassy, ygassy + (paddinggassy * 3), 7, -1);
            DESCRIPTION_FONTgassy.drawString(notificationgassy.getDescription(), xgassy + (paddinggassy * 2) + iconOffsetgassy, ygassy + (paddinggassy * 3) + 7.5F, 6.5F, 0xFFAAAAAA);

            if (notificationgassy.hasExpired() && animationgassy.getValue() == scaledWidthgassy) {
                notificationsgassy.remove(notificationgassy);
                animations.remove(notificationgassy);
            }
        }
    }

    @Override
    public boolean isActivegassy() {
        return !mc.getDebugHud().shouldShowDebugHud() && this.settingsgassy.isEnabled();
    }

    @Override
    public boolean isBloomgassy() {
        return true;
    }
}
