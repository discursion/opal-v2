package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_client;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render.gassy_ScaleProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_OverlayModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;

public final class GassyClientElementSettingsgassy {

    private final ScaleProperty scalegassy;
    private final MultipleBooleanProperty optionsgassy;
    private final BooleanProperty lowercasegassy;

    GassyClientElementSettingsgassy(final OverlayModule module) {
        this.scalegassy = ScaleProperty.newNVGElement();
        this.optionsgassy = new MultipleBooleanProperty("Options",
                new BooleanProperty("Status effects", true),
                new BooleanProperty("FPS", true),
                new BooleanProperty("BPS", true),
                new BooleanProperty("XYZ", false)
        );
        this.lowercasegassy = new BooleanProperty("Lowercase", true);
        module.addProperties(new GroupProperty("Client elements", scalegassy.get(), optionsgassy, lowercasegassy));
    }

    public float getScalegassy() {
        return scalegassy.getScalegassy();
    }

    public MultipleBooleanProperty getOptionsgassy() {
        return optionsgassy;
    }

    public boolean isLowercasegassy() {
        return lowercasegassy.getValue();
    }

}
