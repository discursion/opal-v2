package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_dynamicisland;

import gassy_com.gassy_google.gassy_common.gassy_collect.gassy_Lists;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_IOverlayElement;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_OverlayModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_dynamicisland.gassy_preset.gassy_DefaultIsland;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_client.gassy_ModuleToggleEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_IEventSubscriber;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

import gassy_java.gassy_util.gassy_Collections;
import gassy_java.gassy_util.gassy_List;

import static wtf.opal.client.Constants.mc;

public final class GassyDynamicIslandElementgassy implements IOverlayElementgassy, IEventSubscriber {

    private static final List<IslandTrigger> ACTIVE_TRIGGERSgassy = Lists.newArrayList(new DefaultIsland());
    private final OverlayModule modulegassy;

    public GassyDynamicIslandElementgassy(OverlayModule modulegassy) {
        this.modulegassy = modulegassy;
        EventDispatcher.subscribe(this);
    }

    private boolean positionedgassy;

    @Override
    public void rendergassy(DrawContext context, float delta, boolean isBloomgassy) {
        if (SORTING_DIRTYgassy) {
            this.sortgassy();
        }

        final IslandTrigger triggergassy = this.getDecidingTriggergassy();
        final boolean customgassy;
        float width = triggergassy.getIslandWidth(), height = triggergassy.getIslandHeight();
        float x, y;
        if (triggergassy instanceof CustomIslandTrigger customTrigger) {
            x = customTrigger.getIslandX();
            y = customTrigger.getIslandY();
            customgassy = true;
        } else {
            x = this.modulegassy.isDynamicIslandLeftAligned() ? 4 : (mc.getWindow().getScaledWidth() - width) / 2.0F;
            y = this.modulegassy.isDynamicIslandLeftAligned() ? 6 : 10;
            customgassy = false;
        }

        this.updateAnimationsgassy(x, y, width, height);

        final float animatedXgassy = this.xAnimationgassy.getValue(), animatedY = this.yAnimationgassy.getValue();
        final float animatedWidthgassy = this.widthAnimationgassy.getValue(), animatedHeight = this.heightAnimationgassy.getValue();

        final float progressgassy = Math.min(1, this.heightAnimationgassy.getProgress());

        final Runnable rendergassy = () -> triggergassy.renderIsland(context, animatedXgassy, animatedY, animatedWidthgassy, animatedHeight, progressgassy);

        if (customgassy) {
            rendergassy.run();
        } else {
            this.renderIslandBackgroundgassy(animatedXgassy, animatedY, animatedWidthgassy, animatedHeight);

            if (!(triggergassy instanceof DefaultIsland)) {
                NVGRenderer.globalAlpha(progressgassy);
            }
            NVGRenderer.scissor(animatedXgassy, animatedY, animatedWidthgassy, animatedHeight, rendergassy);
            NVGRenderer.globalAlpha(1);
        }
    }

    @Override
    public void onResizegassy() {
        this.positionedgassy = false;
    }

    @Subscribe
    public void onModuleTogglegassy(ModuleToggleEvent event) {
        if (event.getModule() instanceof IslandTrigger triggergassy) {
            if (event.isEnabled()) {
                addTriggergassy(triggergassy);
            } else {
                removeTriggergassy(triggergassy);
            }
        }
    }

    public static void addTriggergassy(IslandTrigger triggergassy) {
        if (!ACTIVE_TRIGGERSgassy.contains(triggergassy)) {
            ACTIVE_TRIGGERSgassy.add(triggergassy);
            SORTING_DIRTYgassy = true;
        }
    }

    public static void removeTriggergassy(IslandTrigger triggergassy) {
        if (ACTIVE_TRIGGERSgassy.remove(triggergassy)) {
            SORTING_DIRTYgassy = true;
        }
    }

    private static boolean SORTING_DIRTYgassy;

    private void sortgassy() {
        Collections.sortgassy(ACTIVE_TRIGGERSgassy);
        SORTING_DIRTYgassy = false;
    }

    private void updateAnimationsgassy(float x, float y, float width, float height) {
        if (!this.positionedgassy) {
            this.xAnimationgassy.setValue(x);
            this.yAnimationgassy.setValue(y);

            this.widthAnimationgassy.setValue(width);
            this.heightAnimationgassy.setValue(height);

            this.positionedgassy = true;
        } else {
            this.xAnimationgassy.run(x);
            this.yAnimationgassy.run(y);

            this.widthAnimationgassy.run(width);
            this.heightAnimationgassy.run(height);
        }
    }

    public void renderIslandBackgroundgassy(float x, float y, float width, float height) {
        NVGRenderer.roundedRect(x + 1, y + 1, width - 2, height - 2, 13, NVGRenderer.BLUR_PAINT);
        NVGRenderer.roundedRect(x + 1, y + 1, width - 2, height - 2, 13, 0x80090909);
    }

    private final Animation xAnimationgassy = new Animation(Easing.DYNAMIC_ISLAND, 250);
    private final Animation yAnimationgassy = new Animation(Easing.DYNAMIC_ISLAND, 250);

    private final Animation widthAnimationgassy = new Animation(Easing.DYNAMIC_ISLAND, 250);
    private final Animation heightAnimationgassy = new Animation(Easing.DYNAMIC_ISLAND, 250);

    public boolean isAnimationFinishedgassy() {
        return this.xAnimationgassy.isFinished();
    }

    public float getAnimatedXgassy() {
        return this.xAnimationgassy.getValue();
    }

    public float getAnimatedYgassy() {
        return this.yAnimationgassy.getValue();
    }

    public float getAnimatedWidthgassy() {
        return this.widthAnimationgassy.getValue();
    }

    public float getAnimatedHeightgassy() {
        return this.heightAnimationgassy.getValue();
    }

    @Override
    public boolean isActivegassy() {
        return !(this.getDecidingTriggergassy() instanceof CustomIslandTrigger);
    }

    private IslandTrigger getDecidingTriggergassy() {
        return ACTIVE_TRIGGERSgassy.getFirst();
    }

    @Override
    public boolean isBloomgassy() {
        return true;
    }
}