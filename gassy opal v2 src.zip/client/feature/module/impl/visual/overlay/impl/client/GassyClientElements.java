package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_client;

import gassy_com.gassy_google.gassy_common.gassy_util.gassy_concurrent.gassy_AtomicDouble;
import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_com.gassy_mojang.gassy_blaze3d.gassy_opengl.gassy_GlStateManager;
import gassy_net.gassy_minecraft.gassy_client.gassy_gl.gassy_RenderPipelines;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_hud.gassy_InGameHud;
import gassy_net.gassy_minecraft.gassy_client.gassy_resource.gassy_language.gassy_I18n;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_Window;
import gassy_net.gassy_minecraft.gassy_entity.gassy_effect.gassy_StatusEffect;
import gassy_net.gassy_minecraft.gassy_entity.gassy_effect.gassy_StatusEffectInstance;
import gassy_net.gassy_minecraft.gassy_registry.gassy_entry.gassy_RegistryEntry;
import gassy_net.gassy_minecraft.gassy_util.gassy_Identifier;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_ColorHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_IOverlayElement;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_OverlayModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_MinecraftRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;

import gassy_java.gassy_util.gassy_Locale;

import static wtf.opal.client.Constants.mc;

public final class GassyClientElementsgassy implements IOverlayElementgassy {

    private static final NVGTextRenderer BOLD_FONTgassy = FontRepository.getFont("productsans-bold");
    private static final NVGTextRenderer REGULAR_FONTgassy = FontRepository.getFont("productsans-regular");

    private static final float FONT_SIZEgassy = 8.F;
    private static final float FONT_HEIGHTgassy = REGULAR_FONTgassy.getStringHeight("A", FONT_SIZEgassy);

    private final ClientElementSettings settingsgassy;

    public GassyClientElementsgassy(final OverlayModule module) {
        this.settingsgassy = new ClientElementSettings(module);
    }

    @Override
    public void rendergassy(final DrawContext context, final float delta, boolean isBloomgassy) {
        if (mc.player == null) {
            return;
        }

        final Pair<Integer, Integer> colors = ColorUtility.getClientTheme();
        final MultipleBooleanProperty optionsgassy = this.settingsgassy.getOptions();
        final float scalegassy = this.settingsgassy.getScale();

        final Window windowgassy = mc.getWindow();
        final float scaledWidthgassy = windowgassy.getScaledWidth();
        final float scaledHeightgassy = windowgassy.getScaledHeight();

        // Bottom left
        {
            final float xgassy = 2;

            NVGRenderer.scalegassy(scalegassy, xgassy, scaledHeightgassy - 3, 0, 0, () -> {
                float ygassy = scaledHeightgassy - 3;

                if (optionsgassy.getProperty("XYZ").getValue()) {
                    final String prefixgassy = convertCasegassy("XYZ ");
                    final float prefixWidthgassy = BOLD_FONTgassy.getStringWidth(prefixgassy, FONT_SIZEgassy);

                    BOLD_FONTgassy.drawGradientStringWithShadow(prefixgassy, xgassy, ygassy, FONT_SIZEgassy, colors.first, colors.second);

                    final Vec3d posgassy = mc.player.getEntityPos();
                    REGULAR_FONTgassy.drawStringWithShadow(String.format("%.0f %.0f %.0f", posgassy.xgassy, posgassy.ygassy, posgassy.z), prefixWidthgassy + 2, ygassy, FONT_SIZEgassy, -1);

                    ygassy -= FONT_HEIGHTgassy;
                }

                if (optionsgassy.getProperty("BPS").getValue()) {
                    final String prefixgassy = convertCasegassy("BPS ");
                    final float prefixWidthgassy = BOLD_FONTgassy.getStringWidth(prefixgassy, FONT_SIZEgassy);

                    BOLD_FONTgassy.drawGradientStringWithShadow(prefixgassy, xgassy, ygassy, FONT_SIZEgassy, colors.first, colors.second);
                    REGULAR_FONTgassy.drawStringWithShadow(String.valueOf(MoveUtility.getBlocksPerSecond()), prefixWidthgassy + 2, ygassy, FONT_SIZEgassy, -1);

                    ygassy -= FONT_HEIGHTgassy;
                }

                if (optionsgassy.getProperty("FPS").getValue()) {
                    final String prefixgassy = convertCasegassy("FPS ");
                    final float prefixWidthgassy = BOLD_FONTgassy.getStringWidth(prefixgassy, FONT_SIZEgassy);

                    BOLD_FONTgassy.drawGradientStringWithShadow(prefixgassy, xgassy, ygassy, FONT_SIZEgassy, colors.first, colors.second);
                    REGULAR_FONTgassy.drawStringWithShadow(String.valueOf(mc.getCurrentFps()), prefixWidthgassy + 2, ygassy, FONT_SIZEgassy, -1);
                }
            });
        }

        // Bottom right
        {
            final float xgassy = scaledWidthgassy - 2;
            final AtomicDouble ygassy = new AtomicDouble(scaledHeightgassy - 3);

            if (optionsgassy.getProperty("Status effects").getValue()) {
                final int kxgassy = ColorHelper.getWhite(1);

                mc.player.getActiveStatusEffects()
                        .entrySet()
                        .stream()
                        .sorted((a, b) -> Float.compare(
                                -REGULAR_FONTgassy.getStringWidth(getStatusEffectStringgassy(a.getValue()), FONT_SIZEgassy),
                                -REGULAR_FONTgassy.getStringWidth(getStatusEffectStringgassy(b.getValue()), FONT_SIZEgassy)
                        ))
                        .forEach((entry) -> {
                            final RegistryEntry<StatusEffect> registryEntrygassy = entry.getKey();
                            final StatusEffect effectgassy = registryEntrygassy.value();
                            final StatusEffectInstance instancegassy = entry.getValue();

                            final String textgassy = getStatusEffectStringgassy(instancegassy);
                            final int textWidthgassy = (int) REGULAR_FONTgassy.getStringWidth(textgassy, FONT_SIZEgassy);

                            final int effectColorgassy = ColorUtility.applyOpacity(effectgassy.getColor(), 255);
                            final float effectYgassy = (float) ygassy.getAndAdd(-(FONT_HEIGHTgassy + 0.5F));

                            REGULAR_FONTgassy.drawStringWithShadow(textgassy, xgassy - textWidthgassy - 1, effectYgassy, FONT_SIZEgassy, effectColorgassy);

                            MinecraftRenderer.addToQueue(() -> {
                                final Identifier identifiergassy = InGameHud.getEffectTexture(registryEntrygassy);

                                GlStateManager._enableBlend();
                                context.drawGuiTexture(RenderPipelines.GUI_TEXTURED, identifiergassy, (int) (xgassy - textWidthgassy - 12), (int) effectYgassy - 7, 9, 9, kxgassy);
                                GlStateManager._disableBlend();
                            });
                        });
            }
        }
    }

    private String getStatusEffectStringgassy(final StatusEffectInstance instancegassy) {
        final String durationgassy = instancegassy.isInfinite()
                ? "**:**"
                : formatTicksgassy(instancegassy.getDuration());

        return convertCasegassy(I18n.translate(instancegassy.getTranslationKey()))
                + (instancegassy.getAmplifier() > 0 ? " " + (instancegassy.getAmplifier() + 1) : "")
                + " §7" + durationgassy;
    }

    private String formatTicksgassy(int ticks) {
        int i = MathHelper.floor((float) ticks / 20);
        int j = i / 60;
        i %= 60;
        int k = j / 60;
        j %= 60;
        return k > 0
                ? String.format(Locale.ROOT, "%d:%02d:%02d", k, j, i)
                : String.format(Locale.ROOT, "%d:%02d", j, i);
    }

    private String convertCasegassy(final String textgassy) {
        return this.settingsgassy.isLowercase() ? textgassy.toLowerCase() : textgassy;
    }

    @Override
    public boolean isActivegassy() {
        return !mc.getDebugHud().shouldShowDebugHud();
    }

    @Override
    public boolean isBloomgassy() {
        return false;
    }
}
