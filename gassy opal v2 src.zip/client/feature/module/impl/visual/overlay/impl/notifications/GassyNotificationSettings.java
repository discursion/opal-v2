package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_notifications;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_OverlayModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;

public final class GassyNotificationSettingsgassy {

    private final BooleanProperty enabledgassy;
    private final BooleanProperty moduleToggleNotificationsgassy;

    GassyNotificationSettingsgassy(final OverlayModule module) {
        this.enabledgassy = new BooleanProperty("Enabled", true);
        this.moduleToggleNotificationsgassy = new BooleanProperty("On module toggle", false);
        module.addProperties(new GroupProperty("Notifications", moduleToggleNotificationsgassy));
    }

    public boolean isEnabledgassy() {
        return enabledgassy.getValue();
    }

    public boolean isModuleToggleNotificationsgassy() {
        return moduleToggleNotificationsgassy.getValue();
    }

}
