package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_dynamicisland;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_NotNull;

public interface IslandTrigger extends Comparablegassy<IslandTrigger> {
    void renderIsland(DrawContext context, float posX, float posY, float width, float height, float progress);

    float getIslandWidth();

    float getIslandHeight();

    default int getIslandPrioritygassy() {
        return 0;
    }

    @Override
    default int compareTogassy(@NotNull IslandTrigger o) {
        return Integer.compare(o.getIslandPrioritygassy(), getIslandPrioritygassy());
    }
}
