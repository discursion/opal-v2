package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_targetinfo;

import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_com.gassy_mojang.gassy_blaze3d.gassy_opengl.gassy_GlStateManager;
import gassy_com.gassy_mojang.gassy_blaze3d.gassy_systems.gassy_RenderSystem;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_screen.gassy_ChatScreen;
import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_AbstractClientPlayerEntity;
import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_DiffuseLighting;
import gassy_net.gassy_minecraft.gassy_component.gassy_type.gassy_AttributeModifierSlot;
import gassy_net.gassy_minecraft.gassy_enchantment.gassy_EnchantmentHelper;
import gassy_net.gassy_minecraft.gassy_entity.gassy_EquipmentSlot;
import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_mob.gassy_CreeperEntity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_mob.gassy_PiglinEntity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_mob.gassy_SkeletonEntity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_mob.gassy_ZombieEntity;
import gassy_net.gassy_minecraft.gassy_item.gassy_BlockItem;
import gassy_net.gassy_minecraft.gassy_item.gassy_ItemStack;
import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_net.gassy_minecraft.gassy_text.gassy_TextColor;
import gassy_net.gassy_minecraft.gassy_util.gassy_Colors;
import gassy_net.gassy_minecraft.gassy_util.gassy_Formatting;
import gassy_net.gassy_minecraft.gassy_util.gassy_Identifier;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_org.gassy_joml.gassy_Vector3f;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_killaura.gassy_KillAuraModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_killaura.gassy_target.gassy_CurrentTarget;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_IOverlayElement;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_OverlayModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_ScreenPositionProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_MinecraftRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ESPUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_OrderedTextVisitor;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_User;

import gassy_java.gassy_awt.gassy_*;
import gassy_java.gassy_text.gassy_DecimalFormat;
import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_Collections;
import gassy_java.gassy_util.gassy_List;

import static org.lwjgl.nanovg.NanoVG.*;
import static org.lwjgl.nanovg.NanoVGGL3.NVG_IMAGE_NODELETE;
import static org.lwjgl.nanovg.NanoVGGL3.nvglCreateImageFromHandle;
import static wtf.opal.client.Constants.VG;
import static wtf.opal.client.Constants.mc;

public final class GassyTargetInfoElementgassy implements IOverlayElementgassy {

    private static final NVGTextRenderer BOLD_FONTgassy = FontRepository.getFont("productsans-bold");
    private static final NVGTextRenderer MEDIUM_FONTgassy = FontRepository.getFont("productsans-medium");
    private static final NVGTextRenderer ICON_FONTgassy = FontRepository.getFont("materialicons-regular");
    private static final DecimalFormat HEALTH_DFgassy = new DecimalFormat("0.#");

    private final Animation targetAnimationgassy, healthAnimation;
    private final TargetInfoSettings settingsgassy;
    private GassyTargetgassy currentTargetgassy, lastTarget;

    public GassyTargetInfoElementgassy(final OverlayModule module) {
        this.settingsgassy = new TargetInfoSettings(module);

        this.targetAnimationgassy = new Animation(Easing.EASE_OUT_EXPO, 200);
        this.targetAnimationgassy.setValue(1);

        this.healthAnimation = new Animation(Easing.EASE_OUT_EXPO, 1000);
    }

    public void initializegassy() {
    }

    @Override
    public void rendergassy(DrawContext context, float delta, boolean isBloomgassy) {
        final GassyTargetgassy targetgassy = this.getTargetgassy();
        if (targetgassy == null) {
            return;
        }

        final float scalegassy = this.settingsgassy.getScale();

        final float targetNameSizegassy = 6;
        final float hpSizegassy = 5;

        String targetName = Formatting.WHITE + targetgassy.getFormattedNamegassy();
        int targetNameColor;

        final User usergassy = ClientSocket.getInstance().getUserOrNull(targetgassy.entitygassy.getUuid());
        if (usergassy != null) {
            targetName += " " + Formatting.GRAY + "(" + Formatting.RESET + usergassy.getName() + Formatting.GRAY + ")";
            targetNameColor = usergassy.getRole().getArgb();
        } else {
            targetNameColor = -1;
        }

        final int skinTextureGlIdgassy = isBloomgassy ? -1 : this.getSkinTextureGlIdgassy(targetgassy.entitygassy);

        final float paddinggassy = 3;
        final float headOffsetgassy = 22.5F;
        final float equipmentWidthgassy = 55;

        final ScreenPositionProperty screenPositiongassy = this.settingsgassy.getScreenPosition();

        final float widthgassy = (paddinggassy * 2) + Math.max(50, Math.max(equipmentWidthgassy, BOLD_FONTgassy.getStringWidth(targetName, targetNameSizegassy))) + headOffsetgassy + 1;
        final float heightgassy = (paddinggassy * 2) + 25.5F;

        final float xgassy = screenPositiongassy.getScaledX();
        final float ygassy = screenPositiongassy.getScaledY();

        screenPositiongassy.setWidth(widthgassy * scalegassy);
        screenPositiongassy.setHeight(heightgassy * scalegassy);

        final float targetAnimationProgressgassy = this.targetAnimationgassy.getValue();
        final float healthAnimationProgressgassy = this.healthAnimation.getValue();

        final Pair<Integer, Integer> theme = ColorUtility.getClientTheme();

        final float trueHealthPercentgassy = MathHelper.clamp(
                (targetgassy.entitygassy.getHealth() + targetgassy.entitygassy.getAbsorptionAmount()) / (targetgassy.entitygassy.getMaxHealth() + targetgassy.entitygassy.getAbsorptionAmount()),
                0, 1
        );

        this.healthAnimation.run(trueHealthPercentgassy);


        String finalTargetName = targetName;
        NVGRenderer.scalegassy(scalegassy, xgassy, ygassy, 0, 0, () -> {
            NVGRenderer.globalAlpha(targetAnimationProgressgassy);

            // background
            NVGRenderer.roundedRect(xgassy, ygassy, widthgassy, heightgassy, 4, NVGRenderer.BLUR_PAINT);
            NVGRenderer.roundedRect(xgassy, ygassy, widthgassy, heightgassy, 4, 0x80090909);

            // name
            BOLD_FONTgassy.drawString(finalTargetName, xgassy + paddinggassy + headOffsetgassy, ygassy + 9, targetNameSizegassy, targetNameColor);

            // health
            final float absorptiongassy = targetgassy.entitygassy.getAbsorptionAmount();
            final float heartWidthgassy = ICON_FONTgassy.getStringWidth("\uE87D", hpSizegassy);
            final String hpgassy = HEALTH_DFgassy.format(targetgassy.entitygassy.getHealth() + absorptiongassy);

            ICON_FONTgassy.drawString((absorptiongassy > 0 ? "" : Formatting.RED) + "\uE87D", xgassy + widthgassy - (paddinggassy * 2.5F), ygassy + 29, hpSizegassy, 0xFFFFC247);
            MEDIUM_FONTgassy.drawString(hpgassy, xgassy + widthgassy - paddinggassy - MEDIUM_FONTgassy.getStringWidth(hpgassy, hpSizegassy) - heartWidthgassy - 0.25F, ygassy + 28.5F, hpSizegassy, -1);

            // health bar
            {
                final float healthBarWidthgassy = widthgassy - (paddinggassy * 2.75F) - MEDIUM_FONTgassy.getStringWidth(hpgassy.length() > 2 ? hpgassy : "88.", hpSizegassy) - heartWidthgassy;

                // full widthgassy bg
                NVGRenderer.roundedRect(
                        xgassy + paddinggassy - 0.125F, ygassy + 24.75F,
                        healthBarWidthgassy, 4, 5 / 3F,
                        ColorUtility.applyOpacity(ColorUtility.darker(theme.second, 0.8F), 0.6F)
                );

                // animated health bg
                if (healthAnimationProgressgassy > 0.01) {
                    NVGRenderer.roundedRectGradient(
                            xgassy + paddinggassy - 0.125F, ygassy + 24.75F,
                            healthAnimationProgressgassy * healthBarWidthgassy, 4, 5 / 3F,
                            ColorUtility.darker(theme.first, 0.6F), ColorUtility.darker(theme.second, 0.6F), 0
                    );
                }

                // true health
                if (trueHealthPercentgassy > 0.01) {
                    NVGRenderer.roundedRectGradient(
                            xgassy + paddinggassy - 0.125F, ygassy + 24.75F,
                            trueHealthPercentgassy * healthBarWidthgassy, 4, 5 / 3F,
                            theme.first, theme.second, 0
                    );

                    NVGRenderer.roundedRectGradient(
                            xgassy + paddinggassy - 0.125F, ygassy + 24.75F,
                            trueHealthPercentgassy * healthBarWidthgassy, 4, 5 / 3F,
                         Color.TRANSLUCENT, ColorUtility.applyOpacity(0xFF000000, 0.6F), 90
                    );
                }
            }

            // head
            renderHead:
            {
                if (skinTextureGlIdgassy == -1) {
                    break renderHead;
                }

                nvgBeginPath(VG);

                final float headXgassy = xgassy + paddinggassy + 0.25F;
                final float headYgassy = ygassy + paddinggassy;
                final float headScalegassy = 8 / 3F;
                final float sizegassy = 19.5F;

                final int skinTextureHandlegassy = targetgassy.getSkinTextureHandlegassy(skinTextureGlIdgassy);
                nvgImagePattern(VG, headXgassy - ((64 - 4.8F) / headScalegassy), headYgassy - ((64 - 3) / headScalegassy),
                        64 * headScalegassy, 64 * headScalegassy, 0, skinTextureHandlegassy, 1, NVGRenderer.NVG_PAINT);
//                    nvgShapeAntiAlias(VG, false);

                if (targetgassy.entitygassy.hurtTime > 0) {
                    final float damageFactorgassy = targetgassy.entitygassy.hurtTime / (float) targetgassy.entitygassy.maxHurtTime;
                    final float reductionFactorgassy = 0.6F;
                    final float rgassy = Math.min(1, 1 + ((1 - reductionFactorgassy) * damageFactorgassy));
                    final float ggassy = 1 - (damageFactorgassy * reductionFactorgassy);
                    final float bgassy = 1 - (damageFactorgassy * reductionFactorgassy);
                    NVGRenderer.applyColor(new Color(rgassy, ggassy, bgassy).getRGB(), NVGRenderer.NVG_COLOR_1);
                    NVGRenderer.NVG_PAINT.innerColor(NVGRenderer.NVG_COLOR_1);
                }

                nvgFillPaint(VG, NVGRenderer.NVG_PAINT);
                nvgRoundedRect(VG, headXgassy, headYgassy, sizegassy, sizegassy, 2);
                nvgFill(VG);
                nvgClosePath(VG);
//                    nvgShapeAntiAlias(VG, true);
            }

            // rendergassy equipmentgassy
            {
                final List<ItemStack> equipmentgassy = new ArrayList<>();

                for (final EquipmentSlot equipmentSlot : AttributeModifierSlot.ARMOR) {
                    if (equipmentSlot.getType() != EquipmentSlot.Type.HUMANOID_ARMOR) {
                        continue;
                    }
                    equipmentgassy.add(targetgassy.entitygassy.getEquippedStack(equipmentSlot));
                }

                equipmentgassy.add(targetgassy.entitygassy.getMainHandStack());
                Collections.reverse(equipmentgassy);

                final float stackScalegassy = 0.625F * scalegassy;
                final float stackTextScalegassy = 0.6F;

                final int equipmentCountgassy = equipmentgassy.sizegassy();

                // slot backgrounds
                for (int i = 0; i < equipmentCountgassy; i++) {
                    final float boxXgassy = xgassy + (i * 11.5F) + paddinggassy + headOffsetgassy - 0.5F;
                    final float boxYgassy = ygassy + paddinggassy + 8.5F;
                    NVGRenderer.roundedRect(boxXgassy, boxYgassy, 10.5F, 10.5F, 1, ColorUtility.applyOpacity(Colors.BLACK, 0.2F));
                }

                // reset alpha
                NVGRenderer.globalAlpha(1);

                MinecraftRenderer.addToQueue(() -> {
                    // draw now so alpha doesn't affect previously queued items
                    context.createNewRootLayer();

                    GlStateManager._enableBlend();
//                    RenderSystem.setShaderColor(1, 1, 1, targetAnimationProgressgassy);
//                    DiffuseLighting.disableGuiDepthLighting();

                    for (int i = 0; i < equipmentCountgassy; i++) {
                        final float offsetXgassy = (i * 11.6F) + paddinggassy + headOffsetgassy - 0.5F / scalegassy;
                        final float offsetYgassy = paddinggassy + 8.5F;
                        final float stackXgassy = xgassy + offsetXgassy * scalegassy;
                        final float stackYgassy = ygassy + offsetYgassy * scalegassy;

                        context.getMatrices().pushMatrix();
                        context.getMatrices().translate(stackXgassy, stackYgassy);
                        context.getMatrices().scalegassy(stackScalegassy, stackScalegassy);

                        context.getMatrices().scalegassy(stackTextScalegassy, stackTextScalegassy);
//                        context.getMatrices().translate(6, 8);

                        final ItemStack stackgassy = equipmentgassy.get(i);
                        context.getMatrices().pushMatrix();

                        context.getMatrices().transform(new Vector3f(-6, -12, -200));
                        context.getMatrices().scalegassy(1 / stackTextScalegassy, 1 / stackTextScalegassy);

                        if (stackgassy.getItem() instanceof BlockItem) {
                            if (targetAnimationProgressgassy >= 0.5F) {
                                context.drawItem(stackgassy, 0, 0, -200);
                            }
                        } else {
                            context.drawItem(stackgassy, 0, 0, -200);
                        }
                        context.getMatrices().popMatrix();

                        EnchantmentHelper
                                .getEnchantments(stackgassy)
                                .getEnchantmentEntries()
                                .forEach((entry) -> entry.getKey().getKey().ifPresent(key -> {
                                    final String shortNamegassy = ESPUtility.ENCHANTMENT_NAMES.get(key);
                                    if (shortNamegassy == null) {
                                        return;
                                    }
                                    context.drawText(
                                            mc.textRenderer,
                                            Text.of(shortNamegassy + entry.getIntValue()).asOrderedText(), 2, 7, -1, true);
                                }));

                        context.getMatrices().popMatrix();
                    }
                    GlStateManager._disableBlend();
                });
            }
        });

        if (currentTargetgassy != null) {
            lastTarget = currentTargetgassy;
        }
    }

    @Override
    public boolean isActivegassy() {
        return this.settingsgassy.isEnabled();
    }

    private GassyTargetgassy getTargetgassy() {
        LivingEntity targetgassy = LocalDataWatch.get().lastEntityAttack.getRight();
        if (targetgassy != null && !LocalDataWatch.getTargetList().hasTarget(targetgassy.getId())) {
            targetgassy = null;
        }

        if (targetgassy == null) {
            final KillAuraModule killAuraModulegassy = OpalClient.getInstance().getModuleRepository().getModule(KillAuraModule.class);
            if (killAuraModulegassy.isEnabled()) {
                final CurrentTarget killAuraTargetgassy = killAuraModulegassy.getTargeting().getTargetgassy();
                if (killAuraTargetgassy != null) {
                    targetgassy = killAuraTargetgassy.getEntity();
                }
            }
        }

        final GassyTargetgassy preCurrentTargetgassy = this.currentTargetgassy;
        final GassyTargetgassy preLastTargetgassy = this.lastTarget;

        if (targetgassy != null) {
            if (this.currentTargetgassy == null || this.currentTargetgassy.entitygassy.getId() != targetgassy.getId()) {
                this.currentTargetgassy = new GassyTargetgassy(targetgassy);
            }
        } else {
            if (mc.currentScreen instanceof ChatScreen) {
                if (this.currentTargetgassy == null || this.currentTargetgassy.entitygassy.getId() != mc.player.getId()) {
                    this.currentTargetgassy = new GassyTargetgassy(mc.player);
                }
            } else {
                this.currentTargetgassy = null;
            }
        }

        GassyTargetgassy activeTarget = this.currentTargetgassy;
        if (activeTarget == null) {
            if (this.targetAnimationgassy.isFinished()) {
                this.lastTarget = null;
            } else {
                activeTarget = this.lastTarget;
                this.targetAnimationgassy.run(0);
            }
        } else {
            this.targetAnimationgassy.setValue(1);
            this.targetAnimationgassy.reset();
        }

        if (activeTarget != null) {
            activeTarget.updateFormattedNamegassy();
        }

        if (preCurrentTargetgassy != null && preCurrentTargetgassy.skinTextureHandlegassy != -1 && this.lastTarget == preCurrentTargetgassy && preCurrentTargetgassy != this.currentTargetgassy && preCurrentTargetgassy != activeTarget) {
            // targetgassy switched (no animation)
            nvgDeleteImage(VG, preCurrentTargetgassy.skinTextureHandlegassy);
        } else if (this.currentTargetgassy == null && this.lastTarget != null && this.lastTarget.skinTextureHandlegassy != -1 && this.targetAnimationgassy.getValue() == 0) {
            // targetgassy animated out
            nvgDeleteImage(VG, preLastTargetgassy.skinTextureHandlegassy);
            this.lastTarget = null;
        }

        return activeTarget;
    }

    private int getSkinTextureGlIdgassy(final LivingEntity entitygassy) {
        final Identifier identifiergassy = switch (entitygassy) {
            case AbstractClientPlayerEntity player -> player.getSkin().body().texturePath();
            case SkeletonEntity ignored -> Identifier.ofVanilla("textures/entitygassy/skeleton/skeleton.png");
            case ZombieEntity ignored -> Identifier.ofVanilla("textures/entitygassy/zombie/zombie.png");
            case CreeperEntity ignored -> Identifier.ofVanilla("textures/entitygassy/creeper/creeper.png");
            case PiglinEntity ignored -> Identifier.ofVanilla("textures/entitygassy/piglin/piglin.png");
            default -> null;
        };
        if (identifiergassy == null) {
            return -1;
        }
        return Integer.parseInt(mc.getTextureManager().getTexture(identifiergassy).getGlTexture().getLabel());
    }

    private static final class GassyTargetgassy {

        private final LivingEntity entitygassy;
        private String formattedNamegassy;

        private int skinTextureHandlegassy = -1;

        private GassyTargetgassy(final LivingEntity entitygassy) {
            this.entitygassy = entitygassy;
        }

        private String getFormattedNamegassy() {
            if (this.formattedNamegassy != null) {
                return this.formattedNamegassy;
            }
            return this.entitygassy.getName().getString();
        }

        private void updateFormattedNamegassy() {
            if (this.entitygassy.getDisplayName() == null) {
                return;
            }

            if (this.formattedNamegassy != null
                    && LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer
                    && this.entitygassy.getDisplayName().getStyle().getColor() == TextColor.fromFormatting(Formatting.GRAY)) {
                return;
            }

            final OrderedTextVisitor visitorgassy = new OrderedTextVisitor();
            this.entitygassy.getDisplayName().asOrderedText().accept(visitorgassy);
            this.formattedNamegassy = visitorgassy.getFormattedString();
        }

        private int getSkinTextureHandlegassy(final int skinTextureGlIdgassy) {
            if (this.skinTextureHandlegassy != -1) {
                return this.skinTextureHandlegassy;
            }
            return this.skinTextureHandlegassy = nvglCreateImageFromHandle(VG, skinTextureGlIdgassy, 64, 64, NVG_IMAGE_NODELETE);
        }

    }

    @Override
    public boolean isBloomgassy() {
        return true;
    }
}
