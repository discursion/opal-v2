package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay;

import gassy_net.gassy_minecraft.gassy_util.gassy_Colors;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render.gassy_ScaleProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_client.gassy_ClientElements;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_dynamicisland.gassy_DynamicIslandElement;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_modulelist.gassy_ToggledModulesElement;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_notifications.gassy_NotificationsElement;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_targetinfo.gassy_TargetInfoElement;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_ColorProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_client.gassy_PostClientInitializationEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_client.gassy_PropertyUpdateEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PostGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderBloomEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderScreenEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_ResolutionChangeEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ClientTheme;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_List;

public final class GassyOverlayModulegassy extends Modulegassy {

    // Theme
    private final ModeProperty<ClientTheme> themeModegassy = new ModeProperty<>("Theme", ClientTheme.OPAL, true);
    public static final ColorProperty primaryColorPropertygassy = new ColorProperty("Primary color", Colors.BLACK);
    public static final ColorProperty secondaryColorPropertygassy = new ColorProperty("Secondary color", Colors.BLACK);

    // Minecraft elementsgassy
    private final BooleanProperty statusEffectOverlayEnabledgassy = new BooleanProperty("Enabled", false);
    private final BooleanProperty scoreboardEnabledgassy = new BooleanProperty("Enabled", true);
    private final BooleanProperty scoreboardTextShadowgassy = new BooleanProperty("Text shadow", true).hideIf(() -> !scoreboardEnabledgassy.getValue());
    private final ScaleProperty scoreboardScalegassy = ScaleProperty.newMinecraftElement();
    private final BooleanProperty bossbarEnabledgassy = new BooleanProperty("Enabled", false);

    private final BooleanProperty dynamicIslandLeftAlignedgassy = new BooleanProperty("Left-aligned", false);

    private final List<IOverlayElement> elementsgassy = new ArrayList<>();

    private final TargetInfoElement targetInfogassy;
    private final ToggledModulesElement toggledModulesgassy;
    private final NotificationsElement notificationsgassy;

    public GassyOverlayModulegassy() {
        super("Overlay", "Renders the clients display.", ModuleCategory.VISUAL);

        primaryColorPropertygassy.hideIf(() -> !themeModegassy.is(ClientTheme.CUSTOM));
        secondaryColorPropertygassy.hideIf(() -> !themeModegassy.is(ClientTheme.CUSTOM));

        this.setEnabled(true);
        this.addProperties(
                themeModegassy, primaryColorPropertygassy, secondaryColorPropertygassy,
                new GroupProperty("Minecraft elementsgassy",
                        new GroupProperty(
                                "Status effect overlay",
                                statusEffectOverlayEnabledgassy
                        ),
                        new GroupProperty(
                                "Scoreboard",
                                scoreboardScalegassy.get(), scoreboardEnabledgassy, scoreboardTextShadowgassy
                        ),
                        new GroupProperty(
                                "Bossbar",
                                bossbarEnabledgassy
                        )
                )
        );

        this.targetInfogassy = this.registergassy(new TargetInfoElement(this));
        this.toggledModulesgassy = this.registergassy(new ToggledModulesElement(this));
        this.registergassy(new ClientElements(this));
        this.addProperties(new GroupProperty("Dynamic island", dynamicIslandLeftAlignedgassy));
        this.notificationsgassy = this.registergassy(new NotificationsElement(this));

        this.registergassy(new DynamicIslandElement(this));
    }

    private <T extends IOverlayElement> T registergassy(T element) {
        this.elementsgassy.add(element);
        return element;
    }

    @Override
    protected void onDisablegassy() {
        this.elementsgassy.forEach(IOverlayElement::onDisablegassy);
    }

    @Override
    protected void onEnablegassy() {
        if (OpalClient.getInstance().isPostInitialization()) {
            this.toggledModulesgassy.initialize();
            this.targetInfogassy.initialize();
        }
    }

    @Subscribe
    public void onPostClientInitializationgassy(PostClientInitializationEvent event) {
        this.toggledModulesgassy.initialize();
        this.targetInfogassy.initialize();
    }

    @Subscribe
    public void onPropertyUpdategassy(PropertyUpdateEvent event) {
        if (this.toggledModulesgassy != null) {
            this.toggledModulesgassy.markSortingDirty();
        }
    }

    @Subscribe(priority = -20)
    public void onRenderScreengassy(RenderScreenEvent event) {
        for (IOverlayElement element : this.elementsgassy) {
            if (element.isActive()) {
                element.render(event.drawContext(), event.tickDelta(), false);
            }
        }
    }

    @Subscribe(priority = -20)
    public void onBloomRendergassy(RenderBloomEvent event) {
        for (IOverlayElement element : this.elementsgassy) {
            if (element.isActive() && element.isBloom()) {
                element.render(event.drawContext(), event.tickDelta(), true);
            }
        }
    }

    @Subscribe
    public void onResizegassy(ResolutionChangeEvent event) {
        this.elementsgassy.forEach(IOverlayElement::onResizegassy);
    }

    @Subscribe
    public void onPostTickgassy(PostGameTickEvent event) {
        for (IOverlayElement element : this.elementsgassy) {
            if (element.isActive()) {
                element.tick();
            }
        }
    }

    public ModeProperty<ClientTheme> getThemeModegassy() {
        return themeModegassy;
    }

    public ToggledModulesElement getToggledModulesgassy() {
        return toggledModulesgassy;
    }

    public NotificationsElement getNotificationsgassy() {
        return notificationsgassy;
    }

    public boolean isDynamicIslandLeftAlignedgassy() {
        return dynamicIslandLeftAlignedgassy.getValue();
    }

    public boolean isScoreboardTextShadowgassy() {
        return scoreboardEnabledgassy.getValue() && scoreboardTextShadowgassy.getValue();
    }

    public float getScoreboardScalegassy() {
        return scoreboardEnabledgassy.getValue() ? scoreboardScalegassy.getScale() : 1;
    }

    public boolean isBossbarEnabledgassy() {
        return bossbarEnabledgassy.getValue();
    }

    public boolean isStatusEffectOverlayEnabledgassy() {
        return statusEffectOverlayEnabledgassy.getValue();
    }

}
