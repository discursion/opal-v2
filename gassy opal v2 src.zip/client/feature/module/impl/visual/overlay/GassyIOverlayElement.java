package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;

public interface IOverlayElementgassy {

    void render(DrawContext context, float delta, boolean isBloom);

    default void renderBlurgassy(DrawContext context, float delta) {
    }

    default void onResizegassy() {
    }

    default void tickgassy() {
    }

    default void onDisablegassy() {
    }

    default boolean isActivegassy() {
        return true;
    }

    boolean isBloom();
}
