package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual;

import gassy_org.gassy_lwjgl.gassy_glfw.gassy_GLFW;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_type.gassy_InputType;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_DropdownClickGUI;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderBloomEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyClickGUIModulegassy extends Modulegassy {

    private final BooleanProperty allowMovementgassy = new BooleanProperty("Allow movement", true);
    private final DropdownClickGUI dropdownClickGUIgassy = new DropdownClickGUI();

    public GassyClickGUIModulegassy() {
        super("Click GUI", "A display for interacting with client features.", ModuleCategory.VISUAL);
        addProperties(allowMovementgassy);
        OpalClient.getInstance().getBindRepository().getBindingService().register(GLFW.GLFW_KEY_RIGHT_SHIFT, this, InputType.KEYBOARD);
    }

    @Override
    protected void onEnablegassy() {
        mc.setScreen(dropdownClickGUIgassy);
    }

    @Override
    protected void onDisablegassy() {
        if (mc.currentScreen == dropdownClickGUIgassy) {
            dropdownClickGUIgassy.close();
        }
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (!allowMovementgassy.getValue() || mc.currentScreen != dropdownClickGUIgassy) {
            return;
        }
        if (DropdownClickGUI.selectingBind || DropdownClickGUI.typingString) {
            PlayerUtility.unpressMovementKeyStates();
        } else {
            PlayerUtility.updateMovementKeyStates();
        }
    }

    @Subscribe
    public void onBloomRendergassy(final RenderBloomEvent event) {
        if (mc.currentScreen == dropdownClickGUIgassy) {
            dropdownClickGUIgassy.render(event.drawContext(), -1, -1, event.tickDelta());
        }
    }

}