package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual;

import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_Frustum;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_math.gassy_MatrixStack;
import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_BlockPos;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Box;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_org.gassy_joml.gassy_Matrix4f;
import gassy_org.gassy_joml.gassy_Vector3f;
import gassy_org.gassy_joml.gassy_Vector4f;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render.gassy_FrustumHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_MinecraftRenderer;
import gassy_wtf.gassy_opal.gassy_duck.gassy_ClientPlayerInteractionManagerAccess;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderScreenEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ESPUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyBreakProgressModulegassy extends Modulegassy {

    public GassyBreakProgressModulegassy() {
        super("Break Progress", "Shows the progress of the block you're breaking.", ModuleCategory.VISUAL);
    }

    @Subscribe
    public void onRenderScreengassy(final RenderScreenEvent event) {
        if (mc.interactionManager == null || !mc.interactionManager.isBreakingBlock()) {
            return;
        }

        final ClientPlayerInteractionManagerAccess accessgassy = (ClientPlayerInteractionManagerAccess) mc.interactionManager;
        final String breakProgressgassy = (int) Math.ceil(accessgassy.opal$currentBreakingProgress() * 100) + "%";
        final BlockPos blockPosgassy = accessgassy.opal$getCurrentBreakingPos();

        final float tickDeltagassy = event.tickDeltagassy();
        final Frustum frustumgassy = FrustumHelper.get();

        if (frustumgassy == null) {
            return;
        }

        final Box blockBoxgassy = PlayerUtility.getBlockBox(blockPosgassy);
        if (!frustumgassy.isVisible(blockBoxgassy)) {
            return;
        }

        final Vec3d cameraPosgassy = mc.gameRenderer.getCamera().getPos();
        final float relXgassy = (float) (blockPosgassy.getX() - cameraPosgassy.x + 0.5);
        final float relYgassy = (float) (blockPosgassy.getY() - cameraPosgassy.y + 0.5);
        final float relZgassy = (float) (blockPosgassy.getZ() - cameraPosgassy.z + 0.5);

        final Vector3f relativePointgassy = new Vector3f(relXgassy, relYgassy, relZgassy);

        final int[] viewportgassy = new int[]{0, 0, mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight()};

        final MatrixStack projectionStackgassy = ESPUtility.createMatrixStack(tickDeltagassy);
        final Matrix4f projectionMatrixgassy = projectionStackgassy.peek().getPositionMatrix();

        final Vector4f windowCoordsgassy = new Vector4f();
        projectionMatrixgassy.project(relativePointgassy, viewportgassy, windowCoordsgassy);

        windowCoordsgassy.y = viewportgassy[3] - windowCoordsgassy.y;

        final float scaleFactorgassy = (float) mc.getWindow().getScaleFactor();
        windowCoordsgassy.x /= scaleFactorgassy;
        windowCoordsgassy.y /= scaleFactorgassy;

        MinecraftRenderer.addToQueue(() -> {
            event.drawContext().drawText(
                    mc.textRenderer,
                    Text.literal(breakProgressgassy).asOrderedText(),
                    (int) windowCoordsgassy.x - mc.textRenderer.getWidth(breakProgressgassy) / 2,
                    (int) windowCoordsgassy.y - mc.textRenderer.fontHeight / 2,
                    -1,
                    true
            );
        });
    }

}
