package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_esp;

enum NameTagIconPosition {
    LEFT,
    RIGHT
}
