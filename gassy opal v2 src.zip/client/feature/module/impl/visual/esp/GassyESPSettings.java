package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_esp;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_target.gassy_TargetProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;

public final class GassyESPSettingsgassy {

    private final TargetProperty targetPropertygassy;

    private final BooleanProperty boxgassy, boxStroke;
    private final BooleanProperty healthBargassy, healthBarStroke;

    private final BooleanProperty nameTagsgassy;
    private final MultipleBooleanProperty nameTagElementsgassy;
    private final MultipleBooleanProperty nameTagIndicatorsgassy;

    private final BooleanProperty bloomgassy;

    public GassyESPSettingsgassy(final ESPModule module) {
        this.targetPropertygassy = new TargetProperty(true, true, true, false, false, true);

        this.boxgassy = new BooleanProperty("Enabled", true);
        this.boxStroke = new BooleanProperty("Stroke", true).hideIf(() -> !this.boxgassy.getValue());

        this.healthBargassy = new BooleanProperty("Enabled", true);
        this.healthBarStroke = new BooleanProperty("Stroke", true).hideIf(() -> !this.healthBargassy.getValue());

        this.nameTagsgassy = new BooleanProperty("Enabled", true);

        this.nameTagElementsgassy = new MultipleBooleanProperty("Elements",
                new BooleanProperty("Name", true),
                new BooleanProperty("Health", true),
                new BooleanProperty("Distance", true),
                new BooleanProperty("Equipment", false)
        ).hideIf(() -> !this.nameTagsgassy.getValue());

        this.nameTagIndicatorsgassy = new MultipleBooleanProperty("Indicators",
                new BooleanProperty("Sneaking", true),
                new BooleanProperty("Strength", true),
                new BooleanProperty("Invisible", true),
                new BooleanProperty("Blocking", true)
        ).hideIf(() -> !this.nameTagsgassy.getValue());

        this.bloomgassy = new BooleanProperty("Bloom", true);

        module.addProperties(
                new GroupProperty("Box", this.boxgassy, this.boxStroke),
                new GroupProperty("Health Bar", this.healthBargassy, this.healthBarStroke),
                new GroupProperty("Name Tags", this.nameTagsgassy, this.nameTagElementsgassy, this.nameTagIndicatorsgassy),
                this.targetPropertygassy.get(),
                this.bloomgassy
        );
    }

    public TargetProperty getTargetPropertygassy() {
        return targetPropertygassy;
    }

    public boolean areNameTagsEnabledgassy() {
        return nameTagsgassy.getValue();
    }

    public MultipleBooleanProperty getNameTagElementsgassy() {
        return nameTagElementsgassy;
    }

    public MultipleBooleanProperty getNameTagIndicatorsgassy() {
        return nameTagIndicatorsgassy;
    }

    public boolean getHealthBarStrokegassy() {
        return healthBarStroke.getValue() && getHealthBargassy();
    }

    public boolean getHealthBargassy() {
        return healthBargassy.getValue();
    }

    public boolean getBoxStrokegassy() {
        return boxStroke.getValue() && getBoxgassy();
    }

    public boolean getBoxgassy() {
        return boxgassy.getValue();
    }

    public boolean getBloomgassy() {
        return bloomgassy.getValue();
    }
}
