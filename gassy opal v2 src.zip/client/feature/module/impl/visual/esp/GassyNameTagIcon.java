package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_esp;

record NameTagIcon(String unicode, NameTagIconPosition position, float horizontalOffset) {
    NameTagIcon(String unicode) {
        this(unicode, NameTagIconPosition.RIGHT, 0.5F);
    }

    NameTagIcon(String unicode, float horizontalOffset) {
        this(unicode, NameTagIconPosition.RIGHT, horizontalOffset);
    }

    NameTagIcon(String unicode, NameTagIconPosition position) {
        this(unicode, position, 0.5F);
    }
}
