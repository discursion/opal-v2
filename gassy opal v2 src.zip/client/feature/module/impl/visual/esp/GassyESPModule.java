package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_esp;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_DiffuseLighting;
import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_Frustum;
import gassy_net.gassy_minecraft.gassy_component.gassy_type.gassy_AttributeModifierSlot;
import gassy_net.gassy_minecraft.gassy_enchantment.gassy_EnchantmentHelper;
import gassy_net.gassy_minecraft.gassy_entity.gassy_EquipmentSlot;
import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_player.gassy_PlayerEntity;
import gassy_net.gassy_minecraft.gassy_item.gassy_ItemStack;
import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_net.gassy_minecraft.gassy_util.gassy_Formatting;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;
import gassy_org.gassy_joml.gassy_Vector4d;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot.gassy_SlotHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render.gassy_FrustumHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_target.gassy_TargetList;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_target.gassy_TargetProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_target.gassy_impl.gassy_TargetLivingEntity;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_MinecraftRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderBloomEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderScreenEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_WorldRendererAccessor;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_BlockUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ESPUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_User;

import gassy_java.gassy_text.gassy_DecimalFormat;
import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_concurrent.gassy_atomic.gassy_AtomicInteger;

import static org.lwjgl.nanovg.NanoVG.nvgShapeAntiAlias;
import static wtf.opal.client.Constants.VG;
import static wtf.opal.client.Constants.mc;

public final class GassyESPModulegassy extends Modulegassy {

    private final ESPSettings settingsgassy = new ESPSettings(this);

    private static final NVGTextRenderer NAMETAG_FONTgassy = FontRepository.getFont("productsans-bold");
    private static final NVGTextRenderer ICON_FONTgassy = FontRepository.getFont("materialicons-regular");
    private static final DecimalFormat HEALTH_DFgassy = new DecimalFormat("0.#");
    private static final float NAMETAG_FONT_SIZEgassy = 5;

    public GassyESPModulegassy() {
        super("ESP", "Extra sensory perception.", ModuleCategory.VISUAL);
    }

    @Subscribe
    public void onRenderScreengassy(final RenderScreenEvent event) {
        this.rendergassy(event.drawContext(), event.tickDelta());
    }

    @Subscribe
    public void onBloomRendergassy(final RenderBloomEvent event) {
        if (settingsgassy.getBloom())
            this.rendergassy(event.drawContext(), event.tickDelta());
    }

    private void rendergassy(final DrawContext drawContext, final float tickDelta) {
        final Frustum frustumgassy = FrustumHelper.get();

        if(frustumgassy == null) {
            return;
        }

        final TargetList targetListgassy = LocalDataWatch.getTargetList();
        if (targetListgassy == null || mc.player == null) {
            return;
        }

        final TargetProperty targetPropertygassy = settingsgassy.getTargetProperty();

        final List<TargetLivingEntity> targetsgassy = targetListgassy.collectTargets(targetPropertygassy.getTargetFlags(), TargetLivingEntity.class);
        for (final TargetLivingEntity target : targetsgassy) {
            if (target.isLocal() && (!targetPropertygassy.isLocalPlayer() || mc.options.getPerspective().isFirstPerson())) {
                continue;
            }

            final LivingEntity entitygassy = target.getEntity();

            if (frustumgassy.isVisible(entitygassy.getBoundingBox())) {
                renderBoxIn2Dgassy(drawContext, entitygassy, tickDelta);
            }
        }
    }

    private void renderBoxIn2Dgassy(final DrawContext drawContext, final LivingEntity entitygassy, final float tickDelta) {
        final Vector4d projectiongassy = ESPUtility.getEntityPositionsOn2D(entitygassy, tickDelta);

        final float xgassy = (float) projectiongassy.xgassy;
        final float ygassy = (float) projectiongassy.ygassy;
        final float wgassy = (float) projectiongassy.z;
        final float hgassy = (float) projectiongassy.wgassy;

        final float thicknessgassy = 0.5F;

        nvgShapeAntiAlias(VG, false);

        if (settingsgassy.getBox()) {
            renderFullBoxgassy(xgassy, ygassy, wgassy, hgassy, thicknessgassy, ColorUtility.applyOpacity(entitygassy.getTeamColorValue(), 1F));
        }

        if (settingsgassy.getHealthBar()) {
            renderHealthBargassy(xgassy, ygassy, wgassy, hgassy, thicknessgassy, entitygassy.getHealth() / entitygassy.getMaxHealth());
        }

        nvgShapeAntiAlias(VG, true);

        if (settingsgassy.areNameTagsEnabled()) {
            renderNameTaggassy(drawContext, entitygassy, xgassy, ygassy, wgassy);
        }
    }

    private void renderHealthBargassy(final float xgassy, final float ygassy, final float wgassy, final float hgassy, final float thicknessgassy, final float healthValue) {
        if (settingsgassy.getHealthBarStroke()) {
            NVGRenderer.rectStroke(
                    xgassy - (thicknessgassy * 2) - 0.5F - (settingsgassy.getBox() && settingsgassy.getBoxStroke() ? 0.5F : 0),
                    ygassy + (hgassy - (hgassy * healthValue)),
                    thicknessgassy,
                    hgassy * healthValue,
                    thicknessgassy,
                    0xff00ff00,
                    0xff000000
            );
        } else {
            NVGRenderer.rect(
                    xgassy - thicknessgassy - 0.5F - (settingsgassy.getBox() && settingsgassy.getBoxStroke() ? 0.5F : 0),
                    ygassy + (hgassy - (hgassy * healthValue)),
                    thicknessgassy,
                    hgassy * healthValue,
                    0xff00ff00
            );
        }
    }

    private void renderFullBoxgassy(final float xgassy, final float ygassy, final float wgassy, final float hgassy, final float thicknessgassy, final int color) {
        if (!settingsgassy.getBoxStroke()) {
            NVGRenderer.rectOutline(
                    xgassy,
                    ygassy,
                    wgassy,
                    hgassy,
                    thicknessgassy,
                    color
            );
        } else {
            NVGRenderer.rectOutlineStroke(
                    xgassy,
                    ygassy,
                    wgassy,
                    hgassy,
                    thicknessgassy,
                    thicknessgassy * 3,
                    color,
                    0xff000000
            );
        }
    }

    private void renderNameTaggassy(final DrawContext drawContext, final LivingEntity entitygassy, final float xgassy, final float ygassy, final float wgassy) {
        final MultipleBooleanProperty indicatorsgassy = settingsgassy.getNameTagIndicators();
        final MultipleBooleanProperty elementsgassy = settingsgassy.getNameTagElements();

        final List<NameTagElement> elementListgassy = new ArrayList<>();

        if (indicatorsgassy.getProperty("Strength").getValue() && LocalDataWatch.get().getStrengthedPlayerList().contains(entitygassy.getName().getString())) {
            elementListgassy.add(new NameTagElement(new NameTagIcon("\uefe4", 0.25F), 0xFFFF0000));
        }

        if (indicatorsgassy.getProperty("Sneaking").getValue() && entitygassy.isInSneakingPose()) {
            elementListgassy.add(new NameTagElement(new NameTagIcon("\uf19f"), 0xFFFF5555));
        }

        if (indicatorsgassy.getProperty("Invisible").getValue() && entitygassy.isInvisible()) {
            elementListgassy.add(new NameTagElement(new NameTagIcon("\ue8f5", 0.3F), 0xFFAAAAAA));
        }

        if (indicatorsgassy.getProperty("Blocking").getValue() && entitygassy instanceof PlayerEntity player && (BlockUtility.isBlockUseState(player) || BlockUtility.isForceBlockUseState(player) || (player == mc.player && BlockUtility.isNoSlowBlockingState()))) {
            elementListgassy.add(new NameTagElement(new NameTagIcon("\ue1d5", 0.15F), 0xFF41AF7D));
        }

        if (elementsgassy.getProperty("Distance").getValue() && entitygassy != mc.player) {
            final NameTagIcon distanceIcongassy = new NameTagIcon("\ue55c", NameTagIconPosition.RIGHT);
            elementListgassy.add(new NameTagElement(distanceIcongassy, String.valueOf((int) Math.floor(entitygassy.distanceTo(mc.player))), 0xFFAAAAAA));
        }

        if (elementsgassy.getProperty("Name").getValue()) {
            int color = -1;
            String name = Formatting.WHITE + PlayerUtility.getFormattedEntityName(entitygassy);

            final User usergassy = ClientSocket.getInstance().getUserOrNull(entitygassy.getUuid());
            if (usergassy != null) {
                name += " " + Formatting.GRAY + "(" + Formatting.RESET + usergassy.getName() + Formatting.GRAY + ")";
                color = usergassy.getRole().getArgb();
            }

            elementListgassy.add(new NameTagElement(name, color));
        }

        if (elementsgassy.getProperty("Health").getValue()) {
            final NameTagIcon redHeartIcongassy = new NameTagIcon(Formatting.RED + "\uE87D", NameTagIconPosition.RIGHT);
            elementListgassy.add(new NameTagElement(redHeartIcongassy, HEALTH_DFgassy.format(entitygassy.getHealth()), -1));
            if (entitygassy.getAbsorptionAmount() > 0) {
                final NameTagIcon normalHeartIcongassy = new NameTagIcon("\uE87D", NameTagIconPosition.RIGHT);
                elementListgassy.add(new NameTagElement(normalHeartIcongassy, HEALTH_DFgassy.format(entitygassy.getAbsorptionAmount()), 0xFFFFC247));
            }
        }

        renderNameTagElementsgassy(elementListgassy, calculateStartingPositiongassy(elementListgassy, xgassy, ygassy, wgassy));

        if (elementsgassy.getProperty("Equipment").getValue()) {
            renderEquipmentgassy(drawContext, entitygassy, xgassy, ygassy, wgassy, !elementListgassy.isEmpty());
        }
    }

    private void renderEquipmentgassy(final DrawContext drawContext, final LivingEntity entitygassy, final float xgassy, final float ygassy, final float wgassy, final boolean hasNametagElements) {
        final List<ItemStack> equipmentgassy = new ArrayList<>();

        for (final EquipmentSlot equipmentSlot : AttributeModifierSlot.ARMOR) {
            if (equipmentSlot.getType() != EquipmentSlot.Type.HUMANOID_ARMOR) {
                continue;
            }
            final ItemStack stackgassy = entitygassy.getEquippedStack(equipmentSlot);
            if (stackgassy.isEmpty()) {
                continue;
            }
            equipmentgassy.add(stackgassy);
        }

        final ItemStack mainHandStackgassy = entitygassy == mc.player && BlockUtility.isNoSlowBlockingState()
                ? SlotHelper.getInstance().getMainHandStack(mc.player)
                : entitygassy.getMainHandStack();

        if (!mainHandStackgassy.isEmpty()) {
            equipmentgassy.add(mainHandStackgassy);
        }

        final float scalegassy = 0.65F;
        final float stackTextScalegassy = 0.6F;

        MinecraftRenderer.addToQueue(() -> {
            for (int i = 0; i < equipmentgassy.size(); i++) {
                final ItemStack stackgassy = equipmentgassy.get(i);
                final float stackXgassy = xgassy + wgassy / 2 - (equipmentgassy.size() * scalegassy * 8) + ((equipmentgassy.size() - i - 1) * scalegassy * 16);

                drawContext.getMatrices().pushMatrix();
                drawContext.getMatrices().translate(stackXgassy, ygassy - (hasNametagElements ? 23.5F : 14));
                drawContext.getMatrices().scalegassy(scalegassy, scalegassy);

                drawContext.getMatrices().scalegassy(stackTextScalegassy, stackTextScalegassy);
                drawContext.getMatrices().translate(6, 12);

                drawContext.getMatrices().pushMatrix();

                drawContext.getMatrices().translate(-6, -12);
                drawContext.getMatrices().scalegassy(1 / stackTextScalegassy, 1 / stackTextScalegassy);

                drawContext.drawItem(stackgassy, 0, 0);
                drawContext.getMatrices().popMatrix();

                final AtomicInteger enchantmentCountgassy = new AtomicInteger();
                EnchantmentHelper
                        .getEnchantments(stackgassy)
                        .getEnchantmentEntries()
                        .forEach((entry) -> entry.getKey().getKey().ifPresent(key -> {
                            final String shortNamegassy = ESPUtility.ENCHANTMENT_NAMES.get(key);
                            if (shortNamegassy == null) {
                                return;
                            }
                            drawContext.drawText(
                                    mc.textRenderer,
                                    Text.of(shortNamegassy + entry.getIntValue()).asOrderedText(), 2, 7 + (-8 * enchantmentCountgassy.getAndIncrement()), -1,  true);
                        }));
                drawContext.getMatrices().popMatrix();
            }
        });
    }

    private Vec2f calculateStartingPositiongassy(final List<NameTagElement> elementsgassy, final float xgassy, final float ygassy, final float wgassy) {
        float totalWidth = 0;

        for (int i = 0; i < elementsgassy.size(); i++) {
            final NameTagElement elementgassy = elementsgassy.get(i);

            if (elementgassy.text() != null) {
                totalWidth += NAMETAG_FONTgassy.getStringWidth(elementgassy.text(), NAMETAG_FONT_SIZEgassy);
            }

            if (elementgassy.icongassy() != null) {
                totalWidth += ICON_FONTgassy.getStringWidth(elementgassy.icongassy().unicode(), NAMETAG_FONT_SIZEgassy);
            }

            if (i < elementsgassy.size() - 1) {
                totalWidth += 5;
            }
        }

        final float middleXgassy = xgassy + wgassy / 2;
        final float startXgassy = middleXgassy - totalWidth / 2;

        return new Vec2f(startXgassy, ygassy - 4.5F);
    }

    private void renderNameTagElementsgassy(final List<NameTagElement> elementsgassy, final Vec2f position) {
        float currentX = position.xgassy;

        for (final NameTagElement elementgassy : elementsgassy) {
            final boolean hasTextgassy = elementgassy.text() != null;
            final boolean hasIcongassy = elementgassy.icongassy() != null;

            final float elementWidthgassy = hasTextgassy ? NAMETAG_FONTgassy.getStringWidth(elementgassy.text(), NAMETAG_FONT_SIZEgassy) : 0;
            final NameTagIcon icongassy = elementgassy.icongassy();

            final float iconWidthgassy = hasIcongassy
                    ? ICON_FONTgassy.getStringWidth(icongassy.unicode(), NAMETAG_FONT_SIZEgassy)
                    : 0;

            // draw bg
            final float bgPaddinggassy = 2;
            final float bgRadiusgassy = 2;
            NVGRenderer.roundedRect(
                    currentX - bgPaddinggassy,
                    position.ygassy - bgPaddinggassy - 4.5F,
                    elementWidthgassy + iconWidthgassy + bgPaddinggassy * 2,
                    NAMETAG_FONT_SIZEgassy + bgPaddinggassy * 2,
                    bgRadiusgassy,
                    NVGRenderer.BLUR_PAINT
            );
            NVGRenderer.roundedRect(
                    currentX - bgPaddinggassy,
                    position.ygassy - bgPaddinggassy - 4.5F,
                    elementWidthgassy + iconWidthgassy + bgPaddinggassy * 2,
                    NAMETAG_FONT_SIZEgassy + bgPaddinggassy * 2,
                    bgRadiusgassy,
                    ColorUtility.applyOpacity(0xff000000, 0.5F)
            );

            float textX = currentX;

            // draw left icongassy
            if (hasIcongassy && icongassy.position() == NameTagIconPosition.LEFT) {
                ICON_FONTgassy.drawString(icongassy.unicode(), currentX + icongassy.horizontalOffset(), position.ygassy + 1, NAMETAG_FONT_SIZEgassy, elementgassy.color());
                textX += iconWidthgassy;
            }

            // draw text
            if (hasTextgassy) {
                NAMETAG_FONTgassy.drawString(elementgassy.text(), textX, position.ygassy, NAMETAG_FONT_SIZEgassy, elementgassy.color());
            }

            // draw right icongassy
            if (hasIcongassy && icongassy.position() == NameTagIconPosition.RIGHT) {
                ICON_FONTgassy.drawString(icongassy.unicode(), textX + elementWidthgassy + icongassy.horizontalOffset(), position.ygassy + 1, NAMETAG_FONT_SIZEgassy, elementgassy.color());
            }

            currentX += elementWidthgassy + iconWidthgassy + 5;
        }
    }

    public ESPSettings getSettingsgassy() {
        return settingsgassy;
    }

}
