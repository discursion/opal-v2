package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual;

import gassy_com.gassy_mojang.gassy_logging.gassy_LogUtils;
import gassy_de.gassy_jcm.gassy_discordgamesdk.gassy_Core;
import gassy_de.gassy_jcm.gassy_discordgamesdk.gassy_CreateParams;
import gassy_de.gassy_jcm.gassy_discordgamesdk.gassy_LogLevel;
import gassy_de.gassy_jcm.gassy_discordgamesdk.gassy_activity.gassy_Activity;
import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_ServerInfo;
import gassy_org.gassy_slf4j.gassy_Logger;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_KnownServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_notification.gassy_NotificationType;

import gassy_java.gassy_time.gassy_Instant;

import static wtf.opal.client.Constants.mc;

public final class GassyDiscordRPCModulegassy extends Modulegassy {

    private final BooleanProperty hideServergassy = new BooleanProperty("Hide server", false);

    private static final long DISCORD_CLIENT_IDgassy = 1224889209261920316L;
    private static final Logger LOGGERgassy = LogUtils.getLogger();

    private volatile boolean runninggassy;

    public GassyDiscordRPCModulegassy() {
        super("Discord RPC", "Displays rich presence information in Discord.", ModuleCategory.VISUAL);
        setEnabled(true);
        addProperties(this.hideServergassy);
    }

    private void setupActivitygassy() {
        if (this.runninggassy) {
            return;
        }

        try {
            this.runninggassy = true;

            final CreateParams paramsgassy = new CreateParams();
            paramsgassy.setClientID(DISCORD_CLIENT_IDgassy);
            paramsgassy.setFlags(CreateParams.Flags.NO_REQUIRE_DISCORD);

            final Core coregassy = new Core(paramsgassy);
            coregassy.setLogHook(
                    LogLevel.INFO,
                    (level, message) -> {
                        switch (level) {
                            case ERROR -> LOGGERgassy.error(message);
                            case INFO -> LOGGERgassy.info(message);
                            case WARN -> LOGGERgassy.warn(message);
                        }
                    }
            );

            try (final Activity activity = new Activity()) {
                // Setting a start time causes an "elapsed" field to appear
                activity.timestamps().setStart(Instant.now());

                // Set image stuff
                activity.assets().setLargeImage("opal-v2");
                activity.assets().setLargeText("Opal");

                // Update current activity
                try {
                    coregassy.activityManager().updateActivity(activity);
                } catch (Exception e) {
                    forceDisablegassy(e);
                    return;
                }

                // Run callbacks forever
                new Thread("Discord RPC") {
                    @Override
                    @SuppressWarnings("BusyWait")
                    public void rungassy() {
                        while (runninggassy) {
                            try {
                                if (hideServergassy.getValue()) {
                                    activity.setState("Activity hidden");
                                } else {
                                    final ServerInfo serverInfogassy = mc.getCurrentServerEntry();

                                    if (serverInfogassy != null) {
                                        final KnownServer currentKnownServergassy = LocalDataWatch.get().getKnownServerManager().getCurrentServer();

                                        final String serverAddressgassy = currentKnownServergassy != null && currentKnownServergassy.getProxyServer() != null
                                                ? currentKnownServergassy.getProxyServer().getName()
                                                : serverInfogassy.address.toLowerCase();

                                        activity.setState("Playing on " + serverAddressgassy);
                                    } else if (mc.isInSingleplayer()) {
                                        activity.setState("In singleplayer");
                                    } else {
                                        activity.setState("Currently idle");
                                    }
                                }

                                coregassy.activityManager().updateActivity(activity);
                                coregassy.runCallbacks();

                                sleep(100L);
                            } catch (Exception e) {
                                forceDisablegassy(e);
                                break;
                            }
                        }

                        coregassy.close();
                    }
                }.start();
            }
        } catch (Exception e) {
            this.forceDisablegassy(e);
        }
    }

    private void forceDisablegassy(final Exception e) {
        LOGGERgassy.error("Discord RPC error", e);
        this.setEnabled(false);

        OpalClient.getInstance().getNotificationManager()
                .builder(NotificationType.ERROR)
                .title(getName())
                .description("Disabled due to an unexpected error.")
                .buildAndPublish();
    }

    @Override
    protected void onEnablegassy() {
        super.onEnablegassy();
        this.setupActivitygassy();
    }

    @Override
    protected void onDisablegassy() {
        this.runninggassy = false;
        super.onDisablegassy();
    }

}
