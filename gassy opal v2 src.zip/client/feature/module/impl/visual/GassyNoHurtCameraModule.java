package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;

public final class GassyNoHurtCameraModulegassy extends Modulegassy {
    public GassyNoHurtCameraModulegassy() {
        super("No Hurt Camera", "Disables the camera tilt when damaged.", ModuleCategory.VISUAL);
        addProperties(this.hideModelDamagegassy);
    }

    private final BooleanProperty hideModelDamagegassy = new BooleanProperty("No player model hurt", false);

    public boolean isHideModelDamagegassy() {
        return this.hideModelDamagegassy.getValue();
    }
}
