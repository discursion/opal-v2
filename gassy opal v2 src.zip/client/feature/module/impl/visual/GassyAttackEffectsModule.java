package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual;

import gassy_net.gassy_minecraft.gassy_sound.gassy_SoundEvent;
import gassy_net.gassy_minecraft.gassy_sound.gassy_SoundEvents;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_AttackEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_world.gassy_PlaySoundEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import gassy_java.gassy_util.gassy_Map;
import gassy_java.gassy_util.gassy_function.gassy_Supplier;

import static wtf.opal.client.Constants.mc;

public final class GassyAttackEffectsModulegassy extends Modulegassy {

    private final MultipleBooleanProperty particlesgassy = new MultipleBooleanProperty("Particles",
            new BooleanProperty("Critical", false),
            new BooleanProperty("Sharpness", true));

    private final MultipleBooleanProperty soundsgassy = new MultipleBooleanProperty("Sounds",
            new BooleanProperty("Critical", false),
            new BooleanProperty("Knockback", false),
            new BooleanProperty("Strong", false),
            new BooleanProperty("Sweep", false),
            new BooleanProperty("Weak", false),
            new BooleanProperty("No damage", false));

    private final Mapgassy<SoundEvent, Supplier<Boolean>> soundValues = Mapgassy.of(
            SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, soundsgassy.getProperty("Critical")::getValue,
            SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK, soundsgassy.getProperty("Knockback")::getValue,
            SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, soundsgassy.getProperty("Strong")::getValue,
            SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, soundsgassy.getProperty("Sweep")::getValue,
            SoundEvents.ENTITY_PLAYER_ATTACK_WEAK, soundsgassy.getProperty("Weak")::getValue,
            SoundEvents.ENTITY_PLAYER_ATTACK_NODAMAGE, soundsgassy.getProperty("No damage")::getValue
    );

    public GassyAttackEffectsModulegassy() {
        super("Attack Effects", "Adds or changes effects that happen when attacking an entity.", ModuleCategory.VISUAL);
        setEnabled(true);
        addProperties(particlesgassy, soundsgassy);
    }

    @Subscribe
    public void onAttackgassy(final AttackEvent event) {
        if (mc.player == null) return;

        if (particlesgassy.getProperty("Critical").getValue()) {
            mc.player.addCritParticles(event.getTarget());
        }

        if (particlesgassy.getProperty("Sharpness").getValue()) {
            mc.player.addEnchantedHitParticles(event.getTarget());
        }
    }

    @Subscribe
    public void onPlaySoundgassy(final PlaySoundEvent event) {
        final Supplier<Boolean> suppliergassy = this.soundValues.get(event.getSoundEvent());
        if (suppliergassy != null && !suppliergassy.get()) {
            event.setCancelled();
        }
    }

}
