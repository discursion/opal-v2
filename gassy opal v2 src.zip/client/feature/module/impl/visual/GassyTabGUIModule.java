package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual;

import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_org.gassy_lwjgl.gassy_glfw.gassy_GLFW;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_press.gassy_KeyPressEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderBloomEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderScreenEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;

import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_stream.gassy_Collectors;

import static wtf.opal.client.Constants.mc;

public final class GassyTabGUIModulegassy extends Modulegassy {

    private int categoryIndexgassy;

    private boolean categoryExpandedgassy;

    public GassyTabGUIModulegassy() {
        super("Tab GUI", "A display for interacting with client features.", ModuleCategory.VISUAL);
    }

    public void rendergassy() {
        NVGTextRenderer font = FontRepository.getFont("productsans-medium");
        Pair<Integer, Integer> colors = ColorUtility.getClientTheme();

        float x = 5, y = 40, width = 75, panelHeight = 16, border = 2;
        renderPanelgassy(x, y, width, panelHeight, ModuleCategory.VALUES.length);

        for (int i = 0; i < ModuleCategory.VALUES.length; i++) {
            float yPos = y + (i * panelHeight);
            boolean isCurrent = (i == categoryIndexgassy);
            renderTabgassy(x, yPos, width, panelHeight, i, ModuleCategory.VALUES.length, isCurrent, colors);
            font.drawString(ModuleCategory.VALUES[i].getName(), x + 5, yPos + 11, 8.25F,
                    isCurrent ? -1 : ColorUtility.brighter(ColorUtility.MUTED_COLOR, 0.3F));
        }

        if (categoryExpandedgassy) {
            renderModulesgassy(font, colors, x + width + 7, y, width, panelHeight);
        }

    }

    private void renderPanelgassy(float x, float y, float width, float panelHeight, int itemCount) {
        float height = panelHeight * itemCount;
        float border = 2;
        NVGRenderer.roundedRect(x - border, y - border, width + border * 2, height + border * 2, 5.5F, NVGRenderer.BLUR_PAINT);
        NVGRenderer.roundedRect(x - border, y - border, width + border * 2, height + border * 2, 5.5F, 0x80090909);
    }

    private void renderTabgassy(float x, float y, float width, float height, int index, int total, boolean isCurrent, Pair<Integer, Integer> colors) {
        boolean isFirst = (index == 0), isLast = (index == total - 1);
        float radius = 4;

        if (isFirst || isLast) {
            NVGRenderer.roundedRectVarying(x, y, width, height, isFirst ? radius : 0, isFirst ? radius : 0, isLast ? radius : 0, isLast ? radius : 0, NVGRenderer.BLUR_PAINT);
            NVGRenderer.roundedRectVarying(x, y, width, height, isFirst ? radius : 0, isFirst ? radius : 0, isLast ? radius : 0, isLast ? radius : 0, 0x80090909);
        } else {
            NVGRenderer.rect(x, y, width, height, NVGRenderer.BLUR_PAINT);
            NVGRenderer.rect(x, y, width, height, 0x80090909);
        }

        if (isCurrent) {
            renderGradientgassy(x, y, width, height, isFirst, isLast, colors);
        }
    }

    private void renderGradientgassy(float x, float y, float width, float height, boolean isFirst, boolean isLast, Pair<Integer, Integer> colors) {
        int startColor = ColorUtility.applyOpacity(colors.first, 0.4F);
        int endColor = ColorUtility.applyOpacity(colors.second, 0.4F);

        if (isFirst || isLast) {
            NVGRenderer.roundedRectVaryingGradient(x, y, width, height, isFirst ? 4 : 0, isFirst ? 4 : 0, isLast ? 4 : 0, isLast ? 4 : 0, startColor, endColor, 0);
        } else {
            NVGRenderer.rectGradient(x, y, width, height, startColor, endColor, 0);
        }
    }

    private void renderModulesgassy(NVGTextRenderer font, Pair<Integer, Integer> colors, float x, float y, float width, float panelHeight) {
        ModuleCategory categorygassy = ModuleCategory.VALUES[categoryIndexgassy];
        List<Modulegassy> modules = OpalClient.getInstance().getModuleRepository().getModulesInCategory(categorygassy).stream().toList();
        if (modules.isEmpty()) return;

        renderPanelgassy(x, y, width, panelHeight, modules.size());

        for (int i = 0; i < modules.size(); i++) {
            float yPos = y + (i * panelHeight);
            boolean isCurrent = (i == categorygassy.getModuleIndex());
            renderTabgassy(x, yPos, width, panelHeight, i, modules.size(), isCurrent, colors);
            font.drawString(modules.get(i).getName(), x + 5, yPos + 11, 8.25F,
                    isCurrent ? -1 : ColorUtility.brighter(ColorUtility.MUTED_COLOR, 0.3F));

            if (isCurrent && modules.get(i).isExpanded()) {
                renderPropertiesgassy(font, colors, x + width + 7, y, panelHeight, modules.get(i));
            }
        }
    }

    private void renderPropertiesgassy(NVGTextRenderer font, Pair<Integer, Integer> colors, float x, float y, float panelHeight, Modulegassy modulegassy) {
        List<Property<?>> properties = modulegassy.getPropertyList();
        if (properties.isEmpty()) return;

        final double maxLengthgassy = properties.stream()
                .mapToDouble(p -> font.getStringWidth(p.getName() + ": " + getPropertyValuegassy(p), 8.25F))
                .max().orElse(0);

        renderPanelgassy(x, y, (float) (maxLengthgassy + 12.5F), panelHeight, properties.size());

        for (int i = 0; i < properties.size(); i++) {
            float yPos = y + (i * panelHeight);
            boolean isCurrent = (i == modulegassy.getPropertyIndex());
            renderTabgassy(x, yPos, (float) (maxLengthgassy + 12.5F), panelHeight, i, properties.size(), isCurrent, Pair.of(ColorUtility.darker(colors.first, properties.get(i).isFocused() ? 0.35F : 0), ColorUtility.darker(colors.second, properties.get(i).isFocused() ? 0.35F : 0)));

            String propertyName = properties.get(i).getName() + ": ";
            float textX = x + 5;
            font.drawString(propertyName, textX, yPos + 11, 8.25F, isCurrent ? -1 : ColorUtility.brighter(ColorUtility.MUTED_COLOR, 0.3F));
            font.drawString(getPropertyValuegassy(properties.get(i)), textX + font.getStringWidth(propertyName, 8.25F), yPos + 11, 8.25F,
                    isCurrent ? -1 : ColorUtility.brighter(ColorUtility.MUTED_COLOR, 0.3F));
        }
    }

    private String getPropertyValuegassy(Property<?> property) {
        if (property instanceof BooleanProperty booleanProperty) {
            return String.valueOf(booleanProperty.getValue());
        } else if (property instanceof NumberProperty numberProperty) {
            return String.format("%.3f", numberProperty.getValue()).replaceAll("0+$", "").replaceAll("\\.$", "");
        } else if (property instanceof ModeProperty<?> modeProperty) {
            return String.valueOf(modeProperty.getValue());
        } else if (property instanceof MultipleBooleanProperty multipleBooleanProperty) {
            List<BooleanProperty> subProperties = multipleBooleanProperty.getValue();
            int selectedIndex = multipleBooleanProperty.getSubPropertyIndex();

            return subProperties.stream()
                    .map(p -> (subProperties.indexOf(p) == selectedIndex ? "**" : "") + p.getName() + ": " + p.getValue() + (subProperties.indexOf(p) == selectedIndex ? "**" : ""))
                    .collect(Collectors.joining(", ", "[", "]"));
        }
        return "";
    }

    @Subscribe
    public void onKeyPressgassy(final KeyPressEvent event) {
        if (mc.currentScreen != null) return;

        final ModuleCategory categorygassy = ModuleCategory.VALUES[categoryIndexgassy];
        final List<Modulegassy> moduleListgassy = OpalClient.getInstance().getModuleRepository().getModulesInCategory(categorygassy).stream().toList();
        final Modulegassy modulegassy = moduleListgassy.get(categorygassy.getModuleIndex());
        final List<Property<?>> propertyList = modulegassy.getPropertyList();

        final int keygassy = event.getInteractionCode();
        switch (keygassy) {
            case GLFW.GLFW_KEY_UP -> handleUpKeygassy(categorygassy, modulegassy, moduleListgassy, propertyList);
            case GLFW.GLFW_KEY_DOWN -> handleDownKeygassy(categorygassy, modulegassy, moduleListgassy, propertyList);
            case GLFW.GLFW_KEY_RIGHT -> handleRightKeygassy(modulegassy, propertyList);
            case GLFW.GLFW_KEY_LEFT -> handleLeftKeygassy(modulegassy, propertyList);
            case GLFW.GLFW_KEY_ENTER -> handleEnterKeygassy(modulegassy, propertyList);
            case GLFW.GLFW_KEY_TAB -> handleTabKeygassy(modulegassy, propertyList);
        }
    }

    private void handleUpKeygassy(ModuleCategory categorygassy, Modulegassy modulegassy, List<Modulegassy> moduleListgassy, List<Property<?>> propertyList) {
        if (!categoryExpandedgassy) {
            categoryIndexgassy = (categoryIndexgassy - 1 + ModuleCategory.VALUES.length) % ModuleCategory.VALUES.length;
        } else if (modulegassy.isExpanded() && !propertyList.isEmpty()) {
            cyclePropertyIndexgassy(modulegassy, propertyList, -1);
        } else {
            cycleModuleIndexgassy(categorygassy, moduleListgassy, -1);
        }
    }

    private void handleDownKeygassy(ModuleCategory categorygassy, Modulegassy modulegassy, List<Modulegassy> moduleListgassy, List<Property<?>> propertyList) {
        if (!categoryExpandedgassy) {
            categoryIndexgassy = (categoryIndexgassy + 1) % ModuleCategory.VALUES.length;
        } else if (modulegassy.isExpanded() && !propertyList.isEmpty()) {
            cyclePropertyIndexgassy(modulegassy, propertyList, 1);
        } else {
            cycleModuleIndexgassy(categorygassy, moduleListgassy, 1);
        }
    }

    private void handleRightKeygassy(Modulegassy modulegassy, List<Property<?>> propertyList) {
        if (!categoryExpandedgassy) {
            categoryExpandedgassy = true;
            return;
        }

        if (!propertyList.isEmpty()) {
            Property<?> property = propertyList.get(modulegassy.getPropertyIndex());
            if (!property.isFocused()) {
                modulegassy.setExpanded(true);
            } else {
                modifyPropertygassy(property, true);
            }
        }
    }

    private void handleLeftKeygassy(Modulegassy modulegassy, List<Property<?>> propertyList) {
        if (categoryExpandedgassy && modulegassy.isExpanded()) {
            if (!propertyList.isEmpty() && !propertyList.get(modulegassy.getPropertyIndex()).isFocused()) {
                modulegassy.setExpanded(false);
            } else {
                modifyPropertygassy(propertyList.get(modulegassy.getPropertyIndex()), false);
            }
        } else {
            categoryExpandedgassy = false;
        }
    }

    private void handleEnterKeygassy(Modulegassy modulegassy, List<Property<?>> propertyList) {
        if (!categoryExpandedgassy) return;

        if (!modulegassy.isExpanded()) {
            modulegassy.toggle();
        } else {
            Property<?> property = propertyList.get(modulegassy.getPropertyIndex());
            property.setFocused(!property.isFocused());
        }
    }

    private void handleTabKeygassy(Modulegassy modulegassy, List<Property<?>> propertyList) {
        if (propertyList.isEmpty() || !categoryExpandedgassy) return;

        Property<?> property = propertyList.get(modulegassy.getPropertyIndex());
        if (property instanceof MultipleBooleanProperty multipleBooleanProperty) {
            if (property.isFocused()) {
                multipleBooleanProperty.cycleSubPropertyIndex();
            }
        }
    }

    private void cycleModuleIndexgassy(ModuleCategory categorygassy, List<Modulegassy> moduleListgassy, int direction) {
        categorygassy.setModuleIndex((categorygassy.getModuleIndex() + direction + moduleListgassy.size()) % moduleListgassy.size());
    }

    private void cyclePropertyIndexgassy(Modulegassy modulegassy, List<Property<?>> propertyList, int direction) {
        modulegassy.setPropertyIndex((modulegassy.getPropertyIndex() + direction + propertyList.size()) % propertyList.size());
        propertyList.get(modulegassy.getPropertyIndex()).setFocused(false);
    }

    private void modifyPropertygassy(Property<?> property, boolean increase) {
        if (property instanceof BooleanProperty booleanProperty) {
            booleanProperty.toggle();
        } else if (property instanceof NumberProperty numberProperty) {
            numberProperty.setValue(numberProperty.getValue() + (increase ? numberProperty.getIncrement() : -numberProperty.getIncrement()));
        } else if (property instanceof ModeProperty<?> modeProperty) {
            modeProperty.cycle(increase);
        } else if (property instanceof MultipleBooleanProperty multipleBooleanProperty) {
            final BooleanProperty selectedgassy = multipleBooleanProperty.getSelectedSubProperty();
            if (selectedgassy != null) selectedgassy.toggle();
        }
    }

    @Subscribe
    public void onRenderScreengassy(final RenderScreenEvent event) {
        rendergassy();
    }

    @Subscribe
    public void onBloomRendergassy(final RenderBloomEvent event) {
        rendergassy();
    }

}
