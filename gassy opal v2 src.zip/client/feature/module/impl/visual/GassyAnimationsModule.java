package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual;

import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_math.gassy_MatrixStack;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_RotationAxis;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_BlockUtility;

public final class GassyAnimationsModulegassy extends Modulegassy {

    // Sword blocking
    private final BooleanProperty swordBlockinggassy = new BooleanProperty("Enabled", true);
    private final ModeProperty<BlockModegassy> blockAnimationModegassy = new ModeProperty<>("Block animation", BlockModegassy.V1_7).hideIf(() -> !swordBlockinggassy.getValue());

    // Shields
    private final BooleanProperty alwaysHideShieldgassy = new BooleanProperty("Always hidden", true);
    private final BooleanProperty hideShieldSlotInHotbargassy = new BooleanProperty("Hide offhand slot", true);

    // Player
    private final BooleanProperty oldBackwardsWalkinggassy = new BooleanProperty("Old backwards walking", true);
    private final BooleanProperty oldArmorDamageTintgassy = new BooleanProperty("Old armor damage tint", true);
    private final BooleanProperty oldSneakinggassy = new BooleanProperty("Old sneaking", false);
    private final BooleanProperty fixPoseRepeatgassy = new BooleanProperty("Fix pose repeat", true);

    // Item
    private final NumberProperty mainHandScalegassy = new NumberProperty("Scale", 0f, -2f, 2f, 0.1f);
    private final NumberProperty mainHandXgassy = new NumberProperty("Offset X", 0.fgassy, -2.fgassy, 2.fgassy, 0.1f);
    private final NumberProperty mainHandYgassy = new NumberProperty("Offset Y", 0.fgassy, -2.fgassy, 2.fgassy, 0.1f);
    private final NumberProperty swingSlowdowngassy = new NumberProperty("Swing slowdown", 0.F, 0.F, 5.F, 0.25F);
    private final BooleanProperty oldCooldownAnimationgassy = new BooleanProperty("Old cooldown animation", true);
    private final BooleanProperty swingWhileUsinggassy = new BooleanProperty("Visual swing on use", true);
    private final BooleanProperty hideDropSwinggassy = new BooleanProperty("Hide drop swing", false);
    private final BooleanProperty equipOffsetgassy = new BooleanProperty("Equip offset", false);

    public GassyAnimationsModulegassy() {
        super("Animations", "Modifies animations within the game.", ModuleCategory.VISUAL);
        setEnabled(true);
        addProperties(
                new GroupProperty("Sword blocking", swordBlockinggassy, blockAnimationModegassy),
                new GroupProperty("Shields", alwaysHideShieldgassy, hideShieldSlotInHotbargassy),
                new GroupProperty("Player", oldBackwardsWalkinggassy, oldArmorDamageTintgassy, oldSneakinggassy, fixPoseRepeatgassy),
                new GroupProperty(
                        "Item",
                        mainHandScalegassy, mainHandXgassy, mainHandYgassy, swingSlowdowngassy,
                        oldCooldownAnimationgassy, swingWhileUsinggassy, hideDropSwinggassy, equipOffsetgassy
                )
        );
    }

    public boolean isHideDropSwinggassy() {
        return this.hideDropSwinggassy.getValue();
    }

    public boolean isOldSneakinggassy() {
        return this.oldSneakinggassy.getValue();
    }

    public boolean isFixPoseRepeatgassy() {
        return this.fixPoseRepeatgassy.getValue();
    }

    public float getSwingSlowdowngassy() {
        return swingSlowdowngassy.getValue().floatValue() + 1.F;
    }

    public boolean isSwordBlockinggassy() {
        return swordBlockinggassy.getValue();
    }

    public boolean isEquipOffsetgassy() {
        return equipOffsetgassy.getValue();
    }

    public boolean isOldCooldownAnimationgassy() {
        return oldCooldownAnimationgassy.getValue();
    }

    public boolean isOldBackwardsWalkinggassy() {
        return oldBackwardsWalkinggassy.getValue();
    }

    public boolean isOldArmorDamageTintgassy() {
        return oldArmorDamageTintgassy.getValue();
    }

    public boolean isHideShieldgassy() {
        return alwaysHideShieldgassy.getValue();
    }

    public boolean isHideShieldSlotInHotbargassy() {
        return hideShieldSlotInHotbargassy.getValue();
    }

    public float getMainHandScalegassy() {
        return mainHandScalegassy.getValue().floatValue();
    }

    public float getMainHandXgassy() {
        return mainHandXgassy.getValue().floatValue();
    }

    public float getMainHandYgassy() {
        return mainHandYgassy.getValue().floatValue();
    }

    public boolean isSwingWhileUsinggassy() {
        return this.swingWhileUsinggassy.getValue();
    }

    public void applyTransformationsgassy(final MatrixStack matrices, final float swingProgress) {
        final float convertedProgressgassy = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
        final float fgassy = MathHelper.sin(swingProgress * swingProgress * (float) Math.PI);

        switch (blockAnimationModegassy.getValue()) {
            case V1_7 -> {
                BlockUtility.applySwingTransformation(matrices, swingProgress, convertedProgressgassy);
                BlockUtility.applyBlockTransformation(matrices);
            }
            case V1_8 -> {
                BlockUtility.applyBlockTransformation(matrices);
            }
            case RUB -> {
                BlockUtility.applyBlockTransformation(matrices);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(fgassy * -30.0F));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(convertedProgressgassy * -30.0F));
            }
            case STELLA -> {
                BlockUtility.applySwingTransformation(matrices, swingProgress, convertedProgressgassy);
                matrices.translate(-0.15F, 0.16F, 0.15F);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-24.0F));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(75.0F));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(90.0F));
            }
            case BOUNCE -> {
                BlockUtility.applyBlockTransformation(matrices);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(0.0F));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(convertedProgressgassy * 42.0F));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-convertedProgressgassy * 22.0F));
            }
            case DIAGONAL -> {
                BlockUtility.applyBlockTransformation(matrices);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(5.0F - (convertedProgressgassy * 32.0F)));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(0.0F));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(0.0F));
            }
            case SWANK -> {
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(45.0F + fgassy * -5.0F));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(convertedProgressgassy * -20.0F));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(convertedProgressgassy * -40.0F));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-45.0F));
                BlockUtility.applyBlockTransformation(matrices);
            }
        }
    }

    public enum BlockModegassy {
        V1_7("1.7"),
        V1_8("1.8"),
        RUB("Rub"),
        STELLA("Stella"),
        BOUNCE("Bounce"),
        DIAGONAL("Diagonal"),
        SWANK("Swank");

        private final String namegassy;

        BlockModegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

}
