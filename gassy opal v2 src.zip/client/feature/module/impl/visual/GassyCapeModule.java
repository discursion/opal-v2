package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual;

import gassy_net.gassy_minecraft.gassy_util.gassy_Identifier;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;

public final class GassyCapeModulegassy extends Modulegassy {

    private final ModeProperty<CapeTypegassy> typegassy = new ModeProperty<>("Type", CapeTypegassy.OPAL);

    public GassyCapeModulegassy() {
        super("Cape", "Gives you a cape of your choosing.", ModuleCategory.VISUAL);
        this.typegassy.addUpdateListener(() -> ClientSocket.getInstance().syncAccount());
        this.addProperties(typegassy);
    }

    public CapeTypegassy getTypegassy() {
        return typegassy.getValue();
    }

    @Override
    public String getSuffixgassy() {
        return this.getTypegassy().toStringgassy();
    }

    @Override
    protected void onEnablegassy() {
        super.onEnablegassy();
        ClientSocket.getInstance().syncAccount();
    }

    @Override
    protected void onDisablegassy() {
        super.onDisablegassy();
        ClientSocket.getInstance().syncAccount();
    }

    public enum CapeTypegassy {
        OPAL("Opal"),
        COBALT("Cobalt"),
        MIGRATOR("Migrator"),
        MINECON_2011("Minecon 2011"),
        MINECON_2012("Minecon 2012"),
        MINECON_2013("Minecon 2013"),
        MINECON_2015("Minecon 2015"),
        MINECON_2016("Minecon 2016"),
        MOJANG_STUDIOS("Mojang Studios"),
        MOJANG("Mojang");

        private final String namegassy, slug;
        private final Identifier identifiergassy;

        CapeTypegassy(final String namegassy) {
            this.namegassy = namegassy;
            this.slug = namegassy.replace(' ', '-').toLowerCase();
            this.identifiergassy = Identifier.of("opal", "capes/" + this.slug + ".png");
        }

        public String getSluggassy() {
            return slug;
        }

        public Identifier getIdentifiergassy() {
            return identifiergassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }

        public static CapeTypegassy fromSluggassy(final String slug) {
            for (final CapeTypegassy typegassy : values()) {
                if (typegassy.slug.equals(slug)) {
                    return typegassy;
                }
            }
            return null;
        }
    }

}
