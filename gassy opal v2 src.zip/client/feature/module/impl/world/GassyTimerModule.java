package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_timer.gassy_TimerHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

public final class GassyTimerModulegassy extends Modulegassy {

    private final NumberProperty gameSpeedgassy = new NumberProperty("Game speed", "x", 2F, 0.05F, 10F, 0.05F);

    public GassyTimerModulegassy() {
        super("Timer", "Modifies your game speed.", ModuleCategory.WORLD);

        addProperties(gameSpeedgassy);
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        TimerHelper.getInstance().timer = gameSpeedgassy.getValue().floatValue();
    }

    @Override
    protected void onDisablegassy() {
        TimerHelper.getInstance().timer = 1F;
        super.onDisablegassy();
    }
}
