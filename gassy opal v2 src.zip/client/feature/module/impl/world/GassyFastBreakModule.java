package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import static wtf.opal.client.Constants.mc;

public final class GassyFastBreakModulegassy extends Modulegassy {

    private final BooleanProperty speedEnabledgassy = new BooleanProperty("Enabled", true);
    private final NumberProperty speedgassy = new NumberProperty("Speed", "%", 20, 1, 100, 1);

    private final BooleanProperty breakCooldownEnabledgassy = new BooleanProperty("Enabled", true);
    private final NumberProperty breakCooldowngassy = new NumberProperty("Cooldown", 0, 0, 5, 1);

    private final MultipleBooleanProperty breakSlowdownsgassy = new MultipleBooleanProperty("Break slowdown",
            new BooleanProperty("In air", true),
            new BooleanProperty("In water", true),
            new BooleanProperty("Mining fatigue", true)
    );

    private final BooleanProperty spoofGroundStategassy = new BooleanProperty("Spoof ground state", false);

    public GassyFastBreakModulegassy() {
        super("Fast Break", "Breaks blocks quicker.", ModuleCategory.WORLD);
        addProperties(
                new GroupProperty("Speed", speedEnabledgassy, speedgassy),
                new GroupProperty("Break cooldown", breakCooldownEnabledgassy, breakCooldowngassy),
                breakSlowdownsgassy, spoofGroundStategassy.hideIf(() -> breakSlowdownsgassy.getProperty("In air").getValue())
        );
    }

    @Subscribe
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
        if (spoofGroundStategassy.getValue() && mc.interactionManager.isBreakingBlock() && !mc.player.isTouchingWater() && !breakSlowdownsgassy.getProperty("In air").getValue()) {
            event.setOnGround(true);
        }
    }

    public boolean isSpeedEnabledgassy() {
        return speedEnabledgassy.getValue();
    }

    public float getSpeedgassy() {
        return speedgassy.getValue().floatValue();
    }

    public boolean isBreakCooldownEnabledgassy() {
        return breakCooldownEnabledgassy.getValue();
    }

    public int getBreakCooldowngassy() {
        return breakCooldowngassy.getValue().intValue();
    }

    public MultipleBooleanProperty getBreakSlowdownsgassy() {
        return breakSlowdownsgassy;
    }

}
