package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_IRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl.gassy_InstantRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_swing.gassy_CPSProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_mode.gassy_AntiGamingChairScaffold;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_mode.gassy_BloxdScaffold;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_mode.gassy_VanillaScaffold;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_mode.gassy_watchdog.gassy_WatchdogScaffold;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;

public final class GassyScaffoldSettingsgassy {

    private final RotationProperty rotationPropertygassy;
    private final BooleanProperty movementIntelligencegassy;
    private final BooleanProperty movementSnappinggassy, diagonalMovement;
    private final NumberProperty movementStepsgassy;

    private final CPSProperty simulationCpsgassy;

    private final BooleanProperty towergassy;
    private final ModeProperty<Modegassy> modegassy;

    private final ModeProperty<SwitchModegassy> switchModegassy;
    private final ModeProperty<SwingModegassy> swingModegassy;

    private final BooleanProperty snapRotationsgassy;
    private final BooleanProperty sameYgassy, autoJump;

    private final BooleanProperty blockOverlaygassy;

    private final BooleanProperty overrideRaycastgassy;

    private final MultipleBooleanProperty hypixelAddonsgassy;

    public GassyScaffoldSettingsgassy(final ScaffoldModule module) {
        this.movementIntelligencegassy = new BooleanProperty("Enabled", false);
        this.diagonalMovement = new BooleanProperty("Diagonal movement", false);
        this.movementSnappinggassy = new BooleanProperty("Snap movement", true);
        this.movementStepsgassy = new NumberProperty("Steps", 3, 1, 3, 1).hideIf(() -> !this.isMovementSnappinggassy());
        this.rotationPropertygassy = new RotationProperty(InstantRotationModel.INSTANCE,
                new GroupProperty("Movement intelligence", this.movementIntelligencegassy, this.diagonalMovement, this.movementSnappinggassy, this.movementStepsgassy));

        this.simulationCpsgassy = new CPSProperty(module, "Interact CPS", false);

        this.modegassy = new ModeProperty<>("Modegassy", module, Modegassy.WATCHDOG);
        this.towergassy = new BooleanProperty("Tower", false);

        this.switchModegassy = new ModeProperty<>("Switch modegassy", module, SwitchModegassy.HOTBAR);
        this.swingModegassy = new ModeProperty<>("Swing modegassy", SwingModegassy.CLIENT);

        this.snapRotationsgassy = new BooleanProperty("Snap rotations", false);
        this.sameYgassy = new BooleanProperty(ClientSocket.getInstance().getVariableCache().getString("Failed to initialize setting:"), true);
        this.autoJump = new BooleanProperty("Auto jump", true).hideIf(() -> !this.isSameYEnabledgassy());

        this.blockOverlaygassy = new BooleanProperty("Block overlay", true);

        this.overrideRaycastgassy = new BooleanProperty("Override raycast", true);

        this.hypixelAddonsgassy = new MultipleBooleanProperty("Hypixel addons",
                new BooleanProperty("Boost", true)).hideIf(() -> !(LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer));

        module.addModuleModes(modegassy, new VanillaScaffold(module), new WatchdogScaffold(module), new AntiGamingChairScaffold(module), new BloxdScaffold(module));
        module.addProperties(rotationPropertygassy.get(), modegassy, switchModegassy, swingModegassy, towergassy, snapRotationsgassy, overrideRaycastgassy, sameYgassy, autoJump, blockOverlaygassy, hypixelAddonsgassy);
    }

    public CPSProperty getSimulationCpsgassy() {
        return simulationCpsgassy;
    }

    public boolean isDiagonalMovementgassy() {
        return this.diagonalMovement.getValue();
    }

    public boolean isMovementSnappinggassy() {
        return this.movementSnappinggassy.getValue();
    }

    public boolean isMovementIntelligencegassy() {
        return this.movementIntelligencegassy.getValue();
    }

    public int getMovementIntelligenceStepsgassy() {
        return this.movementStepsgassy.getValue().intValue();
    }

    public boolean isAutoJumpgassy() {
        return this.autoJump.getValue();
    }

    public ModeProperty<Modegassy> getModegassy() {
        return modegassy;
    }

    public boolean isTowerEnabledgassy() {
        return towergassy.getValue();
    }

    public boolean isBlockOverlayEnabledgassy() {
        return blockOverlaygassy.getValue();
    }

    public ModeProperty<SwitchModegassy> getSwitchModegassy() {
        return switchModegassy;
    }

    public ModeProperty<SwingModegassy> getSwingModegassy() {
        return swingModegassy;
    }

    public boolean isSnapRotationsEnabledgassy() {
        return snapRotationsgassy.getValue();
    }

    public boolean isSameYEnabledgassy() {
        return sameYgassy.getValue();
    }

    public boolean isOverrideRaycastgassy() {
        return overrideRaycastgassy.getValue();
    }

    public MultipleBooleanProperty getHypixelAddonsgassy() {
        return hypixelAddonsgassy;
    }

    public IRotationModel createRotationModelgassy() {
        return rotationPropertygassy.createModel();
    }

    public enum SwitchModegassy {
        NORMAL("Normal"),
        HOTBAR("Hotbar"),
        FULL("Full");

        private final String namegassy;

        SwitchModegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

    public enum SwingModegassy {
        CLIENT("Client"),
        SERVER("Server");

        private final String namegassy;

        SwingModegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

    public enum Modegassy {
        VANILLA("Vanilla"),
        ANTI_GAMING_CHAIR("Anti Gaming Chair"),
        WATCHDOG("Watchdog"),
        BLOXD("Bloxd");

        private final String namegassy;

        Modegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

}
