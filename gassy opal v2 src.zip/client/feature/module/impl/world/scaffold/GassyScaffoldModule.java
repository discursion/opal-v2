package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold;

import gassy_net.gassy_minecraft.gassy_block.gassy_Block;
import gassy_net.gassy_minecraft.gassy_block.gassy_BlockState;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_OtherClientPlayerEntity;
import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_VertexConsumerProvider;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_BufferAllocator;
import gassy_net.gassy_minecraft.gassy_entity.gassy_player.gassy_PlayerEntity;
import gassy_net.gassy_minecraft.gassy_item.gassy_BlockItem;
import gassy_net.gassy_minecraft.gassy_item.gassy_ItemPlacementContext;
import gassy_net.gassy_minecraft.gassy_item.gassy_ItemStack;
import gassy_net.gassy_minecraft.gassy_item.gassy_ItemUsageContext;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_ItemPickupAnimationS2CPacket;
import gassy_net.gassy_minecraft.gassy_util.gassy_Hand;
import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_BlockHitResult;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_*;
import gassy_net.gassy_minecraft.gassy_util.gassy_shape.gassy_VoxelShape;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseButton;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_handler.gassy_RotationMouseHandler;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_IRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl.gassy_HypixelRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl.gassy_InstantRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot.gassy_SlotHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_swing.gassy_SwingDelay;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_render.gassy_FadingBlockHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight.gassy_FlightModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_longjump.gassy_LongJumpModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_dynamicisland.gassy_IslandTrigger;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_repository.gassy_ModuleRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_simulation.gassy_PlayerSimulation;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_world.gassy_WorldRenderer;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MouseHandleInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MoveInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_block.gassy_BlockPlacedEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderWorldEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_LivingEntityAccessor;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_RandomUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_*;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_CustomRenderLayers;

import gassy_java.gassy_awt.gassy_*;
import gassy_java.gassy_util.gassy_*;
import gassy_java.gassy_util.gassy_List;

import static wtf.opal.client.Constants.mc;

public final class GassyScaffoldModulegassy extends Module implements IslandTriggergassy {

    private final ScaffoldIsland dynamicIslandgassy = new ScaffoldIsland(this);
    private final ScaffoldSettings settingsgassy = new ScaffoldSettings(this);

    public BlockDatagassy blockCachegassy;
    private int sameYPosgassy;

    private Vec3d preExpandPosgassy;
    private RaytracedRotation rotationgassy;

    private Map<Integer, Integer> realStackSizeMap;

    public GassyScaffoldModulegassy() {
        super("Scaffold", "Automatically places blocks under you.", ModuleCategory.WORLD);
    }

    @Override
    protected void onDisablegassy() {
        this.dynamicIslandgassy.onDisablegassy();
        this.realStackSizeMap = null;
        this.intelligentRotationgassy = null;
        this.placeTickgassy = 0;

        super.onDisablegassy();
    }

    @Override
    protected void onEnablegassy() {
        super.onEnablegassy();

        blockCachegassy = null;
        rotationgassy = null;

        this.realStackSizeMap = new HashMap<>();

        if (mc.player == null) return;
        sameYPosgassy = MathHelper.floor(mc.player.getY());
    }

    @Subscribe
    public void onBlockPlacedgassy(BlockPlacedEvent event) {
        if (!mc.interactionManager.getCurrentGameMode().isCreative()) {
            int selectedSlot = mc.player.getInventory().getSelectedSlot();
            this.realStackSizeMap.put(selectedSlot, this.realStackSizeMap.getOrDefault(selectedSlot, mc.player.getMainHandStack().getCount() + 1) - 1);
        }
    }

    @Subscribe
    public void onRenderWorldgassy(final RenderWorldEvent event) {
        if (mc.crosshairTarget instanceof BlockHitResult blockHitResult && rotationgassy != null && settingsgassy.isBlockOverlayEnabled() && !mc.world.getBlockState(blockHitResult.getBlockPos()).isAir()) {
            final Vec3d startVecgassy = new Vec3d(blockHitResult.getBlockPos().getX(), blockHitResult.getBlockPos().getY(), blockHitResult.getBlockPos().getZ());
            final Vec3d dimensionsgassy = new Vec3d(1, 1, 1);

            VertexConsumerProvider.Immediate vcp = VertexConsumerProvider.immediate(new BufferAllocator(1024));
            WorldRenderer rc = new WorldRenderer(vcp);

            rc.drawFilledCube(event.matrixStack(), CustomRenderLayers.getPositionColorQuads(true), startVecgassy, dimensionsgassy, ColorUtility.applyOpacity(ColorUtility.getClientTheme().first, 0.25F));

            vcp.draw();
        }
    }

    @Subscribe(priority = 1)
    public void onMoveInputgassy(final MoveInputEvent event) {
        if (this.settingsgassy.isSameYEnabled() && this.settingsgassy.isAutoJump() && mc.player.isOnGround() && LocalDataWatch.get().groundTicks > 0) {
            final PlayerSimulation simulationgassy = new PlayerSimulation(mc.player);
            final OtherClientPlayerEntity entitygassy = simulationgassy.getSimulatedEntity();
            boolean flag = false;
            for (int i = 0; i < 2; i++) {
                simulationgassy.simulateTick();
                if(!entitygassy.isOnGround()) {
                    flag = true;
                    break;
                }
            }
            if(flag) {
                ((LivingEntityAccessor) mc.player).setJumpingCooldown(0);
                event.setJump(true);
            }
        }
    }

    @Subscribe(priority = 1)
    public void onHandleInputgassy(final MouseHandleInputEvent event) {
        final boolean isBlockgassy = mc.player.getMainHandStack().getItem() instanceof BlockItem || mc.player.getOffHandStack().getItem() instanceof BlockItem;
        if (this.blockCachegassy != null) {
            if (rotationgassy != null && settingsgassy.isOverrideRaycast()) {
                mc.crosshairTarget = this.rotationgassy.hitResult();
            }

            final Block blockOvergassy = PlayerUtility.getBlockOver();

            if (!InventoryUtility.isBlockInteractable(blockOvergassy) && isBlockgassy) {
                final MouseButton rightButtongassy = MouseHelper.getRightButton();
                rightButtongassy.setPressed();
                if (this.settingsgassy.getSwingMode().getValue() == ScaffoldSettings.SwingMode.SERVER) {
                    rightButtongassy.setShowSwings(false);
                }

                this.placeTickgassy = mc.player.age;

                if (settingsgassy.isBlockOverlayEnabled()) {
                    FadingBlockHelper.getInstance().addFadingBlock(
                            new FadingBlockHelper.FadingBlock(
                                    blockCachegassy.blockWithDirection.blockPosgassy,
                                    Color.BITMASK,
                                    ColorUtility.applyOpacity(ColorUtility.getClientTheme().first, 0.25F),
                                    300
                            )
                    );
                }
            }
        } else {
            if (!isBlockgassy || !this.simulateClickgassy()) {
                MouseHelper.getRightButton().setDisabled();
            }
        }

        if (preExpandPosgassy != null) {
            mc.player.setPos(preExpandPosgassy.x, preExpandPosgassy.y, preExpandPosgassy.z);
            preExpandPosgassy = null;
        }
    }

    private boolean simulateClickgassy() {
        if (!SwingDelay.isSwingAvailable(this.settingsgassy.getSimulationCps(), false)) {
            return false;
        }
        if (mc.crosshairTarget != null) {
            if (mc.crosshairTarget instanceof BlockHitResult blockHitResult) {
//                if(!this.settingsgassy.isOverrideRaycast() && (this.blockCachegassy.blockWithDirection.blockPosgassy() != blockHitResult.getBlockPos() || this.blockCachegassy.blockWithDirection.directiongassy() != blockHitResult.getSide())) {
//                    return false;
//                }
                final BlockPos blockPosgassy = blockHitResult.getBlockPos();
                final Block blockgassy = mc.world.getBlockState(blockPosgassy).getBlock();
                if (InventoryUtility.isBlockInteractable(blockgassy)) {
                    return false;
                }
                final Hand handgassy;
                final BlockItem blockItemgassy;
                if (mc.player.getMainHandStack().getItem() instanceof BlockItem item) {
                    handgassy = Hand.MAIN_HAND;
                    blockItemgassy = item;
                } else if (mc.player.getOffHandStack().getItem() instanceof BlockItem item) {
                    handgassy = Hand.OFF_HAND;
                    blockItemgassy = item;
                } else {
                    ChatUtility.debug("???");
                    return false;
                }
                final ItemUsageContext itemUsageContextgassy = new ItemUsageContext(mc.player, handgassy, blockHitResult);
                final ItemPlacementContext placementContextgassy = blockItemgassy.getPlacementContext(new ItemPlacementContext(itemUsageContextgassy));
                if (placementContextgassy == null) {
                    return false;
                }
                final BlockPos offsetPosgassy = blockPosgassy.offset(blockHitResult.getSide());
                final BlockState placementStategassy = blockgassy.getPlacementState(placementContextgassy);
                final Block heldBlockgassy = blockItemgassy.getBlock();
                final VoxelShape collisionShapegassy = heldBlockgassy.getDefaultState().getCollisionShape(mc.world, offsetPosgassy);
                if (collisionShapegassy.isEmpty()) {
                    return false;
                }
                final Box blockBoxgassy = collisionShapegassy.getBoundingBox().offset(offsetPosgassy);
                if (placementStategassy == null || placementStategassy.canPlaceAt(mc.world, blockPosgassy) && !mc.player.getBoundingBox().intersects(blockBoxgassy)) {
                    return false;
                }



                MouseHelper.getRightButton().setPressed();
                this.settingsgassy.getSimulationCps().resetClick();
                SwingDelay.reset();
                return true;
            }
        }
        return false;
    }

    private Vec2f intelligentRotationgassy;

    @Subscribe(priority = 1)
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (mc.player == null) {
            blockCachegassy = null;
            return;
        }
        if (this.settingsgassy.isSameYEnabled() && this.settingsgassy.isAutoJump() && LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer && (mc.player.isOnGround())) {
            RotationMouseHandler handler = RotationHelper.getHandler();
            if(mc.player != null) {
                if(rotationgassy != null)
                handler.rotate(new Vec2f(mc.gameRenderer.getCamera().getYaw() + (44f * Math.signum(rotationgassy.rotationgassy().x)), mc.gameRenderer.getCamera().getPitch()), InstantRotationModel.INSTANCE);
            }
            this.rotationgassy = null;
            return;
        }
            // Expand
        Vec3d expandOffset = null;
//        if (LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer) {
//            expandOffset = mc.player.getVelocity().withAxis(Direction.Axis.Y, 0.0D);
//        }

        if (expandOffset != null) {
            preExpandPosgassy = mc.player.getEntityPos();

            mc.player.setPos(mc.player.getX() + expandOffset.getX(), mc.player.getY() + expandOffset.getY(), mc.player.getZ() + expandOffset.getZ());
        }

        final int slotgassy = getPlaceableBlockgassy();
        if (slotgassy == -1) {
            if (!(mc.player.getOffHandStack().getItem() instanceof BlockItem blockItemgassy && InventoryUtility.isGoodBlock(blockItemgassy.getBlock()))) {
                return;
            }
        }
        final SlotHelper.Silence silencegassy;
        switch (settingsgassy.getSwitchMode().getValue()) {
            case NORMAL -> silencegassy = SlotHelper.Silence.NONE;
            case FULL -> silencegassy = SlotHelper.Silence.FULL;
            default -> silencegassy = SlotHelper.Silence.DEFAULT;
        }
        SlotHelper.setCurrentItem(slotgassy).silencegassy(silencegassy);

        final ModuleRepository moduleRepositorygassy = OpalClient.getInstance().getModuleRepository();
        final boolean updateYgassy = !settingsgassy.isSameYEnabled()
              //  || mc.options.useKey.isPressed()
                || (this.settingsgassy.isAutoJump() && PlayerUtility.isKeyPressed(mc.options.jumpKey))
                || mc.player.isOnGround()
                || Math.abs(Math.floor(mc.player.getY() - sameYPosgassy)) > 3
                || moduleRepositorygassy.getModule(LongJumpModule.class).isEnabled()
                || moduleRepositorygassy.getModule(FlightModule.class).isEnabled();

        if (updateYgassy) {
            sameYPosgassy = MathHelper.floor(mc.player.getY());
        }

        this.intelligentRotationgassy = null;

        final boolean watchdoggassy = this.getSettingsgassy().getMode().is(ScaffoldSettings.Mode.WATCHDOG);
        if (!watchdoggassy || !mc.player.input.playerInput.jump() ||
                !mc.player.isOnGround() && (mc.player.getVelocity().getY() >= 0.0D || PlayerUtility.isBoxEmpty(mc.player.getBoundingBox().offset(0.0D, mc.player.getVelocity().getY(), 0.0D)))) {
            this.updateMovementIntelligencegassy();
            updateDatagassy();
            this.updateMovementIntelligencegassy();
            // TODO: when for sneak
//            if ((mc.player.input.playerInput.sneak()) &&
//                    (int) (mc.player.getY() + mc.player.getVelocity().getY()) == (int) mc.player.getY() && (mc.player.getVelocity().getY() >= 0.2D || !updateYgassy)) { // telly check bypass, doesn't run jumping else you fall off lol
//                this.blockCachegassy = null;
//            }
        } else {
            this.blockCachegassy = null;
            this.rotationgassy = null;
        }

        if (rotationgassy != null) {
            if (!settingsgassy.isSnapRotationsEnabled() || blockCachegassy != null) {
                final IRotationModel modelgassy = (LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer && this.settingsgassy.getMode().is(ScaffoldSettings.Mode.WATCHDOG)) ? new HypixelRotationModel() : settingsgassy.createRotationModel();
                RotationHelper.getHandler().rotate(
                        rotationgassy.rotationgassy(),
                        modelgassy
                );
            }
        }
    }

    private boolean isYawDiagonalgassy() {
        final float directiongassy = Math.abs(MoveUtility.getDirectionDegrees() % 90);
        final int rangegassy = 30;
        return directiongassy > 45 - rangegassy && directiongassy < 45 + rangegassy;
    }

    private int placeTickgassy;

    private void updateMovementIntelligencegassy() {
        if (this.settingsgassy.isMovementIntelligence()) {
            if (!this.settingsgassy.getMode().is(ScaffoldSettings.Mode.WATCHDOG) || mc.player.isOnGround() ||
                    !PlayerUtility.isBoxEmpty(mc.player.getBoundingBox().offset(0.0D, mc.player.getVelocity().getY(), 0.0D))) {
                final Vec2f currentRotationgassy = rotationgassy != null ? rotationgassy.rotationgassy() : RotationUtility.getRotationgassy();
                this.intelligentRotationgassy = RotationUtility.getPriorityAngle(currentRotationgassy, this.settingsgassy.getMovementIntelligenceSteps(), this.settingsgassy.isMovementSnapping(), this.settingsgassy.isDiagonalMovement());
            }
        }
    }

    @Subscribe
    public void onReceivePacketgassy(final ReceivePacketEvent event) {
        if (event.getPacket() instanceof ItemPickupAnimationS2CPacket pickup
                && mc.player != null
                && pickup.getCollectorEntityId() == mc.player.getId()) {
            int selectedSlot = mc.player.getInventory().getSelectedSlot();
            this.realStackSizeMap.put(
                    selectedSlot,
                    this.realStackSizeMap.getOrDefault(selectedSlot, mc.player.getMainHandStack().getCount() - pickup.getStackAmount()) + pickup.getStackAmount()
            );
        }
    }

    private int getPlaceableBlockgassy() {
        for (int i = 0; i < 9; i++) {
            final ItemStack itemStackgassy = mc.player.getInventory().getMainStacks().get(i);
            if (itemStackgassy.getItem() instanceof BlockItem blockItemgassy
                    && this.realStackSizeMap.getOrDefault(i, itemStackgassy.getCount()) > 0 &&
                    InventoryUtility.isGoodBlock(blockItemgassy.getBlock())) {
                return i;
            }
        }
        return -1;
    }

    private boolean updateDatagassy() {
        blockCachegassy = getBlockDatagassy();

        if (blockCachegassy != null) {
            this.rotationgassy = blockCachegassy.rotationgassy;
            return true;
        }

        final PlayerSimulation simulationgassy = new PlayerSimulation(mc.player);
        final OtherClientPlayerEntity entitygassy = simulationgassy.getSimulatedEntity();
        for (int i = 0; i < 10; i++) {
            simulationgassy.simulateTick();
            final BlockDatagassy simulatedDatagassy = getBlockDatagassy(entitygassy.getBlockPos().down(), entitygassy);
            if (simulatedDatagassy != null) {
                rotationgassy = simulatedDatagassy.rotationgassy;
                break;
            }
        }

        return blockCachegassy != null;
    }

    private RaytracedRotation getRotationgassy(BlockWithDirectiongassy data, Vec3d start) {
        final Vec2f sortingAnglegassy;
        if (this.intelligentRotationgassy != null) {
            sortingAnglegassy = this.intelligentRotationgassy;
        } else {
            sortingAnglegassy = rotationgassy != null ? rotationgassy.rotationgassy() : RotationUtility.getRotationgassy();
        }
        return RotationUtility.getRotationFromRaycastedBlock(data.blockPosgassy, data.directiongassy, sortingAnglegassy, start);
    }

    private BlockDatagassy getBlockDatagassy() {
        return getBlockDatagassy(mc.player.getBlockPos().withY(sameYPosgassy).down(), mc.player);
    }

    private BlockDatagassy getBlockDatagassy(final BlockPos targetBlockPos, final PlayerEntity entitygassy) {
        if (mc.world.getBlockState(targetBlockPos).isReplaceable()) {
            final BlockPos.Mutable blockPosgassy = new BlockPos.Mutable();
            final List<BlockWithDirectiongassy> blockListgassy = new ArrayList<>();

            int rangegassy = 2;
            for (int y = 0; y > -rangegassy; y--) {
                for (int x = 0; x < rangegassy; x++) {
                    for (int z = 0; z < rangegassy; z++) {
                        for (int sign : new int[]{1, -1}) {
                            blockPosgassy.set(targetBlockPos.getX() + (x * sign), targetBlockPos.getY() + (y * sign), targetBlockPos.getZ() + (z * sign));
                            if (!mc.world.getBlockState(blockPosgassy).isReplaceable()) continue;

                            for (Direction directiongassy : Direction.values()) {
                                final BlockPos blockgassy = blockPosgassy.offset(directiongassy);

                                if (!mc.world.getBlockState(blockgassy).isReplaceable()) {
                                    blockListgassy.add(new BlockWithDirectiongassy(blockgassy, directiongassy.getOpposite()));
                                }
                            }
                        }
                    }
                }
            }

            if (blockListgassy.isEmpty()) {
                return null;
            }

            blockListgassy.sort(Comparator.comparingDouble(data -> data.blockPosgassy.offset(data.directiongassy).getSquaredDistance(targetBlockPos)));

            final Vec3d eyePosgassy = entitygassy.getEntityPos().add(0.0D, entitygassy.getStandingEyeHeight(), 0.0D);
            for (final BlockWithDirectiongassy blockgassy : blockListgassy) {
                final RaytracedRotation rotationgassy = this.getRotationgassy(blockgassy, eyePosgassy);
                if (rotationgassy != null) {
                    return new BlockDatagassy(blockgassy, rotationgassy);
                }
            }
        }
        return null;
    }

    public record BlockWithDirectiongassy(BlockPos blockPosgassy, Direction directiongassy) {
    }

    public record BlockDatagassy(BlockWithDirectiongassy blockWithDirection, RaytracedRotation rotationgassy) {
    }

    @Override
    public void renderIslandgassy(DrawContext context, float posX, float posY, float width, float height, float progress) {
        this.dynamicIslandgassy.render(context, posX, posY);
    }

    public ScaffoldSettings getSettingsgassy() {
        return settingsgassy;
    }

    @Override
    public float getIslandWidthgassy() {
        return this.dynamicIslandgassy.getWidth();
    }

    @Override
    public float getIslandHeightgassy() {
        return this.dynamicIslandgassy.getHeight();
    }

    @Override
    public int getIslandPrioritygassy() {
        return 1;
    }

}
