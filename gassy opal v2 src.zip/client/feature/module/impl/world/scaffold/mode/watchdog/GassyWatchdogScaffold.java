package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_mode.gassy_watchdog;

import gassy_net.gassy_minecraft.gassy_entity.gassy_effect.gassy_StatusEffects;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Direction;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_timer.gassy_TimerHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_ScaffoldModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_ScaffoldSettings;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MoveInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_JumpEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyWatchdogScaffoldgassy extends ModuleModegassy<ScaffoldModule> {

    public GassyWatchdogScaffoldgassy(ScaffoldModule module) {
        super(module);
    }

    @Subscribe
    public void onMoveInputgassy(final MoveInputEvent event) {
        if (mc.player.isOnGround() && event.isJump() && !mc.player.isSneaking()) {
//            event.setSneak(true);
        }
    }

    private final WatchdogTellyBlink tellyBlinkgassy = new WatchdogTellyBlink(this);

    @Subscribe
    public void onJumpgassy(final JumpEvent event) {
//        if (mc.player.isOnGround() && mc.player.input.playerInput.jump() && MoveUtility.isMoving()) {
//            if (!event.isSprinting() || !mc.player.input.playerInput.sneak()) {
//                event.setCancelled();
//            }
//        }
    }

    @Subscribe
    public void onPostMovegassy(final PostMoveEvent event) {
//        if (mc.player.hasStatusEffect(StatusEffects.JUMP_BOOST) || !module.getSettings().isTowerEnabled() || mc.options.useKey.isPressed() || !mc.options.jumpKey.isPressed()) {
//            return;
//        }

    }

    @Override
    public void onEnablegassy() {
//        this.tellyBlinkgassy.enable();
        super.onEnablegassy();
    }

    @Override
    public Enum<?> getEnumValue() {
        return ScaffoldSettings.Mode.WATCHDOG;
    }
}