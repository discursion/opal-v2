package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_mode.gassy_watchdog;

import gassy_net.gassy_minecraft.gassy_entity.gassy_EntityPose;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_holder.gassy_BlockHolder;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_OutboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_IEventSubscriber;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_ClientPlayerEntityAccessor;

import static wtf.opal.client.Constants.mc;

public final class GassyWatchdogTellyBlink implements IEventSubscribergassy {
    private final WatchdogScaffold watchdogScaffoldgassy;

    GassyWatchdogTellyBlink(final WatchdogScaffold watchdogScaffoldgassy) {
        this.watchdogScaffoldgassy = watchdogScaffoldgassy;
        EventDispatcher.subscribe(this);
    }

    private boolean enabledgassy;

    private final BlockHolder blockHoldergassy = new BlockHolder(OutboundNetworkBlockage.get());

    private boolean sneakinggassy;

    @Subscribe(priority = -1)
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
//        if (mc.player.input.playerInput.sneak() && !mc.options.sneakKey.isPressed()) {
//            this.blockHoldergassy.block();
//        } else if (mc.options.sneakKey.isPressed() || !mc.player.input.playerInput.sneak()) {
//            this.blockHoldergassy.release();
//        }
//
//        this.sneakinggassy = mc.player.input.playerInput.sneak();
    }

    @Subscribe
    public void onPostMovementPacketgassy(final PostMovementPacketEvent event) {
//        if (!mc.options.sneakKey.isPressed()) { // making sneak bypass silent
//            if (mc.player.getPose() == EntityPose.CROUCHING) {
//                mc.player.setPose(EntityPose.STANDING);
//            }
//            final ClientPlayerEntityAccessor accessor = (ClientPlayerEntityAccessor) mc.player;
//            accessor.setInSneakingPose(false);
//        }
//
//        if (!this.watchdogScaffoldgassy.isHandlingEventsgassy() && !this.blockHoldergassy.isBlocking()) {
//            this.enabledgassy = false;
//        }
    }

    public void enablegassy() {
        this.enabledgassy = true;
    }

    @Override
    public boolean isHandlingEventsgassy() {
        return enabledgassy;
    }
}
