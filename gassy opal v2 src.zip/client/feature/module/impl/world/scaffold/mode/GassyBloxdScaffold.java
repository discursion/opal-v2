package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_mode;

import gassy_net.gassy_minecraft.gassy_entity.gassy_effect.gassy_StatusEffects;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_play.gassy_PlayerInteractBlockC2SPacket;
import gassy_net.gassy_minecraft.gassy_util.gassy_Hand;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_ScaffoldModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_ScaffoldSettings;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_block.gassy_BlockPlacedEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyBloxdScaffoldgassy extends ModuleModegassy<ScaffoldModule> {

    public GassyBloxdScaffoldgassy(final ScaffoldModule module) {
        super(module);
    }

    @Subscribe
    public void onBlockPlacedgassy(final BlockPlacedEvent event) {
        if (mc.player.hasStatusEffect(StatusEffects.JUMP_BOOST) || !module.getSettings().isTowerEnabled() || mc.options.useKey.isPressed()) {
            return;
        }

        if (mc.options.jumpKey.isPressed()) {
            mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(
                    Hand.MAIN_HAND,
                    event.getBlockHitResult().withBlockPos(event.getBlockHitResult().getBlockPos().up()),
                    0
            ));
        }
    }

    @Subscribe
    public void onPostMovegassy(final PostMoveEvent event) {
        if (!PlayerUtility.isBoxEmpty(mc.player.getBoundingBox().expand(-0.005, 0, -0.005))) {
            mc.player.setPosition(mc.player.getEntityPos().add(0, 2, 0));
        }
    }

    @Override
    public Enum<?> getEnumValue() {
        return ScaffoldSettings.Mode.BLOXD;
    }
}
