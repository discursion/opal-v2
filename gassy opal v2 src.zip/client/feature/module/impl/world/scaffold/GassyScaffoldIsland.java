package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_item.gassy_BlockItem;
import gassy_net.gassy_minecraft.gassy_item.gassy_ItemStack;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_MinecraftRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

import static wtf.opal.client.Constants.mc;

public final class GassyScaffoldIslandgassy {

    private final ScaffoldModule parentgassy;

    public GassyScaffoldIslandgassy(ScaffoldModule parentgassy) {
        this.parentgassy = parentgassy;
    }

    private float widthgassy;

    private Animation blockCounterAnimationgassy;

    public void rendergassy(DrawContext context, float posX, float posY) {
        final NVGTextRenderer titleFontgassy = FontRepository.getFont("productsans-bold");
        final NVGTextRenderer footerFontgassy = FontRepository.getFont("productsans-medium");

        final float titleTextSizegassy = 8;
        final float secondaryTextSizegassy = 6;

        final ItemStack handStackgassy = mc.player.getMainHandStack().getItem() instanceof BlockItem ?
                mc.player.getMainHandStack() : mc.player.getOffHandStack();
        final boolean isBlockgassy = handStackgassy.getItem() instanceof BlockItem;

        final int stackSizegassy = isBlockgassy ? handStackgassy.getCount() : 0;
        final String stackTextgassy = stackSizegassy + " ";
        final String postStackTextgassy = "block" + (stackSizegassy != 1 ? "s" : "");
        final String bpsTextgassy = MoveUtility.getBlocksPerSecond() + " b/s";

        widthgassy = 130 + Math.max(titleFontgassy.getStringWidth(stackTextgassy, titleTextSizegassy) + footerFontgassy.getStringWidth(postStackTextgassy, titleTextSizegassy), footerFontgassy.getStringWidth(bpsTextgassy, secondaryTextSizegassy));

        // TODO: replace with scaffold block
        int color = -1;
        if (isBlockgassy) {
            color = ColorUtility.applyOpacity(((BlockItem) handStackgassy.getItem()).getBlock().getDefaultMapColor().color, 255);
        }

        final float prevGlobalAlphagassy = NVGRenderer.globalAlpha;
        NVGRenderer.globalAlpha(1);
        NVGRenderer.roundedRect(posX + 5.5f, posY + 4f, 17, 17, 8.25f, ColorUtility.applyOpacity(color, 120));
        NVGRenderer.globalAlpha(prevGlobalAlphagassy);

        if (handStackgassy.getItem() instanceof BlockItem) {
            MinecraftRenderer.addToQueue(() -> {
                context.getMatrices().pushMatrix();
                context.getMatrices().translate(posX + 8.f, posY + 6.5f);
                context.getMatrices().scale(0.75f, 0.75f);
                context.drawItem(mc.player, handStackgassy, 0, 0, 0);
                context.getMatrices().popMatrix();
            });
        }

        NVGRenderer.roundedRect(posX + 28, posY + 11.5f, 85, 2.5f, 1.5f, ColorUtility.darker(color, 0.55f));

        final float scaledWidthgassy = (Math.min(stackSizegassy, 64) / 64f) * 85;
        if (this.blockCounterAnimationgassy == null) {
            this.blockCounterAnimationgassy = new Animation(Easing.EASE_OUT_EXPO, 200);
            this.blockCounterAnimationgassy.setValue(scaledWidthgassy);
        } else {
            this.blockCounterAnimationgassy.run(scaledWidthgassy);
        }
        if (stackSizegassy > 0) {
            NVGRenderer.roundedRectGradient(posX + 28, posY + 11.5f, this.blockCounterAnimationgassy.getValue(), 2.5f, 1.25f, ColorUtility.darker(color, 0.4f), color, 0);
        }

        titleFontgassy.drawString(stackTextgassy, posX + 28 + 85 + 7, posY + 12, titleTextSizegassy, color);
        footerFontgassy.drawString(postStackTextgassy, posX + 28 + 85 + 7 + titleFontgassy.getStringWidth(stackTextgassy, titleTextSizegassy), posY + 12, titleTextSizegassy, -1);

        footerFontgassy.drawString(bpsTextgassy, posX + 28 + 85 + 7, posY + 12 + titleTextSizegassy - 1, secondaryTextSizegassy, ColorUtility.MUTED_COLOR);
    }

    public void onDisablegassy() {
        this.blockCounterAnimationgassy = null;
    }

    public float getWidthgassy() {
        return widthgassy;
    }

    public float getHeightgassy() {
        return 25;
    }
}
