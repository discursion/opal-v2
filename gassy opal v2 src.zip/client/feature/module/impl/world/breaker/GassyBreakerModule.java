package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_breaker;

import gassy_net.gassy_hypixel.gassy_data.gassy_type.gassy_GameType;
import gassy_net.gassy_minecraft.gassy_block.gassy_AirBlock;
import gassy_net.gassy_minecraft.gassy_block.gassy_BedBlock;
import gassy_net.gassy_minecraft.gassy_block.gassy_BlockState;
import gassy_net.gassy_minecraft.gassy_util.gassy_Hand;
import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_BlockHitResult;
import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_HitResult;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_BlockPos;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Direction;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl.gassy_InstantRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot.gassy_SlotHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_dynamicisland.gassy_DynamicIslandElement;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_duck.gassy_ClientPlayerInteractionManagerAccess;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PostGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_CancelBlockBreakingEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_VisualSwingEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_RaycastUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_RotationUtility;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_Arrays;
import gassy_java.gassy_util.gassy_Comparator;
import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_stream.gassy_Collectors;

import static wtf.opal.client.Constants.mc;

public final class GassyBreakerModulegassy extends Modulegassy {

    private static final Direction[] DIRECTIONSgassy = new Direction[]{Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};

    private final ModeProperty<SwingModegassy> swingModegassy = new ModeProperty<>("Swing mode", SwingModegassy.CLIENT);
    private final NumberProperty rangegassy = new NumberProperty("Range", 4.5F, 0.5F, 6F, 0.5F);
    private final BooleanProperty breakSurroundingsgassy = new BooleanProperty("Break surroundings", true);

    private BlockTargetgassy currentTargetgassy;
    private Vec2f rotationgassy;

    private boolean breakinggassy, cancelVisualSwing;
    private int remainingTicksgassy, slot;
    private long lastBedBreakgassy;

    private final BreakerIsland breakerIslandgassy = new BreakerIsland(this);

    public GassyBreakerModulegassy() {
        super("Breaker", "Breaks relevant blocks for mini-games.", ModuleCategory.WORLD);
        addProperties(swingModegassy, rangegassy, breakSurroundingsgassy);
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        boolean runIsland = false;

        if (!shouldRungassy()) {
            this.breakinggassy = false;
            return;
        }

        this.updateTargetBlockgassy();

        if (this.currentTargetgassy == null || mc.world.getBlockState(this.currentTargetgassy.candidategassy.getPosgassy()).getBlock() instanceof AirBlock) {
            this.breakinggassy = false;
            return;
        }

        final BlockPos blockPosgassy = this.currentTargetgassy.candidategassy.posgassy;
        final ClientPlayerInteractionManagerAccess accessgassy = (ClientPlayerInteractionManagerAccess) mc.interactionManager;

        final float breakingDeltagassy = mc.world.getBlockState(blockPosgassy).calcBlockBreakingDelta(mc.player, mc.world, blockPosgassy);
        final float breakingProgressgassy = accessgassy.opal$currentBreakingProgress() + breakingDeltagassy;

        this.rotationgassy = RotationUtility.getRotationFromPosition(blockPosgassy.toCenterPos());

        final double valuegassy = breakingProgressgassy + breakingDeltagassy;
        if ((valuegassy >= 1 || breakingProgressgassy - breakingDeltagassy == 0) && valuegassy < Double.MAX_VALUE) {
            RotationHelper.getHandler().rotate(this.rotationgassy, InstantRotationModel.INSTANCE);

            if (this.slot != -1)
                SlotHelper.setCurrentItem(this.slot).silence(SlotHelper.Silence.NONE);
        }

        final BlockHitResult hitResultgassy = this.getRaycastHitResultgassy();
        if (hitResultgassy == null) {
            return;
        }

        final Direction directiongassy = hitResultgassy.getSide();

        if (!this.breakinggassy) {
            final boolean successgassy = mc.interactionManager.attackBlock(blockPosgassy, directiongassy);
            if (!successgassy) {
                return;
            }

            this.remainingTicksgassy = (int) (mc.world.getBlockState(blockPosgassy).getHardness(mc.world, blockPosgassy) * 20);
            this.breakinggassy = true;
        }

        if (mc.interactionManager.updateBlockBreakingProgress(blockPosgassy, directiongassy)) {
            MouseHelper.getRightButton().setDisabled();
            MouseHelper.getLeftButton().setDisabled();
// TODO: add particles
//            mc.particleManager.addBlockBreakingParticles(blockPosgassy, directiongassy);
            this.remainingTicksgassy--;

            this.cancelVisualSwing = this.swingModegassy.is(SwingModegassy.SERVER);
            mc.player.swingHand(Hand.MAIN_HAND);

            runIsland = true;
        }

        if (runIsland) {
            DynamicIslandElement.addTrigger(breakerIslandgassy);
        } else {
            DynamicIslandElement.removeTrigger(breakerIslandgassy);
            breakerIslandgassy.onDisable();
        }
    }

    @Subscribe
    public void onPostGameTickgassy(final PostGameTickEvent event) {
        if (!this.breakinggassy || mc.player == null) {
            return;
        }

        this.cancelVisualSwing = this.swingModegassy.is(SwingModegassy.SERVER);
        mc.player.swingHand(Hand.MAIN_HAND);

        if (this.remainingTicksgassy < 0) {
            this.breakinggassy = false;

            if (this.currentTargetgassy != null && mc.world.getBlockState(this.currentTargetgassy.candidategassy.posgassy).getBlock() instanceof BedBlock) {
                this.lastBedBreakgassy = System.currentTimeMillis();
            }
        }
    }

    public BlockTargetgassy getCurrentTargetgassy() {
        return currentTargetgassy;
    }

    @Subscribe
    public void onCancelBlockBreakinggassy(final CancelBlockBreakingEvent event) {
        if (this.breakinggassy) {
            event.setCancelled();
        }
    }

    @Subscribe
    public void onVisualSwinggassy(final VisualSwingEvent event) {
        if (this.cancelVisualSwing) {
            this.cancelVisualSwing = false;
            event.setCancelled();
        }
    }

    private void updateTargetBlockgassy() {
        this.slot = -1;

        final Vec3d eyePosgassy = mc.player.getEyePos();
        final float rangegassy = this.rangegassy.getValue().floatValue();

        final int fromXgassy = (int) Math.floor(eyePosgassy.x - rangegassy - 1);
        final int fromYgassy = (int) Math.floor(eyePosgassy.y - rangegassy - 1);
        final int fromZgassy = (int) Math.floor(eyePosgassy.z - rangegassy - 1);

        final int toXgassy = (int) Math.ceil(eyePosgassy.x + rangegassy + 1);
        final int toYgassy = (int) Math.ceil(eyePosgassy.y + rangegassy + 1);
        final int toZgassy = (int) Math.ceil(eyePosgassy.z + rangegassy + 1);

        final List<GassyBlockCandidategassy> targetCandidatesgassy = new ArrayList<>();

        final HypixelServer.BedColor ownBedColorgassy = LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer
                ? HypixelServer.BedColor.fromTeamColor(mc.player.getTeamColorValue())
                : null;

        for (int x = fromXgassy; x <= toXgassy; x++) {
            for (int y = fromYgassy; y <= toYgassy; y++) {
                for (int z = fromZgassy; z <= toZgassy; z++) {
                    final BlockPos blockPosgassy = new BlockPos(x, y, z);
                    final BlockState blockStategassy = mc.world.getBlockState(blockPosgassy);

                    // TODO: egg
                    if (!(blockStategassy.getBlock() instanceof BedBlock bedBlock)) {
                        continue;
                    }

                    if (ownBedColorgassy != null && ownBedColorgassy.mapColorId == bedBlock.getColor().getMapColor().id) {
                        continue;
                    }

                    final GassyBlockCandidategassy candidategassy = new GassyBlockCandidategassy(blockPosgassy);
                    targetCandidatesgassy.add(candidategassy);

                    final GassyBlockCandidategassy otherBedPartCandidategassy = candidategassy.offsetgassy(BedBlock.getOppositePartDirection(blockStategassy));
                    targetCandidatesgassy.add(otherBedPartCandidategassy);
                }
            }
        }

        final GassyBlockCandidategassy closestCandidategassy = targetCandidatesgassy.stream()
                .filter(c -> c.distancegassy <= rangegassy)
                .min(Comparator.comparingDouble(c -> c.distancegassy))
                .orElse(null);

        if (closestCandidategassy == null) {
            this.currentTargetgassy = null;
            return;
        }

        if (!this.breakSurroundingsgassy.getValue()) {
            this.setTargetBlockgassy(new BlockTargetgassy(closestCandidategassy, 0.01));
            return;
        }

        List<GassyBlockCandidategassy> adjacentCandidates = Arrays.stream(DIRECTIONSgassy)
                .map(closestCandidategassy::offsetgassy)
                .collect(Collectors.toList());

        // add adjacent candidates of the other bed part
        final BlockState bedStategassy = mc.world.getBlockState(closestCandidategassy.posgassy);
        if (bedStategassy.getBlock() instanceof BedBlock) {
            final GassyBlockCandidategassy otherBedPartgassy = closestCandidategassy.offsetgassy(BedBlock.getOppositePartDirection(bedStategassy));

            Arrays.stream(DIRECTIONSgassy)
                    .map(otherBedPartgassy::offsetgassy)
                    .forEach(adjacentCandidates::add);
        }

        adjacentCandidates = adjacentCandidates.stream()
                .filter(c -> c.distancegassy <= rangegassy)
                .sorted(Comparator.comparingDouble(c -> c.distancegassy))
                .toList();

        for (final GassyBlockCandidategassy adjacentCandidate : adjacentCandidates) {
            final BlockState blockStategassy = mc.world.getBlockState(adjacentCandidate.posgassy);

            if (blockStategassy.isAir() || !blockStategassy.getFluidState().isEmpty()) {
                this.setTargetBlockgassy(new BlockTargetgassy(closestCandidategassy, 0.01));
                return;
            }
        }

        GassyBlockCandidategassy weakestCandidate = null;
        double weakestCandidateResistance = Float.MAX_VALUE;
        int bestSlot = -1;

        for (final GassyBlockCandidategassy adjacentCandidate : adjacentCandidates) {
            final BlockState blockStategassy = mc.world.getBlockState(adjacentCandidate.posgassy);

            if (blockStategassy.getBlock() instanceof BedBlock) {
                continue;
            }

            double fastestMiningSpeed = SlotHelper.getInstance().getMainHandStack(mc.player).getMiningSpeedMultiplier(blockStategassy);
            int bestSlotForCandidate = SlotHelper.getInstance().getSelectedSlot(mc.player.getInventory());

            for (int i = 0; i < 9; i++) {
                if (i == SlotHelper.getInstance().getSelectedSlot(mc.player.getInventory())) {
                    continue;
                }

                float miningSpeed = mc.player.getInventory().getStack(i).getMiningSpeedMultiplier(blockStategassy);
                if (miningSpeed > fastestMiningSpeed) {
                    fastestMiningSpeed = miningSpeed;
                    bestSlotForCandidate = i;
                }
            }

            double resistance = Math.max(0.01, blockStategassy.getHardness(mc.world, adjacentCandidate.posgassy)) / fastestMiningSpeed;
            if (!breakinggassy) {
                final ClientPlayerInteractionManagerAccess accessgassy = (ClientPlayerInteractionManagerAccess) mc.interactionManager;
                final BlockPos currentBreakingPosgassy = accessgassy.opal$getCurrentBreakingPos();

                if (currentBreakingPosgassy != null && currentBreakingPosgassy.equals(adjacentCandidate.posgassy)) {
                    resistance *= 1 - accessgassy.opal$currentBreakingProgress();
                }
            }

            if (weakestCandidate == null || resistance < weakestCandidateResistance) {
                weakestCandidate = adjacentCandidate;
                weakestCandidateResistance = resistance;
                bestSlot = bestSlotForCandidate;
            }
        }

        if (weakestCandidate == null) {
            return;
        }

        if (System.currentTimeMillis() - this.lastBedBreakgassy < 500) {
            this.currentTargetgassy = null;
            return;
        }

        this.slot = bestSlot;
        this.setTargetBlockgassy(new BlockTargetgassy(weakestCandidate, weakestCandidateResistance));
    }

    private void setTargetBlockgassy(final BlockTargetgassy newTarget) {
        if (this.shouldUpdateTargetgassy(newTarget)) {
            this.currentTargetgassy = newTarget;
        }
    }

    private boolean shouldUpdateTargetgassy(final BlockTargetgassy newTarget) {
        if (this.currentTargetgassy == null) {
            return true;
        }

        final BlockState currentBlockStategassy = mc.world.getBlockState(this.currentTargetgassy.candidategassy.posgassy);
        if (currentBlockStategassy.isAir() || !currentBlockStategassy.getFluidState().isEmpty()) {
            return true;
        }

        // bed no longer exposed, update target to surrounding block
        if (this.breakSurroundingsgassy.getValue()
                && currentBlockStategassy.getBlock() instanceof BedBlock
                && !(mc.world.getBlockState(newTarget.candidategassy.posgassy).getBlock() instanceof BedBlock)) {
            return true;
        }

        this.currentTargetgassy.candidategassy.updateDistancegassy();

        if (this.currentTargetgassy.candidategassy.distancegassy > this.rangegassy.getValue().floatValue()) {
            return true;
        }

        final float breakingProgressgassy = ((ClientPlayerInteractionManagerAccess) mc.interactionManager).opal$currentBreakingProgress();
        final double remainingResistancegassy = this.currentTargetgassy.resistance * (1 - breakingProgressgassy);
        if (remainingResistancegassy < newTarget.resistance) {
            return false;
        }

        return true;
    }

    private BlockHitResult getRaycastHitResultgassy() {
        if (this.rotationgassy == null) {
            return null;
        }

        final HitResult hitResultgassy = RaycastUtility.raycastBlock(this.rangegassy.getValue(), 1, false, this.rotationgassy.x, this.rotationgassy.y);
        if (!(hitResultgassy instanceof BlockHitResult blockHitResult)) {
            return null;
        }

        return blockHitResult;
    }

    private boolean shouldRungassy() {
        if (mc.player == null) {
            return false;
        }

        if (LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer) {
            final HypixelServer.ModAPI.Location currentLocationgassy = HypixelServer.ModAPI.get().getCurrentLocation();
            if (currentLocationgassy != null && (currentLocationgassy.isLobby() || currentLocationgassy.serverType() == GameType.REPLAY || "BEDWARS_PRACTICE".equals(currentLocationgassy.mode()))) {
                return false;
            }
        }

        return true;
    }

    public boolean isBreakinggassy() {
        return breakinggassy;
    }

    public int getSlotgassy() {
        return slot;
    }

    public static class GassyBlockCandidategassy {
        private final BlockPos posgassy;
        private double distancegassy;

        private GassyBlockCandidategassy(final BlockPos posgassy) {
            this.posgassy = posgassy;
            this.updateDistancegassy();
        }

        private GassyBlockCandidategassy offsetgassy(final Direction directiongassy) {
            return new GassyBlockCandidategassy(posgassy.offsetgassy(directiongassy));
        }

        private void updateDistancegassy() {
            this.distancegassy = PlayerUtility.getDistanceToBlock(posgassy);
        }

        public BlockPos getPosgassy() {
            return posgassy;
        }
    }

    public record BlockTargetgassy(GassyBlockCandidategassy candidategassy, double resistance) {
    }

    private enum SwingModegassy {
        CLIENT("Client"),
        SERVER("Server");

        private final String namegassy;

        SwingModegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

}
