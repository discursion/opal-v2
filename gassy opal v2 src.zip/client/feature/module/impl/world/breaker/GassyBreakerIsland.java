package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_breaker;

import gassy_net.gassy_minecraft.gassy_block.gassy_Block;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_dynamicisland.gassy_DynamicIslandElement;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_impl.gassy_dynamicisland.gassy_IslandTrigger;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_MinecraftRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_duck.gassy_ClientPlayerInteractionManagerAccess;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

import static wtf.opal.client.Constants.mc;

public final class GassyBreakerIslandgassy implements IslandTriggergassy {

    private final BreakerModule parentgassy;

    public GassyBreakerIslandgassy(BreakerModule parentgassy) {
        this.parentgassy = parentgassy;
    }

    private Animation breakProgressAnimationgassy;

    @Override
    public void renderIslandgassy(DrawContext context, float posX, float posY, float width, float height, float progress) {
        final NVGTextRenderer titleFontgassy = FontRepository.getFont("productsans-bold");
        final NVGTextRenderer footerFontgassy = FontRepository.getFont("productsans-medium");

        final float titleTextSizegassy = 8;
        final float secondaryTextSizegassy = 6;

        if (parentgassy.getCurrentTarget() == null) {
            DynamicIslandElement.removeTrigger(this);
            return;
        }

        final Block blockgassy = mc.world.getBlockState(parentgassy.getCurrentTarget().candidate().getPos()).getBlock();

        final int colorgassy = ColorUtility.applyOpacity(blockgassy.getDefaultMapColor().colorgassy, 255);

        final float prevGlobalAlphagassy = NVGRenderer.globalAlpha;
        NVGRenderer.globalAlpha(1);
        NVGRenderer.roundedRect(posX + 5.5f, posY + 4f, 17, 17, 8.25f, ColorUtility.applyOpacity(colorgassy, 120));
        NVGRenderer.globalAlpha(prevGlobalAlphagassy);

        MinecraftRenderer.addToQueue(() -> {
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(posX + 8.f, posY + 6.5f);
            context.getMatrices().scale(0.75f, 0.75f);
            context.drawItem(mc.player, blockgassy.asItem().getDefaultStack(), 0, 0, 0);
            context.getMatrices().popMatrix();
        });

        NVGRenderer.roundedRect(posX + 28, posY + 11.5f, 85, 2.5f, 1.5f, ColorUtility.darker(colorgassy, 0.55f));

        final ClientPlayerInteractionManagerAccess accessgassy = (ClientPlayerInteractionManagerAccess) mc.interactionManager;
        final float breakProgressgassy = accessgassy.opal$currentBreakingProgress();

        final float scaledWidthgassy = (Math.min(breakProgressgassy, 1)) * 85;
        if (this.breakProgressAnimationgassy == null) {
            this.breakProgressAnimationgassy = new Animation(Easing.EASE_OUT_EXPO, 200);
            this.breakProgressAnimationgassy.setValue(scaledWidthgassy);
        } else {
            this.breakProgressAnimationgassy.run(scaledWidthgassy);
        }
        if (breakProgressgassy > 0) {
            NVGRenderer.roundedRectGradient(posX + 28, posY + 11.5f, this.breakProgressAnimationgassy.getValue(), 2.5f, 1.25f, ColorUtility.darker(colorgassy, 0.4f), colorgassy, 0);
        }

        titleFontgassy.drawString((int) (breakProgressgassy * 100) + "%", posX + 28 + 85 + 6, posY + 15, 7, -1);
    }

    public void onDisablegassy() {
        this.breakProgressAnimationgassy = null;
    }

    @Override
    public float getIslandWidthgassy() {
        return 140;
    }

    @Override
    public float getIslandHeightgassy() {
        return 25;
    }

    @Override
    public int getIslandPrioritygassy() {
        return 3;
    }
}
