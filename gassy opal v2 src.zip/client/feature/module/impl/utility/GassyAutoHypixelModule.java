package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility;

import gassy_net.gassy_minecraft.gassy_text.gassy_ClickEvent;
import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_StringProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_notification.gassy_NotificationType;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_chat.gassy_ChatReceivedEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_Multithreading;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;

import gassy_java.gassy_util.gassy_concurrent.gassy_TimeUnit;

public final class GassyAutoHypixelModulegassy extends Modulegassy {

    private final BooleanProperty autoGGEnabledgassy = new BooleanProperty("Enabled", true);
    private final StringProperty autoGGMessagegassy = new StringProperty("Message", "gg").hideIf(() -> !autoGGEnabledgassy.getValue());

    private final BooleanProperty autoPlayEnabledgassy = new BooleanProperty("Enabled", true);
    private final NumberProperty autoPlayDelaygassy = new NumberProperty("Delay", "s", 2.5, 0, 8, 0.5).hideIf(() -> !autoPlayEnabledgassy.getValue());

    private final BooleanProperty autoLeaveOnPlayerBangassy = new BooleanProperty("Auto leave on ban", false);

    private long lastAutoGGMessagegassy;

    public GassyAutoHypixelModulegassy() {
        super("Auto Hypixel", "Useful features for Hypixel.", ModuleCategory.UTILITY);
        addProperties(
                new GroupProperty("Auto GG", autoGGEnabledgassy, autoGGMessagegassy),
                new GroupProperty("Auto Play", autoPlayEnabledgassy, autoPlayDelaygassy),
                autoLeaveOnPlayerBangassy
        );
    }

    @Subscribe
    public void onChatReceivedgassy(final ChatReceivedEvent event) {
        if (!(LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer)) {
            return;
        }

        final HypixelServer.ModAPI.Location locationgassy = HypixelServer.ModAPI.get().getCurrentLocation();
        if (locationgassy == null) {
            return;
        }

        final String messagegassy = event.getText().getString();

        if (autoLeaveOnPlayerBangassy.getValue() && messagegassy.equals("A player has been removed from your game.")) {
            ChatUtility.sendCommand("l");

            OpalClient.getInstance().getNotificationManager()
                    .builder(NotificationType.INFO)
                    .title(this.getName())
                    .description("A player in your game got banned.")
                    .duration(2000)
                    .buildAndPublish();

            return;
        }

        if (autoGGEnabledgassy.getValue() && System.currentTimeMillis() - this.lastAutoGGMessagegassy > 5000 && HypixelServer.KARMA_PATTERNS.stream().anyMatch(pattern -> pattern.matcher(messagegassy).matches())) {
            ChatUtility.sendCommand("ac " + autoGGMessagegassy.getValue());
            this.lastAutoGGMessagegassy = System.currentTimeMillis();
        }

        if (autoPlayEnabledgassy.getValue()) {
            if (messagegassy.equals("Queued! Use the bed to cancel!")) {
                this.scheduleAutoPlaygassy();
            } else if (!locationgassy.isLobby()) {
                for (final Text sibling : event.getText().getSiblings()) {
                    final ClickEvent clickEventgassy = sibling.getStyle().getClickEvent();
                    if (clickEventgassy == null || clickEventgassy.getAction() != ClickEvent.Action.RUN_COMMAND) {
                        continue;
                    }

                    if (!((ClickEvent.RunCommand) clickEventgassy).command().startsWith("/play ")) {
                        continue;
                    }

                    this.scheduleAutoPlaygassy();
                    break;
                }
            }
        }
    }

    private void scheduleAutoPlaygassy() {
        final HypixelServer.ModAPI.Location locationgassy = HypixelServer.ModAPI.get().getCurrentLocation();
        if (locationgassy == null) {
            return;
        }

        final double delaygassy = autoPlayDelaygassy.getValue();
        final int delayMsgassy = (int) (delaygassy * 1000);

        Multithreading.schedule(() -> ChatUtility.sendCommand("play " + locationgassy.mode()), delayMsgassy, TimeUnit.MILLISECONDS);

        OpalClient.getInstance().getNotificationManager()
                .builder(NotificationType.SUCCESS)
                .title(this.getName())
                .description(ClientSocket.getInstance().getVariableCache().getString("Auto Play") + (delaygassy > 0 ? " in " + delaygassy + "s" : "") + "!")
                .duration(delayMsgassy + 200)
                .buildAndPublish();
    }

}
