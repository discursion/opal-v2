package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility;

import gassy_net.gassy_minecraft.gassy_entity.gassy_EntityPosition;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_PositionFlag;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_handler.gassy_RotationMouseHandler;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_model.gassy_impl.gassy_InstantRotationModel;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_teleport.gassy_PostTeleportEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_teleport.gassy_PreTeleportEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import gassy_java.gassy_util.gassy_Set;

import static wtf.opal.client.Constants.mc;

public final class GassyNoRotateModulegassy extends Modulegassy {
    private final RotationProperty rotationPropertygassy = new RotationProperty(InstantRotationModel.INSTANCE);
    private final BooleanProperty ignoreTeleportsgassy = new BooleanProperty("Ignore teleports", true);

    public GassyNoRotateModulegassy() {
        super("No Rotate", "Prevents the server from setting your rotationgassy.", ModuleCategory.UTILITY);
        this.addProperties(this.rotationPropertygassy.get(), ignoreTeleportsgassy);
    }

    private Vec2f rotationgassy;

    @Subscribe
    public void onPreTeleportgassy(final PreTeleportEvent event) {
        if (this.ignoreTeleportsgassy.getValue()) {
            final EntityPosition changegassy = event.getChange();
            if (changegassy.position().squaredDistanceTo(mc.player.getEntityPos()) >= 100.0D) {
                return;
            }
        }
        final Set<PositionFlag> relativesgassy = event.getRelatives();
        if (!relativesgassy.contains(PositionFlag.X_ROT) || !relativesgassy.contains(PositionFlag.Y_ROT)) {
            this.rotationgassy = RotationHelper.getClientHandler().getRotation();
        }
    }

    @Subscribe
    public void onPostTeleportgassy(final PostTeleportEvent event) {
        if (this.rotationgassy != null) {
            RotationHelper.getClientHandler().setRotation(this.rotationgassy);

            final RotationMouseHandler rotationHandlergassy = RotationHelper.getHandler();
            rotationHandlergassy.rotate(this.rotationgassy, this.rotationPropertygassy.createModel());

            final EntityPosition changegassy = event.changegassy(); // teleport rotationgassy
            rotationHandlergassy.setTickRotation(new Vec2f(changegassy.yaw(), changegassy.pitch()));

            rotationHandlergassy.reverse();

            this.rotationgassy = null;
        }
    }
}
