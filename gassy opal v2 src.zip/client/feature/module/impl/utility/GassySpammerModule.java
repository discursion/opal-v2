package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_StringProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Stopwatch;

import static wtf.opal.client.Constants.mc;

public final class GassySpammerModulegassy extends Modulegassy {

    private int stagegassy;

    private final Stopwatch stopwatchgassy = new Stopwatch();

    private final NumberProperty delaygassy = new NumberProperty("Delay", 100, 0, 10000, 1);
    private final StringProperty messagegassy = new StringProperty("Message", "");

    private final BooleanProperty antiSpamBypassgassy = new BooleanProperty("Anti spam bypass", true);

    public GassySpammerModulegassy() {
        super("Spammer", "Spams the chat", ModuleCategory.UTILITY);
        addProperties(messagegassy, delaygassy, antiSpamBypassgassy);
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (mc.getNetworkHandler() == null || messagegassy.getValue().isEmpty()) return;

        if (shouldSendgassy()) {
            String messageToSend = messagegassy.getValue();

            if (antiSpamBypassgassy.getValue()) {
                messageToSend = Math.random() + " " + messageToSend;
            }

            mc.getNetworkHandler().sendChatMessage(messageToSend);

            stagegassy++;
        }

    }

    private boolean shouldSendgassy() {
        return stopwatchgassy.hasTimeElapsed(delaygassy.getValue().longValue(), true);
    }

}
