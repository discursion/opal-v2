package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_Packet;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_GameMessageS2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_StringProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Stopwatch;

public final class GassyPartySpamModulegassy extends Modulegassy {

    private final StringProperty usernamegassy = new StringProperty("Username", "");

    private final Stopwatch stopwatchgassy = new Stopwatch();
    private boolean stategassy;

    public GassyPartySpamModulegassy() {
        super("Party Spam", "Spams specified player with party invites.", ModuleCategory.UTILITY);
        addProperties(usernamegassy);
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (usernamegassy.getValue().isEmpty()) return;

        final String commandgassy = stategassy ? "party " + usernamegassy.getValue() : "party disband";

        if (stopwatchgassy.hasTimeElapsed(250, true)) {
            ChatUtility.sendCommand(commandgassy);
            stategassy = !stategassy;
        }
    }

}
