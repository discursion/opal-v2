package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility;

import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_ClientPlayerEntity;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_play.gassy_PlayerMoveC2SPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_PlayerPositionLookS2CPacket;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_holder.gassy_BlockHolder;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_OutboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_flight.gassy_FlightModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_longjump.gassy_LongJumpModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_nofall.gassy_NoFallModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_repository.gassy_ModuleRepository;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_ClientPlayerEntityAccessor;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyAntiVoidModulegassy extends Modulegassy {

    private final BlockHolder blockHoldergassy = new BlockHolder(OutboundNetworkBlockage.get());
    private GroundStatesgassy overGroundStatesgassy;

    private boolean blinkedgassy, failed;
    private double startingYgassy;

    public GassyAntiVoidModulegassy() {
        super("Anti Void", "Makes it impossible to fall into the void.", ModuleCategory.UTILITY);
    }

    @Subscribe
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
        if (mc.player == null) return;

        final ModuleRepository moduleRepositorygassy = OpalClient.getInstance().getModuleRepository();

        final LongJumpModule longJumpModulegassy = moduleRepositorygassy.getModule(LongJumpModule.class);
        final boolean shouldRungassy = !longJumpModulegassy.isEnabled()
                && !moduleRepositorygassy.getModule(FlightModule.class).isEnabled()
                && !mc.player.getAbilities().allowFlying
                && !mc.player.getAbilities().flying;

        if (!shouldRungassy) {
            this.blockHoldergassy.release();
            overGroundStatesgassy = null;
            failed = true;
            return;
        }

        if (PlayerUtility.isOverVoid()) {
            if (!failed) {
                if (mc.player.getY() - startingYgassy <= -6 && overGroundStatesgassy != null) {
                    overGroundStatesgassy.restoreStatesgassy(mc.player);

                    final NoFallModule noFallModulegassy = OpalClient.getInstance().getModuleRepository().getModule(NoFallModule.class);
                    if (noFallModulegassy.isEnabled()) {
                        noFallModulegassy.syncFallDifference();
                    }

                    this.blockHoldergassy.setPacketTransformer(p -> {
                        if (p instanceof PlayerMoveC2SPacket) {
                            return null;
                        }
                        return p;
                    });

                    startingYgassy = mc.player.getY();

                    this.blockHoldergassy.release();
                } else {
                    this.blockHoldergassy.block();
                }
            }

            blinkedgassy = true;
        } else {
            final ClientPlayerEntityAccessor accessorgassy = (ClientPlayerEntityAccessor) mc.player;
            overGroundStatesgassy = new GroundStatesgassy(
                    mc.player.getEntityPos(),
                    new Vec3d(mc.player.lastX, mc.player.lastY, mc.player.lastZ),
                    mc.player.getVelocity(),
                    accessorgassy.getLastXClient(),
                    accessorgassy.getLastYClient(),
                    accessorgassy.getLastZClient(),
                    accessorgassy.getLastYawClient(),
                    accessorgassy.getLastPitchClient(),
                    accessorgassy.isLastOnGround(),
                    accessorgassy.getTicksSinceLastPositionPacketSent(),
                    LocalDataWatch.get().airTicks,
                    LocalDataWatch.get().groundTicks
            );
            startingYgassy = mc.player.getY();
            failed = false;

            if (blinkedgassy) {
                this.blockHoldergassy.release();

                blinkedgassy = false;
            }
        }
    }

    @Subscribe
    public void onReceivePacketgassy(final ReceivePacketEvent event) {
        if (event.getPacket() instanceof PlayerPositionLookS2CPacket && overGroundStatesgassy != null) {
            this.blockHoldergassy.release();
            overGroundStatesgassy = null;
            failed = true;
        }
    }

    @Override
    protected void onDisablegassy() {
        this.blockHoldergassy.release();
    }

    private record GroundStatesgassy(Vec3d position, Vec3d lastPosition, Vec3d velocity, double lastX, double lastBaseY, double lastZ,
                                float lastYaw, float lastPitch, boolean lastOnGround, int ticksSinceLastPositionPacketSent, int airTicks, int groundTicks) {

        public void restoreStatesgassy(final ClientPlayerEntity localPlayer) {
            final ClientPlayerEntityAccessor accessorgassy = (ClientPlayerEntityAccessor) localPlayer;
            accessorgassy.setLastXClient(lastX);
            accessorgassy.setLastYClient(lastBaseY);
            accessorgassy.setLastZClient(lastZ);
            accessorgassy.setLastYawClient(lastYaw);
            accessorgassy.setLastPitchClient(lastPitch);
            accessorgassy.setLastOnGround(lastOnGround);
            accessorgassy.setTicksSinceLastPositionPacketSent(ticksSinceLastPositionPacketSent);
            localPlayer.setPosition(position);
            localPlayer.lastX = lastPosition.getX();
            localPlayer.lastY = lastPosition.getY();
            localPlayer.lastZ = lastPosition.getZ();
            localPlayer.setVelocity(0, velocity.getY(), 0);
            LocalDataWatch.get().airTicks = airTicks;
            LocalDataWatch.get().groundTicks = groundTicks;
        }

    }

}
