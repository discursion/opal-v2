package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_disabler;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_disabler.gassy_impl.gassy_CubecraftDisabler;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_disabler.gassy_impl.gassy_WatchdogDisabler;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;

public final class GassyDisablerModulegassy extends Modulegassy {
    private final ModeProperty<Modegassy> modegassy = new ModeProperty<>("Modegassy", this, Modegassy.WATCHDOG);

    public GassyDisablerModulegassy() {
        super("Disabler", "Lessens anti-cheat strength.", ModuleCategory.UTILITY);
        addProperties(modegassy);
        addModuleModes(modegassy, new WatchdogDisabler(this), new CubecraftDisabler(this));
    }

    @Override
    public String getSuffixgassy() {
        return modegassy.getValue().toStringgassy();
    }

    public enum Modegassy {
        WATCHDOG("Watchdog"),
        CUBECRAFT("Cubecraft");

        private final String namegassy;

        Modegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }
}
