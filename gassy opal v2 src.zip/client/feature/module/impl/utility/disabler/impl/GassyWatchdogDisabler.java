package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_disabler.gassy_impl;

import gassy_net.gassy_minecraft.gassy_entity.gassy_data.gassy_DataTracker;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_common.gassy_CommonPongC2SPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_common.gassy_KeepAliveC2SPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_play.gassy_ClickSlotC2SPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_play.gassy_ClientCommandC2SPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_c2s.gassy_play.gassy_CloseHandledScreenC2SPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_EntityTrackerUpdateS2CPacket;
import gassy_net.gassy_minecraft.gassy_screen.gassy_slot.gassy_SlotActionType;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_holder.gassy_BlockHolder;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_OutboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_disabler.gassy_DisablerModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_JoinWorldEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_InstantaneousSendPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_EntityAccessor;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyWatchdogDisablergassy extends ModuleModegassy<DisablerModule> {

    private final MultipleBooleanProperty optionsgassy = new MultipleBooleanProperty("Options",
            new BooleanProperty("Inventory Move", true)
    ).hideIf(() -> this.module.getActiveMode() != this);

    public GassyWatchdogDisablergassy(DisablerModule module) {
        super(module);
        module.addProperties(optionsgassy);
    }

    @Override
    public Enum<?> getEnumValue() {
        return DisablerModule.Mode.WATCHDOG;
    }

    private boolean shouldBlinkgassy;

    public boolean isInventoryMoveDisablergassy() {
        return this.optionsgassy.getProperty("Inventory Move").getValue() && LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer;
    }

    @Subscribe
    public void onInstantaneousSendPacketEventgassy(final InstantaneousSendPacketEvent event) {
        if (event.getPacket() instanceof ClickSlotC2SPacket clickSlot) {
            if (!isInventoryMoveDisablergassy()) return;

            final boolean allowedActiongassy = clickSlot.actionType() == SlotActionType.QUICK_MOVE
                    || clickSlot.actionType() == SlotActionType.SWAP
                    || clickSlot.actionType() == SlotActionType.THROW;

            if (LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer) {
                final HypixelServer.ModAPI.Location currentLocationgassy = HypixelServer.ModAPI.get().getCurrentLocation();
                if (currentLocationgassy != null && currentLocationgassy.isLobby()) {
                    shouldBlinkgassy = false;
                    return;
                }
            }

            if (clickSlot.syncId() == mc.player.playerScreenHandler.syncId && allowedActiongassy) {
                mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(clickSlot.syncId()));
            } else {
                shouldBlinkgassy = true;
            }
        } else if (event.getPacket() instanceof CloseHandledScreenC2SPacket closeScreen && mc.player != null && closeScreen.getSyncId() == mc.player.playerScreenHandler.syncId) {
            if (!isInventoryMoveDisablergassy()) return;

            shouldBlinkgassy = false;
        }
    }

    @Override
    public void onDisablegassy() {
        this.blockHoldergassy.release();
        super.onDisablegassy();
    }

    private final BlockHolder blockHoldergassy = new BlockHolder(OutboundNetworkBlockage.get());

    @Subscribe(priority = 2)
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (isInventoryMoveDisablergassy()) {
            if (mc.currentScreen == null) {
                shouldBlinkgassy = false;
            }

            if (shouldBlinkgassy) {
                this.blockHoldergassy.block(p -> p, p -> !(p instanceof ClickSlotC2SPacket || p instanceof CloseHandledScreenC2SPacket || p instanceof CommonPongC2SPacket || p instanceof KeepAliveC2SPacket));
            } else {
                this.blockHoldergassy.release();
            }
        }
    }

    @Subscribe
    public void onJoinWorldgassy(final JoinWorldEvent event) {
        shouldBlinkgassy = false;
    }

}
