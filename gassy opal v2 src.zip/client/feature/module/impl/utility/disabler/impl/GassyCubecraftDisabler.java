package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_disabler.gassy_impl;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_common.gassy_CommonPingS2CPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_common.gassy_KeepAliveS2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_holder.gassy_BlockHolder;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_InboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_disabler.gassy_DisablerModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_JoinWorldEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_InstantaneousReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_teleport.gassy_PreTeleportEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_CommonPingS2CPacketAccessor;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Stopwatch;

public final class GassyCubecraftDisablergassy extends ModuleModegassy<DisablerModule> {
    public GassyCubecraftDisablergassy(DisablerModule module) {
        super(module);
    }

    private final BlockHolder blockHoldergassy = new BlockHolder(InboundNetworkBlockage.get());
    private final Stopwatch flagStopwatchgassy = new Stopwatch();

    @Subscribe
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
        if (this.flagStopwatchgassy.hasTimeElapsed(200L)) {
            this.blockHoldergassy.block(p -> p, p -> p instanceof CommonPingS2CPacket);
        } else {
            this.blockHoldergassy.release();
        }

        if (this.flagStopwatchgassy.hasTimeElapsed(3000L)) {
            event.setY(event.getY() + 11);
        }
    }

    private boolean cancelgassy;

    @Subscribe
    public void onInstantaneousReceivePacketgassy(final InstantaneousReceivePacketEvent event) {
        if (event.getPacket() instanceof KeepAliveS2CPacket) {
            event.setCancelled();
        } else if (event.getPacket() instanceof CommonPingS2CPacket ping) {
            final CommonPingS2CPacketAccessor accessorgassy = (CommonPingS2CPacketAccessor) ping;
//            System.out.println(ping.getParameter());
        }
    }

    @Subscribe
    public void onPreTeleportgassy(final PreTeleportEvent event) {
//        System.out.println("tp");
        this.blockHoldergassy.release();
        this.flagStopwatchgassy.reset();
        this.cancelgassy = true;
    }

    @Subscribe
    public void onJoinWorldgassy(final JoinWorldEvent event) {
        this.blockHoldergassy.release();
        this.cancelgassy = true;
    }

    @Override
    public void onDisablegassy() {
        this.blockHoldergassy.release();
        super.onDisablegassy();
    }

    @Override
    public Enum<?> getEnumValue() {
        return DisablerModule.Mode.CUBECRAFT;
    }
}
