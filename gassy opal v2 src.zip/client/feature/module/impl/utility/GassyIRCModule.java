package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;

public final class GassyIRCModulegassy extends Modulegassy {

    public GassyIRCModulegassy() {
        super("IRC", "Lets you chat with other Opal users.", ModuleCategory.UTILITY);
        setEnabled(true);
    }

}
