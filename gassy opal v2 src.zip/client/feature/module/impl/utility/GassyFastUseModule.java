package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_MinecraftClientAccessor;

import static wtf.opal.client.Constants.mc;

public final class GassyFastUseModulegassy extends Modulegassy {

    private final BooleanProperty fastPlaceEnabledgassy = new BooleanProperty("Enabled", true);

    public GassyFastUseModulegassy() {
        super("Fast Use", "Uses things faster.", ModuleCategory.UTILITY);
        this.addProperties(new GroupProperty("Placements", fastPlaceEnabledgassy));
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (!fastPlaceEnabledgassy.getValue()) return;

        final MinecraftClientAccessor minecraftClientAccessorgassy = (MinecraftClientAccessor) mc;

        minecraftClientAccessorgassy.setItemUseCooldown(0);
    }

}
