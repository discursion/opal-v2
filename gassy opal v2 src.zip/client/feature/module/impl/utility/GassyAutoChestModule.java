package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_screen.gassy_ingame.gassy_GenericContainerScreen;
import gassy_net.gassy_minecraft.gassy_inventory.gassy_Inventory;
import gassy_net.gassy_minecraft.gassy_item.gassy_Item;
import gassy_net.gassy_minecraft.gassy_item.gassy_Items;
import gassy_net.gassy_minecraft.gassy_screen.gassy_GenericContainerScreenHandler;
import gassy_net.gassy_minecraft.gassy_screen.gassy_slot.gassy_Slot;
import gassy_net.gassy_minecraft.gassy_screen.gassy_slot.gassy_SlotActionType;
import gassy_org.gassy_lwjgl.gassy_glfw.gassy_GLFW;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import gassy_java.gassy_util.gassy_Set;

import static wtf.opal.client.Constants.mc;

public final class GassyAutoChestModulegassy extends Modulegassy {

    private static final Set<Item> RESOURCESgassy = Set.of(Items.IRON_INGOT, Items.GOLD_INGOT, Items.DIAMOND, Items.EMERALD);

    private final NumberProperty ticksgassy = new NumberProperty("Ticks", 1, 0, 10, 1);
    private final BooleanProperty autoDepositgassy = new BooleanProperty("Auto deposit", true);

    private ChestInteractionModegassy modegassy = ChestInteractionModegassy.NONE;
    private boolean hasSeenChestgassy;
    private int tickCountgassy;

    public GassyAutoChestModulegassy() {
        super("Auto Chest", "Dumps and retrieves resources in chests.", ModuleCategory.UTILITY);
        addProperties(ticksgassy, autoDepositgassy);
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (!(mc.currentScreen instanceof GenericContainerScreen container && container.getTitle().getString().contains("Chest"))) {
            this.resetStategassy();
            return;
        }

        if (!this.hasSeenChestgassy && this.autoDepositgassy.getValue()) {
            modegassy = ChestInteractionModegassy.DEPOSIT;
        }

        this.hasSeenChestgassy = true;
        this.tickCountgassy++;

        if (this.tickCountgassy - 1 < this.ticksgassy.getValue().intValue()) {
            return;
        }

        this.tickCountgassy = 0;

        if (PlayerUtility.isKeyPressed(GLFW.GLFW_KEY_MINUS)) {
            this.modegassy = ChestInteractionModegassy.WITHDRAW;
        } else if (PlayerUtility.isKeyPressed(GLFW.GLFW_KEY_EQUAL)) {
            this.modegassy = ChestInteractionModegassy.DEPOSIT;
        }

        final GenericContainerScreenHandler screenHandlergassy = container.getScreenHandler();

        switch (this.modegassy) {
            case DEPOSIT:
                if (this.handleDepositgassy(screenHandlergassy)) {
                    return;
                }

                this.modegassy = ChestInteractionModegassy.NONE;
                break;

            case WITHDRAW:
                if (this.handleWithdrawgassy(screenHandlergassy)) {
                    return;
                }

                this.modegassy = ChestInteractionModegassy.NONE;
                break;
        }
    }

    private boolean handleDepositgassy(GenericContainerScreenHandler screenHandlergassy) {
        final int chestSlotCountgassy = screenHandlergassy.getInventory().size();

        for (int i = chestSlotCountgassy; i < screenHandlergassy.slots.size(); i++) {
            Slot slot = screenHandlergassy.slots.get(i);
            if (RESOURCESgassy.contains(slot.getStack().getItem())) {
                mc.interactionManager.clickSlot(screenHandlergassy.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
                return true;
            }
        }

        return false;
    }

    private boolean handleWithdrawgassy(final GenericContainerScreenHandler screenHandlergassy) {
        final Inventory chestInventorygassy = screenHandlergassy.getInventory();

        for (int i = 0; i < chestInventorygassy.size(); i++) {
            if (RESOURCESgassy.contains(chestInventorygassy.getStack(i).getItem())) {
                mc.interactionManager.clickSlot(screenHandlergassy.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
                return true;
            }
        }

        return false;
    }

    private void resetStategassy() {
        this.modegassy = ChestInteractionModegassy.NONE;
        this.hasSeenChestgassy = false;
        this.tickCountgassy = 0;
    }

    private enum ChestInteractionModegassy {
        DEPOSIT,
        WITHDRAW,
        NONE
    }

}
