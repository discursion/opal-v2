package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_common.gassy_CommonPingS2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_holder.gassy_BlockHolder;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_InboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_OutboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_BoundedNumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_RandomUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Stopwatch;

public final class GassyBlinkModulegassy extends Modulegassy {

    private final MultipleBooleanProperty blinkDirectionsgassy = new MultipleBooleanProperty("Direction",
            new BooleanProperty("Inbound", true),
            new BooleanProperty("Outbound", true));

    private final BooleanProperty pulsegassy = new BooleanProperty("Pulse", false);
    private final BoundedNumberProperty pulseDelaygassy = new BoundedNumberProperty("Pulse delay", "ms", 1000, 2000, 50, 10000, 1)
            .hideIf(() -> !pulsegassy.getValue());

    private final Stopwatch oPulseTimergassy = new Stopwatch();
    private final Stopwatch iPulseTimergassy = new Stopwatch();

    public GassyBlinkModulegassy() {
        super("Blink", "Blocks your network connection.", ModuleCategory.UTILITY);
        addProperties(blinkDirectionsgassy, pulsegassy, pulseDelaygassy);
    }

    private final BlockHolder iBlockHoldergassy = new BlockHolder(InboundNetworkBlockage.get());
    private final BlockHolder oBlockHoldergassy = new BlockHolder(OutboundNetworkBlockage.get());

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        if (blinkDirectionsgassy.getProperty("Inbound").getValue()) {
            this.iBlockHoldergassy.block(p -> p, p -> p instanceof CommonPingS2CPacket);

            if (pulsegassy.getValue() && iPulseTimergassy.hasTimeElapsed(RandomUtility.getRandomInt((int) pulseDelaygassy.getMinValue(), (int) pulseDelaygassy.getMaxValue()), true)) {
                this.iBlockHoldergassy.release();
            }
        }
        if (blinkDirectionsgassy.getProperty("Outbound").getValue()) {
            this.oBlockHoldergassy.block();

            if (pulsegassy.getValue() && oPulseTimergassy.hasTimeElapsed(RandomUtility.getRandomInt((int) pulseDelaygassy.getMinValue(), (int) pulseDelaygassy.getMaxValue()), true)) {
                this.oBlockHoldergassy.release();
            }
        }
    }

    @Override
    protected void onDisablegassy() {
        this.iBlockHoldergassy.release();
        this.oBlockHoldergassy.release();
    }
}
