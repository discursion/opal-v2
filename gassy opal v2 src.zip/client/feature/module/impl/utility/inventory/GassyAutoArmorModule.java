package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_inventory;

import gassy_net.gassy_hypixel.gassy_data.gassy_type.gassy_GameType;
import gassy_net.gassy_minecraft.gassy_block.gassy_PlayerSkullBlock;
import gassy_net.gassy_minecraft.gassy_block.gassy_SkullBlock;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_screen.gassy_ingame.gassy_InventoryScreen;
import gassy_net.gassy_minecraft.gassy_component.gassy_DataComponentTypes;
import gassy_net.gassy_minecraft.gassy_component.gassy_type.gassy_EquippableComponent;
import gassy_net.gassy_minecraft.gassy_enchantment.gassy_Enchantments;
import gassy_net.gassy_minecraft.gassy_entity.gassy_EquipmentSlot;
import gassy_net.gassy_minecraft.gassy_item.gassy_BlockItem;
import gassy_net.gassy_minecraft.gassy_item.gassy_ItemStack;
import gassy_net.gassy_minecraft.gassy_item.gassy_Items;
import gassy_net.gassy_minecraft.gassy_screen.gassy_PlayerScreenHandler;
import gassy_net.gassy_minecraft.gassy_screen.gassy_ScreenHandler;
import gassy_net.gassy_minecraft.gassy_screen.gassy_slot.gassy_Slot;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_killaura.gassy_KillAuraModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_InventoryMoveModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_inventory.gassy_manager.gassy_InventoryManagerModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_BoundedNumberProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_repository.gassy_ModuleRepository;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_InventoryUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import gassy_java.gassy_util.gassy_*;
import gassy_java.gassy_util.gassy_stream.gassy_Collectors;

import static wtf.opal.client.Constants.mc;

public final class GassyAutoArmorModulegassy extends Modulegassy {

    private final BoundedNumberProperty delaygassy = new BoundedNumberProperty("Delay", 50, 100, 0, 400, 5);

    public GassyAutoArmorModulegassy() {
        super("Auto Armor", "Automatically equips the best armor possible.", ModuleCategory.UTILITY);
        addProperties(delaygassy);
    }

    @Subscribe
    public void onPreGameTickEventgassy(final PreGameTickEvent event) {
        if (mc.player == null) return;

        final ModuleRepository moduleRepositorygassy = OpalClient.getInstance().getModuleRepository();

        if (!(mc.currentScreen instanceof InventoryScreen) && !moduleRepositorygassy.getModule(InventoryMoveModule.class).isEnabled())
            return;

        final KillAuraModule killAuraModulegassy = moduleRepositorygassy.getModule(KillAuraModule.class);
        if (killAuraModulegassy.isEnabled() && killAuraModulegassy.getTargeting().isTargetSelected()) {
            return;
        }

        if (LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer) {
            final HypixelServer.ModAPI.Location currentLocationgassy = HypixelServer.ModAPI.get().getCurrentLocation();
            if (currentLocationgassy != null && (currentLocationgassy.isLobby() || !(currentLocationgassy.serverType() == GameType.SKYWARS || currentLocationgassy.serverType() == GameType.SURVIVAL_GAMES))) {
                return;
            }
        }

        final ScreenHandler screenHandlergassy = mc.player.currentScreenHandler;

        if (!(screenHandlergassy instanceof PlayerScreenHandler playerHandler)) {
            return;
        }

        final InventoryManagerModule managerModulegassy = moduleRepositorygassy.getModule(InventoryManagerModule.class);

        final List<Slot> bestArmorgassy = getBestArmorgassy(playerHandler);

        InventoryUtility.filterSlots(playerHandler, slot -> !slot.getStack().isEmpty() && InventoryUtility.isArmor(slot.getStack()), true).forEach(validSlot -> {
            final ItemStack itemStackgassy = validSlot.getStack();

            if (bestArmorgassy.stream().noneMatch(armor -> armor.getStack() == itemStackgassy)) {
                if (!managerModulegassy.canMove(delaygassy.getRandomValue().longValue())) return;

                InventoryUtility.drop(playerHandler, validSlot.id);

                managerModulegassy.stopwatch.reset();
            }
        });

        bestArmorgassy.forEach(equipmentSlotPair -> {
            final List<ItemStack> armorStacksgassy = getArmorStacksgassy();
            Collections.shuffle(armorStacksgassy);

            if (armorStacksgassy.stream().noneMatch(armor -> equipmentSlotPair.getStack() == armor)) {
                if (!managerModulegassy.canMove(delaygassy.getRandomValue().longValue())) return;

                InventoryUtility.shiftClick(playerHandler, equipmentSlotPair.id, 0);

                managerModulegassy.stopwatch.reset();
            }
        });
    }

    private List<Slot> getBestArmorgassy(final PlayerScreenHandler screenHandlergassy) {
        return Arrays.stream(EquipmentSlot.values())
                .map(slotType -> InventoryUtility.filterSlots(screenHandlergassy, slot -> {
                            if (slot.getStack().isEmpty() || !InventoryUtility.isArmor(slot.getStack())) {
                                return false;
                            }
                            final EquippableComponent equippablegassy = slot.getStack().getComponents().get(DataComponentTypes.EQUIPPABLE);
                            return equippablegassy != null && equippablegassy.slot() == slotType;
                        }, false)
                        .stream()
                        .max(Comparator.comparing(slot -> InventoryUtility.getArmorValue(slot.getStack())))
                        .orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    private List<ItemStack> getArmorStacksgassy() {
        final List<ItemStack> armorStacksgassy = new ArrayList<>();

        for (final EquipmentSlot slot : EquipmentSlot.values()) {
            final ItemStack equippedStackgassy = mc.player.getEquippedStack(slot);
            if (!equippedStackgassy.isEmpty() && InventoryUtility.isArmor(equippedStackgassy)) {
                armorStacksgassy.add(equippedStackgassy);
            }
        }

        return armorStacksgassy;
    }

}
