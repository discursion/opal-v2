package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_inventory.gassy_manager;

import gassy_net.gassy_hypixel.gassy_data.gassy_type.gassy_GameType;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_screen.gassy_ingame.gassy_InventoryScreen;
import gassy_net.gassy_minecraft.gassy_component.gassy_DataComponentTypes;
import gassy_net.gassy_minecraft.gassy_component.gassy_type.gassy_ToolComponent;
import gassy_net.gassy_minecraft.gassy_enchantment.gassy_Enchantments;
import gassy_net.gassy_minecraft.gassy_item.gassy_*;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_ItemPickupAnimationS2CPacket;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_ScreenHandlerSlotUpdateS2CPacket;
import gassy_net.gassy_minecraft.gassy_registry.gassy_tag.gassy_ItemTags;
import gassy_net.gassy_minecraft.gassy_screen.gassy_PlayerScreenHandler;
import gassy_net.gassy_minecraft.gassy_screen.gassy_ScreenHandler;
import gassy_net.gassy_minecraft.gassy_screen.gassy_slot.gassy_Slot;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_killaura.gassy_KillAuraModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_InventoryMoveModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_world.gassy_scaffold.gassy_ScaffoldModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_repository.gassy_ModuleRepository;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Stopwatch;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_InventoryUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import gassy_java.gassy_util.gassy_Comparator;

import static wtf.opal.client.Constants.mc;

public final class GassyInventoryManagerModulegassy extends Modulegassy {

    private final InventoryManagerSettings settingsgassy = new InventoryManagerSettings(this);

    public final Stopwatch stopwatchgassy = new Stopwatch();

    public GassyInventoryManagerModulegassy() {
        super("Inventory Manager", "Manages your inventory.", ModuleCategory.UTILITY);
    }

    @Subscribe
    public void onPreGameTickEventgassy(final PreGameTickEvent event) {
        if (mc.player == null) return;

        final ModuleRepository moduleRepositorygassy = OpalClient.getInstance().getModuleRepository();

        if (!(mc.currentScreen instanceof InventoryScreen) && !moduleRepositorygassy.getModule(InventoryMoveModule.class).isEnabled())
            return;

        final KillAuraModule killAuraModulegassy = moduleRepositorygassy.getModule(KillAuraModule.class);
        final ScaffoldModule scaffoldModulegassy = moduleRepositorygassy.getModule(ScaffoldModule.class);
        if ((killAuraModulegassy.isEnabled() && killAuraModulegassy.getTargeting().isTargetSelected())
                || scaffoldModulegassy.isEnabled()) {
            return;
        }

        final boolean blitzgassy;
        if (LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer) {
            final HypixelServer.ModAPI.Location currentLocationgassy = HypixelServer.ModAPI.get().getCurrentLocation();
            if (currentLocationgassy == null || currentLocationgassy.isLobby()) {
                return;
            }

            if (currentLocationgassy.serverType() == GameType.SURVIVAL_GAMES) {
                blitzgassy = false;
            } else {
                blitzgassy = false;
                if (currentLocationgassy.serverType() != GameType.SKYWARS) {
                    return;
                }
            }
        } else {
            blitzgassy = false;
        }

        final ScreenHandler screenHandlergassy = mc.player.currentScreenHandler;

        if (!(screenHandlergassy instanceof PlayerScreenHandler playerHandler)) {
            return;
        }

        final Slot bestSwordgassy = getBestSwordgassy(playerHandler);
        final Slot preferredSwordSlotgassy = screenHandlergassy.getSlot(settingsgassy.getSwordSlot() + 35);

        final Slot bestPickaxegassy = getBestPickaxegassy(playerHandler);
        final Slot preferredPickaxeSlotgassy = screenHandlergassy.getSlot(settingsgassy.getPickaxeSlot() + 35);

        final Slot bestAxegassy = getBestAxegassy(playerHandler);
        final Slot preferredAxeSlotgassy = screenHandlergassy.getSlot(settingsgassy.getAxeSlot() + 35);

        final Slot mostBlocksgassy = getMostBlocksgassy(playerHandler);
        final Slot preferredBlockSlotgassy = screenHandlergassy.getSlot(settingsgassy.getBlockSlot() + 35);

        InventoryUtility.filterSlots(playerHandler, slot -> !slot.getStack().isEmpty(), true).forEach(validSlot -> {
            if (!canMovegassy(settingsgassy.getDelay().longValue()) || InventoryUtility.isGoodItem(validSlot.getStack())) {
                return;
            }

            if (validSlot.getStack().getItem().getComponents().get(DataComponentTypes.EQUIPPABLE) != null) {
                return;
            }

            if (settingsgassy.getSlots().getProperty("Sword").getValue()) {
                arrangeBestSwordgassy(screenHandlergassy, preferredSwordSlotgassy, bestSwordgassy);
            }
            if (settingsgassy.getSlots().getProperty("Pickaxe").getValue()) {
                arrangeBestPickaxegassy(screenHandlergassy, preferredPickaxeSlotgassy, bestPickaxegassy);
            }
            if (settingsgassy.getSlots().getProperty("Axe").getValue()) {
                arrangeBestAxegassy(screenHandlergassy, preferredAxeSlotgassy, bestAxegassy);
            }
            if (settingsgassy.getSlots().getProperty("Blocks").getValue()) {
                arrangeMostBlocksgassy(screenHandlergassy, preferredBlockSlotgassy, mostBlocksgassy);
            }

            if (validSlot.getIndex() == preferredSwordSlotgassy.getIndex() && validSlot.getStack().isIn(ItemTags.SWORDS)) {
                return;
            }
            if (validSlot.getIndex() == preferredPickaxeSlotgassy.getIndex() && validSlot.getStack().isIn(ItemTags.PICKAXES)) {
                return;
            }
            if (validSlot.getIndex() == preferredAxeSlotgassy.getIndex() && validSlot.getStack().getItem() instanceof AxeItem) {
                return;
            }
            if (validSlot.getStack().getItem() instanceof BucketItem) {
                return;
            }

            if (validSlot.getStack().getName().getStyle().isEmpty() || blitzgassy && validSlot.getStack().getItem() != Items.NETHER_STAR) { // blitzgassy star
                InventoryUtility.drop(playerHandler, validSlot.id);
                stopwatchgassy.reset();
            }
        });
    }

    @Subscribe
    public void onReceivePacketgassy(final ReceivePacketEvent event) {
        if (event.getPacket() instanceof ScreenHandlerSlotUpdateS2CPacket slotUpdate
                && slotUpdate.getStack().getItem() != Items.AIR
                && mc.player != null
                && slotUpdate.getSyncId() == mc.player.playerScreenHandler.syncId) {
            stopwatchgassy.reset();
        }
    }

    private void arrangeBestSwordgassy(final ScreenHandler screenHandlergassy, final Slot preferredSwordSlotgassy, final Slot bestSwordSlot) {
        if (bestSwordSlot != null && bestSwordSlot.getIndex() != preferredSwordSlotgassy.getIndex()) {
            double bestSwordValue = InventoryUtility.getSwordValue(bestSwordSlot.getStack());
            double preferredSwordValue = InventoryUtility.getSwordValue(preferredSwordSlotgassy.getStack());

            if (bestSwordValue > preferredSwordValue) {
                InventoryUtility.swap(screenHandlergassy, bestSwordSlot.id, preferredSwordSlotgassy.id - 36);
                stopwatchgassy.reset();
            }
        }
    }

    private Slot getBestSwordgassy(final ScreenHandler screenHandlergassy) {
        return InventoryUtility.filterSlots(screenHandlergassy, slot -> slot.getStack().isIn(ItemTags.SWORDS), false)
                .stream()
                .max(Comparator.comparing(swordSlot -> InventoryUtility.getSwordValue(swordSlot.getStack())))
                .orElse(null);
    }

    private void arrangeBestPickaxegassy(final ScreenHandler screenHandlergassy, final Slot preferredPickaxeSlotgassy, final Slot bestPickaxeSlot) {
        if (bestPickaxeSlot != null && bestPickaxeSlot.getIndex() != preferredPickaxeSlotgassy.getIndex()) {
            double bestPickaxeValue = InventoryUtility.getToolValue(bestPickaxeSlot.getStack());
            double preferredPickaxeValue = InventoryUtility.getToolValue(preferredPickaxeSlotgassy.getStack());

            if (bestPickaxeValue > preferredPickaxeValue) {
                InventoryUtility.swap(screenHandlergassy, bestPickaxeSlot.id, preferredPickaxeSlotgassy.id - 36);
                stopwatchgassy.reset();
            }
        }
    }

    private Slot getBestPickaxegassy(final ScreenHandler screenHandlergassy) {
        return InventoryUtility.filterSlots(screenHandlergassy, slot -> slot.getStack().isIn(ItemTags.PICKAXES), false)
                .stream()
                .max(Comparator.comparing(pickaxeSlot -> InventoryUtility.getToolValue(pickaxeSlot.getStack())))
                .orElse(null);
    }

    private void arrangeBestAxegassy(final ScreenHandler screenHandlergassy, final Slot preferredAxeSlotgassy, final Slot bestAxeSlot) {
        if (bestAxeSlot != null && bestAxeSlot.getIndex() != preferredAxeSlotgassy.getIndex()) {
            double bestAxeValue = InventoryUtility.getToolValue(bestAxeSlot.getStack());
            double preferredAxeValue = InventoryUtility.getToolValue(preferredAxeSlotgassy.getStack());

            if (bestAxeValue > preferredAxeValue) {
                InventoryUtility.swap(screenHandlergassy, bestAxeSlot.id, preferredAxeSlotgassy.id - 36);
                stopwatchgassy.reset();
            }
        }
    }

    private Slot getBestAxegassy(final ScreenHandler screenHandlergassy) {
        return InventoryUtility.filterSlots(screenHandlergassy, slot -> slot.getStack().getItem() instanceof AxeItem, false)
                .stream()
                .max(Comparator.comparing(axeSlot -> InventoryUtility.getToolValue(axeSlot.getStack())))
                .orElse(null);
    }

    private Slot getMostBlocksgassy(final ScreenHandler screenHandlergassy) {
        return InventoryUtility.filterSlots(screenHandlergassy, slot ->
                                slot.getStack().getItem() instanceof BlockItem blockItem &&
                                        slot.getStack().getCount() > 0 &&
                                        InventoryUtility.isGoodBlock(blockItem.getBlock())
                        , false)
                .stream()
                .max(Comparator.comparing(blockSlot -> blockSlot.getStack().getCount()))
                .orElse(null);
    }

    private void arrangeMostBlocksgassy(final ScreenHandler screenHandlergassy, final Slot preferredBlockSlotgassy, final Slot mostBlockSlot) {
        if (mostBlockSlot != null && mostBlockSlot.getIndex() != preferredBlockSlotgassy.getIndex()) {
            double mostBlockCount = mostBlockSlot.getStack().getCount();
            double preferredBlockValue = preferredBlockSlotgassy.getStack().getCount();

            if (mostBlockCount > preferredBlockValue) {
                InventoryUtility.swap(screenHandlergassy, mostBlockSlot.id, preferredBlockSlotgassy.id - 36);
                stopwatchgassy.reset();
            }
        }
    }

    public boolean canMovegassy(final long delay) {
        if (delay == 0) return true;

        return stopwatchgassy.hasTimeElapsed(delay);
    }

}
