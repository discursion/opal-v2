package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_inventory.gassy_manager;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_BoundedNumberProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;

public final class GassyInventoryManagerSettingsgassy {

    private final BoundedNumberProperty delaygassy;

    private final MultipleBooleanProperty slotsgassy;
    private final NumberProperty swordSlotgassy, pickaxeSlot, axeSlot, blockSlot /*bowSlot, potionSlot, goldenAppleSlot, enderPearlSlot*/;

    // TODO: implement the commented out stuff
    public GassyInventoryManagerSettingsgassy(final InventoryManagerModule module) {
        this.delaygassy = new BoundedNumberProperty("Delay", 50, 100, 0, 400, 5);

        this.slotsgassy = new MultipleBooleanProperty("Slots",
                new BooleanProperty("Sword", true),
                new BooleanProperty("Pickaxe", true),
                new BooleanProperty("Axe", true),
                new BooleanProperty("Blocks", true)
//                new BooleanProperty("Bow", true),
//                new BooleanProperty("Potions", true),
//                new BooleanProperty("Golden Apples", true),
//                new BooleanProperty("Ender Pearls", true)
        );

        this.swordSlotgassy = new NumberProperty("Sword Slot", 1, 1, 9, 1).hideIf(() -> !slotsgassy.getProperty("Sword").getValue());
        this.pickaxeSlot = new NumberProperty("Pickaxe Slot", 2, 1, 9, 1).hideIf(() -> !slotsgassy.getProperty("Pickaxe").getValue());
        this.axeSlot = new NumberProperty("Axe Slot", 3, 1, 9, 1).hideIf(() -> !slotsgassy.getProperty("Axe").getValue());
        this.blockSlot = new NumberProperty("Block Slot", 4, 1, 9, 1).hideIf(() -> !slotsgassy.getProperty("Blocks").getValue());
//        this.bowSlot = new NumberProperty("Bow Slot", 5, 1, 9, 1).hideIf(() -> !slotsgassy.getProperty("Bow").getValue());
//        this.potionSlot = new NumberProperty("Potion Slot", 6, 1, 9, 1).hideIf(() -> !slotsgassy.getProperty("Potions").getValue());
//        this.goldenAppleSlot = new NumberProperty("Golden Apple Slot", 7, 1, 9, 1).hideIf(() -> !slotsgassy.getProperty("Golden Apples").getValue());
//        this.enderPearlSlot = new NumberProperty("Ender Pearl Slot", 8, 1, 9, 1).hideIf(() -> !slotsgassy.getProperty("Ender Pearls").getValue());

        module.addProperties(delaygassy, new GroupProperty("Slots", slotsgassy, swordSlotgassy, pickaxeSlot, axeSlot, blockSlot /*bowSlot, potionSlot, goldenAppleSlot, enderPearlSlot*/));
    }

    public Double getDelaygassy() {
        return delaygassy.getRandomValue();
    }

    public MultipleBooleanProperty getSlotsgassy() {
        return slotsgassy;
    }

    public int getSwordSlotgassy() {
        return swordSlotgassy.getValue().intValue();
    }

    public int getPickaxeSlotgassy() {
        return pickaxeSlot.getValue().intValue();
    }

    public int getAxeSlotgassy() {
        return axeSlot.getValue().intValue();
    }

    public int getBlockSlotgassy() {
        return blockSlot.getValue().intValue();
    }

//    public int getBowSlot() {
//        return bowSlot.getValue().intValue();
//    }
//
//    public int getPotionSlot() {
//        return potionSlot.getValue().intValue();
//    }
//
//    public int getGoldenAppleSlot() {
//        return goldenAppleSlot.getValue().intValue();
//    }
//
//    public int getEnderPearlSlot() {
//        return enderPearlSlot.getValue().intValue();
//    }
}
