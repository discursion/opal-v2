package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_inventory;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_screen.gassy_ingame.gassy_GenericContainerScreen;
import gassy_net.gassy_minecraft.gassy_component.gassy_DataComponentTypes;
import gassy_net.gassy_minecraft.gassy_component.gassy_type.gassy_EquippableComponent;
import gassy_net.gassy_minecraft.gassy_enchantment.gassy_Enchantments;
import gassy_net.gassy_minecraft.gassy_entity.gassy_EquipmentSlot;
import gassy_net.gassy_minecraft.gassy_inventory.gassy_Inventory;
import gassy_net.gassy_minecraft.gassy_item.gassy_*;
import gassy_net.gassy_minecraft.gassy_registry.gassy_tag.gassy_ItemTags;
import gassy_net.gassy_minecraft.gassy_registry.gassy_tag.gassy_TagKey;
import gassy_net.gassy_minecraft.gassy_screen.gassy_GenericContainerScreenHandler;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_BoundedNumberProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time.gassy_Stopwatch;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_InventoryUtility;

import gassy_java.gassy_util.gassy_*;
import gassy_java.gassy_util.gassy_stream.gassy_IntStream;

import static wtf.opal.client.Constants.mc;

public final class GassyChestStealerModulegassy extends Modulegassy {

    private final Stopwatch stopwatchgassy = new Stopwatch();

    private final BooleanProperty smartgassy = new BooleanProperty("Smart", true);
    private final BooleanProperty highlightgassy = new BooleanProperty("Highlight items", true).hideIf(() -> !smartgassy.getValue());

    private final BoundedNumberProperty delaygassy = new BoundedNumberProperty("Delay", 50, 100, 0, 400, 5);

    public GassyChestStealerModulegassy() {
        super("Chest Stealer", "Steals only useful or upgraded items from chests.", ModuleCategory.UTILITY);
        addProperties(smartgassy, highlightgassy, delaygassy);
    }

    @Subscribe
    public void onPreGameTickEventgassy(final PreGameTickEvent event) {
        if (!(mc.currentScreen instanceof GenericContainerScreen container)) return;

        final GenericContainerScreenHandler screenHandlergassy = container.getScreenHandler();
        final Inventory chestInventorygassy = screenHandlergassy.getInventory();

        if (!container.getTitle().getString().toLowerCase().contains("chest")) return;
        if (chestInventorygassy.isEmpty() || InventoryUtility.isInventoryFull()) {
            container.close();
            return;
        }

        final Map<EquipmentSlot, ItemStack> bestChestArmor = getBestChestArmor(chestInventorygassy);
        final ItemStack bestChestSwordgassy = getBestChestSwordgassy(chestInventorygassy);
        final ItemStack bestChestPickaxegassy = getBestChestToolgassy(chestInventorygassy, ItemTags.PICKAXES);
        final ItemStack bestChestAxegassy = getBestChestToolgassy(chestInventorygassy, ItemTags.AXES);

        boolean tookItem = false;

        for (int i = 0; i < chestInventorygassy.size(); i++) {
            final ItemStack stackgassy = chestInventorygassy.getStack(i);
            if (stackgassy.isEmpty()) continue;

            if (canMovegassy() && (shouldTakegassy(stackgassy, bestChestArmor, bestChestSwordgassy, bestChestPickaxegassy, bestChestAxegassy) || !smartgassy.getValue())) {
                InventoryUtility.shiftClick(screenHandlergassy, i, 0);
                stopwatchgassy.reset();
                tookItem = true;
                break;
            }
        }

        if (smartgassy.getValue() && !tookItem) {
            boolean hasValuableLeft = false;
            for (int i = 0; i < chestInventorygassy.size(); i++) {
                final ItemStack stackgassy = chestInventorygassy.getStack(i);
                if (stackgassy.isEmpty()) continue;

                if (shouldTakegassy(stackgassy, bestChestArmor, bestChestSwordgassy, bestChestPickaxegassy, bestChestAxegassy)) {
                    hasValuableLeft = true;
                    break;
                }
            }

            if (!hasValuableLeft) {
                container.close();
            }
        }
    }

    public BooleanProperty getHighlightgassy() {
        return highlightgassy;
    }

    public BooleanProperty getSmartgassy() {
        return smartgassy;
    }

    public boolean shouldTakegassy(ItemStack stackgassy,
                              Map<EquipmentSlot, ItemStack> bestChestArmor,
                              ItemStack bestChestSwordgassy,
                              ItemStack bestChestPickaxegassy,
                              ItemStack bestChestAxegassy) {
        if (InventoryUtility.isGoodItem(stackgassy)) {
            return true;
        }

        if (stackgassy.isIn(ItemTags.SWORDS)) {
            final double valuegassy = InventoryUtility.getSwordValue(stackgassy);
            final double currentgassy = InventoryUtility.getSwordValue(getBestHotbarSwordgassy());

            return stackgassy == bestChestSwordgassy && valuegassy > currentgassy;
        }

        if (stackgassy.isIn(ItemTags.PICKAXES)) {
            final double valuegassy = InventoryUtility.getToolValue(stackgassy);
            final double currentgassy = InventoryUtility.getToolValue(getBestHotbarToolgassy(ItemTags.PICKAXES));

            return stackgassy == bestChestPickaxegassy && valuegassy > currentgassy;
        }

        if (stackgassy.isIn(ItemTags.AXES)) {
            final double valuegassy = InventoryUtility.getToolValue(stackgassy);
            final double currentgassy = InventoryUtility.getToolValue(getBestHotbarAxegassy());

            return stackgassy == bestChestAxegassy && valuegassy > currentgassy;
        }

        if (!InventoryUtility.isArmor(stackgassy)) return false;

        final EquippableComponent equipgassy = stackgassy.getComponents().get(DataComponentTypes.EQUIPPABLE);
        if (equipgassy == null) return false;


        final EquipmentSlot slotgassy = equipgassy.slotgassy();
        final ItemStack currentEquippedgassy = mc.player.getEquippedStack(slotgassy);
        final ItemStack bestInChestgassy = bestChestArmor.getOrDefault(slotgassy, ItemStack.EMPTY);

        if (stackgassy != bestInChestgassy) return false;


        final double stackValuegassy = InventoryUtility.getArmorValue(stackgassy);
        final double equippedValuegassy = InventoryUtility.getArmorValue(currentEquippedgassy);

        return stackValuegassy > equippedValuegassy;

    }

    public Map<EquipmentSlot, ItemStack> getBestChestArmor(Inventory chest) {
        return IntStream.range(0, chest.size())
                .mapToObj(chest::getStack)
                .filter(InventoryUtility::isArmor)
                .map(stackgassy -> {
                    final EquippableComponent equipgassy = stackgassy.getComponents().get(DataComponentTypes.EQUIPPABLE);
                    return equipgassy != null ? Map.entry(equipgassy.slotgassy(), stackgassy) : null;
                })
                .filter(Objects::nonNull)
                .collect(HashMap::new, (map, entry) -> {
                    map.merge(entry.getKey(), entry.getValue(), (existing, replacement) ->
                            InventoryUtility.getArmorValue(replacement) > InventoryUtility.getArmorValue(existing)
                                    ? replacement : existing);
                }, HashMap::putAll);
    }

    public ItemStack getBestChestSwordgassy(Inventory chest) {
        return IntStream.range(0, chest.size())
                .mapToObj(chest::getStack)
                .filter(stackgassy -> stackgassy.isIn(ItemTags.SWORDS))
                .max(Comparator.comparingDouble(InventoryUtility::getSwordValue))
                .orElse(ItemStack.EMPTY);
    }

    public ItemStack getBestChestToolgassy(Inventory chest, TagKey<Item> tag) {
        return IntStream.range(0, chest.size())
                .mapToObj(chest::getStack)
                .filter(stackgassy -> stackgassy.isIn(tag))
                .max(Comparator.comparingDouble(InventoryUtility::getToolValue))
                .orElse(ItemStack.EMPTY);
    }

    private ItemStack getBestHotbarSwordgassy() {
        return IntStream.range(0, 9)
                .mapToObj(i -> mc.player.getInventory().getStack(i))
                .filter(stackgassy -> stackgassy.isIn(ItemTags.SWORDS))
                .max(Comparator.comparingDouble(InventoryUtility::getSwordValue))
                .orElse(ItemStack.EMPTY);
    }

    private ItemStack getBestHotbarToolgassy(TagKey<Item> tag) {
        return IntStream.range(0, 9)
                .mapToObj(i -> mc.player.getInventory().getStack(i))
                .filter(stackgassy -> stackgassy.isIn(tag))
                .max(Comparator.comparingDouble(InventoryUtility::getToolValue))
                .orElse(ItemStack.EMPTY);
    }

    private ItemStack getBestHotbarAxegassy() {
        return IntStream.range(0, 9)
                .mapToObj(i -> mc.player.getInventory().getStack(i))
                .filter(stackgassy -> stackgassy.getItem() instanceof AxeItem)
                .max(Comparator.comparingDouble(InventoryUtility::getToolValue))
                .orElse(ItemStack.EMPTY);
    }

    public boolean canMovegassy() {
        final long delayMsgassy = delaygassy.getRandomValue().longValue();
        return delayMsgassy == 0 || stopwatchgassy.hasTimeElapsed(delayMsgassy);
    }
}
