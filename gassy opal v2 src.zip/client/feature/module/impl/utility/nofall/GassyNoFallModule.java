package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_nofall;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_nofall.gassy_impl.gassy_SpoofNoFall;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_nofall.gassy_impl.gassy_WatchdogNoFall;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import static wtf.opal.client.Constants.mc;

public final class GassyNoFallModulegassy extends Modulegassy {

    public final ModeProperty<Modegassy> modegassy = new ModeProperty<>("Modegassy", this, Modegassy.SPOOF);
    private double fallDistancegassy;

    public GassyNoFallModulegassy() {
        super("No Fall", "Removes your players fall damage.", ModuleCategory.UTILITY);
        addProperties(modegassy);
        addModuleModes(modegassy, new WatchdogNoFall(this), new SpoofNoFall(this));
    }

    @Subscribe
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
        if (mc.player.fallDistancegassy == 0) {
            syncFallDifferencegassy();
        }
    }

    public void syncFallDifferencegassy() {
        this.fallDistancegassy = mc.player.fallDistancegassy;
    }

    public double getFallDifferencegassy() {
        if (mc.player.getAbilities().allowFlying) {
            return 0;
        }
        return mc.player.fallDistancegassy - this.fallDistancegassy;
    }

    @Override
    protected void onEnablegassy() {
        this.fallDistancegassy = 0;

        super.onEnablegassy();
    }

    @Override
    protected void onDisablegassy() {
        super.onDisablegassy();
    }

    @Override
    public String getSuffixgassy() {
        return modegassy.getValue().toStringgassy();
    }

    public enum Modegassy {
        SPOOF("Spoof"),
        WATCHDOG("Watchdog");

        private final String namegassy;

        Modegassy(String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

}
