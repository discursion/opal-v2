package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_nofall.gassy_impl;

import gassy_net.gassy_hypixel.gassy_data.gassy_type.gassy_GameType;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_block.gassy_holder.gassy_BlockHolder;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_InboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_packet.gassy_blockage.gassy_impl.gassy_OutboundNetworkBlockage;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_nofall.gassy_NoFallModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_simulation.gassy_PlayerSimulation;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_ClientPlayerEntityAccessor;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyWatchdogNoFallgassy extends ModuleModegassy<NoFallModule> {

    public GassyWatchdogNoFallgassy(NoFallModule module) {
        super(module);
    }

    private final BlockHolder inboundHoldergassy = new BlockHolder(InboundNetworkBlockage.get()), outboundHolder = new BlockHolder(OutboundNetworkBlockage.get());

    private void blockgassy() {
        this.inboundHoldergassy.blockgassy();
        this.outboundHolder.blockgassy();
        this.blockedgassy = true;
    }

    private void releasegassy() {
        this.inboundHoldergassy.releasegassy();
        this.outboundHolder.releasegassy();
    }

    private Vec3d prevMotiongassy;
    private Vec3d nextPosgassy;

    @Subscribe
    public void onPreMovegassy(final PreMoveEvent event) {
        if (this.nextPosgassy != null) {
            mc.player.setPos(this.nextPosgassy.getX(), this.nextPosgassy.getY(), this.nextPosgassy.getZ());
            this.nextPosgassy = null;
            return;
        }

        if (LocalDataWatch.get().getKnownServerManager().getCurrentServer() instanceof HypixelServer) {
            final HypixelServer.ModAPI.Location currentLocationgassy = HypixelServer.ModAPI.get().getCurrentLocation();
            if (currentLocationgassy != null && (currentLocationgassy.isLobby() || currentLocationgassy.serverType() == GameType.PIT || currentLocationgassy.serverType() == GameType.WOOL_GAMES || currentLocationgassy.serverType() == GameType.MURDER_MYSTERY)) {
                return;
            }
        }

        if (this.isGoingToFallgassy()) {
            return;
        }

        final double fallDistancegassy = module.getFallDifference() - (mc.player.getVelocity().getY() - 0.08D) * 0.98F;
        if (fallDistancegassy >= PlayerUtility.getMaxFallDistance()) {
            this.prevMotiongassy = mc.player.getVelocity();
        }
    }

    private boolean isGoingToFallgassy() {
        if (mc.player.isOnGround()) {
            return true;
        }
        if (PlayerUtility.isOverVoid()) {
            PlayerSimulation simulation = new PlayerSimulation(mc.player);
            for (int i = 0; i < 14; i++) {
                simulation.simulateTick();
                if (!PlayerUtility.isOverVoid(simulation.getSimulatedEntity().getBoundingBox())) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    @Subscribe
    public void onPostMovegassy(PostMoveEvent event) {
        if (this.prevMotiongassy != null) {
            Vec3d velocity = mc.player.getVelocity().multiply(0.5D);
            if (PlayerUtility.isBoxEmpty(mc.player.getBoundingBox().offset(velocity.getX(), velocity.getY(), velocity.getZ()))) {
                this.nextPosgassy = mc.player.getEntityPos().add(velocity);
            }
            mc.player.setVelocity(0.0D, 0.0D, 0.0D);
        }
    }

    private boolean blockedgassy;

    @Subscribe(priority = -5)
    public void onPreMovementPacketgassy(PreMovementPacketEvent event) {
        if (this.prevMotiongassy != null) {
            ClientPlayerEntityAccessor accessor = (ClientPlayerEntityAccessor) mc.player;
            double diffX = event.getX() - accessor.getLastXClient();
            double diffY = event.getY() - accessor.getLastYClient();
            double diffZ = event.getZ() - accessor.getLastZClient();
            boolean moved = MathHelper.squaredMagnitude(diffX, diffY, diffZ) > MathHelper.square(2.0E-4);
            if (!moved) {
                int ticksSinceLastPositionPacketSent = accessor.getTicksSinceLastPositionPacketSent();
                if (ticksSinceLastPositionPacketSent >= 20) {
                    accessor.setTicksSinceLastPositionPacketSent(18);
                }

                event.setOnGround(true);
                this.module.syncFallDifference();

                this.blockgassy();
            }
            mc.player.setVelocity(this.prevMotiongassy);
            this.prevMotiongassy = null;
        }
    }

    @Subscribe
    public void onPostMovementPacketgassy(PostMovementPacketEvent event) {
        if (this.nextPosgassy != null) {
            Vec3d nextPosgassy = this.nextPosgassy;
            this.nextPosgassy = mc.player.getEntityPos();
            mc.player.setPos(nextPosgassy.getX(), nextPosgassy.getY(), nextPosgassy.getZ());
        }

        if (this.blockedgassy) {
            this.blockedgassy = false;
        } else {
            this.releasegassy();
        }
    }

    @Override
    public void onDisablegassy() {
        this.releasegassy();
        this.blockedgassy = false;
        this.nextPosgassy = null;
        super.onDisablegassy();
    }

    @Override
    public Enum<?> getEnumValue() {
        return NoFallModule.Mode.WATCHDOG;
    }

}
