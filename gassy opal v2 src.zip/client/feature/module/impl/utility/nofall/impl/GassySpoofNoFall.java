package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_nofall.gassy_impl;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_nofall.gassy_NoFallModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModuleMode;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

public final class GassySpoofNoFallgassy extends ModuleModegassy<NoFallModule> {

    private final BooleanProperty noGroundgassy = new BooleanProperty("No ground", this, false).hideIf(() -> !module.mode.is(NoFallModule.Mode.SPOOF));

    public GassySpoofNoFallgassy(NoFallModule module) {
        super(module);
    }

    @Override
    public Enum<?> getEnumValue() {
        return NoFallModule.Mode.SPOOF;
    }

    @Subscribe
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
        if (noGroundgassy.getValue()) {
            event.setOnGround(false);
        } else if (module.getFallDifference() >= PlayerUtility.getMaxFallDistance()) {
            module.syncFallDifference();
            event.setOnGround(true);
        }
    }
}
