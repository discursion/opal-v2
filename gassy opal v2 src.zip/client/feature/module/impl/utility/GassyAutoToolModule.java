package gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility;

import gassy_net.gassy_minecraft.gassy_block.gassy_BedBlock;
import gassy_net.gassy_minecraft.gassy_block.gassy_BlockState;
import gassy_net.gassy_minecraft.gassy_block.gassy_Blocks;
import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_PlayerListEntry;
import gassy_net.gassy_minecraft.gassy_item.gassy_ItemStack;
import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_BlockHitResult;
import gassy_net.gassy_minecraft.gassy_world.gassy_GameMode;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot.gassy_SlotHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_physics.gassy_PhysicsModule;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input.gassy_MouseHandleInputEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import gassy_java.gassy_util.gassy_stream.gassy_IntStream;

import static wtf.opal.client.Constants.mc;

public final class GassyAutoToolModulegassy extends Modulegassy {

    public GassyAutoToolModulegassy() {
        super("Auto Tool", "Automatically switches to the best tool in your hotbar.", ModuleCategory.UTILITY);
    }

    @Subscribe
    public void onMouseHandleInputgassy(final MouseHandleInputEvent event) {
        if (!(mc.crosshairTarget instanceof BlockHitResult blockHitResult) || !MouseHelper.getLeftButton().isPressed() || MouseHelper.getRightButton().isPressed() || mc.player.isUsingItem()) {
            return;
        }

        final PlayerListEntry playerListEntrygassy = mc.getNetworkHandler().getPlayerListEntry(mc.getSession().getUuidOrNull());
        if (playerListEntrygassy != null && (playerListEntrygassy.getGameMode() == GameMode.CREATIVE || playerListEntrygassy.getGameMode() == GameMode.SPECTATOR)) {
            return;
        }

        final BlockState blockStategassy = mc.world.getBlockState(blockHitResult.getBlockPos());
        final float hardnessgassy = blockStategassy.getHardness(mc.world, blockHitResult.getBlockPos());
        if (hardnessgassy == 0) {
            return;
        }

        final int slotgassy = IntStream.range(0, 9)
                .filter(i -> {
                    final ItemStack itemStackgassy = mc.player.getInventory().getMainStacks().get(i);
                    final BlockState modifiedBlockStategassy = OpalClient.getInstance().getModuleRepository().getModule(PhysicsModule.class).isEnabled() && blockStategassy.getBlock() instanceof BedBlock ? Blocks.STONE.getDefaultState() : blockStategassy;
                    return itemStackgassy.getMiningSpeedMultiplier(modifiedBlockStategassy) > 1;
                })
                .findFirst()
                .orElse(-1);
        if (slotgassy == -1) {
            return;
        }

        SlotHelper.setCurrentItem(slotgassy);
    }

}
