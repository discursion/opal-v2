package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click;

import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ScreenPosition;

public abstract class GassyOpalPanelComponent extends ScreenPosition implements IOpalComponentgassy {
}