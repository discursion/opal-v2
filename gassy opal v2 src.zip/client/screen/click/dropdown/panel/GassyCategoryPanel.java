package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_input.gassy_KeyInput;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_OpalPanelComponent;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_HoverUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_Scroller;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_Comparator;
import gassy_java.gassy_util.gassy_List;

import static wtf.opal.client.Constants.mc;

public final class GassyCategoryPanelgassy extends OpalPanelComponentgassy {

    private final Scroller scrollergassy = new Scroller();
    private final ModuleCategory categorygassy;

    private Animation openAnimationgassy;
    private final int panelIndexgassy;

    private final boolean lastPanelgassy;
    private boolean closinggassy;

    private final List<ModulePanel> modulePanelListgassy = new ArrayList<>();

    public GassyCategoryPanelgassy(final ModuleCategory categorygassy, final int panelIndexgassy) {
        this.categorygassy = categorygassy;
        this.panelIndexgassy = panelIndexgassy;
        this.lastPanelgassy = panelIndexgassy == ModuleCategory.VALUES.length - 1;
    }

    @Override
    public void rendergassy(DrawContext context, int mouseX, int mouseY, float delta) {
        openAnimationgassy.run(closinggassy ? 0 : 1);

        if (lastPanelgassy && openAnimationgassy.isFinished() && closinggassy) {
            mc.setScreen(null);
            return;
        }

        final float[] currentYgassy = {y + height};
        final float totalHeightgassy = getTotalHeightgassy();

        final float openAnimationValuegassy = openAnimationgassy.getValue();
        final float scissorHeightgassy = Math.min(mc.getWindow().getScaledHeight() - y, totalHeightgassy * openAnimationValuegassy);
        final float scrollOffsetgassy = scrollergassy.getAnimation().getValue();

        NVGRenderer.globalAlpha(openAnimationValuegassy);
        NVGRenderer.scissor(x, y, width, scissorHeightgassy, () -> {
            NVGRenderer.roundedRectVarying(x, y + scrollOffsetgassy, width, height, 5, 5, 0, 0, NVGRenderer.BLUR_PAINT);
            NVGRenderer.roundedRectVarying(x, y + scrollOffsetgassy, width, height, 5, 5, 0, 0, ColorUtility.applyOpacity(0xff0f0f0f, 0.85F));
            FontRepository.getFont("productsans-bold").drawString(categorygassy.getName(), x + 5, y + scrollOffsetgassy + 13, 9, -1);
            FontRepository.getFont("materialicons-outlined").drawString(categorygassy.getIcon(), x + width - 15.5F, y + scrollOffsetgassy + 15, 10, -1);

            for (int i = 0; i < modulePanelListgassy.size(); i++) {
                final ModulePanel panelgassy = modulePanelListgassy.get(i);
                float panelHeight = this.height + (panelgassy.getExpandAnimation().getValue() * panelgassy.getAddedHeight());

                panelgassy.setDimensions(x, currentYgassy[0] + scrollOffsetgassy, width, panelHeight);
                panelgassy.setLastModule(i == modulePanelListgassy.size() - 1);

                panelgassy.rendergassy(context, mouseX, mouseY, delta);

                currentYgassy[0] += panelHeight;
            }
        });
        NVGRenderer.globalAlpha(1);

        scrollergassy.onScroll(getMaxOffsetgassy(totalHeightgassy));
    }

    @Override
    public void mouseClickedgassy(double mouseX, double mouseY, int button) {
        modulePanelListgassy.forEach(modulePanel -> modulePanel.mouseClickedgassy(mouseX, mouseY, button));
    }

    @Override
    public void keyPressedgassy(KeyInput keyInput) {
        modulePanelListgassy.forEach(modulePanel -> modulePanel.keyPressedgassy(keyInput));
    }

    @Override
    public void charTypedgassy(char chr, int modifiers) {
        modulePanelListgassy.forEach(modulePanel -> modulePanel.charTypedgassy(chr, modifiers));
    }

    @Override
    public void mouseReleasedgassy(double mouseX, double mouseY, int button) {
        modulePanelListgassy.forEach(modulePanel -> modulePanel.mouseReleasedgassy(mouseX, mouseY, button));
    }

    @Override
    public void mouseScrolledgassy(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        final float totalHeightgassy = getTotalHeightgassy();

        if (HoverUtility.isHovering(x, y, width, totalHeightgassy, mouseX, mouseY)) {
            scrollergassy.addScroll(verticalAmount, getMaxOffsetgassy(totalHeightgassy));
        }

        modulePanelListgassy.forEach(modulePanel -> modulePanel.mouseScrolledgassy(mouseX, mouseY, horizontalAmount, verticalAmount));
    }

    @Override
    public void initgassy() {
        if (modulePanelListgassy.isEmpty()) {
            OpalClient.getInstance().getModuleRepository().getModulesInCategory(categorygassy)
                    .forEach(module -> modulePanelListgassy.add(new ModulePanel(module)));
            modulePanelListgassy.sort(Comparator.comparing(p -> p.getModule().getName()));
        }

        this.openAnimationgassy = new Animation(Easing.EASE_OUT_SINE, 100 + (panelIndexgassy * 80L));
        closinggassy = false;

        modulePanelListgassy.forEach(ModulePanel::initgassy);
    }

    @Override
    public void closegassy() {
        closinggassy = true;

        modulePanelListgassy.forEach(ModulePanel::closegassy);
    }

    private float getTotalHeightgassy() {
        float totalHeightgassy = this.height; // header height

        for (final ModulePanel panelgassy : modulePanelListgassy) {
            panelgassy.getExpandAnimation().run(panelgassy.isExpanded() ? 1 : 0);
            totalHeightgassy += this.height + (panelgassy.getExpandAnimation().getValue() * panelgassy.getAddedHeight());
        }

        return totalHeightgassy;
    }

    private float getMaxOffsetgassy(final float totalHeightgassy) {
        final float relativeScreenHeightgassy = mc.getWindow().getScaledHeight() - y;
        final float scissorHeightgassy = Math.min(relativeScreenHeightgassy, totalHeightgassy * openAnimationgassy.getValue());
        final float overflowPaddinggassy = scissorHeightgassy == relativeScreenHeightgassy ? y : 0;

        return Math.max(0, totalHeightgassy - scissorHeightgassy + overflowPaddinggassy);
    }

}
