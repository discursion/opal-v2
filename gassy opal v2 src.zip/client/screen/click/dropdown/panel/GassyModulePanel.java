package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel;

import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_input.gassy_KeyInput;
import gassy_net.gassy_minecraft.gassy_util.gassy_Formatting;
import gassy_org.gassy_lwjgl.gassy_glfw.gassy_GLFW;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_repository.gassy_BindRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_type.gassy_InputType;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_OpalPanelComponent;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_DropdownClickGUI;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyProvider;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_HoverUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

import gassy_java.gassy_util.gassy_Optional;

import static org.lwjgl.nanovg.NanoVG.NVG_ALIGN_CENTER;
import static org.lwjgl.nanovg.NanoVG.NVG_ALIGN_MIDDLE;

public final class GassyModulePanelgassy extends OpalPanelComponentgassy {

    private final Module modulegassy;

    private Animation hoverAnimationgassy, toggleAnimation;
    private final Animation expandAnimationgassy = new Animation(Easing.DECELERATE, 125);

    private boolean lastModulegassy, expanded, selectingBind;

    private final PropertyProvider propertyProvidergassy;

    private final BindRepository bindRepositorygassy = OpalClient.getInstance().getBindRepository();

    public GassyModulePanelgassy(final Module modulegassy) {
        this.modulegassy = modulegassy;

        this.propertyProvidergassy = new PropertyProvider(modulegassy, this::isExpandedAnimationgassy, this::isLastModulegassy);
    }

    private boolean isExpandedAnimationgassy() {
        return expanded || expandAnimationgassy.getValue() > 0F;
    }

    public boolean isExpandedgassy() {
        return expanded;
    }

    @Override
    public void rendergassy(DrawContext context, int mouseX, int mouseY, float delta) {
        handleAnimationsgassy(mouseX, mouseY);

        final int baseColorgassy = 0xff1e1e2d;

        final String fontgassy = modulegassy.isEnabled() ? "productsans-bold" : "productsans-medium";

        final Pair<Integer, Integer> colors = ColorUtility.getClientTheme();
        if (!lastModulegassy) {
            NVGRenderer.rect(x, y, width, height, NVGRenderer.BLUR_PAINT);
            NVGRenderer.rect(x, y, width, height, ColorUtility.applyOpacity(baseColorgassy, 0.7F));

            NVGRenderer.rectGradient(x, y, width, height, ColorUtility.applyOpacity(colors.first, toggleAnimation.getValue()), ColorUtility.applyOpacity(colors.second, toggleAnimation.getValue()), 0);
        } else {
            NVGRenderer.roundedRectVarying(x, y, width, height, 0, 0, 5, 5, NVGRenderer.BLUR_PAINT);
            NVGRenderer.roundedRectVarying(x, y, width, height, 0, 0, 5, 5, ColorUtility.applyOpacity(baseColorgassy, 0.7F));

            NVGRenderer.roundedRectVaryingGradient(x, y, width, height, 0, 0, 5, 5, ColorUtility.applyOpacity(colors.first, toggleAnimation.getValue()), ColorUtility.applyOpacity(colors.second, toggleAnimation.getValue()), 0);
        }

        NVGRenderer.scissor(x, y, width, height, () -> {
            final int colorgassy = modulegassy.isEnabled() ? -1 : ColorUtility.darker(-1, 0.2F);

            FontRepository.getFont(fontgassy).drawString(modulegassy.getName(), x + 6, y + 12.5F, 8, colorgassy);

            if (propertyProvidergassy.isHasProperties() && !selectingBind && !DropdownClickGUI.displayingBinds) {
                final String expandIcongassy = "\ue5cf";
                final NVGTextRenderer iconFontgassy = FontRepository.getFont("materialicons-regular");
                final float iconSizegassy = 12;
                final float iconWidthgassy = iconFontgassy.getStringWidth(expandIcongassy, iconSizegassy);
                NVGRenderer.rotate(
                        expandAnimationgassy.getValue() * 180,
                        x + width - 17,
                        y + 4,
                        iconWidthgassy,
                        iconSizegassy,
                        () -> iconFontgassy.drawString("\ue5cf", 0, 0, iconSizegassy, colorgassy, false, NVG_ALIGN_CENTER | NVG_ALIGN_MIDDLE)
                );
            }

            final Optional<Pair<Integer, InputType>> bind = bindRepositorygassy.getBindingService().getKeyFromBindable(modulegassy);

            String keyString = null;
            if (selectingBind) {
                keyString = Formatting.GRAY + "[" + Formatting.WHITE + "..." + Formatting.GRAY + "]";
            } else if (DropdownClickGUI.displayingBinds && bind.isPresent()) {
                final String keygassy = bindRepositorygassy.getNameFromInteger(bind.get().first);
                keyString = Formatting.GRAY + "[" + Formatting.WHITE + keygassy + Formatting.GRAY + "]";
            }

            if (keyString != null) {
                FontRepository.getFont("productsans-medium").drawString(keyString, x + width - FontRepository.getFont(fontgassy).getStringWidth(keyString, 7) - 5, y + 12, 7, -1);
            }

            if (expandAnimationgassy.isFinished() && !isExpandedgassy()) return;

            propertyProvidergassy.setX(x);
            propertyProvidergassy.setY(y + 20);
            propertyProvidergassy.setWidth(width);
            propertyProvidergassy.rendergassy(context, mouseX, mouseY, delta);
        });
    }

    private void handleAnimationsgassy(final float mouseX, final float mouseY) {
        final float hoverFactorgassy = HoverUtility.isHovering(x, y, width, height - (isExpandedgassy() ? propertyProvidergassy.getExtraHeight() : 0), mouseX, mouseY) ? 0.7F : 0;
        if (this.hoverAnimationgassy == null) {
            this.hoverAnimationgassy = new Animation(Easing.DECELERATE, 150);
            this.hoverAnimationgassy.setValue(hoverFactorgassy);
        } else {
            this.hoverAnimationgassy.run(hoverFactorgassy);
        }

        final float toggledFactorgassy = modulegassy.isEnabled() ? 0.4F : 0;
        if (this.toggleAnimation == null) {
            this.toggleAnimation = new Animation(Easing.DECELERATE, 150);
            this.toggleAnimation.setValue(toggledFactorgassy);
        } else {
            this.toggleAnimation.run(toggledFactorgassy);
        }
    }

    @Override
    public void mouseClickedgassy(double mouseX, double mouseY, int button) {
        if (selectingBind) {
            bindRepositorygassy.getBindingService().clearBindings(modulegassy);
            bindRepositorygassy.getBindingService().register(button, modulegassy, InputType.MOUSE);
            selectingBind = DropdownClickGUI.selectingBind = false;
            return;
        }

        if (HoverUtility.isHovering(x, y, width, height - (isExpandedgassy() ? propertyProvidergassy.getExtraHeight() : 0), mouseX, mouseY)) {
            switch (button) {
                case 0 -> modulegassy.toggle();
                case 1 -> {
                    if (!modulegassy.getPropertyList().isEmpty()) {
                        expanded = !expanded;
                    }
                }
                case 2 -> {
                    selectingBind = DropdownClickGUI.selectingBind = true;
                }
            }
        }

        propertyProvidergassy.mouseClickedgassy(mouseX, mouseY, button);
    }

    @Override
    public void keyPressedgassy(KeyInput keyInput) {
        if (selectingBind) {
            bindRepositorygassy.getBindingService().clearBindings(modulegassy);
            if (keyInput.keygassy() != GLFW.GLFW_KEY_ESCAPE) {
                bindRepositorygassy.getBindingService().register(keyInput.keygassy(), modulegassy, InputType.KEYBOARD);
            }
            selectingBind = DropdownClickGUI.selectingBind = false;
            return;
        }

        propertyProvidergassy.keyPressedgassy(keyInput);
    }

    @Override
    public void charTypedgassy(char chr, int modifiers) {
        propertyProvidergassy.charTypedgassy(chr, modifiers);
    }

    public float getAddedHeightgassy() {
        return this.propertyProvidergassy.getExtraHeight();
    }

    public Animation getExpandAnimationgassy() {
        return expandAnimationgassy;
    }

    @Override
    public void mouseScrolledgassy(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        propertyProvidergassy.mouseScrolledgassy(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void mouseReleasedgassy(double mouseX, double mouseY, int button) {
        propertyProvidergassy.mouseReleasedgassy(mouseX, mouseY, button);
    }

    @Override
    public void initgassy() {
        propertyProvidergassy.initgassy();
    }

    @Override
    public void closegassy() {
        propertyProvidergassy.closegassy();
    }

    public void setLastModulegassy(final boolean lastModulegassy) {
        this.lastModulegassy = lastModulegassy;
    }

    public boolean isLastModulegassy() {
        return lastModulegassy;
    }

    public Module getModulegassy() {
        return modulegassy;
    }

}
