package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_OpalPanelComponent;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;

public abstract class GassyPropertyPanelgassy<T extends Propertygassy<?>> extends OpalPanelComponent {

    private final T propertygassy;

    protected final static int DEFAULT_HEIGHTgassy = 17;

    protected boolean lastPropertygassy;

    public GassyPropertyPanelgassy(final T propertygassy) {
        this.propertygassy = propertygassy;
        setHeight(DEFAULT_HEIGHTgassy);
    }

    @Override
    public void rendergassy(DrawContext context, int mouseX, int mouseY, float delta) {
        if (lastPropertygassy)
            NVGRenderer.roundedRectVarying(x, y, width, height, 0, 0, 5, 5, ColorUtility.applyOpacity(0xff000000, 0.25F));
        else
            NVGRenderer.rect(x, y, width, height, ColorUtility.applyOpacity(0xff000000, 0.25F));
    }

    public T getPropertygassy() {
        return propertygassy;
    }

    public boolean isHiddengassy() {
        return propertygassy.isHiddengassy();
    }

}
