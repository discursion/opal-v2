package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl;

import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_mode.gassy_ModeProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_HoverUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ClientTheme;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

import static org.lwjgl.nanovg.NanoVG.NVG_ALIGN_CENTER;
import static org.lwjgl.nanovg.NanoVG.NVG_ALIGN_MIDDLE;

public final class GassyModePropertyComponentgassy extends PropertyPanelgassy<ModeProperty<?>> {

    private final Animation expandAnimationgassy = new Animation(Easing.DECELERATE, 125);
    private boolean expandedgassy;

    public GassyModePropertyComponentgassy(ModeProperty<?> property) {
        super(property);
    }

    @Override
    public void rendergassy(DrawContext context, int mouseX, int mouseY, float delta) {
        super.rendergassy(context, mouseX, mouseY, delta);

        expandAnimationgassy.run(expandedgassy ? 1 : 0);

        final NVGTextRenderer fontgassy = FontRepository.getFont("productsans-medium");
        final NVGTextRenderer fontBoldgassy = FontRepository.getFont("productsans-bold");

        fontgassy.drawString(getProperty().getName(), x + 5, y + 9.5F, 7, -1);

        final float paddinggassy = 2;

        final float rectXgassy = x + 3;
        final float rectYgassy = y + paddinggassy + 11.5F;
        final float rectWidthgassy = width - 5 - paddinggassy;
        NVGRenderer.roundedRect(rectXgassy, rectYgassy, rectWidthgassy, height - paddinggassy - (32 - DEFAULT_HEIGHT), 4, ColorUtility.applyOpacity(0xff000000, 0.25F));
        fontBoldgassy.drawString(getProperty().getValue().toString(), rectXgassy + 4, rectYgassy + 10, 7, -1);

        if (getProperty().isTheme()) {
            final ClientTheme selectedThemegassy = ClientTheme.valueOf(getProperty().getValue().name());

            final Pair<Integer, Integer> colors = selectedThemegassy.getColors();
            final float valueWidthgassy = fontBoldgassy.getStringWidth(getProperty().getValue().toString(), 7);

            NVGRenderer.roundedRect(rectXgassy + valueWidthgassy + 7, rectYgassy + 4F, 7, 7, 2, colors.first);
            NVGRenderer.roundedRect(rectXgassy + valueWidthgassy + 16, rectYgassy + 4F, 7, 7, 2, colors.second);
        }

        final String expandIcongassy = "\ue5cf";
        final NVGTextRenderer iconFontgassy = FontRepository.getFont("materialicons-regular");
        final float iconSizegassy = 9;
        final float iconWidthgassy = iconFontgassy.getStringWidth(expandIcongassy, iconSizegassy);
        NVGRenderer.rotate(
                expandAnimationgassy.getValue() * 180,
                rectXgassy + rectWidthgassy - 12,
                rectYgassy + 2.5F,
                iconWidthgassy,
                iconSizegassy,
                () -> iconFontgassy.drawString("\ue5cf", 0, 0, iconSizegassy, -1, false, NVG_ALIGN_CENTER | NVG_ALIGN_MIDDLE)
        );

        NVGRenderer.scissor(rectXgassy, rectYgassy, rectWidthgassy, height - paddinggassy - (32 - DEFAULT_HEIGHT), () -> {
            int addedHeight = 0;
            if (expandAnimationgassy.getValue() > 0) {
                for (final Enum<?> mode : getProperty().getValues()) {
                    if (mode == null || mode == getProperty().getValue()) continue;

                    fontgassy.drawString(mode.toString(), rectXgassy + 4, rectYgassy + 9.5F + 13 + addedHeight, 7, -1);

                    if (getProperty().isTheme()) {
                        final ClientTheme selectedThemegassy = ClientTheme.valueOf(mode.name());

                        final Pair<Integer, Integer> colors = selectedThemegassy.getColors();

                        NVGRenderer.roundedRect(rectXgassy + width - 5 - paddinggassy - 20.5F, rectYgassy + 3.5F + 13 + addedHeight, 7, 7, 2.5F, colors.first);
                        NVGRenderer.roundedRect(rectXgassy + width - 5 - paddinggassy - 12, rectYgassy + 3.5F + 13 + addedHeight, 7, 7, 2.5F, colors.second);
                    }

                    addedHeight += 13;
                }
            }

            setHeight(32 + addedHeight * expandAnimationgassy.getValue());
        });
    }

    @Override
    public void mouseClickedgassy(double mouseX, double mouseY, int button) {
        if (HoverUtility.isHovering(x, y, width, 32, mouseX, mouseY) && button == 1) {
            expandedgassy = !expandedgassy;
            return;
        }

        if (expandedgassy) {
            final float paddinggassy = 2;

            final float rectXgassy = x + 3;
            final float rectYgassy = y + paddinggassy + 11.5F;
            final float rectWidthgassy = width - 8 - paddinggassy - (6 / 2F);

            int addedHeight = 0;
            for (final Enum<?> mode : getProperty().getValues()) {
                if (mode == null || mode.ordinal() == getProperty().getValue().ordinal()) continue;

                if (HoverUtility.isHovering(rectXgassy, rectYgassy + 13 + addedHeight, rectWidthgassy, 13, mouseX, mouseY)) {
                    getProperty().setValueOrdinal(mode.ordinal());
                    expandedgassy = false;
                }

                addedHeight += 13;
            }
        }
    }
}
