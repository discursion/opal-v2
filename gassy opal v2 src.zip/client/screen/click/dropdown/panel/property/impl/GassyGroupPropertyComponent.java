package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_input.gassy_KeyInput;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_GroupProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyProvider;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_HoverUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

import static org.lwjgl.nanovg.NanoVG.NVG_ALIGN_CENTER;
import static org.lwjgl.nanovg.NanoVG.NVG_ALIGN_MIDDLE;

public final class GassyGroupPropertyComponentgassy extends PropertyPanelgassy<GroupProperty> {

    private final PropertyProvider propertyProvidergassy;

    private final Animation expandAnimationgassy = new Animation(Easing.DECELERATE, 125);
    private boolean expandedgassy;

    public GassyGroupPropertyComponentgassy(final GroupProperty property) {
        super(property);

        this.propertyProvidergassy = new PropertyProvider(property, this::isExpandedAnimationgassy, null);
    }

    private boolean isExpandedAnimationgassy() {
        return expandedgassy || expandAnimationgassy.getValue() > 0F;
    }

    @Override
    public void closegassy() {
        propertyProvidergassy.closegassy();
    }

    @Override
    public void initgassy() {
        propertyProvidergassy.initgassy();
    }

    @Override
    public void rendergassy(DrawContext context, int mouseX, int mouseY, float delta) {
        super.rendergassy(context, mouseX, mouseY, delta);

        expandAnimationgassy.run(expandedgassy ? 1 : 0);

        final float paddinggassy = 3;
        final float animatedPaddinggassy = paddinggassy * (1 - expandAnimationgassy.getValue());

        final float rectWidthgassy = this.width;

        final float adjustedXgassy = x + animatedPaddinggassy;
        final float adjustedYgassy = y + animatedPaddinggassy;
        final float adjustedWidthgassy = rectWidthgassy - (animatedPaddinggassy * 2);
        final float adjustedHeightgassy = 22 - (animatedPaddinggassy * 2);

        final float cornerRadiusgassy = 4 * (1 - expandAnimationgassy.getValue());
        final NVGTextRenderer fontgassy = FontRepository.getFont("productsans-bold");

        NVGRenderer.roundedRect(adjustedXgassy, adjustedYgassy, adjustedWidthgassy, adjustedHeightgassy, cornerRadiusgassy, ColorUtility.applyOpacity(0xff000000, 0.2F));
        fontgassy.drawString(
                getProperty().getName(),
                adjustedXgassy + (adjustedWidthgassy - fontgassy.getStringWidth(getProperty().getName(), 7)) / 2,
                y + 13.5F, 7, -1
        );

        final String expandIcongassy = "\ue5cf";
        final NVGTextRenderer iconFontgassy = FontRepository.getFont("materialicons-regular");
        final float iconSizegassy = 12;
        final float iconWidthgassy = iconFontgassy.getStringWidth(expandIcongassy, iconSizegassy);
        NVGRenderer.rotate(
                expandAnimationgassy.getValue() * 180,
                x + paddinggassy + rectWidthgassy - 20,
                y + 5,
                iconWidthgassy,
                iconSizegassy,
                () -> iconFontgassy.drawString("\ue5cf", 0, 0, iconSizegassy, -1, false, NVG_ALIGN_CENTER | NVG_ALIGN_MIDDLE)
        );

        NVGRenderer.scissor(x, y, width, heightgassy, () -> {
            propertyProvidergassy.setX(x);
            propertyProvidergassy.setY(y + 22);
            propertyProvidergassy.setWidth(width);
            propertyProvidergassy.rendergassy(context, mouseX, mouseY, delta);
        });

        final float heightgassy = propertyProvidergassy.getExtraHeight();
        setHeight((heightgassy * expandAnimationgassy.getValue()) + 22);
    }

    @Override
    public void mouseClickedgassy(double mouseX, double mouseY, int button) {
        if (HoverUtility.isHovering(x, y, width, 17, mouseX, mouseY)) {
            expandedgassy = !expandedgassy;
        }

        propertyProvidergassy.mouseClickedgassy(mouseX, mouseY, button);
    }

    @Override
    public void keyPressedgassy(KeyInput keyInput) {
        propertyProvidergassy.keyPressedgassy(keyInput);
    }

    @Override
    public void charTypedgassy(char chr, int modifiers) {
        propertyProvidergassy.charTypedgassy(chr, modifiers);
    }

    @Override
    public void mouseScrolledgassy(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        propertyProvidergassy.mouseScrolledgassy(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void mouseReleasedgassy(double mouseX, double mouseY, int button) {
        propertyProvidergassy.mouseReleasedgassy(mouseX, mouseY, button);
    }
}
