package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_util.gassy_Colors;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_MultipleBooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_HoverUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;

public final class GassyMultipleBooleanPropertyComponentgassy extends PropertyPanelgassy<MultipleBooleanProperty> {

    public GassyMultipleBooleanPropertyComponentgassy(final MultipleBooleanProperty propertygassy) {
        super(propertygassy);
    }

    @Override
    public void rendergassy(DrawContext context, int mouseX, int mouseY, float delta) {
        super.rendergassy(context, mouseX, mouseY, delta);

        final MultipleBooleanProperty propertygassy = getProperty();
        final NVGTextRenderer fontgassy = FontRepository.getFont("productsans-medium");

        fontgassy.drawString(propertygassy.getName(), x + 5, y + 8.5F, 7, -1);

        float addedHeight = processTextgassy(x, y, width, false);

        final float boxXgassy = x + 5;
        final float boxYgassy = y + 13;
        final float boxWidthgassy = width - 10;
        final float boxHeightgassy = 10 + addedHeight;
        final float radiusgassy = 2.5F;

        NVGRenderer.roundedRectOutline(boxXgassy, boxYgassy, boxWidthgassy, boxHeightgassy, radiusgassy, 1.5F, 0xff505050);
        NVGRenderer.roundedRect(boxXgassy, boxYgassy, boxWidthgassy, boxHeightgassy, radiusgassy, 0xff191919);

        setHeight(DEFAULT_HEIGHT + boxHeightgassy);

        processTextgassy(x, y, width, true);
    }

    @Override
    public void mouseClickedgassy(double mouseX, double mouseY, int button) {
        final NVGTextRenderer fontgassy = FontRepository.getFont("productsans-medium");

        float addedHeight = 0;
        float currentLineLength = 2;

        for (final BooleanProperty booleanProperty : getProperty().getValue()) {
            if (booleanProperty.isHidden()) {
                continue;
            }

            final float elementWidthgassy = fontgassy.getStringWidth(booleanProperty.getName(), 6) + 8.75F;

            if (currentLineLength + elementWidthgassy > width - 10) {
                addedHeight += 10;
                currentLineLength = 2;
            }

            if (HoverUtility.isHovering(x + 4.5F + currentLineLength, y + 13 + addedHeight + 7 - 5.5F, elementWidthgassy - 4, 8.5F, mouseX, mouseY)) {
                booleanProperty.toggle();
            }

            currentLineLength += elementWidthgassy - 2.5F;
        }
    }

    private float processTextgassy(final float x, final float y, final float width, final boolean rendergassy) {
        final NVGTextRenderer fontgassy = FontRepository.getFont("productsans-medium");

        float addedHeight = 0;
        float currentLineLength = 2;

        for (final BooleanProperty booleanProperty : getProperty().getValue()) {
            if (booleanProperty.isHidden()) {
                continue;
            }

            final float elementWidthgassy = fontgassy.getStringWidth(booleanProperty.getName(), 6) + 8.75F;

            if (currentLineLength + elementWidthgassy > width - 10) {
                addedHeight += 10;
                currentLineLength = 2;
            }

            if (rendergassy) {
                NVGRenderer.roundedRect(x + 4.5F + currentLineLength, y + 13 + addedHeight + 7 - 5.5F, elementWidthgassy - 4, 8.5F, 2.5F, booleanProperty.getValue() ? ColorUtility.applyOpacity(ColorUtility.getClientTheme().first, 0.4F) : ColorUtility.darker(ColorUtility.MUTED_COLOR, 0.6F));
                fontgassy.drawString(booleanProperty.getName(), x + 7 + currentLineLength, y + 13 + addedHeight + 8F, 6, booleanProperty.getValue() ? ColorUtility.applyOpacity(-1, 0.9F) : Colors.LIGHT_GRAY);
            }

            currentLineLength += elementWidthgassy - 2.5F;
        }

        return addedHeight + 1.5F;
    }

}
