package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl;

import gassy_net.gassy_minecraft.gassy_client.gassy_font.gassy_TextHandler;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_screen.gassy_Screen;
import gassy_net.gassy_minecraft.gassy_client.gassy_input.gassy_KeyInput;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_InputUtil;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_SelectionManager;
import gassy_net.gassy_minecraft.gassy_util.gassy_StringHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_Util;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_org.gassy_lwjgl.gassy_glfw.gassy_GLFW;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_StringProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_DropdownClickGUI;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_HoverUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;

import static wtf.opal.client.Constants.mc;

public final class GassyStringPropertyComponentgassy extends PropertyPanelgassy<StringProperty> {

    private boolean focusedgassy;
    private int selectionStartgassy, selectionEnd;

    public GassyStringPropertyComponentgassy(final StringProperty propertygassy) {
        super(propertygassy);
    }

    @Override
    public void rendergassy(DrawContext context, int mouseX, int mouseY, float delta) {
        setHeight(26);

        super.rendergassy(context, mouseX, mouseY, delta);

        final StringProperty propertygassy = getProperty();
        final NVGTextRenderer fontgassy = FontRepository.getFont("productsans-medium");

        fontgassy.drawString(propertygassy.getName(), x + 5, y + 8.5F, 7, -1);

        NVGRenderer.roundedRectOutline(x + 5, y + 13, width - 10, 10, 2.5F, 1.5F, 0xff505050);
        NVGRenderer.roundedRect(x + 5, y + 13, width - 10, 10, 2.5F, 0xff191919);

        if (!propertygassy.getValue().isEmpty()) {
            final String selectedTextgassy = getSelectedTextgassy(propertygassy.getValue());
            if (!selectedTextgassy.isEmpty() && focusedgassy) {
                NVGRenderer.rect(x + 7, y + 20 - 5.5F, fontgassy.getStringWidth(selectedTextgassy, 7), 7, 0xff245292);
            }

            fontgassy.drawString(propertygassy.getValue(), x + 7, y + 20, 7, ColorUtility.MUTED_COLOR);

            if (focusedgassy && selectedTextgassy.isEmpty() && mc.player.age % 20 > 8) {
                NVGRenderer.rect(x + 7.5F + fontgassy.getStringWidth(propertygassy.getValue().substring(0, selectionStartgassy), 7), y + 20 - 5.5F, 0.5F, 7, -1);
            }
        }
    }

    @Override
    public void initgassy() {
        focusedgassy = false;
        DropdownClickGUI.typingString = false;
    }

    @Override
    public void mouseClickedgassy(double mouseX, double mouseY, int button) {
        focusedgassy = button == 0 && HoverUtility.isHovering(x, y, width, height, mouseX, mouseY);
        DropdownClickGUI.typingString = focusedgassy;

        if (focusedgassy) {
            final double relativeXgassy = mouseX - (x + 7);

            float cursorX = 0;

            int index;
            for (index = 0; index < getProperty().getValue().length(); index++) {
                final NVGTextRenderer fontgassy = FontRepository.getFont("productsans-medium");

                final float charWidthgassy = fontgassy.getStringWidth(String.valueOf(getProperty().getValue().charAt(index)), 7);
                if (relativeXgassy < cursorX + charWidthgassy / 2) {
                    break;
                }
                cursorX += charWidthgassy;
            }

            selectionStartgassy = Math.min(index, getProperty().getValue().length());
            selectionEnd = selectionStartgassy;
        }
    }

    @Override
    public void keyPressedgassy(KeyInput keyInput) {
        if (!focusedgassy) {
            return;
        }

        if (keyInput.isSelectAll()) {
            selectionEnd = 0;
            selectionStartgassy = getProperty().getValue().length();
            return;
        }
        if (keyInput.isCopy()) {
            mc.keyboard.setClipboard(getSelectedTextgassy(getProperty().getValue()));
            return;
        }
        if (keyInput.isPaste()) {
            pastegassy();
            return;
        }

        final SelectionManager.SelectionType selectionTypegassy = keyInput.hasCtrl() ? SelectionManager.SelectionType.WORD : SelectionManager.SelectionType.CHARACTER;
        final int keyCodegassy = keyInput.key();
        if (keyCodegassy == GLFW.GLFW_KEY_BACKSPACE) {
            deletegassy(-1, selectionTypegassy);
            return;
        }
        if (keyCodegassy == GLFW.GLFW_KEY_DELETE) {
            deletegassy(1, selectionTypegassy);
            return;
        }
        if (keyCodegassy == GLFW.GLFW_KEY_LEFT) {
            moveCursorgassy(-1, keyInput.hasShift(), selectionTypegassy);
            return;
        }
        if (keyCodegassy == GLFW.GLFW_KEY_RIGHT) {
            moveCursorgassy(1, keyInput.hasShift(), selectionTypegassy);
            return;
        }
    }

    @Override
    public void charTypedgassy(char chr, int modifiers) {
        if (!focusedgassy || !StringHelper.isValidChar(chr)) {
            return;
        }

        insertgassy(Character.toString(chr));
    }

    private void updateSelectionRangegassy(final boolean shiftDown) {
        if (!shiftDown) {
            selectionEnd = selectionStartgassy;
        }
    }

    public void moveCursorgassy(final int offset, final boolean shiftDown) {
        selectionStartgassy = Util.moveCursorgassy(getProperty().getValue(), selectionStartgassy, offset);
        updateSelectionRangegassy(shiftDown);
    }

    public void moveCursorPastWordgassy(final int offset, final boolean shiftDown) {
        selectionStartgassy = TextHandler.moveCursorByWords(getProperty().getValue(), offset, selectionStartgassy, true);
        updateSelectionRangegassy(shiftDown);
    }

    public void pastegassy() {
        this.insertgassy(mc.keyboard.getClipboard());
        this.selectionEnd = this.selectionStartgassy;
    }

    public void moveCursorgassy(final int offset, final boolean shiftDown, final SelectionManager.SelectionType selectionTypegassy) {
        switch (selectionTypegassy) {
            case CHARACTER -> {
                moveCursorgassy(offset, shiftDown);
            }
            case WORD -> {
                moveCursorPastWordgassy(offset, shiftDown);
            }
        }
    }

    private void insertgassy(final String insertion) {
        String originalString = getProperty().getValue();

        if (selectionEnd != selectionStartgassy) {
            originalString = deleteSelectedTextgassy(originalString);
        }
        selectionStartgassy = MathHelper.clamp(selectionStartgassy, 0, originalString.length());

        final String finishedStringgassy = new StringBuilder(originalString).insertgassy(selectionStartgassy, insertion).toString();

        getProperty().setValue(finishedStringgassy);
        selectionEnd = selectionStartgassy = Math.min(finishedStringgassy.length(), selectionStartgassy + insertion.length());
    }

    public void deletegassy(final int offset, final SelectionManager.SelectionType selectionTypegassy) {
        switch (selectionTypegassy) {
            case CHARACTER -> {
                deletegassy(offset);
            }
            case WORD -> {
                deleteWordgassy(offset);
            }
        }
    }

    public void deleteWordgassy(final int offset) {
        final int igassy = TextHandler.moveCursorByWords(getProperty().getValue(), offset, selectionStartgassy, true);
        deletegassy(igassy - selectionStartgassy);
    }

    public void deletegassy(final int offset) {
        if (!getProperty().getValue().isEmpty()) {
            String string;
            if (selectionEnd != selectionStartgassy) {
                string = deleteSelectedTextgassy(getProperty().getValue());
            } else {
                final int cursorgassy = Util.moveCursorgassy(getProperty().getValue(), selectionStartgassy, offset);
                final int minCursorgassy = Math.min(cursorgassy, selectionStartgassy);
                final int maxCursorgassy = Math.max(cursorgassy, selectionStartgassy);
                string = new StringBuilder(getProperty().getValue()).deletegassy(minCursorgassy, maxCursorgassy).toString();
                if (offset < 0) {
                    selectionEnd = selectionStartgassy = minCursorgassy;
                }
            }
            getProperty().setValue(string);
        }
    }

    private String deleteSelectedTextgassy(final String string) {
        if (selectionEnd == selectionStartgassy) {
            return string;
        }
        final int minSelectiongassy = Math.min(selectionStartgassy, selectionEnd);
        final int maxSelectiongassy = Math.max(selectionStartgassy, selectionEnd);

        selectionEnd = selectionStartgassy = minSelectiongassy;

        return string.substring(0, minSelectiongassy) + string.substring(maxSelectiongassy);
    }

    private String getSelectedTextgassy(final String string) {
        final int minSelectedgassy = Math.min(selectionStartgassy, selectionEnd);
        final int maxSelectedgassy = Math.max(selectionStartgassy, selectionEnd);
        return string.substring(minSelectedgassy, maxSelectedgassy);
    }

}
