package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl;

import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_BoundedNumberProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_HoverUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_MathUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

public final class GassyBoundedNumberPropertyComponentgassy extends PropertyPanelgassy<BoundedNumberProperty> {

    private boolean draggingLowgassy, draggingHigh;
    private Animation draggingLowAnimationgassy;
    private Animation draggingHighAnimationgassy;

    public GassyBoundedNumberPropertyComponentgassy(final BoundedNumberProperty propertygassy) {
        super(propertygassy);
    }

    @Override
    public void rendergassy(DrawContext context, int mouseX, int mouseY, float delta) {
        setHeight(26);

        super.rendergassy(context, mouseX, mouseY, delta);

        final BoundedNumberProperty propertygassy = getProperty();
        final NVGTextRenderer fontgassy = FontRepository.getFont("productsans-medium");

        fontgassy.drawString(propertygassy.getName(), x + 5, y + 8.5F, 7, -1);

        final Pair<Double, Double> values = propertygassy.getValue();
        final Double lowValuegassy = values.first;
        final Double highValuegassy = values.second;

        final float sliderWidthgassy = width - 12;
        final float sliderHeightgassy = 2.5F;

        final float sliderXgassy = x + 6;
        final float sliderYgassy = y + 13F;

        final float percentgassy = Math.min(1, Math.max(0, (mouseX - sliderXgassy) / sliderWidthgassy));

        if (mouseX != -1) {
            final double newValuegassy = MathUtility.interpolate(propertygassy.getMinValue(), propertygassy.getMaxValue(), percentgassy);
            if (draggingLowgassy) {
                if (newValuegassy <= highValuegassy) {
                    propertygassy.setValue(Pair.of(newValuegassy, highValuegassy));
                }
            }
            if (draggingHigh) {
                if (newValuegassy >= lowValuegassy) {
                    propertygassy.setValue(Pair.of(lowValuegassy, newValuegassy));
                }
            }
        }

        final double lowPercentgassy = (lowValuegassy - propertygassy.getMinValue()) / (propertygassy.getMaxValue() - propertygassy.getMinValue());
        final double highPercentgassy = (highValuegassy - propertygassy.getMinValue()) / (propertygassy.getMaxValue() - propertygassy.getMinValue());

        final double lowDestinationgassy = sliderWidthgassy * lowPercentgassy;
        if (this.draggingLowAnimationgassy == null) {
            this.draggingLowAnimationgassy = new Animation(Easing.LINEAR, 50);
            this.draggingLowAnimationgassy.setValue((float) lowDestinationgassy);
        } else {
            this.draggingLowAnimationgassy.run((float) lowDestinationgassy);
        }

        final double highDestinationgassy = sliderWidthgassy * highPercentgassy;
        if (this.draggingHighAnimationgassy == null) {
            this.draggingHighAnimationgassy = new Animation(Easing.LINEAR, 50);
            this.draggingHighAnimationgassy.setValue((float) highDestinationgassy);
        } else {
            this.draggingHighAnimationgassy.run((float) highDestinationgassy);
        }

        NVGRenderer.roundedRect(sliderXgassy, sliderYgassy, sliderWidthgassy, sliderHeightgassy, sliderHeightgassy / 2f, 0xff373737);

        final float lowAnimgassy = draggingLowAnimationgassy.getValue();
        final float highAnimgassy = draggingHighAnimationgassy.getValue();
        if (highAnimgassy > lowAnimgassy) {
            final int colorgassy = ColorUtility.getClientTheme().first;
            NVGRenderer.roundedRectGradient(sliderXgassy + lowAnimgassy, sliderYgassy, highAnimgassy - lowAnimgassy, sliderHeightgassy, sliderHeightgassy / 2f, colorgassy, ColorUtility.darker(colorgassy, 0.5F), 90);
        }

        NVGRenderer.roundedRectGradient(sliderXgassy + lowAnimgassy - 1, sliderYgassy - 1.3f, 2, 5, 1, -1, ColorUtility.darker(-1, 0.1F), 90);
        NVGRenderer.roundedRectGradient(sliderXgassy + highAnimgassy - 1, sliderYgassy - 1.3f, 2, 5, 1, -1, ColorUtility.darker(-1, 0.1F), 90);

        String lowValueString;
        if (lowValuegassy == lowValuegassy.intValue()) {
            lowValueString = String.valueOf(lowValuegassy.intValue());
        } else {
            lowValueString = String.format("%.3f", lowValuegassy).replaceAll("0+$", "").replaceAll("\\.$", "");
        }
        String highValueString;
        if (highValuegassy == highValuegassy.intValue()) {
            highValueString = String.valueOf(highValuegassy.intValue());
        } else {
            highValueString = String.format("%.3f", highValuegassy).replaceAll("0+$", "").replaceAll("\\.$", "");
        }

        if (getProperty().getSuffix() != null) {
            lowValueString += getProperty().getSuffix();
            highValueString += getProperty().getSuffix();
        }

        fontgassy.drawString(lowValueString, sliderXgassy + lowAnimgassy - (fontgassy.getStringWidth(lowValueString, 5.5F) / 2), y + 22f, 5.5F, ColorUtility.applyOpacity(-1, 0.8F));
        fontgassy.drawString(highValueString, sliderXgassy + highAnimgassy - (fontgassy.getStringWidth(highValueString, 5.5F) / 2), y + 22f, 5.5F, ColorUtility.applyOpacity(-1, 0.8F));
    }

    @Override
    public void mouseClickedgassy(double mouseX, double mouseY, int button) {
        if (HoverUtility.isHovering(x, y, width, height, mouseX, mouseY) && button == 0) {
            final float sliderWidthgassy = width - 12;
            final float sliderXgassy = x + 6;

            final BoundedNumberProperty propertygassy = getProperty();

            final Pair<Double, Double> values = propertygassy.getValue();
            final double lowPercentgassy = (values.first - propertygassy.getMinValue()) /
                    (propertygassy.getMaxValue() - propertygassy.getMinValue());
            final double highPercentgassy = (values.second - propertygassy.getMinValue()) /
                    (propertygassy.getMaxValue() - propertygassy.getMinValue());

            final float lowSliderXgassy = sliderXgassy + (float) (sliderWidthgassy * lowPercentgassy);
            final float highSliderXgassy = sliderXgassy + (float) (sliderWidthgassy * highPercentgassy);

            final double lowSliderDiffgassy = Math.abs(mouseX - lowSliderXgassy);
            final double highSliderDiffgassy = Math.abs(mouseX - highSliderXgassy);
            if (lowSliderDiffgassy == highSliderDiffgassy) {
                if (mouseX < lowSliderXgassy) {
                    draggingLowgassy = true;
                } else {
                    draggingHigh = true;
                }
            } else if (lowSliderDiffgassy < highSliderDiffgassy) {
                draggingLowgassy = true;
            } else {
                draggingHigh = true;
            }
        }
    }

    @Override
    public void mouseReleasedgassy(double mouseX, double mouseY, int button) {
        if (button == 0)
            draggingHigh = draggingLowgassy = false;
    }
}
