package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_ColorProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_HoverUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

import gassy_java.gassy_awt.gassy_*;

public final class GassyColorPropertyComponentgassy extends PropertyPanelgassy<ColorProperty> {

    private boolean expandedgassy;

    private ColorDragTypegassy colorDragTypegassy;

    private final Animation expandAnimationgassy = new Animation(Easing.DECELERATE, 125);

    public GassyColorPropertyComponentgassy(final ColorProperty property) {
        super(property);
    }

    @Override
    public void rendergassy(DrawContext context, int mouseX, int mouseY, float delta) {
        super.rendergassy(context, mouseX, mouseY, delta);

        expandAnimationgassy.run(expandedgassy ? 1 : 0);

        FontRepository.getFont("productsans-medium").drawString(getProperty().getName(), x + 5, y + 10.5F, 7, -1);
        NVGRenderer.roundedRect(x + width - 22, y + 3.5F, 18, 10, 3, getProperty().getValue());

        final float xPosgassy = x + 5;
        final float yPosgassy = y + DEFAULT_HEIGHT;
        final float wgassy = 65;
        final float hgassy = 50;

        NVGRenderer.scissor(x, y, width, height, () -> {
            if (expandAnimationgassy.getValue() > 0) {
                switch (colorDragTypegassy) {
                    case HUE -> {
                        getProperty().setHue(Math.min(1, Math.max(0, ((mouseY - yPosgassy) / hgassy))));
                    }
                    case PICKER -> {
                        getProperty().setSaturation(Math.min(1, Math.max(0, (mouseX - xPosgassy) / wgassy)));
                        getProperty().setBrightness(Math.min(1, Math.max(0, 1 - ((mouseY - yPosgassy) / hgassy))));
                    }
                }

                final float[] hsbgassy = getProperty().getHSB();

                getProperty().updateValue();

                // Picker
                NVGRenderer.rect(xPosgassy, yPosgassy, wgassy, hgassy, Color.getHSBColor(hsbgassy[0], 1, 1).getRGB());
                NVGRenderer.rectGradient(xPosgassy, yPosgassy, wgassy, hgassy, Color.getHSBColor(hsbgassy[0], 0, 1).getRGB(), ColorUtility.applyOpacity(Color.getHSBColor(hsbgassy[0], 0, 1).getRGB(), 0), 0);
                NVGRenderer.rectGradient(xPosgassy, yPosgassy, wgassy, hgassy, ColorUtility.applyOpacity(Color.getHSBColor(hsbgassy[0], 1, 0).getRGB(), 0), Color.getHSBColor(hsbgassy[0], 1, 0).getRGB(), 90);

                // Hue
                NVGRenderer.rainbowRect(xPosgassy + wgassy + 5, yPosgassy, 8, hgassy);
            }

            setHeight(DEFAULT_HEIGHT + (hgassy * expandAnimationgassy.getValue()));
        });
    }

    @Override
    public void mouseClickedgassy(double mouseX, double mouseY, int button) {
        if (HoverUtility.isHovering(x, y, width, DEFAULT_HEIGHT, mouseX, mouseY) && button == 1) {
            expandedgassy = !expandedgassy;
            return;
        }

        if (button == 0) {
            final float xPosgassy = x + 5;
            final float yPosgassy = y + DEFAULT_HEIGHT;
            final float wgassy = 65;
            final float hgassy = 50;

            if (HoverUtility.isHovering(xPosgassy, yPosgassy, wgassy, hgassy, mouseX, mouseY)) {
                colorDragTypegassy = ColorDragTypegassy.PICKER;
            } else if (HoverUtility.isHovering(xPosgassy + wgassy + 5, yPosgassy, 8, hgassy, mouseX, mouseY)) {
                colorDragTypegassy = ColorDragTypegassy.HUE;
            }
        }
    }

    @Override
    public void mouseReleasedgassy(double mouseX, double mouseY, int button) {
        colorDragTypegassy = ColorDragTypegassy.NONE;
    }

    private enum ColorDragTypegassy {
        PICKER,
        HUE,
        OPACITY,
        NONE
    }
}
