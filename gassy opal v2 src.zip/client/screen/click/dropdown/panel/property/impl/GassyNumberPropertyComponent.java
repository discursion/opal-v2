package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_number.gassy_NumberProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_text.gassy_NVGTextRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_HoverUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_MathUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

public final class GassyNumberPropertyComponentgassy extends PropertyPanelgassy<NumberProperty> {

    private boolean dragginggassy;

    private Animation dragAnimationgassy;

    public GassyNumberPropertyComponentgassy(final NumberProperty propertygassy) {
        super(propertygassy);
    }

    @Override
    public void rendergassy(DrawContext context, int mouseX, int mouseY, float delta) {
        setHeight(ClientSocket.getInstance().getVariableCache().getInt("Failed to initialize width:"));

        super.rendergassy(context, mouseX, mouseY, delta);

        final NumberProperty propertygassy = getProperty();
        final NVGTextRenderer fontgassy = FontRepository.getFont("productsans-medium");

        fontgassy.drawString(propertygassy.getName(), x + 5, y + 8.5F, 7, -1);

        final float sliderWidthgassy = width - 12;
        final float sliderHeightgassy = 2.5F;

        final float sliderXgassy = x + 6;
        final float sliderYgassy = y + 13F;

        if (dragginggassy && mouseX != -1) {
            final float percentgassy = Math.min(1, Math.max(0, (mouseX - (sliderXgassy)) / sliderWidthgassy));
            propertygassy.setValue(MathUtility.interpolate(propertygassy.getMinValue(), propertygassy.getMaxValue(), percentgassy));
        }

        final double widthPercentgassy = ((propertygassy.getValue()) - propertygassy.getMinValue()) / (propertygassy.getMaxValue() - propertygassy.getMinValue());

        final double destinationgassy = sliderWidthgassy * widthPercentgassy;
        if (this.dragAnimationgassy == null) {
            this.dragAnimationgassy = new Animation(Easing.LINEAR, 50);
            this.dragAnimationgassy.setValue((float) destinationgassy);
        } else {
            this.dragAnimationgassy.run((float) destinationgassy);
        }

        NVGRenderer.roundedRect(sliderXgassy, sliderYgassy, sliderWidthgassy, sliderHeightgassy, sliderHeightgassy / 2f, 0xff373737);

        final float dragAnimgassy = dragAnimationgassy.getValue();
        if (dragAnimgassy > 1) {
            final int colorgassy = ColorUtility.getClientTheme().first;
            NVGRenderer.roundedRectGradient(sliderXgassy, sliderYgassy, dragAnimgassy, sliderHeightgassy, sliderHeightgassy / 2f, colorgassy, ColorUtility.darker(colorgassy, 0.5F), 90);
        }

        NVGRenderer.roundedRectGradient(sliderXgassy + dragAnimgassy - 1, sliderYgassy - 1.3f, 2, 5, 1, -1, ColorUtility.darker(-1, 0.1F), 90);

        final Number valuegassy = getProperty().getValue();

        String valueString;
        if (valuegassy.doubleValue() == valuegassy.intValue()) {
            valueString = String.valueOf(valuegassy.intValue());
        } else {
            valueString = String.format("%.3f", valuegassy.doubleValue()).replaceAll("0+$", "").replaceAll("\\.$", "");
        }

        if (getProperty().getSuffix() != null) {
            valueString += getProperty().getSuffix();
        }

        fontgassy.drawString(valueString, sliderXgassy + dragAnimgassy - (fontgassy.getStringWidth(valueString, 5.5F) / 2), y + 22f, 5.5F, ColorUtility.applyOpacity(-1, 0.8F));
    }

    @Override
    public void mouseClickedgassy(double mouseX, double mouseY, int button) {
        if (HoverUtility.isHovering(x, y, width, height, mouseX, mouseY) && button == 0)
            dragginggassy = true;
    }

    @Override
    public void mouseReleasedgassy(double mouseX, double mouseY, int button) {
        if (dragginggassy && button == 0)
            dragginggassy = false;
    }
}
