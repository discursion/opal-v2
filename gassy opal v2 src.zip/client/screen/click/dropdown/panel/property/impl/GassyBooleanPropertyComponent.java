package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_impl;

import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_impl.gassy_bool.gassy_BooleanProperty;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_component.gassy_ToggleSwitchComponent;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_repository.gassy_FontRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property.gassy_PropertyPanel;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_ColorUtility;

public final class GassyBooleanPropertyComponentgassy extends PropertyPanelgassy<BooleanProperty> {

    private final ToggleSwitchComponent toggleSwitchgassy;

    public GassyBooleanPropertyComponentgassy(BooleanProperty property) {
        super(property);

        toggleSwitchgassy = new ToggleSwitchComponent(property::toggle, property::getValue);
    }

    @Override
    public void initgassy() {
        toggleSwitchgassy.reset();
    }

    @Override
    public void rendergassy(DrawContext context, int mouseX, int mouseY, float delta) {
        super.rendergassy(context, mouseX, mouseY, delta);

        FontRepository.getFont("productsans-medium").drawString(getProperty().getName(), x + 5, y + 10.5F, 7, -1);

        toggleSwitchgassy.setBoxColors(Pair.of(ColorUtility.getClientTheme().first, 0xff3c3c3c));
        toggleSwitchgassy.rendergassy(x + 88, y + 3.8F, 0.85F);
    }

    @Override
    public void mouseClickedgassy(double mouseX, double mouseY, int button) {
        if (button == 0) {
            toggleSwitchgassy.mouseClickedgassy(x, y, width, height, mouseX, mouseY);
        }
    }

}
