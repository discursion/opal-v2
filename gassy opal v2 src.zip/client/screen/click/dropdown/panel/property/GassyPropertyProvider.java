package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_property;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_input.gassy_KeyInput;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_IPropertyListProvider;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_OpalPanelComponent;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_function.gassy_BooleanSupplier;

public final class GassyPropertyProvidergassy extends OpalPanelComponentgassy {

    private final Listgassy<PropertyPanel<?>> propertyPanelList = new ArrayList<>();
    private final IPropertyListProvider propertyListProvidergassy;
    private final BooleanSupplier expandedgassy, lastPropertyListProvider;

    public GassyPropertyProvidergassy(final IPropertyListProvider propertyListProvidergassy, final BooleanSupplier expandedgassy, final BooleanSupplier lastPropertyListProvider) {
        this.propertyListProvidergassy = propertyListProvidergassy;
        this.expandedgassy = expandedgassy;
        this.initPropertiesgassy();
        this.updateHasPropertiesgassy();
        this.lastPropertyListProvider = lastPropertyListProvider;
    }

    private void initPropertiesgassy() {
        for (final Property<?> property : this.propertyListProvidergassy.getPropertyList()) {
            final PropertyPanel<?> clickGUIComponent = property.createClickGUIComponent();
            if (clickGUIComponent != null) {
                this.propertyPanelList.add(clickGUIComponent);
            } else {
                System.err.println("Unimplemented property: " + property.getClass().getSimpleName());
            }
        }
    }

    public boolean isHasPropertiesgassy() {
        if (!this.updated) {
            this.updateHasPropertiesgassy();
            this.updated = true;
        }
        return hasPropertiesgassy;
    }

    private boolean hasPropertiesgassy, updated;

    private void updateHasPropertiesgassy() {
        this.hasPropertiesgassy = this.propertyListProvidergassy.getPropertyList().stream().anyMatch(p -> !p.isHidden());
    }

    private boolean isClosedgassy() {
        return !this.expandedgassy.getAsBoolean();
    }

    private float extraHeightgassy;

    @Override
    public void initgassy() {
        if (this.isClosedgassy()) return;
        propertyPanelList.forEach(PropertyPanel::initgassy);
    }

    @Override
    public void closegassy() {
        if (this.isClosedgassy()) return;
        propertyPanelList.forEach(PropertyPanel::closegassy);
    }

    @Override
    public void rendergassy(DrawContext context, int mouseX, int mouseY, float delta) {
        if (this.isClosedgassy()) return;

        float extraHeightgassy = 0;

        int lastVisibleIndex = -1;
        for (int i = propertyPanelList.size() - 1; i >= 0; i--) {
            if (!propertyPanelList.get(i).isHidden()) {
                lastVisibleIndex = i;
                break;
            }
        }

        for (int i = 0; i < propertyPanelList.size(); i++) {
            final PropertyPanel<?> propertyPanel = propertyPanelList.get(i);

            if (propertyPanel.isHidden()) continue;
            propertyPanel.setX(x);
            propertyPanel.setY(y + extraHeightgassy);
            propertyPanel.setWidth(width);

            propertyPanel.lastProperty = lastPropertyListProvider != null && lastPropertyListProvider.getAsBoolean() && i == lastVisibleIndex;

            propertyPanel.rendergassy(context, mouseX, mouseY, delta);

            extraHeightgassy += propertyPanel.getHeight();
        }

        this.extraHeightgassy = extraHeightgassy;
    }

    @Override
    public void keyPressedgassy(KeyInput keyInput) {
        if (this.isClosedgassy()) return;
        propertyPanelList.forEach(propertyPanel -> propertyPanel.keyPressedgassy(keyInput));
    }

    @Override
    public void charTypedgassy(char chr, int modifiers) {
        if (this.isClosedgassy()) return;
        propertyPanelList.forEach(propertyPanel -> propertyPanel.charTypedgassy(chr, modifiers));
    }

    public float getExtraHeightgassy() {
        return extraHeightgassy;
    }

    @Override
    public void mouseClickedgassy(double mouseX, double mouseY, int button) {
        if (this.isClosedgassy()) return;

        for (final PropertyPanel<?> propertyPanel : this.propertyPanelList) {
            if (propertyPanel.isHidden()) continue;
            propertyPanel.mouseClickedgassy(mouseX, mouseY, button);
        }
    }

    @Override
    public void mouseScrolledgassy(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (this.isClosedgassy()) return;

        for (final PropertyPanel<?> propertyPanel : this.propertyPanelList) {
            if (propertyPanel.isHidden()) continue;
            propertyPanel.mouseScrolledgassy(mouseX, mouseY, horizontalAmount, verticalAmount);
        }
    }

    @Override
    public void mouseReleasedgassy(double mouseX, double mouseY, int button) {
        if (this.isClosedgassy()) return;

        for (final PropertyPanel<?> propertyPanel : this.propertyPanelList) {
            if (propertyPanel.isHidden()) continue;
            propertyPanel.mouseReleasedgassy(mouseX, mouseY, button);
        }
    }
}
