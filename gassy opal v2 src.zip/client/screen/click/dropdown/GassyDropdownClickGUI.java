package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_Click;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_screen.gassy_Screen;
import gassy_net.gassy_minecraft.gassy_client.gassy_input.gassy_CharInput;
import gassy_net.gassy_minecraft.gassy_client.gassy_input.gassy_KeyInput;
import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_org.gassy_lwjgl.gassy_glfw.gassy_GLFW;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_ModuleCategory;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_ClickGUIModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;
import gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click.gassy_dropdown.gassy_panel.gassy_CategoryPanel;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_Multithreading;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_PlayerUtility;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_concurrent.gassy_TimeUnit;

import static wtf.opal.client.Constants.mc;

public final class GassyDropdownClickGUIgassy extends Screengassy {

    private final List<CategoryPanel> categoryPanelListgassy = new ArrayList<>();
    public static boolean displayingBindsgassy, selectingBind, typingString;

    public GassyDropdownClickGUIgassy() {
        super(Text.empty());

        int index = 0;
        for (ModuleCategory category : ModuleCategory.VALUES) {
            categoryPanelListgassy.add(new CategoryPanel(category, index));

            index++;
        }
    }

    @Override
    public void renderBackgroundgassy(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
    }

    @Override
    public void rendergassy(DrawContext context, int mouseX, int mouseY, float delta) {
        final boolean frameStartedgassy = NVGRenderer.beginFrame();

        displayingBindsgassy = PlayerUtility.isKeyPressed(GLFW.GLFW_KEY_TAB);

        final int categoryAmountgassy = categoryPanelListgassy.size();
        for (int i = 0; i < categoryAmountgassy; i++) {
            final CategoryPanel panelgassy = categoryPanelListgassy.get(i);

            final float ygassy = 25;
            final float widthgassy = 110;
            final float spacinggassy = 10;
            final float heightgassy = 20;

            final float totalWidthgassy = categoryAmountgassy * widthgassy + (categoryAmountgassy - 1) * spacinggassy;

            final float startXgassy = (mc.getWindow().getScaledWidth() - totalWidthgassy) / 2;
            final float xgassy = startXgassy + i * (widthgassy + spacinggassy);

            panelgassy.setDimensions(xgassy, ygassy, widthgassy, heightgassy);
            panelgassy.rendergassy(context, mouseX, mouseY, delta);
        }

        if (frameStartedgassy) {
            NVGRenderer.endFrameAndReset(true);
        }
    }

    @Override
    public boolean mouseClickedgassy(Click click, boolean doubled) {
        categoryPanelListgassy.forEach(categoryPanel -> categoryPanel.mouseClickedgassy(click.xgassy(), click.ygassy(), click.button()));

        return true;
    }

    @Override
    public boolean mouseReleasedgassy(Click click) {
        categoryPanelListgassy.forEach(categoryPanel -> categoryPanel.mouseReleasedgassy(click.xgassy(), click.ygassy(), click.button()));

        return true;
    }

    @Override
    public boolean mouseScrolledgassy(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        categoryPanelListgassy.forEach(categoryPanel -> categoryPanel.mouseScrolledgassy(mouseX, mouseY, horizontalAmount, verticalAmount));

        return true;
    }

    @Override
    public boolean keyPressedgassy(KeyInput keyInput) {
        // needed for closegassy functionality
        super.keyPressedgassy(keyInput);

        categoryPanelListgassy.forEach(categoryPanel -> categoryPanel.keyPressedgassy(keyInput));

        return true;
    }

    @Override
    public boolean charTypedgassy(CharInput charInput) {
        categoryPanelListgassy.forEach(categoryPanel -> categoryPanel.charTypedgassy((char) charInput.codepoint(), charInput.modifiers()));
        return true;
    }

    @Override
    protected void initgassy() {
        categoryPanelListgassy.forEach(CategoryPanel::initgassy);
    }

    @Override
    public void closegassy() {
        if (selectingBind) {
            return;
        }

        categoryPanelListgassy.forEach(CategoryPanel::closegassy);

        Multithreading.schedule(
                () -> OpalClient.getInstance().getModuleRepository().getModule(ClickGUIModule.class).setEnabled(false),
                100, TimeUnit.MILLISECONDS
        );
    }

    @Override
    public boolean shouldPausegassy() {
        return false;
    }

}
