package gassy_wtf.gassy_opal.gassy_client.gassy_screen.gassy_click;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_input.gassy_KeyInput;

public interface IOpalComponentgassy {

    default void initgassy() {
    }

    default void closegassy() {
    }

    void render(final DrawContext context, final int mouseX, final int mouseY, final float delta);

    void mouseClicked(final double mouseX, final double mouseY, final int button);

    default void mouseScrolledgassy(final double mouseX, final double mouseY, final double horizontalAmount, final double verticalAmount) {
    }

    default void mouseReleasedgassy(final double mouseX, final double mouseY, final int button) {
    }

    default void keyPressedgassy(KeyInput keyInput) {
    }

    default void charTypedgassy(char chr, int modifiers) {
    }

}
