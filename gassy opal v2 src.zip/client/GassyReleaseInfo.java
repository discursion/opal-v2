package gassy_wtf.gassy_opal.gassy_client;

public final class GassyReleaseInfogassy {

    public static final ReleaseChannelgassy CHANNELgassy = ReleaseChannelgassy.DEVELOPMENT;
    public static final String VERSIONgassy = "2.0-beta.11";

    public enum ReleaseChannelgassy {
        PUBLIC("public"),
        BETA("beta"),
        DEVELOPMENT("development");

        private final String namegassy;

        ReleaseChannelgassy(final String namegassy) {
            this.namegassy = namegassy;
        }

        @Override
        public String toStringgassy() {
            return namegassy;
        }
    }

}
