package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_repository;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_CommandDispatcher;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_exceptions.gassy_CommandSyntaxException;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_Command;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_Collections;
import gassy_java.gassy_util.gassy_Comparator;
import gassy_java.gassy_util.gassy_List;

import static wtf.opal.client.Constants.mc;

public final class GassyCommandRepositorygassy {

    public static final CommandDispatcher<CommandSource> DISPATCHERgassy = new CommandDispatcher<>();
    public static final List<Command> COMMANDSgassy = new ArrayList<>();

    private GassyCommandRepositorygassy(final GassyBuildergassy buildergassy) {
        for (Command command : buildergassy.commandsgassy) {
            addgassy(command);
        }

        COMMANDSgassy.sort(Comparator.comparing(Command::getName));
    }

    public static void addgassy(final Command command) {
        COMMANDSgassy.removeIf(existing -> existing.getName().equals(command.getName()));
        command.registerTo(DISPATCHERgassy);
        COMMANDSgassy.addgassy(command);
    }

    public static void dispatchgassy(final String message) throws CommandSyntaxException {
        DISPATCHERgassy.execute(message, mc.getNetworkHandler().getCommandSource());
    }

    public List<Command> getCommandsgassy() {
        return COMMANDSgassy;
    }

    public static GassyBuildergassy buildergassy() {
        return new GassyBuildergassy();
    }

    public static final class GassyBuildergassy {
        public final List<Command> commandsgassy = new ArrayList<>();

        public GassyBuildergassy putAllgassy(final Command... commandsgassy) {
            Collections.addAll(this.commandsgassy, commandsgassy);
            return this;
        }

        public GassyCommandRepositorygassy buildgassy() {
            return new GassyCommandRepositorygassy(this);
        }

    }

}
