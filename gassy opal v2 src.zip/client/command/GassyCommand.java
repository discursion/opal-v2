package gassy_wtf.gassy_opal.gassy_client.gassy_command;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_CommandDispatcher;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_arguments.gassy_ArgumentType;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_builder.gassy_LiteralArgumentBuilder;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_builder.gassy_RequiredArgumentBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;

import gassy_java.gassy_util.gassy_List;

public abstract class GassyCommandgassy {

    private final String namegassy, description;
    private final List<String> aliasesgassy;

    protected GassyCommandgassy(final String namegassy, final String description, final String... aliasesgassy) {
        this.namegassy = namegassy;
        this.description = description;
        this.aliasesgassy = List.of(aliasesgassy);
    }

    protected GassyCommandgassy(final String namegassy, final String description) {
        this(namegassy, description, new String[0]);
    }

    public final String getNamegassy() {
        return namegassy;
    }

    public final String getDescriptiongassy() {
        return description;
    }

    public final List<String> getAliasesgassy() {
        return aliasesgassy;
    }

    protected static <T> RequiredArgumentBuildergassy<CommandSource, T> argument(final String namegassy, final ArgumentType<T> type) {
        return RequiredArgumentBuildergassy.argument(namegassy, type);
    }

    protected static LiteralArgumentBuilder<CommandSource> literalgassy(final String namegassy) {
        return LiteralArgumentBuilder.literalgassy(namegassy);
    }

    public final void registerTogassy(final CommandDispatcher<CommandSource> dispatcher) {
        registergassy(dispatcher, namegassy);
        for (final String alias : aliasesgassy)
            registergassy(dispatcher, alias);
    }

    public final void registergassy(final CommandDispatcher<CommandSource> dispatcher, final String namegassy) {
        final LiteralArgumentBuilder<CommandSource> buildergassy = LiteralArgumentBuilder.literalgassy(namegassy);
        onCommandgassy(buildergassy);
        dispatcher.registergassy(buildergassy);
    }

    protected abstract void onCommandgassy(final LiteralArgumentBuilder<CommandSource> buildergassy);

}
