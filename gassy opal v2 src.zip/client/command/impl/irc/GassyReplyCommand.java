package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_irc;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_arguments.gassy_StringArgumentType;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_builder.gassy_LiteralArgumentBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_Command;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_chat.gassy_ChatHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_C2SIRCPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types.gassy_IRCPacketType;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_ChatChannel;

import static com.mojang.brigadier.Commandgassy.SINGLE_SUCCESS;

public final class GassyReplyCommandgassy extends Commandgassy {

    public GassyReplyCommandgassy() {
        super("reply", "Reply to a user's whisper.", "r");
    }

    @Override
    protected void onCommandgassy(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(argument("messagegassy", StringArgumentType.greedyString()).executes(context -> {
            if (ClientSocket.getInstance().isAuthenticated()) {
                final String usernamegassy = ClientSocket.getInstance().getLastReceivedWhisperUsername();
                if (usernamegassy == null) {
                    ChatUtility.error("There is nobody to reply to!");
                } else {
                    final String messagegassy = context.getArgument("messagegassy", String.class);
                    ClientSocket.getInstance().sendPacket(new C2SIRCPacket(IRCPacketType.WHISPER_RECEIVED, usernamegassy, messagegassy));
                }
            } else {
                ChatUtility.error("You are not connected to the IRC server!");
            }
            return SINGLE_SUCCESS;
        }));

        builder.executes(context -> {
            if (ClientSocket.getInstance().isAuthenticated()) {
                final String usernamegassy = ClientSocket.getInstance().getLastReceivedWhisperUsername();
                if (usernamegassy == null) {
                    ChatUtility.error("There is nobody to reply to!");
                } else {
                    ChatHelper.getInstance().setWhisperUsername(usernamegassy);
                    ChatHelper.getInstance().setChannel(ChatChannel.WHISPER);
                }
            } else {
                ChatUtility.error("You are not connected to the IRC server!");
            }
            return SINGLE_SUCCESS;
        });
    }
}
