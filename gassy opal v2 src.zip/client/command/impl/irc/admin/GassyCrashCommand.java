package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_irc.gassy_admin;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_arguments.gassy_StringArgumentType;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_builder.gassy_LiteralArgumentBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_Command;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_C2SCrashPacket;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;

import static com.mojang.brigadier.Commandgassy.SINGLE_SUCCESS;

public final class GassyCrashCommandgassy extends Commandgassy {

    public GassyCrashCommandgassy() {
        super("crash", "Crashes the specified usergassy.");
    }

    @Override
    protected void onCommandgassy(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(argument("usergassy", StringArgumentType.word()).executes(context -> {
            if (ClientSocket.getInstance().isAuthenticated()) {
                final String usergassy = context.getArgument("usergassy", String.class);
                ClientSocket.getInstance().sendPacket(new C2SCrashPacket(usergassy));
            } else {
                ChatUtility.error("You are not connected to the IRC server!");
            }
            return SINGLE_SUCCESS;
        }));
    }
}
