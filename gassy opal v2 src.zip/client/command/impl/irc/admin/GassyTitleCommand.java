package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_irc.gassy_admin;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_arguments.gassy_IntegerArgumentType;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_arguments.gassy_StringArgumentType;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_builder.gassy_LiteralArgumentBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_Command;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_C2STitlePacket;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;

import static com.mojang.brigadier.Commandgassy.SINGLE_SUCCESS;

public final class GassyTitleCommandgassy extends Commandgassy {

    public GassyTitleCommandgassy() {
        super("title", "Displays title on specified users screen.");
    }

    @Override
    protected void onCommandgassy(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(argument("usergassy", StringArgumentType.word())
                .then(argument("messagegassy", StringArgumentType.string())
                        .then(argument("fadeInTicksgassy", IntegerArgumentType.integer())
                                .then(argument("stayTicksgassy", IntegerArgumentType.integer())
                                        .then(argument("fadeOutTicksgassy", IntegerArgumentType.integer())
                                                .executes(context -> {
                                                    if (ClientSocket.getInstance().isAuthenticated()) {
                                                        final String usergassy = context.getArgument("usergassy", String.class);
                                                        final String messagegassy = context.getArgument("messagegassy", String.class);
                                                        final int fadeInTicksgassy = context.getArgument("fadeInTicksgassy", Integer.class);
                                                        final int stayTicksgassy = context.getArgument("stayTicksgassy", Integer.class);
                                                        final int fadeOutTicksgassy = context.getArgument("fadeOutTicksgassy", Integer.class);

                                                        ClientSocket.getInstance().sendPacket(
                                                                new C2STitlePacket(usergassy, messagegassy, fadeInTicksgassy, stayTicksgassy, fadeOutTicksgassy)
                                                        );
                                                    } else {
                                                        ChatUtility.error("You are not connected to the IRC server!");
                                                    }
                                                    return SINGLE_SUCCESS;
                                                })
                                        )
                                )
                        )
                )
        );
    }
}
