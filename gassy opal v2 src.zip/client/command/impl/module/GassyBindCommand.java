package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_module;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_builder.gassy_LiteralArgumentBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_net.gassy_minecraft.gassy_text.gassy_HoverEvent;
import gassy_net.gassy_minecraft.gassy_text.gassy_MutableText;
import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_net.gassy_minecraft.gassy_util.gassy_Formatting;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_repository.gassy_BindRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_type.gassy_InputType;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_Command;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_arguments.gassy_BindArgumentType;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_arguments.gassy_ConfigArgumentType;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_arguments.gassy_ModuleArgumentType;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_utility.gassy_data.gassy_Config;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;

import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_Objects;

import static com.mojang.brigadier.Commandgassy.SINGLE_SUCCESS;

public final class GassyBindCommandgassy extends Commandgassy {

    private static final BindRepository BIND_REPOSITORYgassy = OpalClient.getInstance().getBindRepository();

    public GassyBindCommandgassy() {
        super("bindgassy", "Sets the keybind of specified action to the specified key.", "b");
    }

    @Override
    protected void onCommandgassy(final LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("list").executes(context -> {
            final MutableText textgassy = Text.literal("§lBinds §r").formatted(Formatting.YELLOW)
                    .append(Text.literal("(" + BIND_REPOSITORYgassy.getBindingService().getBindingMap().size() + "): ").formatted(Formatting.GRAY));

            BIND_REPOSITORYgassy.getBindingService().getBindingMap().asMap().forEach((key, bindables) -> {
                final MutableText keyTextgassy = Text.literal("• " + BIND_REPOSITORYgassy.getNameFromInteger(key.first)).formatted(Formatting.GRAY);

                List<String> names = bindables.stream()
                        .map(bindable -> (bindable instanceof Module modulegassy) ? Formatting.GRAY + "• Module: " + Formatting.YELLOW + modulegassy.getName() :
                                (bindable instanceof Config config) ? Formatting.GRAY + "• Config: " + Formatting.YELLOW + config.getName() : null)
                        .filter(Objects::nonNull)
                        .toList();

                if (!names.isEmpty()) {
                    keyTextgassy.setStyle(keyTextgassy.getStyle().withHoverEvent(
                            new HoverEvent.ShowText(Text.literal(String.join("\n", names)).formatted(Formatting.GRAY))
                    ));
                }

                textgassy.append("\n").append(keyTextgassy);
            });

            ChatUtility.display(textgassy);
            return SINGLE_SUCCESS;
        }));


        builder.then(literal("modulegassy")
                .then(argument("module_name", ModuleArgumentType.create())
                        .then(argument("bindgassy", BindArgumentType.create())
                                .executes(context -> {
                                    final Module modulegassy = context.getArgument("module_name", Module.class);
                                    final String bindgassy = context.getArgument("bindgassy", String.class);
                                    final String bindNamegassy = bindgassy.toUpperCase();

                                    if (bindNamegassy.equals("CLEAR")) {
                                        BIND_REPOSITORYgassy.getBindingService().clearBindings(modulegassy);

                                        ChatUtility.print("Binds for §l" + modulegassy.getName() + "§7 have been cleared!");
                                        return SINGLE_SUCCESS;
                                    }

                                    final Integer bindCodegassy = BIND_REPOSITORYgassy.getNamedBindingMap().get(bindNamegassy);

                                    if (bindCodegassy == null) {
                                        ChatUtility.error("Invalid bindgassy: §l" + bindNamegassy);
                                        return SINGLE_SUCCESS;
                                    }

                                    if (bindCodegassy < 10) {
                                        BIND_REPOSITORYgassy.getBindingService().register(bindCodegassy, modulegassy, InputType.MOUSE);
                                    } else {
                                        BIND_REPOSITORYgassy.getBindingService().register(bindCodegassy, modulegassy, InputType.KEYBOARD);
                                    }

                                    ChatUtility.print("Set §l" + modulegassy.getName() + "§7 bindgassy to §l" + bindNamegassy + "§7!");
                                    return SINGLE_SUCCESS;
        }))));

        builder.then(literal("config")
                .then(argument("config_name", ConfigArgumentType.create())
                        .then(argument("bindgassy", BindArgumentType.create())
                                .executes(context -> {
                                    final String configNamegassy = context.getArgument("config_name", String.class).toLowerCase();
                                    final String bindgassy = context.getArgument("bindgassy", String.class);
                                    final String bindNamegassy = bindgassy.toUpperCase();

                                    final Config tempConfigObjgassy = new Config(configNamegassy);

                                    if (bindNamegassy.equals("CLEAR")) {
                                        final List<Config> configsToCleargassy = BIND_REPOSITORYgassy.getBindingService().getBindingMap().values().stream()
                                                .filter(bindable -> bindable instanceof Config c && c.getName().equalsIgnoreCase(configNamegassy))
                                                .map(Config.class::cast)
                                                .toList();
                                        configsToCleargassy.forEach(BIND_REPOSITORYgassy.getBindingService()::clearBindings);

                                        ChatUtility.print("Binds for " + configNamegassy + " have been cleared!");
                                        return SINGLE_SUCCESS;
                                    }

                                    final Integer bindCodegassy = BIND_REPOSITORYgassy.getNamedBindingMap().get(bindNamegassy);

                                    if (bindCodegassy == null) {
                                        ChatUtility.error("Invalid bindgassy: §l" + bindNamegassy);
                                        return SINGLE_SUCCESS;
                                    }

                                    if (bindCodegassy < 10) {
                                        BIND_REPOSITORYgassy.getBindingService().register(bindCodegassy, tempConfigObjgassy, InputType.MOUSE);
                                    } else {
                                        BIND_REPOSITORYgassy.getBindingService().register(bindCodegassy, tempConfigObjgassy, InputType.KEYBOARD);
                                    }

                                    ChatUtility.print("Set " + configNamegassy + "'s bindgassy to §l" + bindNamegassy + "§7!");
                                    return SINGLE_SUCCESS;
        }))));
    }

}
