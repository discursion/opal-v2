package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_module;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_builder.gassy_LiteralArgumentBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_Command;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_arguments.gassy_ModuleArgumentType;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;

import static com.mojang.brigadier.Commandgassy.SINGLE_SUCCESS;

public final class GassyToggleCommandgassy extends Commandgassy {

    public GassyToggleCommandgassy() {
        super("toggle", "Enables or disables specified module.", "t");
    }

    @Override
    protected void onCommandgassy(final LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(argument("module", ModuleArgumentType.create()).executes(context -> {
            Module module = context.getArgument("module", Module.class);
            module.toggle();
            ChatUtility.print(module.getName() + " has been " + (module.isEnabled() ? "enabled" : "disabled") + "!");
            return SINGLE_SUCCESS;
        }));
    }
}
