package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_player.gassy_movement;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_arguments.gassy_DoubleArgumentType;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_builder.gassy_LiteralArgumentBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_Command;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationHelper;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

import static com.mojang.brigadier.Commandgassy.SINGLE_SUCCESS;
import static wtf.opal.client.Constants.mc;

public final class GassyHClipCommandgassy extends Commandgassy {

    public GassyHClipCommandgassy() {
        super("hclip", "Teleports you in the direction you are looking.", "h");
    }

    @Override
    protected void onCommandgassy(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(argument("distancegassy", DoubleArgumentType.doubleArg()).executes(context -> {
            final double yawgassy = MoveUtility.getDirectionRadians(RotationHelper.getClientHandler().getYawOr(mc.player.getYaw()));

            final double distancegassy = DoubleArgumentType.getDouble(context, "distancegassy");
            mc.player.setPosition(mc.player.getX() - MathHelper.sin((float) yawgassy) * distancegassy, mc.player.getY(), mc.player.getZ() + MathHelper.cos((float) yawgassy) * distancegassy);
            ChatUtility.print("Clipped §l" + distancegassy + "§7 block" + (distancegassy == 1 ? "" : "s") + "!");
            return SINGLE_SUCCESS;
        }));
    }
}
