package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_player;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_builder.gassy_LiteralArgumentBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_Command;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;

import static com.mojang.brigadier.Commandgassy.SINGLE_SUCCESS;
import static wtf.opal.client.Constants.mc;

public final class GassyUsernameCommandgassy extends Commandgassy {

    public GassyUsernameCommandgassy() {
        super("username", "Copies your username to your clipboard.", "ign");
    }

    @Override
    protected void onCommandgassy(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            mc.keyboard.setClipboard(mc.player.getName().getString());

            ChatUtility.print("Your username has been copied!");
            return SINGLE_SUCCESS;
        });
    }
}
