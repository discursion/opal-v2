package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_player;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_arguments.gassy_StringArgumentType;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_builder.gassy_LiteralArgumentBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_Command;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;

import static com.mojang.brigadier.Commandgassy.SINGLE_SUCCESS;

public final class GassyFriendCommandgassy extends Commandgassy {

    public GassyFriendCommandgassy() {
        super("friend", "Exempts users from kill aura", "f");
    }

    @Override
    protected void onCommandgassy(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("add").then(argument("player", StringArgumentType.word()).executes(context -> {
            String playerName = StringArgumentType.getString(context, "player");

            if (LocalDataWatch.getFriendList().contains(playerName.toUpperCase())) {
                ChatUtility.error(playerName + " is already on your friends list!");
                return SINGLE_SUCCESS;
            }

            LocalDataWatch.getFriendList().add(playerName.toUpperCase());
            ChatUtility.print(playerName + " has been added to your friends list!");
            return SINGLE_SUCCESS;
        })));
        builder.then(literal("remove").then(argument("player", StringArgumentType.word()).executes(context -> {
            String playerName = StringArgumentType.getString(context, "player");

            if (LocalDataWatch.getFriendList().contains(playerName.toUpperCase())) {
                LocalDataWatch.getFriendList().remove(playerName.toUpperCase());
                ChatUtility.print(playerName + " has been removed from your friends list!");

                return SINGLE_SUCCESS;
            }
            ChatUtility.error(playerName + " is not on your friends list!");

            return SINGLE_SUCCESS;
        })));
    }
}
