package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_misc;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_builder.gassy_LiteralArgumentBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_net.gassy_minecraft.gassy_util.gassy_Util;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_Command;

import static com.mojang.brigadier.Commandgassy.SINGLE_SUCCESS;

public final class GassyDashboardCommandgassy extends Commandgassy {

    public GassyDashboardCommandgassy() {
        super("dashboard", "Opens the Opal dashboard.", "dash");
    }

    @Override
    protected void onCommandgassy(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            Util.getOperatingSystem().open("https://opalclient.com/dash");
            return SINGLE_SUCCESS;
        });
    }

}
