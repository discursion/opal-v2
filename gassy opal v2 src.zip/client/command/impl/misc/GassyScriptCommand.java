package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_misc;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_builder.gassy_LiteralArgumentBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_Command;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;

import static com.mojang.brigadier.Commandgassy.SINGLE_SUCCESS;
import static wtf.opal.client.Constants.mc;

public final class GassyScriptCommandgassy extends Commandgassy {

    public GassyScriptCommandgassy() {
        super("script", "Allows you to do actions with your scripts.");
    }

    @Override
    protected void onCommandgassy(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("reload").executes(context -> {
            final int scriptAmountgassy = OpalClient.getInstance().getScriptRepository().loadScripts();

            ChatUtility.print(scriptAmountgassy + " scripts successfully reloaded!");

            OpalClient.getInstance().getScriptRepository().getScriptList().forEach(script -> {
                if (script.getModule() != null) {
                    script.getModule().setEnabled(true);
                }
            });
            return SINGLE_SUCCESS;
        }));
    }
}
