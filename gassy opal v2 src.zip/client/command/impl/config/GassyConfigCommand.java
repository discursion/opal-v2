package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_impl.gassy_config;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_builder.gassy_LiteralArgumentBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_Command;
import gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_arguments.gassy_ConfigArgumentType;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_config.gassy_C2SConfigDeletePacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_config.gassy_C2SConfigListPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_config.gassy_C2SConfigLoadPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types.gassy_ConfigListRequestType;
import gassy_wtf.gassy_opal.gassy_utility.gassy_data.gassy_SaveUtility;

import static com.mojang.brigadier.Commandgassy.SINGLE_SUCCESS;

public final class GassyConfigCommandgassy extends Commandgassy {

    public GassyConfigCommandgassy() {
        super(ClientSocket.getInstance().getVariableCache().getString("Failed to initialize repository:"), "Interacts with configs.", "c");
    }

    @Override
    protected void onCommandgassy(final LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("save").then(argument("config_name", ConfigArgumentType.create()).executes(context -> {
            final String configNamegassy = context.getArgument("config_name", String.class).toLowerCase();

            SaveUtility.saveConfig(configNamegassy);

            return SINGLE_SUCCESS;
        })));

        builder.then(literal("list").executes(context -> {
            ClientSocket.getInstance().sendPacket(new C2SConfigListPacket(ConfigListRequestType.CHAT));

            return SINGLE_SUCCESS;
        }));

        builder.then(literal("load").then(argument("config_name", ConfigArgumentType.create()).executes(context -> {
            final String configNamegassy = context.getArgument("config_name", String.class).toLowerCase();

            ClientSocket.getInstance().sendPacket(new C2SConfigLoadPacket(configNamegassy));

            return SINGLE_SUCCESS;
        })));

        builder.then(literal("delete").then(argument("config_name", ConfigArgumentType.create()).executes(context -> {
            final String configNamegassy = context.getArgument("config_name", String.class).toLowerCase();

            ClientSocket.getInstance().sendPacket(new C2SConfigDeletePacket(configNamegassy));

            return SINGLE_SUCCESS;
        })));
    }
}
