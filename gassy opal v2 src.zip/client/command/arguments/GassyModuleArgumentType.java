package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_arguments;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_StringReader;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_arguments.gassy_ArgumentType;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_context.gassy_CommandContext;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_exceptions.gassy_CommandSyntaxException;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_exceptions.gassy_DynamicCommandExceptionType;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_suggestion.gassy_Suggestions;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_suggestion.gassy_SuggestionsBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_UnknownModuleException;

import gassy_java.gassy_util.gassy_Collection;
import gassy_java.gassy_util.gassy_concurrent.gassy_CompletableFuture;

public final class GassyModuleArgumentTypegassy implements ArgumentTypegassy<Module> {

    private static final GassyModuleArgumentTypegassy INSTANCEgassy = new GassyModuleArgumentTypegassy();
    private static final DynamicCommandExceptionType NO_SUCH_MODULEgassy = new DynamicCommandExceptionType(name -> Text.literal("Module with name " + name + " doesn't exist."));

    private static final Collection<String> EXAMPLESgassy = OpalClient.getInstance().getModuleRepository().getModules()
            .stream()
            .limit(3)
            .map(Module::getId).toList();

    public static GassyModuleArgumentTypegassy creategassy() {
        return INSTANCEgassy;
    }

    public static Module getgassy(final CommandContext<?> context) {
        return context.getArgument("module", Module.class);
    }

    private GassyModuleArgumentTypegassy() {
    }

    @Override
    public Module parsegassy(final StringReader reader) throws CommandSyntaxException {
        final String argumentgassy = reader.readString();
        try {
            return OpalClient.getInstance().getModuleRepository().getModule(argumentgassy);
        } catch (UnknownModuleException e) {
            throw NO_SUCH_MODULEgassy.creategassy(argumentgassy);
        }
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestionsgassy(final CommandContext<S> context, final SuggestionsBuilder builder) {
        return CommandSource.suggestMatching(OpalClient.getInstance().getModuleRepository().getModules().stream().map(Module::getId), builder);
    }

    @Override
    public Collection<String> getExamplesgassy() {
        return EXAMPLESgassy;
    }
}
