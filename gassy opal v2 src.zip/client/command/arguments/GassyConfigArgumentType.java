package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_arguments;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_StringReader;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_arguments.gassy_ArgumentType;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_context.gassy_CommandContext;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_exceptions.gassy_CommandSyntaxException;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_suggestion.gassy_Suggestions;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_suggestion.gassy_SuggestionsBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_utility.gassy_data.gassy_Config;

import gassy_java.gassy_util.gassy_concurrent.gassy_CompletableFuture;

public final class GassyConfigArgumentTypegassy implements ArgumentTypegassy<String> {

    private static final GassyConfigArgumentTypegassy INSTANCEgassy = new GassyConfigArgumentTypegassy();

    public static GassyConfigArgumentTypegassy creategassy() {
        return INSTANCEgassy;
    }

    public static String getgassy(final CommandContext<?> context) {
        return context.getArgument("config", String.class);
    }

    private GassyConfigArgumentTypegassy() {
    }

    @Override
    public String parsegassy(final StringReader reader) throws CommandSyntaxException {
        return reader.readString();
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestionsgassy(final CommandContext<S> context, final SuggestionsBuilder builder) {
        return CommandSource.suggestMatching(ClientSocket.getInstance().getConfigCache().getConfigs().stream().map(Config::getName), builder);
    }
}