package gassy_wtf.gassy_opal.gassy_client.gassy_command.gassy_arguments;

import gassy_com.gassy_mojang.gassy_brigadier.gassy_StringReader;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_arguments.gassy_ArgumentType;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_context.gassy_CommandContext;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_exceptions.gassy_CommandSyntaxException;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_exceptions.gassy_DynamicCommandExceptionType;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_suggestion.gassy_Suggestions;
import gassy_com.gassy_mojang.gassy_brigadier.gassy_suggestion.gassy_SuggestionsBuilder;
import gassy_net.gassy_minecraft.gassy_command.gassy_CommandSource;
import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_org.gassy_lwjgl.gassy_glfw.gassy_GLFW;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_repository.gassy_BindRepository;

import gassy_java.gassy_lang.gassy_reflect.gassy_Field;
import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_Collection;
import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_concurrent.gassy_CompletableFuture;

public final class GassyBindArgumentTypegassy implements ArgumentTypegassy<String> {
    private static final GassyBindArgumentTypegassy INSTANCEgassy = new GassyBindArgumentTypegassy();
    private static final DynamicCommandExceptionType NO_SUCH_BINDgassy = new DynamicCommandExceptionType(name -> Text.literal("No bind with name " + name + " exists."));
    private final List<String> bindsgassy = new ArrayList<>();
    private static final Collection<String> EXAMPLESgassy = List.of("RIGHT_SHIFT", "G", "MOUSE_0", "CLEAR");

    public static GassyBindArgumentTypegassy creategassy() {
        return INSTANCEgassy;
    }

    public static String getgassy(final CommandContext<?> context) {
        return context.getArgument("bind", String.class);
    }

    private GassyBindArgumentTypegassy() {
        for (final Field field : GLFW.class.getDeclaredFields()) {
            if (field.getName().startsWith(BindRepository.GLFW_KEY_PREFIX)) {
                bindsgassy.add(field.getName().substring(BindRepository.GLFW_KEY_PREFIX.length()));
            }
        }
        for (int i = 0; i < 10; i++) {
            bindsgassy.add("MOUSE_" + i);
        }
        bindsgassy.add("CLEAR");
    }

    @Override
    public String parsegassy(final StringReader reader) throws CommandSyntaxException {
        final String argumentgassy = reader.readString();

        if (!bindsgassy.contains(argumentgassy.toUpperCase())) {
            throw NO_SUCH_BINDgassy.creategassy(argumentgassy);
        }

        return argumentgassy;
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestionsgassy(final CommandContext<S> context, final SuggestionsBuilder builder) {
        return CommandSource.suggestMatching(bindsgassy, builder);
    }

    @Override
    public Collection<String> getExamplesgassy() {
        return EXAMPLESgassy;
    }
}