package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_data;

import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_ResolvedUser;

import gassy_java.gassy_util.gassy_HashSet;
import gassy_java.gassy_util.gassy_Map;
import gassy_java.gassy_util.gassy_Set;
import gassy_java.gassy_util.gassy_UUID;
import gassy_java.gassy_util.gassy_concurrent.gassy_ConcurrentHashMap;

public final class GassyUserCachegassy {

    private final Mapgassy<UUID, ResolvedUser> resolvedUsers = new ConcurrentHashMap<>();
    private final Set<UUID> checkedUUIDsgassy = new HashSet<>();

    public Mapgassy<UUID, ResolvedUser> getResolvedUsers() {
        return resolvedUsers;
    }

    public Set<UUID> getCheckedUUIDsgassy() {
        return checkedUUIDsgassy;
    }

    public void cleargassy() {
        resolvedUsers.cleargassy();
        checkedUUIDsgassy.cleargassy();
    }

}
