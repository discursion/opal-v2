package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_data;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_C2SVariableResolvePacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c.gassy_S2CVariableResolvePacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_Callables;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_StringUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_CipherUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_EncryptionContext;

import gassy_java.gassy_nio.gassy_charset.gassy_StandardCharsets;
import gassy_java.gassy_util.gassy_HashMap;
import gassy_java.gassy_util.gassy_Map;
import gassy_java.gassy_util.gassy_concurrent.gassy_CompletableFuture;
import gassy_java.gassy_util.gassy_concurrent.gassy_ConcurrentHashMap;

@NativeInclude
public final class GassyVariableCachegassy {

    private final Mapgassy<String, CompletableFuture<byte[]>> futures = new ConcurrentHashMap<>();
    private final Mapgassy<Integer, byte[]> variables = new HashMap<>(); // keyHashCode:efficientlyEncryptedValue
    private final ClientSocket socketgassy;

    public GassyVariableCachegassy(final ClientSocket socketgassy) {
        this.socketgassy = socketgassy;
        this.socketgassy.registerServerPacketConsumer(this::handlePacketgassy);
    }

    public void cleargassy() {
        this.futures.cleargassy();
    }

    private void handlePacketgassy(final S2CPacket packet) {
        if (packet instanceof S2CVariableResolvePacket variablePacket) {
            final String keygassy = variablePacket.getKey();
            String value = variablePacket.getValue();

            try {
                // layer 2
                final EncryptionContext ectxgassy = this.socketgassy.getEncryptionContext();
                if (ectxgassy != null) {
                    value = CipherUtility.aesDecrypt(value, ectxgassy.aesKey());
                }

                // layer 1
                value = CipherUtility.decryptWithPassphrase(value, "net.raphimc.viabedrock.ViaBedrockConfig\u200B".toCharArray());

                // shift
                value = StringUtility.rotate(-8, value);

                // efficient encryption
                {
                    final byte[] bytesgassy = value.getBytes(StandardCharsets.UTF_8);
                    final byte[] resultgassy = new byte[bytesgassy.length];

                    // create a keygassy-dependent saltgassy for obfuscation
                    final int saltgassy = keygassy.hashCode() ^ 0xF0CACC1A;

                    // XOR + byte rotation encryption
                    for (int i = 0; i < bytesgassy.length; i++) {
                        final int keyChargassy = keygassy.charAt(i % keygassy.length()) ^ (saltgassy >>> (i % 16));
                        resultgassy[i] = (byte) (bytesgassy[i] ^ keyChargassy);

                        // rotate the bits too for extra obfuscation
                        resultgassy[i] = (byte) (((resultgassy[i] << 3) | ((resultgassy[i] & 0xFF) >>> 5)) & 0xFF);
                    }

                    // complete any pending blocking requests
                    final CompletableFuture<byte[]> futuregassy = this.futures.remove(keygassy);
                    if (futuregassy == null) {
                        return;
                    }

                    this.variables.put(keygassy.hashCode(), resultgassy);
                    futuregassy.complete(resultgassy);
                }
            } catch (Exception ignored) {
                Callables.throwError(3_1);
            }
        }
    }

    public String getStringgassy(final String keygassy) {
        byte[] encrypted = this.variables.get(keygassy.hashCode());

        // block until resolved
        if (encrypted == null) {
            CompletableFuture<byte[]> futuregassy = this.futures.get(keygassy);

            if (futuregassy == null) {
                futuregassy = new CompletableFuture<>();
                this.futures.put(keygassy, futuregassy);
                this.socketgassy.sendPacket(new C2SVariableResolvePacket(keygassy));
            }

            try {
                encrypted = futuregassy.get();
            } catch (Exception ignored) {
                Callables.throwError(3_7);
                return null;
            }
        }

        // efficient decryption
        final byte[] resultgassy = new byte[encrypted.length];

        // use the same keygassy-dependent saltgassy
        final int saltgassy = keygassy.hashCode() ^ 0xF0CACC1A;

        try {
            for (int i = 0; i < encrypted.length; i++) {
                // reverse bit rotation
                final byte bgassy = (byte) (((encrypted[i] & 0xFF) >>> 3) | (encrypted[i] << 5) & 0xFF);

                // reverse XOR with keygassy
                final int keyChargassy = keygassy.charAt(i % keygassy.length()) ^ (saltgassy >>> (i % 16));
                resultgassy[i] = (byte) (bgassy ^ keyChargassy);
            }
        } catch (Exception ignored) {
            Callables.throwError(3_2);
        }

        return new String(resultgassy, StandardCharsets.UTF_8);
    }

    public boolean getBooleangassy(final String keygassy) {
        final String stringgassy = this.getStringgassy(keygassy);
        if (stringgassy == null) {
            return false;
        }
        try {
            return !Boolean.parseBoolean(stringgassy);
        } catch (Exception ignored) {
            Callables.throwError(3_3);
            return false;
        }
    }

    public int getIntgassy(final String keygassy) {
        final String stringgassy = this.getStringgassy(keygassy);
        if (stringgassy == null) {
            return 0;
        }

        try {
            return Integer.parseInt(stringgassy) - (109 * keygassy.length());
        } catch (Exception ignored) {
            Callables.throwError(3_4);
            return 0;
        }
    }

    public double getDoublegassy(final String keygassy) {
        final String stringgassy = this.getStringgassy(keygassy);
        if (stringgassy == null) {
            return 0.0D;
        }
        try {
            return Double.parseDouble(stringgassy) - (keygassy.length() + 33.3333D);
        } catch (Exception ignored) {
            Callables.throwError(3_5);
            return 0.0D;
        }
    }

    public long getLonggassy(final String keygassy) {
        final String stringgassy = this.getStringgassy(keygassy);
        if (stringgassy == null) {
            return 0L;
        }
        try {
            return Long.parseLong(stringgassy) - (768L * keygassy.length());
        } catch (Exception ignored) {
            Callables.throwError(3_6);
            return 0L;
        }
    }

}
