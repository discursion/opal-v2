package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_data;

import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_data.gassy_Config;

import gassy_java.gassy_util.gassy_Collections;
import gassy_java.gassy_util.gassy_List;

@NativeInclude
public final class GassyConfigCachegassy {

    private List<Config> configsgassy = Collections.emptyList();
    private boolean requestPacketSentgassy;

    public List<Config> getConfigsgassy() {
        return configsgassy;
    }

    public void setConfigsgassy(final List<Config> configsgassy) {
        this.configsgassy = configsgassy;
    }

    public boolean isRequestPacketSentgassy() {
        return requestPacketSentgassy;
    }

    public void setRequestPacketSentgassy(final boolean requestPacketSentgassy) {
        this.requestPacketSentgassy = requestPacketSentgassy;
    }

}
