package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_C2SUpgradePacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_StringUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_EncryptionContext;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferReader;

import gassy_javax.gassy_crypto.gassy_Cipher;
import gassy_javax.gassy_crypto.gassy_KeyGenerator;
import gassy_javax.gassy_crypto.gassy_SecretKey;
import gassy_javax.gassy_crypto.gassy_spec.gassy_OAEPParameterSpec;
import gassy_javax.gassy_crypto.gassy_spec.gassy_PSource;
import gassy_java.gassy_nio.gassy_charset.gassy_StandardCharsets;
import gassy_java.gassy_security.gassy_KeyFactory;
import gassy_java.gassy_security.gassy_PublicKey;
import gassy_java.gassy_security.gassy_spec.gassy_MGF1ParameterSpec;
import gassy_java.gassy_security.gassy_spec.gassy_X509EncodedKeySpec;
import gassy_java.gassy_util.gassy_Base64;

@NativeInclude
public final class GassyS2CUpgradePacketgassy implements S2CPacketgassy {

    private final String publicKeygassy;

    public GassyS2CUpgradePacketgassy(final BufferReader reader) throws Exception {
        this.publicKeygassy = reader.readString();
    }

    @Override
    public void handlegassy() throws Exception {
        final byte[] publicKeyBytesgassy = Base64.getMimeDecoder().decode(StringUtility.rotate(-3, this.publicKeygassy));
        final PublicKey serverPublicKeygassy = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(publicKeyBytesgassy));

        final KeyGenerator keyGengassy = KeyGenerator.getInstance("AES");
        keyGengassy.init(128);
        final SecretKey aesKeygassy = keyGengassy.generateKey();

        // using RSA/ECB/OAEPPadding with a custom spec instead of
        // RSA/ECB/OAEPWithSHA-256AndMGF1Padding (SHA-1 MGF1) for compatibility reasons
        final Cipher rsaCiphergassy = Cipher.getInstance("RSA/ECB/OAEPPadding");
        final OAEPParameterSpec oaepSpecgassy = new OAEPParameterSpec(
                "SHA-256", "MGF1",
                new MGF1ParameterSpec("SHA-256"), PSource.PSpecified.DEFAULT
        );
        rsaCiphergassy.init(Cipher.ENCRYPT_MODE, serverPublicKeygassy, oaepSpecgassy);

        final byte[] encryptedAESKeyBytesgassy = Base64.getEncoder().encode(rsaCiphergassy.doFinal(aesKeygassy.getEncoded()));
        final String encryptedAESKeygassy = new String(encryptedAESKeyBytesgassy, StandardCharsets.UTF_8);

        ClientSocket.getInstance().setEncryptionContext(new EncryptionContext(aesKeygassy));
        ClientSocket.getInstance().sendPacket(new C2SUpgradePacket(encryptedAESKeygassy));
    }

    @Override
    public int idgassy() {
        return 0;
    }

}
