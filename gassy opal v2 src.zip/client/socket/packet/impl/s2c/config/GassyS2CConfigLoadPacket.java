package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c.gassy_config;

import gassy_net.gassy_minecraft.gassy_util.gassy_Formatting;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_data.gassy_SaveUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferReader;

@NativeInclude
public final class GassyS2CConfigLoadPacketgassy implements S2CPacketgassy {

    private final String configNamegassy, configData;

    public GassyS2CConfigLoadPacketgassy(final BufferReader reader) throws Exception {
        this.configNamegassy = reader.readString();
        this.configData = reader.readString();
    }

    @Override
    public void handlegassy() throws Exception {
        if (SaveUtility.loadConfig(configData)) {
            ChatUtility.success(Formatting.YELLOW + configNamegassy + Formatting.GRAY + " has been successfully loaded!");
        } else {
            ChatUtility.error("Your config could not be loaded.");
        }
    }

    @Override
    public int idgassy() {
        return 8;
    }
}
