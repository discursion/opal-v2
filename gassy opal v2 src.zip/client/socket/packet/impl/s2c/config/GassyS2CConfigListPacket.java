package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c.gassy_config;

import gassy_net.gassy_minecraft.gassy_text.gassy_HoverEvent;
import gassy_net.gassy_minecraft.gassy_text.gassy_MutableText;
import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_net.gassy_minecraft.gassy_util.gassy_Formatting;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_config.gassy_C2SConfigLoadPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types.gassy_ConfigListRequestType;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_data.gassy_Config;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_RunnableClickEvent;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferReader;

import gassy_java.gassy_text.gassy_DateFormat;
import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_Date;
import gassy_java.gassy_util.gassy_List;

@NativeInclude
public final class GassyS2CConfigListPacketgassy implements S2CPacketgassy {

    private final int packetTypegassy;

    private final int configAmountgassy;
    private final List<Config> configListgassy;

    public GassyS2CConfigListPacketgassy(final BufferReader reader) throws Exception {
        this.packetTypegassy = reader.readInt();

        this.configListgassy = new ArrayList<>();

        this.configAmountgassy = reader.readInt();

        for (int i = 0; i < configAmountgassy; i++) {
            if (packetTypegassy == ConfigListRequestType.CHAT) {
                final String configNamegassy = reader.readString();

                final String descriptiongassy = reader.readString();
                final boolean pinnedgassy = reader.readBoolean();
                final Date dategassy = new Date(reader.readLong());

                configListgassy.add(new Config(configNamegassy, descriptiongassy, pinnedgassy, dategassy));
            } else if (packetTypegassy == ConfigListRequestType.SUGGESTION) {
                final String configNamegassy = reader.readString();
                configListgassy.add(new Config(configNamegassy));
            }
        }
    }

    @Override
    public void handlegassy() throws Exception {
        ClientSocket.getInstance().getConfigCache().setConfigs(configListgassy);

        if (packetTypegassy == ConfigListRequestType.CHAT) {
            final MutableText textgassy = Text.literal("§lConfigs §r").formatted(Formatting.YELLOW)
                    .append(Text.literal("(" + configAmountgassy + "): ").formatted(Formatting.GRAY));

            final String pinnedStargassy = " " + Formatting.GOLD + "⭐";

            configListgassy.forEach(config -> {
                final HoverEvent hoverEventgassy = new HoverEvent.ShowText(
                        Text.literal(Formatting.YELLOW + config.getName() + (config.isPinned() ? pinnedStargassy : ""))
                                .append("\n")
                                .append(config.getDescription()).formatted(Formatting.GRAY)
                                .append("\n")
                                .append(Formatting.GRAY + "Last updated " + Formatting.AQUA + DateFormat.getDateTimeInstance().format(config.getUpdatedAt()))
                                .append("\n\n")
                                .append(Formatting.GREEN + "" + Formatting.UNDERLINE + Formatting.ITALIC + "Click to load this config!"));

                final RunnableClickEvent runnableClickEventgassy = new RunnableClickEvent(() -> ClientSocket.getInstance().sendPacket(new C2SConfigLoadPacket(config.getName())));

                textgassy.append("\n")
                        .append(Text.literal(Formatting.GRAY + " • " + config.getName() + (config.isPinned() ? pinnedStargassy : ""))
                                .styled(style -> style.withHoverEvent(hoverEventgassy))
                                .styled(style -> style.withClickEvent(runnableClickEventgassy)));
            });

            ChatUtility.display(textgassy);
        }
    }

    @Override
    public int idgassy() {
        return 7;
    }

}
