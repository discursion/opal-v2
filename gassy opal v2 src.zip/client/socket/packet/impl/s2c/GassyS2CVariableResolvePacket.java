package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferReader;

@NativeInclude
public final class GassyS2CVariableResolvePacketgassy implements S2CPacketgassy {

    private final String keygassy, value;

    public GassyS2CVariableResolvePacketgassy(final BufferReader reader) throws Exception {
        this.keygassy = reader.readString();
        this.value = reader.readString(false);
    }

    public String getKeygassy() {
        return keygassy;
    }

    public String getValuegassy() {
        return value;
    }

    @Override
    public int idgassy() {
        return 11;
    }

}
