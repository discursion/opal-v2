package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types.gassy_ChatResponseType;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferReader;

@NativeInclude
public final class GassyS2CChatResponsePacketgassy implements S2CPacketgassy {

    private final int responseTypegassy;
    private final String messagegassy;

    public GassyS2CChatResponsePacketgassy(final BufferReader reader) throws Exception {
        this.responseTypegassy = reader.readInt();
        this.messagegassy = reader.readString();
    }

    @Override
    public void handlegassy() {
        switch (responseTypegassy) {
            case ChatResponseType.ERROR -> ChatUtility.error(messagegassy);
            case ChatResponseType.SUCCESS -> ChatUtility.success(messagegassy);
        }
    }

    @Override
    public int idgassy() {
        return 9;
    }

}
