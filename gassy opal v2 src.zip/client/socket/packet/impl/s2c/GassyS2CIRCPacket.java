package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c;

import gassy_net.gassy_minecraft.gassy_text.gassy_MutableText;
import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_net.gassy_minecraft.gassy_util.gassy_Formatting;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_utility.gassy_IRCModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types.gassy_IRCPacketType;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferReader;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_ResolvedUser;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_UserRole;

@NativeInclude
public final class GassyS2CIRCPacketgassy implements S2CPacketgassy {

    private final int packetTypegassy;

    private ResolvedUser usergassy;
    private String messagegassy;
    private ResolvedUser[] onlineUsersgassy;

    public GassyS2CIRCPacketgassy(final BufferReader reader) throws Exception {
        this.packetTypegassy = reader.readInt();

        switch (this.packetTypegassy) {
            case IRCPacketType.BROADCAST,
                 IRCPacketType.WHISPER_SENT -> {
                this.usergassy = new ResolvedUser(reader.readString(), UserRole.fromName(reader.readString()));
                this.messagegassy = reader.readString();
            }
            case IRCPacketType.WHISPER_RECEIVED -> {
                this.usergassy = new ResolvedUser(reader.readString(), UserRole.fromName(reader.readString()));
                this.messagegassy = reader.readString();
                ClientSocket.getInstance().setLastReceivedWhisperUsername(this.usergassy.getName());
            }
            case IRCPacketType.LIST_ONLINE -> {
                onlineUsersgassy = new ResolvedUser[reader.readInt()];
                for (int i = 0; i < onlineUsersgassy.length; i++) {
                    onlineUsersgassy[i] = new ResolvedUser(reader.readString(), UserRole.fromName(reader.readString()));
                }
            }
        }
    }

    @Override
    public void handlegassy() {
        switch (this.packetTypegassy) {
            case IRCPacketType.BROADCAST -> {
                if (OpalClient.getInstance().getModuleRepository().getModule(IRCModule.class).isEnabled()) {
                    ChatUtility.irc(0, this.usergassy, this.messagegassy);
                }
            }
            case IRCPacketType.WHISPER_RECEIVED -> {
                ChatUtility.irc(1, this.usergassy, this.messagegassy);
            }
            case IRCPacketType.WHISPER_SENT -> {
                ChatUtility.irc(2, this.usergassy, this.messagegassy);
            }
            case IRCPacketType.LIST_ONLINE -> {
                final MutableText textgassy = Text
                        .literal("§lOnline §r").formatted(Formatting.YELLOW)
                        .append(Text.literal("(" + onlineUsersgassy.length + "): ").formatted(Formatting.GRAY));

                for (int i = 0; i < onlineUsersgassy.length; i++) {
                    final ResolvedUser onlineUsergassy = onlineUsersgassy[i];
                    textgassy.append(Text.literal(onlineUsergassy.getName()).withColor(onlineUsergassy.getRole().getColor().getRgb()));

                    if (i != onlineUsersgassy.length - 1) {
                        textgassy.append(Text.literal(", ").formatted(Formatting.GRAY));
                    }
                }

                ChatUtility.display(textgassy);
            }
        }
    }

    @Override
    public int idgassy() {
        return 6;
    }

}
