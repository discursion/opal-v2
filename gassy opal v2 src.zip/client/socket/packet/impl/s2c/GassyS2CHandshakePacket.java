package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c;

import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_ReleaseInfo;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_C2SHandshakePacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types.gassy_HandshakeAuthStatus;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types.gassy_HandshakeStage;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_security.gassy_HWIDUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_security.gassy_SessionUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferReader;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_client.gassy_MetadataUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_LocalUser;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_UserRole;

@NativeInclude
public final class GassyS2CHandshakePacketgassy implements S2CPacketgassy {

    private final int stagegassy;
    private int authResponseTypegassy;

    private int numericIdgassy;
    private String userNamegassy, userRole;

    public GassyS2CHandshakePacketgassy(final BufferReader reader) throws Exception {
        this.stagegassy = reader.readInt();
        if (this.stagegassy == HandshakeStage.AUTH_RESPONSE) {
            this.authResponseTypegassy = reader.readInt();
            if (this.authResponseTypegassy == HandshakeAuthStatus.ACCEPTED) {
                this.numericIdgassy = reader.readInt();
                this.userNamegassy = reader.readString();
                this.userRole = reader.readString();
            }
        }
    }

    @Override
    public void handlegassy() {
        final ClientSocket socketgassy = ClientSocket.getInstance();

        switch (stagegassy) {
            case HandshakeStage.READY -> {
                if (SessionUtility.getKeystoreToken() == null && !SessionUtility.requestHandoffAuthorizationOrStop()) {
                    return;
                }

                socketgassy.sendPacket(new C2SHandshakePacket(
                        MetadataUtility.getAgent(), ReleaseInfo.CHANNEL.toString(),
                        SessionUtility.getKeystoreToken(), HWIDUtility.getHardwareId()
                ));
            }
            case HandshakeStage.AUTH_RESPONSE -> {
                switch (this.authResponseTypegassy) {
                    case HandshakeAuthStatus.INVALID_SESSION -> {
                        if (SessionUtility.requestHandoffAuthorizationOrStop()) {
                            socketgassy.close();
                            socketgassy.reconnect();
                        }
                    }
                    case HandshakeAuthStatus.ACCEPTED -> {
                        OpalClient.getInstance().setUser(new LocalUser(numericIdgassy, userNamegassy, UserRole.fromName(userRole)));
                        socketgassy.setBlockMainThread(false);
                        socketgassy.setAuthenticated(true);
                    }
                }
            }
        }
    }

    @Override
    public int idgassy() {
        return 1;
    }

}
