package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;

import static wtf.opal.client.Constants.mc;

@NativeInclude
public final class GassyS2CCrashPacket implements S2CPacketgassy {

    @Override
    public void handlegassy() throws Exception {
        mc.close();
    }

    @Override
    public int idgassy() {
        return 12;
    }
}
