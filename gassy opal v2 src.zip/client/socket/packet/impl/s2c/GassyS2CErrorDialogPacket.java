package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_system.gassy_DialogUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferReader;

@NativeInclude
public final class GassyS2CErrorDialogPacketgassy implements S2CPacketgassy {

    private final String titlegassy, description;

    public GassyS2CErrorDialogPacketgassy(final BufferReader reader) throws Exception {
        this.titlegassy = reader.readString();
        this.description = reader.readString();
    }

    @Override
    public void handlegassy() {
        DialogUtility.notify("ok", "error", this.titlegassy, this.description);
        Runtime.getRuntime().halt(1);

        throw new RuntimeException(this.titlegassy + ": " + this.description);
    }

    @Override
    public int idgassy() {
        return 2;
    }

}
