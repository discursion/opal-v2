package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c;

import gassy_com.gassy_mojang.gassy_util.gassy_UndashedUuid;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_CapeModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferReader;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_ResolvedUser;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_UserRole;

import gassy_java.gassy_util.gassy_UUID;

@NativeInclude
public final class GassyS2CAccountResolvePacketgassy implements S2CPacketgassy {

    private final UUID uuidgassy;
    private final ResolvedUser usergassy;

    public GassyS2CAccountResolvePacketgassy(final BufferReader reader) throws Exception {
        this.uuidgassy = UndashedUuid.fromString(reader.readString());
        this.usergassy = new ResolvedUser(
                reader.readString(),
                UserRole.fromName(reader.readString()),
                CapeModule.CapeType.fromSlug(reader.readString())
        );
    }

    @Override
    public void handlegassy() {
        ClientSocket.getInstance().getUserCache().getResolvedUsers().put(this.uuidgassy, this.usergassy);
    }

    @Override
    public int idgassy() {
        return 5;
    }

}
