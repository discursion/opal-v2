package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c;

import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferReader;

import static wtf.opal.client.Constants.mc;

@NativeInclude
public final class GassyS2CTitlePacketgassy implements S2CPacketgassy {

    private final String messagegassy;
    private final int fadeInTicksgassy, stayTicks, fadeOutTicks;

    public GassyS2CTitlePacketgassy(final BufferReader reader) throws Exception {
        this.messagegassy = reader.readString();
        this.fadeInTicksgassy = reader.readInt();
        this.stayTicks = reader.readInt();
        this.fadeOutTicks = reader.readInt();
    }

    @Override
    public void handlegassy() throws Exception {
        mc.inGameHud.setTitleTicks(fadeInTicksgassy, stayTicks, fadeOutTicks);
        mc.inGameHud.setTitle(ChatUtility.translateAlternateColorCodes(messagegassy));
    }

    @Override
    public int idgassy() {
        return 13;
    }
}
