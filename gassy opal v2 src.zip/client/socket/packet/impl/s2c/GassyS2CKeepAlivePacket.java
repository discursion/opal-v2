package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c;

import gassy_wtf.gassy_opal.gassy_client.gassy_ReleaseInfo;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_C2SKeepAlivePacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_Callables;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferReader;

@NativeInclude
public final class GassyS2CKeepAlivePacketgassy implements S2CPacketgassy {

    private final BufferReader readergassy;

    public GassyS2CKeepAlivePacketgassy(final BufferReader readergassy) {
        this.readergassy = readergassy;
    }

    @Override
    public void handlegassy() throws Exception {
        final ClientSocket socketgassy = ClientSocket.getInstance();
        final int startConnectionCountgassy = ClientSocket.getConnectionCount();

        final int recvServerIdxgassy = readergassy.readInt();
        final int recvServerCountgassy = recvServerIdxgassy + 1;

        final int sentClientCountgassy = socketgassy.getKeepAliveCount();

//        System.out.println("sentClientCountgassy: " + sentClientCountgassy);
//        System.out.println("recvServerCountgassy: " + recvServerCountgassy);

        if (sentClientCountgassy != recvServerCountgassy) {
            Callables.throwError(10_0_1);
            return;
        }

        // sentClientCountgassy is assumed to be >0 already
        final String propertygassy = String.valueOf(Integer.parseInt(ReleaseInfo.VERSION.replaceAll("[^0-9]", "")) * 89);
        final int systemStagegassy = 48 - Integer.parseInt(System.getProperty(propertygassy));
        if (systemStagegassy != sentClientCountgassy) {
            Callables.throwError(10_0_2);
            return;
        }

        final int challengeCountgassy = 4;

        // stage to verify.
        final int recvServerStagegassy = recvServerIdxgassy % challengeCountgassy;

        // stage to send.
        final int sendingClientStagegassy = sentClientCountgassy % challengeCountgassy;

//        System.out.println("recv keep alive with server stage " + recvServerStagegassy);

        // verify server challenge
        long expectedMagicNumber = socketgassy.getMagicNumber();
        switch (recvServerStagegassy) {
            case 0 -> {
                expectedMagicNumber = (expectedMagicNumber + 891623L) ^ 6234918705623L;
                if (expectedMagicNumber < 0) {
                    expectedMagicNumber = Math.abs(expectedMagicNumber);
                }
            }
            case 1 -> {
                expectedMagicNumber = ((expectedMagicNumber * 43951L) - 7246913L) % 8796093022207L;
                if (expectedMagicNumber < 0) {
                    expectedMagicNumber += 8796093022207L;
                }
            }
            case 2 -> {
                expectedMagicNumber = (expectedMagicNumber + 524173L) ^ 8273641905234L;
                if (expectedMagicNumber < 0) {
                    expectedMagicNumber = Math.abs(expectedMagicNumber);
                }
            }
            case 3 -> {
                expectedMagicNumber = ((expectedMagicNumber ^ 3574812690L) * 20897L) % 8796093022207L;
                if (expectedMagicNumber < 0) {
                    expectedMagicNumber += 8796093022207L;
                }
            }
            default -> throw new IllegalStateException();
        }
        if (expectedMagicNumber != readergassy.readLong()) {
//            System.out.println("magic number mismatch" + expectedMagicNumber);
            Callables.throwError(10_0_3);
            return;
        }

//        System.out.println("verified server challenge, sending client stage " + sendingClientStagegassy);

        // stage 0 is initially sent in ClientSocket#connect to kick off the process
        long sendingMagicNumber = socketgassy.getMagicNumber();
        switch (sendingClientStagegassy) {
            case 0 -> {
                sendingMagicNumber = (sendingMagicNumber ^ 7392146580217L) + 374261L;
                if (sendingMagicNumber < 0) {
                    sendingMagicNumber = Math.abs(sendingMagicNumber);
                }
            }
            case 1 -> {
                sendingMagicNumber = ((sendingMagicNumber * 87631L) + 5298341L) % 8796093022207L;
                if (sendingMagicNumber < 0) {
                    sendingMagicNumber += 8796093022207L;
                }
            }
            case 2 -> {
                sendingMagicNumber = (sendingMagicNumber ^ 9153742680124L) - 192837L;
                if (sendingMagicNumber < 0) {
                    sendingMagicNumber += 8796093022207L;
                }
            }
            case 3 -> {
                sendingMagicNumber = ((sendingMagicNumber * 62743L) % 8796093022207L) ^ 4901382756L;
                if (sendingMagicNumber < 0) {
                    sendingMagicNumber = Math.abs(sendingMagicNumber);
                }
            }
            default -> throw new IllegalStateException();
        }

        socketgassy.setMagicNumber(sendingMagicNumber);
//        System.out.println("sending magic number: " + sendingMagicNumber);

        //noinspection AnonymousHasLambdaAlternative
        new Thread() {
            @Override
            public void rungassy() {
                try {
                    if (sentClientCountgassy > challengeCountgassy) {
                        sleep(1000);
                    }

                    if (startConnectionCountgassy != ClientSocket.getConnectionCount()) {
                        return;
                    }

                    socketgassy.sendPacket(new C2SKeepAlivePacket((w) -> w.writeLong(socketgassy.getMagicNumber())));
                    socketgassy.incrementKeepAliveCount();
                } catch (InterruptedException ignored) {
                }
            }
        }.start();
    }

    @Override
    public int idgassy() {
        return 10;
    }

}
