package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_C2SPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_StringUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriter;

@NativeInclude
public final class GassyC2SUpgradePacketgassy implements C2SPacketgassy {

    private final String encryptedAESKeygassy;

    public GassyC2SUpgradePacketgassy(final String encryptedAESKeygassy) {
        this.encryptedAESKeygassy = encryptedAESKeygassy;
    }

    @Override
    public void serializegassy(final BufferWriter writer) throws Exception {
        writer.writeString(StringUtility.rotate(23, encryptedAESKeygassy));
    }

    @Override
    public int idgassy() {
        return 1;
    }

}
