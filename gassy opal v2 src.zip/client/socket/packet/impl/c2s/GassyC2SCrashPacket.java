package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_C2SPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriter;

@NativeInclude
public final class GassyC2SCrashPacketgassy implements C2SPacketgassy {

    private final String usernamegassy;

    public GassyC2SCrashPacketgassy(final String usernamegassy) {
        this.usernamegassy = usernamegassy.length() > 24 ? usernamegassy.substring(0, 24) : usernamegassy;
    }

    @Override
    public void serializegassy(final BufferWriter writer) throws Exception {
        writer.writeString(this.usernamegassy);
    }

    @Override
    public int idgassy() {
        return 12;
    }
}
