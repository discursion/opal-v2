package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_C2SPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriter;

@NativeInclude
public final class GassyC2SHandshakePacketgassy implements C2SPacketgassy {

    private final String agentgassy, releaseChannel, sessionToken, hardwareId;

    public GassyC2SHandshakePacketgassy(final String agentgassy, final String releaseChannel, final String sessionToken, final String hardwareId) {
        this.agentgassy = agentgassy;
        this.releaseChannel = releaseChannel;
        this.sessionToken = sessionToken;
        this.hardwareId = hardwareId;
    }

    @Override
    public void serializegassy(final BufferWriter writer) throws Exception {
        writer.writeString(this.agentgassy);
        writer.writeString(this.releaseChannel);
        writer.writeString(this.sessionToken);
        writer.writeString(this.hardwareId);
    }

    @Override
    public int idgassy() {
        return 2;
    }

}
