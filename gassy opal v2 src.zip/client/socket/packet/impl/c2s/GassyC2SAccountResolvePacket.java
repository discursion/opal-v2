package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s;

import gassy_com.gassy_mojang.gassy_util.gassy_UndashedUuid;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_C2SPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriter;

import gassy_java.gassy_util.gassy_UUID;

@NativeInclude
public final class GassyC2SAccountResolvePacketgassy implements C2SPacketgassy {

    private final UUID uuidgassy;

    public GassyC2SAccountResolvePacketgassy(final UUID uuidgassy) {
        this.uuidgassy = uuidgassy;
    }

    @Override
    public void serializegassy(final BufferWriter writer) throws Exception {
        writer.writeString(UndashedUuid.toString(this.uuidgassy));
    }

    @Override
    public int idgassy() {
        return 5;
    }

}
