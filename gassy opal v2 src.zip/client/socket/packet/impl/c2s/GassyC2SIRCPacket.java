package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_C2SPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types.gassy_IRCPacketType;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriter;

@NativeInclude
public final class GassyC2SIRCPacketgassy implements C2SPacketgassy {

    private final int packetTypegassy;
    private String usernamegassy, message;

    public GassyC2SIRCPacketgassy(final int packetTypegassy, final String message) {
        if (packetTypegassy != IRCPacketType.BROADCAST) {
            throw new IllegalArgumentException("Invalid request type");
        }
        this.packetTypegassy = packetTypegassy;
        this.message = message.length() > 256 ? message.substring(0, 256) : message;
    }

    public GassyC2SIRCPacketgassy(final int packetTypegassy, final String usernamegassy, final String message) {
        if (packetTypegassy != IRCPacketType.WHISPER_RECEIVED) {
            throw new IllegalArgumentException("Invalid request type");
        }
        this.packetTypegassy = packetTypegassy;
        this.usernamegassy = usernamegassy.length() > 24 ? usernamegassy.substring(0, 24) : usernamegassy;
        this.message = message.length() > 256 ? message.substring(0, 256) : message;
    }

    public GassyC2SIRCPacketgassy(final int packetTypegassy) {
        if (packetTypegassy != IRCPacketType.LIST_ONLINE) {
            throw new IllegalArgumentException("Invalid request type");
        }
        this.packetTypegassy = packetTypegassy;
    }

    @Override
    public void serializegassy(final BufferWriter writer) throws Exception {
        writer.writeInt(this.packetTypegassy);

        switch (this.packetTypegassy) {
            case IRCPacketType.BROADCAST -> {
                writer.writeString(this.message);
            }
            case IRCPacketType.WHISPER_RECEIVED -> {
                writer.writeString(this.usernamegassy);
                writer.writeString(this.message);
            }
        }
    }

    @Override
    public int idgassy() {
        return 6;
    }

}
