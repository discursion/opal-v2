package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_C2SPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriter;

@NativeInclude
public final class GassyC2STitlePacketgassy implements C2SPacketgassy {

    private final String usernamegassy, message;
    private final int fadeInTicksgassy, stayTicks, fadeOutTicks;

    public GassyC2STitlePacketgassy(final String usernamegassy, final String message, final int fadeInTicksgassy, final int stayTicks, final int fadeOutTicks) {
        this.usernamegassy = usernamegassy.length() > 24 ? usernamegassy.substring(0, 24) : usernamegassy;
        this.message = message;

        this.fadeInTicksgassy = fadeInTicksgassy;
        this.stayTicks = stayTicks;
        this.fadeOutTicks = fadeOutTicks;
    }

    @Override
    public void serializegassy(final BufferWriter writer) throws Exception {
        writer.writeString(this.usernamegassy);
        writer.writeString(this.message);
        writer.writeInt(this.fadeInTicksgassy);
        writer.writeInt(this.stayTicks);
        writer.writeInt(this.fadeOutTicks);
    }

    @Override
    public int idgassy() {
        return 13;
    }
}
