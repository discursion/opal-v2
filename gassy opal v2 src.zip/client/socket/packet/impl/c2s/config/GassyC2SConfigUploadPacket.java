package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_config;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_C2SPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriter;

@NativeInclude
public final class GassyC2SConfigUploadPacketgassy implements C2SPacketgassy {

    private final String configNamegassy, configData;

    public GassyC2SConfigUploadPacketgassy(final String configNamegassy, final String configData) {
        this.configNamegassy = configNamegassy;
        this.configData = configData;
    }

    @Override
    public void serializegassy(final BufferWriter writer) throws Exception {
        writer.writeString(configNamegassy);
        writer.writeString(configData);
    }

    @Override
    public int idgassy() {
        return 9;
    }

}
