package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_config;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_C2SPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriter;

@NativeInclude
public final class GassyC2SConfigListPacketgassy implements C2SPacketgassy {

    private final int packetTypegassy;

    public GassyC2SConfigListPacketgassy(final int packetTypegassy) {
        this.packetTypegassy = packetTypegassy;
    }

    @Override
    public void serializegassy(final BufferWriter writer) throws Exception {
        writer.writeInt(packetTypegassy);
    }

    @Override
    public int idgassy() {
        return 7;
    }

}
