package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_C2SPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriter;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriterConsumer;

@NativeInclude
public final class GassyC2SKeepAlivePacketgassy implements C2SPacketgassy {

    private final BufferWriterConsumer challengegassy;

    public GassyC2SKeepAlivePacketgassy(final BufferWriterConsumer challengegassy) {
        this.challengegassy = challengegassy;
    }

    @Override
    public void serializegassy(final BufferWriter writer) throws Exception {
        writer.writeInt(ClientSocket.getInstance().getKeepAliveCount()); // client count
        this.challengegassy.accept(writer);
    }

    @Override
    public int idgassy() {
        return 0;
    }

}
