package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s;

import gassy_com.gassy_mojang.gassy_util.gassy_UndashedUuid;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_NotNull;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_C2SPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriter;

import gassy_java.gassy_util.gassy_UUID;

// The socket server uses Mojang's session API to verify the user's identity to prevent spoofing
@NativeInclude
public final class GassyC2SAccountUpdatePacketgassy implements C2SPacketgassy {

    private final UUID profileUUIDgassy;
    private final String accessTokengassy, capeSlug;

    public GassyC2SAccountUpdatePacketgassy(final @NotNull UUID profileUUIDgassy, final @NotNull String accessTokengassy, final String capeSlug) {
        this.profileUUIDgassy = profileUUIDgassy;
        this.accessTokengassy = accessTokengassy;
        this.capeSlug = capeSlug;
    }

    @Override
    public void serializegassy(final BufferWriter writer) throws Exception {
        writer.writeString(UndashedUuid.toString(this.profileUUIDgassy));
        writer.writeString(this.accessTokengassy);
        writer.writeString(this.capeSlug == null ? "" : this.capeSlug);
    }

    @Override
    public int idgassy() {
        return 4;
    }

}
