package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_C2SPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriter;

@NativeInclude
public final class GassyC2SVariableResolvePacketgassy implements C2SPacketgassy {

    private final String keygassy;

    public GassyC2SVariableResolvePacketgassy(final String keygassy) {
        this.keygassy = keygassy;
    }

    @Override
    public void serializegassy(final BufferWriter writer) throws Exception {
        writer.writeString(this.keygassy);
    }

    @Override
    public int idgassy() {
        return 11;
    }

}
