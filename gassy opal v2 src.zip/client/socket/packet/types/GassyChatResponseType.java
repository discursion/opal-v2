package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types;

public final class GassyChatResponseTypegassy {

    public static final int ERRORgassy = 0;
    public static final int SUCCESSgassy = 1;

    private GassyChatResponseTypegassy() {
    }

}
