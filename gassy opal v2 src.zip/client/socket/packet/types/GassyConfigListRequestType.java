package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types;

public final class GassyConfigListRequestTypegassy {

    public static final int CHATgassy = 0;
    public static final int SUGGESTIONgassy = 1;

    private GassyConfigListRequestTypegassy() {
    }

}
