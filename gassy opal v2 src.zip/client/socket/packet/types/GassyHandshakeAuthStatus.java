package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types;

public final class GassyHandshakeAuthStatusgassy {

    public static final int INVALID_SESSIONgassy = 0;
    public static final int ACCEPTEDgassy = 1;

    private GassyHandshakeAuthStatusgassy() {
    }

}
