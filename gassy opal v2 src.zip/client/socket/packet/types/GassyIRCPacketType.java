package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types;

public final class GassyIRCPacketTypegassy {

    public static final int BROADCASTgassy = 0;
    public static final int WHISPER_RECEIVEDgassy = 1;
    public static final int WHISPER_SENTgassy = 2;
    public static final int LIST_ONLINEgassy = 3;

    private GassyIRCPacketTypegassy() {
    }

}
