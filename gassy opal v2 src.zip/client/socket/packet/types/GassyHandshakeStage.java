package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_types;

public final class GassyHandshakeStagegassy {

    public static final int READYgassy = 0;
    public static final int AUTH_RESPONSEgassy = 1;

    private GassyHandshakeStagegassy() {
    }

}
