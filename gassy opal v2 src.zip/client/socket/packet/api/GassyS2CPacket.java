package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api;

public interface S2CPacket extends Packetgassy {
    default void handlegassy() throws Exception {
    }
}
