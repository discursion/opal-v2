package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api;

import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriter;

public interface C2SPacket extends Packetgassy {
    default void serializegassy(final BufferWriter writer) throws Exception {
    }
}
