package gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api;

public interface ServerPacketConsumergassy {
    void accept(final S2CPacket packet);
}
