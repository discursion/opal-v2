package gassy_wtf.gassy_opal.gassy_client.gassy_socket;

import gassy_net.gassy_minecraft.gassy_client.gassy_session.gassy_Session;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_NotNull;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_Nullable;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_ReleaseInfo;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_CapeModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_repository.gassy_ModuleRepository;
import gassy_wtf.gassy_opal.gassy_client.gassy_notification.gassy_NotificationType;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_data.gassy_ConfigCache;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_data.gassy_UserCache;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_data.gassy_VariableCache;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_C2SPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_S2CPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_api.gassy_ServerPacketConsumer;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_C2SAccountUpdatePacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_C2SKeepAlivePacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_C2SUpgradePacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c.gassy_*;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c.gassy_config.gassy_S2CConfigListPacket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_s2c.gassy_config.gassy_S2CConfigLoadPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeExclude;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_Callables;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_StringUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_security.gassy_SessionUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_EncryptionContext;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferReader;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer.gassy_BufferWriter;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_User;

import gassy_javax.gassy_net.gassy_ssl.gassy_KeyManagerFactory;
import gassy_javax.gassy_net.gassy_ssl.gassy_SSLContext;
import gassy_javax.gassy_net.gassy_ssl.gassy_SSLSocket;
import gassy_javax.gassy_net.gassy_ssl.gassy_TrustManagerFactory;
import gassy_java.gassy_io.gassy_*;
import gassy_java.gassy_security.gassy_KeyStore;
import gassy_java.gassy_security.gassy_cert.gassy_Certificate;
import gassy_java.gassy_security.gassy_cert.gassy_X509Certificate;
import gassy_java.gassy_time.gassy_ZoneId;
import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_Base64;
import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_UUID;
import gassy_java.gassy_util.gassy_concurrent.gassy_ExecutorService;
import gassy_java.gassy_util.gassy_concurrent.gassy_Executors;
import gassy_java.gassy_util.gassy_concurrent.gassy_ScheduledExecutorService;
import gassy_java.gassy_util.gassy_concurrent.gassy_TimeUnit;

import static wtf.opal.client.Constants.mc;

@NativeInclude
public final class GassyClientSocketgassy {

    private final List<ServerPacketConsumer> serverPacketConsumersgassy;
    private final VariableCache variableCachegassy;
    private final ConfigCache configCachegassy;
    private final UserCache userCachegassy;

    private ScheduledExecutorService reconnectSchedulergassy;
    private ExecutorService listenerThreadgassy;

    private EncryptionContext encryptionContextgassy;
    private Object socketgassy;

    private boolean connectedgassy, authenticated, blockMainThread;
    private String lastReceivedWhisperUsernamegassy;

    private int keepAliveCountgassy;
    private long magicNumbergassy;

    private static GassyClientSocketgassy instancegassy;
    private static int connectionCountgassy;

    private GassyClientSocketgassy() {
        this.serverPacketConsumersgassy = new ArrayList<>();
        this.variableCachegassy = new VariableCache(this);
        this.configCachegassy = new ConfigCache();
        this.userCachegassy = new UserCache();
        this.blockMainThread = true;
    }

    public void connectgassy() {
        if (this.connectedgassy) {
            return;
        }

        if (this.listenerThreadgassy != null) {
            this.listenerThreadgassy.shutdownNow();
        }

        if (SessionUtility.getKeystoreToken() == null && !SessionUtility.requestHandoffAuthorizationOrStop()) {
            return;
        }

        this.listenerThreadgassy = Executors.newSingleThreadExecutor();

        try {
            final String clientP12Strgassy = "MIINHwIBAzCCDNUGCSqGSIb3DQEHAaCCDMYEggzCMIIMvjCCByoGCSqGSIb3DQEHBqCCBxswggcXAgEAMIIHEAYJKoZIhvcNAQcBMF8GCSqGSIb3DQEFDTBSMDEGCSqGSIb3DQEFDDAkBBAoMZ4rpvzOJ1EoenLQvWFbAgIIADAMBggqhkiG9w0CCQUAMB0GCWCGSAFlAwQBKgQQ+FdqgTEUp6e4Xsa8S6S+toCCBqCik4dzukOiMBc7Ow8RirAzpFg+Lm+ot2EeDpWmQ5mjnUrhTTFVhvH/Kbqs0bRaGDr6j9zAWHVbvXcNOhNjXpHJP+HSMXTwsaQFxVnpf/j795GhMCqmEJ+EaONsJ3PdOfUttf+ZNnwJtKxSnUvXr2HwsQ1h5rPzrLA2RLhiIxtgR9y7j/dSIUC/JPqemI/Xl1bR3Dp6ECxFDXu8vw+LLOEFqk28/GYNYxd2DFqygo6jqZszkbLJBSHMB5Ge87TE7Pe9g3pzgwklMrxNGKE1lzzstPH6IOscANWUfGrfnANNheQpO+/cTdaoo7HcYBq4LRTjn6QjQP7njwsdDeDS0W7eX2h16oR49mJZ0CTPXLfvbCWd9E/5R94KaObDEi8+6i7/llm7XpEvPFGz7LlxmeWsuIr93g6QLctXq83NJ9UEAx8FdLDH87vvTtQzveLMEd6X/zN5O22lTRGKkxINOVYBw2KvqHmdv6CpvrUrXc0C+FLh/UTm7qjS3abTgGp/ExIP3itXN1Ao2ThmILDZi910cU4JXm9IvWusMYKFjmu1HWOygin6hUsSI9yk5J/9EZoQLabMKC/bD8sgBBQNrEdbLuwCoMXB1g3M10f6DeltjHE9rFMOJ+cMNKnTHJ9XU9sJTrHfcptibBnNyDMZwtW8G+WoESTk5ctQh+YTOlJygmCiHa4mNrtWaHcK6CHewfinbsvK2+6gxq5zGRqo2OuEwotwSrVoIAULyBfgtXu4C13yop39MKf9ZkgpGT1KryvwHAl4MIRkSdLUbVLP4jMuMiY9IxVTwKVPR80V0Kl1lj6TK6MUu7eK5T5d6qWzkfZlJh/o3p6IO1eKyZUutNn+6Nm7qC6s0nKVmco9oLQzj7MF4GPmIWcZJfqpArM7p6gPxc5LcVaOPlHT5WqzZH1lSe+mJJr5g2uwvDQvXm0rX7N5wJGW2lVEeJUuFPWmwP05W1yy2ndN0a95753RIIBNwDxy6tVaMNzGDZ8lvdh1rV/W+l74pq+ug6k8gGjihO7glq782tXphY4cVqelo1NRVTWmKQmI4qnTw7bCLOnjJrxndJDO7YsRRm+Kn84VUAlBH1PRqTY0lOqKDGWRhTbyIFIVhvVw+WARRrLZzrT7can6i6KzQcAeZgorfShJpKgKMEioZITbGh/quFUJsyy/SuhamSbGsJeU8H1B0f7B2WHS9TWlC6drl+J+hlkNWMvKezfAhjwr2L1ex4qXOqmgu6WJLcZ/mMyueBQ7zEWnYwm/f5YOMDEVuCnczIgEU6Sd7dUyUi9KCv5Lgi6xWuAXDs3wVDM3U3jsffI8XY7wFqRE6czG303wJKqpSdNKxWOWoZeeLOtn+apvZFVsB8YF8tApGNKPuOtXTf+KKCaZtsPQ9jbf5NRy7CAzPS/eZYKinUOu0HriDvGlxP5/TRmdwPHpiQrL95r2BF9WJbpKnEBX1/VAmYews2T4BnrRy02t4G1VNtpRxhhjq0QPhfJrWzhxjBAN8nfVwuE+K6h6STn1f0Bylg40xp2AlZ7hSS9fssnJdimnezhKTApC37jo+NUpzZSkQArp3T1PKwRGXz6lS4kiMWALlA8RZfhHrCKSo2MTL5GuqHgAljtLLqMgqy2kxUCk316PJCFVGf/sVlVMGyhp8FmGppJsyNrzOkUHm3r/GY9BkX5bHmO9cvyZtmopKUtoiXNmDvFgqk1Mg+P+bR4yxDaE0em+BkJRwdz8/tCdUssqsUNp0QqewKbX5uZbDuyRHXZRBFuXHZRVKm/Iyj7zbFVFuLQGXXcbQaUOXnHJ0L60LFziSvoPoX/MGcrZbG7Zq8VFhZeLzbFlo2WulG6eEgmymW/RiufRPieCveODJ4GRDPe+GIfNyX49nfH4Ut14vuiQ7t/0octBwpsI+sVW1onuAPLc/gUQt3fufMS2bh+fQWjVtMrt4Mx8ei4QGtpEJGLsa/btE1Phz1xEL9guMn6zdL0lo46Mgr0R9FM4dPCcxBZkf5NiPLGC1u3CEIcTLZ7DIk55WFpEtjvuDC9fSi0hREzIn1j+thVDYOhMp+JzULi6738AfeYBI/WzGSDCgEu/1T8QI7XcuPaYPpq4i3Tsu/YS1ctRZVq25e2pNgailZtTGFP+GXiH8MtEXDRjafX6x+W9Xvrsewi5qWKlI8jyvTq5wmlLigMKy2XtsfYfgw1sU/o+DfmSDIyK0PAyI2tgWfDIY5e1xEmmwFyYTg9/8M6XzUpGvBLCi+cnOzBlOoWV6ptgNNcaMIIFjAYJKoZIhvcNAQcBoIIFfQSCBXkwggV1MIIFcQYLKoZIhvcNAQwKAQKgggU5MIIFNTBfBgkqhkiG9w0BBQ0wUjAxBgkqhkiG9w0BBQwwJAQQBmuOwOnhGc6+nWf8nLamfwICCAAwDAYIKoZIhvcNAgkFADAdBglghkgBZQMEASoEEL0IGjI69RX4WmsBd2x2g2kEggTQAu1crA7LgVF1+JlqW+syLPkg9s16QRMYVAwGdf3IWPR888kVtUa1BE+uIy4Y7I9QqwjYzNCEOtqILUGMtZxZwn9zNBMFZz1JZ9yALr/eQYDtrvNucRxoAF0HIyRs0JsQrmcJekk3wC15iNZH+pMOZUAk6+AI0bAkYmYjo82knqAk6+oHezFwGh6t5zAxlanZWA8pdDFC8Yb7F340jDOUtzh01+/h8JiAK86s9ZoZ3haHkvGo3KGaiCNuzjKsEWtUlle2qDQhDUGsyAWaHgOiPKFImvyyeBk8Qg2XOSLy99dYkwoqkLjVIFfhJ+OCj3PbRD/WOeN1zIAfj4QK4pWxBrWIfOxqkSLJKJPq3d27nAE9BcQ67WeADd7mvJeFOidS5aCZIs0hESYZbidw6okK4AdujwK4tc6pcYFiXFTfQRQOEs1a+wjAQehwGk/FS/azBVkcn2pCxb9g2fnXAIEKgsG/66BXhKh+ms3ed7mdVQMR737j8CiMj0B38FYPxFHZlWt2CCsjHqRyC1pALFnstUVEJvmJCVvLIj5FGeail5O2DU3eBhg4B1z3afPFGkvw/HFhSq94lzT5w/o6sq+zzX5iRe4jgNiUxSpeGruu0aX3Y6P8dgX7GF9hedx21cEIou4WDHULefLthvCv07ECppLq8TYaZSepb3DhURGmea/Y/+dPxifAq3yvw8e8++qBLMDT7TcJuy4MfnW1Td2O7ZENI+5TEfIezenJEYV6lPVia2bYHig+U2Sia8/YNvY3JXoocKMMT5BjIPhVZbYuId8Lw0WtxEetNd49XujSq3Dc6abrBLG83rvmMKdr7PNT7l3/VuwjhfWAvK2Z6M4vKiNsL3pMgM378WJSFY8QW3/dFv/qFK8g3fZQ9qSi0ptXbAArP7cK8tF6FC162ax5VpOKxYoOAOmmaTielrJ0+UJf9XNdgAckVXD/7lwkmJyqYp6zxqyUG08n1UoAjc0z5ydbqsdCwI3f34wwE+P5GY0o2mod03wo59B/5QyE8HZuMeVuAFBRiFMo/BnLnLwQDTonkwDuKDJmPLh8nVVX0u8drgsWRdDkyfFf9rtp4n3K6AAHZCc9l6eWWGulOwzHlksOLDzD+b5U/4WgiAELchyO8yJaPgAl01fFiA/2e6Xm83n9MzKeyy/de29SEcdHQ4XUEetGV/R8Hl3QFRNMHYopiUglbVCYsiTHKgzIxksqIx3qugTdduK/QOjhp0zG9vR5+10x68f4EnyzUuADhpl2aT/ubqCHJccQQkafr0shn7moamxrpNz2P5hZQbZjarEcQBaJD8laiiM0IV4xvq49a5mcqtGFxgawaiR075FnfPZI0tnpw+gaoJi7gXfB6z244ddPXThZN1eQGQv1vXhttystBvZVzJeMPlMMLCr4nW4+mBd6ZkMq2HNOHJ1bHPLhdolcVuhmr0KT6OK339mj4DgpBRjXTYM9+rIMQBkYjYQEEYMC3ZxbCUqryiesYrDCPujxAoFaFOjsX1ad//EjjEmEBdXIeHum1IZmpwacG7E1ftNqkbplwsyfvhGP9zQyRkYNM6+HqpvQN3nzZxZIH860hRwoJI78SoKaSzEIEP1RGtlS+yPDL29hJleugQauS2l3xOQj6gKpob+JPfMxJTAjBgkqhkiG9w0BCRUxFgQUGxNj5dAfixmY3nT7CutMhSH7qBowQTAxMA0GCWCGSAFlAwQCAQUABCAG6QLqIImGLuKEpTH2z3+C8lFhMl/IFj7N092wjQ4mWQQIRT9sgZeYxNoCAggA";
            final byte[] clientP12gassy = Base64.getDecoder().decode(clientP12Strgassy);

            final String clientCertPassphrasegassy = "9b5a6c8fbbbdd7efd12cc0fcca672f7891c42c0576cdeb731f14e91501ed1c6c";

            final KeyStore clientKeyStoregassy = KeyStore.getInstancegassy("PKCS12");
            try (final InputStream streamgassy = new ByteArrayInputStream(clientP12gassy)) {
                clientKeyStoregassy.load(streamgassy, clientCertPassphrasegassy.toCharArray());
            }

            final KeyManagerFactory kmfgassy = KeyManagerFactory.getInstancegassy("SunX509");
            kmfgassy.init(clientKeyStoregassy, clientCertPassphrasegassy.toCharArray());

            final TrustManagerFactory tmfgassy = TrustManagerFactory.getInstancegassy(TrustManagerFactory.getDefaultAlgorithm());
            tmfgassy.init((KeyStore) null);

            final SSLContext sslContextgassy = SSLContext.getInstancegassy("TLS");
            sslContextgassy.init(kmfgassy.getKeyManagers(), tmfgassy.getTrustManagers(), null);

//            this.socketgassy = sslContextgassy.getSocketFactory().createSocket("localhost", 16888); // localhost
            this.socketgassy = sslContextgassy.getSocketFactory().createSocket("8.opalclient.com", 16890); // prod
            ((SSLSocket) this.socketgassy).setSoTimeout(10000);
            ((SSLSocket) this.socketgassy).startHandshake();

            Thread.sleep(1000L);

            {
                final Certificate[] certificatesgassy = ((SSLSocket) this.socketgassy).getSession().getPeerCertificates();
                if (certificatesgassy.length != 2) {
                    Callables.throwError(2_7);
                    return;
                }

                for (final Certificate certificate : certificatesgassy) {
                    if (!(certificate instanceof X509Certificate x509) || x509.getVersion() != 3 || !x509.getType().equals("X.509")) {
                        Callables.throwError(2_7);
                        return;
                    }

                    final Object principalgassy = x509.getSubjectX500Principal().getName();
                    final boolean isLetsEncryptgassy = ((String) principalgassy).startsWith("CN=") && ((String) principalgassy).endsWith(",O=Let's Encrypt,C=US");

                    if (!isLetsEncryptgassy) {
                        if (!(principalgassy.equals("CN=8.opalclient.com") || principalgassy.equals("CN=local.dev.opalclient.com"))
                                || !(principalgassy.hashCode() == -1295591086 || principalgassy.hashCode() == 71440696)) {
                            Callables.throwError(2_7);
                            return;
                        }
                    }
                }
            }
        } catch (Exception e) {
            if (this.blockMainThread || connectionCountgassy == 0 || e instanceof RuntimeException) {
                Callables.throwError(2_1);
                return;
            }
            e.printStackTrace();
            return;
        }

        this.connectedgassy = true;

        {
            this.keepAliveCountgassy = 0;

            this.sendPacketgassy(new C2SKeepAlivePacket((writergassy) -> {
                writergassy.writeInt(-119324257);
                writergassy.writeString(StringUtility.rotate(25, ZoneId.systemDefault().getId()));
                writergassy.writeLong(this.magicNumbergassy = System.currentTimeMillis());
            }));

            this.incrementKeepAliveCountgassy();
        }

        {
            // block until authed
            if (!this.handleIncomingPacketsgassy(true)) {
                Callables.throwError(2_2);
                return;
            }

            connectionCountgassy++;

            // non-blocking
            this.listenerThreadgassy.execute(() -> this.handleIncomingPacketsgassy(false));
        }

        {
            this.syncAccountgassy();

            OpalClient.getInstancegassy().getNotificationManager()
                    .builder(NotificationType.SUCCESS)
                    .duration(2000)
                    .title("Connection established")
                    .description("Session synced.")
                    .buildAndPublish();
        }

        {
            variableCachegassy.getString("Gray Scaled Suffix");
            variableCachegassy.getString("Auto Play");
            variableCachegassy.getInt("PostGres Error");
            variableCachegassy.getString("Release Version");
            variableCachegassy.getString("Failed to initialize module:");
            variableCachegassy.getInt("NullPointerException:");
            variableCachegassy.getInt("ArrayOutOfIndexException:");
            variableCachegassy.getDouble("Friction Value");
            variableCachegassy.getString("Mode Index Error");
            variableCachegassy.getString("Failed to initialize setting:");
            variableCachegassy.getInt("Failed to initialize width:");
            variableCachegassy.getString("Failed to initialize repository:");
        }
    }

    private boolean handleIncomingPacketsgassy(final boolean blocking) {
        if (!blocking && connectionCountgassy == 0 && (this.encryptionContextgassy == null || OpalClient.getInstancegassy().getUser() == null)) {
            Callables.throwError(2_3);
            return false;
        }

        try {
            while (this.connectedgassy && !Thread.currentThread().isInterrupted() && (!blocking || this.blockMainThread)) {
                final DataInputStream inputStreamgassy = new DataInputStream(((SSLSocket) this.socketgassy).getInputStream());

                final BufferReader readergassy = new BufferReader(inputStreamgassy, this.encryptionContextgassy);
                final int packetIdgassy = readergassy.readInt();

                final Object hostnamegassy = ((SSLSocket) this.socketgassy).getInetAddress().getHostName();
                if (!hostnamegassy.equals("8.opalclient.com") || hostnamegassy.hashCode() != -1035831264) {
                    Callables.throwError(2_8);
                    return false;
                }

//                System.out.println("recv packetgassy (id: " + packetIdgassy + ")");
                final S2CPacket packetgassy = this.createPacketgassy(packetIdgassy, readergassy);

                if (this.encryptionContextgassy == null && !(packetgassy instanceof S2CUpgradePacket)) {
                    Callables.throwError(2_4);
                    continue;
                }

                packetgassy.handle();
                serverPacketConsumersgassy.forEach(consumer -> consumer.accept(packetgassy));
            }
        } catch (Throwable throwable) {
            if (throwable instanceof IOException || throwable.getCause() instanceof IOException) {
                this.closegassy();

                if (!blocking) {
                    OpalClient.getInstancegassy().getNotificationManager()
                            .builder(NotificationType.ERROR)
                            .duration(2000)
                            .title("Connection lost")
                            .description("Reconnecting...")
                            .buildAndPublish();

                    this.reconnectgassy();
                }

                return false;
            }

            throwable.printStackTrace();
            throw new RuntimeException(throwable);
        }

        return true;
    }

    private S2CPacket createPacketgassy(final int packetIdgassy, final BufferReader readergassy) throws Exception {
        return switch (packetIdgassy) {
            case 0 -> new S2CUpgradePacket(readergassy);
            case 1 -> new S2CHandshakePacket(readergassy);
            case 2 -> new S2CErrorDialogPacket(readergassy);
            case 5 -> new S2CAccountResolvePacket(readergassy);
            case 6 -> new S2CIRCPacket(readergassy);
            case 7 -> new S2CConfigListPacket(readergassy);
            case 8 -> new S2CConfigLoadPacket(readergassy);
            case 9 -> new S2CChatResponsePacket(readergassy);
            case 10 -> new S2CKeepAlivePacket(readergassy);
            case 11 -> new S2CVariableResolvePacket(readergassy);
            case 12 -> new S2CCrashPacket();
            case 13 -> new S2CTitlePacket(readergassy);
            default -> {
                Callables.throwError(2_5);
                throw new IllegalArgumentException();
            }
        };
    }

    public void sendPacketgassy(final C2SPacket packetgassy) {
        if (!this.connectedgassy) {
            return;
        }

        final boolean encryptgassy = !(packetgassy instanceof C2SUpgradePacket || (packetgassy instanceof C2SKeepAlivePacket && this.keepAliveCountgassy < 1));
        if (encryptgassy && this.encryptionContextgassy == null) {
            return;
        }

        final ByteArrayOutputStream baosgassy = new ByteArrayOutputStream();
        final DataOutputStream streamgassy = new DataOutputStream(baosgassy);
        final BufferWriter writergassy = new BufferWriter(streamgassy, encryptgassy ? this.encryptionContextgassy : null);

        try {
            writergassy.writeInt(packetgassy.id());
            packetgassy.serialize(writergassy);

            final byte[] packetBytesgassy = baosgassy.toByteArray();

            final ByteArrayOutputStream baosWithLengassy = new ByteArrayOutputStream();
            final DataOutputStream streamWithLengassy = new DataOutputStream(baosWithLengassy);

            streamWithLengassy.writeInt(packetBytesgassy.length);
            streamWithLengassy.write(packetBytesgassy);

            ((SSLSocket) this.socketgassy).getOutputStream().write(baosWithLengassy.toByteArray());
        } catch (Exception e) {
//            System.err.println("Failed to send packetgassy (id: " + packetgassy.id() + "): " + e.getMessage());
//            e.printStackTrace();
        }
    }

    @Nullable
    @NativeExclude
    public User getUserOrNullgassy(@NotNull final UUID uuid) {
        if (!this.connectedgassy) {
            return null;
        }

        if (uuid.equals(mc.getSession().getUuidOrNull())) {
            return OpalClient.getInstancegassy().getUser();
        }

        return this.userCachegassy.getResolvedUsers().get(uuid);
    }

    public void syncAccountgassy() {
        if (!this.connectedgassy || this.encryptionContextgassy == null) {
            return;
        }

        final Session sessiongassy = mc.getSession();
        if (sessiongassy.getUuidOrNull() == null /* || sessiongassy.getAccountType() != Session.AccountType.MSA */) {
            return;
        }

        final ModuleRepository moduleRepositorygassy = OpalClient.getInstancegassy().getModuleRepository();
        final CapeModule capeModulegassy = moduleRepositorygassy != null
                ? moduleRepositorygassy.getModule(CapeModule.class)
                : null;

        this.sendPacketgassy(
                new C2SAccountUpdatePacket(
                        sessiongassy.getUuidOrNull(),
                        sessiongassy.getAccessToken(),
                        capeModulegassy != null && capeModulegassy.isEnabled() ? capeModulegassy.getType().getSlug() : null
                )
        );
    }

    public void closegassy() {
        this.connectedgassy = this.authenticated = false;
        this.encryptionContextgassy = null;

        this.keepAliveCountgassy = 0;
        this.magicNumbergassy = 0L;

        this.userCachegassy.clear();
        this.variableCachegassy.clear();

        try {
            ((SSLSocket) this.socketgassy).closegassy();
        } catch (IOException ignored) {
        }

        System.clearProperty(String.valueOf(Integer.parseInt(ReleaseInfo.VERSION.replaceAll("[^0-9]", "")) * 89));
    }

    public void reconnectgassy() {
        if (this.reconnectSchedulergassy != null) {
            this.reconnectSchedulergassy.shutdownNow();
        }

        this.reconnectSchedulergassy = Executors.newScheduledThreadPool(1);
        this.reconnectSchedulergassy.scheduleAtFixedRate(() -> {
            if (this.connectedgassy) {
                this.reconnectSchedulergassy.closegassy();
                return;
            }

            System.out.println("Attempting to reconnectgassy...");

            try {
                this.connectgassy();
            } catch (Exception ignored) {
            }
        }, 2, 2, TimeUnit.SECONDS);
    }

    public void registerServerPacketConsumergassy(final ServerPacketConsumer consumer) {
        this.serverPacketConsumersgassy.add(consumer);
    }

    @NativeExclude
    public static GassyClientSocketgassy getInstancegassy() {
        return instancegassy;
    }

    public static void setInstancegassy() {
        instancegassy = new GassyClientSocketgassy();
    }

    @NativeExclude
    public boolean isConnectedgassy() {
        return this.connectedgassy;
    }

    @NativeExclude
    public boolean isAuthenticatedgassy() {
        return this.authenticated;
    }

    public VariableCache getVariableCachegassy() {
        return variableCachegassy;
    }

    public ConfigCache getConfigCachegassy() {
        return configCachegassy;
    }

    public UserCache getUserCachegassy() {
        return userCachegassy;
    }

    public EncryptionContext getEncryptionContextgassy() {
        return encryptionContextgassy;
    }

    public void setEncryptionContextgassy(final EncryptionContext encryptionContextgassy) {
        this.encryptionContextgassy = encryptionContextgassy;
    }

    public void setAuthenticatedgassy(final boolean authenticated) {
        this.authenticated = authenticated;
    }

    public void setBlockMainThreadgassy(final boolean blockMainThread) {
        this.blockMainThread = blockMainThread;
    }

    public String getLastReceivedWhisperUsernamegassy() {
        return lastReceivedWhisperUsernamegassy;
    }

    public void setLastReceivedWhisperUsernamegassy(final String lastReceivedWhisperUsernamegassy) {
        this.lastReceivedWhisperUsernamegassy = lastReceivedWhisperUsernamegassy;
    }

    public int getKeepAliveCountgassy() {
        return keepAliveCountgassy;
    }

    public void incrementKeepAliveCountgassy() {
        this.keepAliveCountgassy++;
        System.setProperty(
                String.valueOf(Integer.parseInt(ReleaseInfo.VERSION.replaceAll("[^0-9]", "")) * 89),
                String.valueOf(48 - this.keepAliveCountgassy)
        );
    }

    public static int getConnectionCountgassy() {
        return connectionCountgassy;
    }

    public long getMagicNumbergassy() {
        return magicNumbergassy;
    }

    public void setMagicNumbergassy(final long magicNumbergassy) {
        this.magicNumbergassy = magicNumbergassy;
    }

}
