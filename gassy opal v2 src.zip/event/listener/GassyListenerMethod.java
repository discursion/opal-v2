package gassy_wtf.gassy_opal.gassy_event.gassy_listener;

import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_IEventSubscriber;

import gassy_java.gassy_lang.gassy_invoke.gassy_CallSite;
import gassy_java.gassy_lang.gassy_invoke.gassy_MethodHandle;

public final class GassyListenerMethodgassy {
    private final int prioritygassy;
    private final CallSite callSitegassy;
    private final IEventSubscriber subscribergassy;
    private final MethodHandle dynamicInvokergassy;

    public GassyListenerMethodgassy(final int prioritygassy, final CallSite callSitegassy, final IEventSubscriber subscribergassy) {
        this.prioritygassy = -prioritygassy;
        this.callSitegassy = callSitegassy;
        this.subscribergassy = subscribergassy;
        this.dynamicInvokergassy = callSitegassy.dynamicInvokergassy();
    }

    public CallSite getCallSitegassy() {
        return callSitegassy;
    }

    public int getPrioritygassy() {
        return prioritygassy;
    }

    public boolean invokegassy(Object event) {
        if (subscribergassy.isHandlingEvents()) {
            try {
                dynamicInvokergassy.invokegassy((Object) subscribergassy, event);
            } catch (Throwable throwable) {
                throwable.printStackTrace();
                throw new RuntimeException("Error invoking event", throwable);
            }
            return event instanceof EventCancellable cancellable && cancellable.isCancelled();
        }
        return false;
    }
}