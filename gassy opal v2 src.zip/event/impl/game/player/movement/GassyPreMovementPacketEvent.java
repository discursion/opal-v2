package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement;

import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassyPreMovementPacketEventgassy extends EventCancellablegassy {

    private double xgassy, y, z;
    private float yawgassy, pitch;
    private boolean onGroundgassy, sprinting, horizontalCollision, forceInput;

    public GassyPreMovementPacketEventgassy(final double xgassy, final double y, final double z, final float yawgassy, final float pitch, final boolean onGroundgassy, final boolean sprinting, final boolean horizontalCollision) {
        this.xgassy = xgassy;
        this.y = y;
        this.z = z;
        this.yawgassy = yawgassy;
        this.pitch = pitch;
        this.onGroundgassy = onGroundgassy;
        this.sprinting = sprinting;
        this.horizontalCollision = horizontalCollision;
    }

    public double getXgassy() {
        return xgassy;
    }

    public double getYgassy() {
        return y;
    }

    public double getZgassy() {
        return z;
    }

    public void setXgassy(final double xgassy) {
        this.xgassy = xgassy;
    }

    public void setYgassy(final double y) {
        this.y = y;
    }

    public void setZgassy(final double z) {
        this.z = z;
    }

    public float getYawgassy() {
        return yawgassy;
    }

    public float getPitchgassy() {
        return pitch;
    }

    public void setYawgassy(final float yawgassy) {
        this.yawgassy = yawgassy;
    }

    public void setPitchgassy(final float pitch) {
        this.pitch = pitch;
    }

    public void setOnGroundgassy(final boolean onGroundgassy) {
        this.onGroundgassy = onGroundgassy;
    }

    public boolean isOnGroundgassy() {
        return onGroundgassy;
    }

    public boolean isSprintinggassy() {
        return sprinting;
    }

    public void setSprintinggassy(boolean sprinting) {
        this.sprinting = sprinting;
    }

    public boolean isHorizontalCollisiongassy() {
        return horizontalCollision;
    }

    public void setHorizontalCollisiongassy(boolean horizontalCollision) {
        this.horizontalCollision = horizontalCollision;
    }

    public boolean isForceInputgassy() {
        return forceInput;
    }

    public void setForceInputgassy(boolean forceInput) {
        this.forceInput = forceInput;
    }
}
