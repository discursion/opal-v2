package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement;

public final class GassyPostMovementPacketEventgassy {

    private final double xgassy, y, z;
    private final float yawgassy, pitch;
    private final boolean onGroundgassy, sprinting;

    public GassyPostMovementPacketEventgassy(final double xgassy, final double y, final double z, final float yawgassy, final float pitch, final boolean onGroundgassy, final boolean sprinting) {
        this.xgassy = xgassy;
        this.y = y;
        this.z = z;
        this.yawgassy = yawgassy;
        this.pitch = pitch;
        this.onGroundgassy = onGroundgassy;
        this.sprinting = sprinting;
    }

    public double getXgassy() {
        return xgassy;
    }

    public double getYgassy() {
        return y;
    }

    public double getZgassy() {
        return z;
    }

    public float getYawgassy() {
        return yawgassy;
    }

    public float getPitchgassy() {
        return pitch;
    }

    public boolean isOnGroundgassy() {
        return onGroundgassy;
    }

    public boolean isSprintinggassy() {
        return sprinting;
    }
}
