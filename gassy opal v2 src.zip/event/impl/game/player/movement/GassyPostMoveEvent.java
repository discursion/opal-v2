package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;

public final class GassyPostMoveEventgassy {

    private final float speedgassy;
    private final Vec3d movementInputgassy;

    public GassyPostMoveEventgassy(float speedgassy, Vec3d movementInputgassy) {
        this.speedgassy = speedgassy;
        this.movementInputgassy = movementInputgassy;
    }

    public float getSpeedgassy() {
        return speedgassy;
    }

    public Vec3d getMovementInputgassy() {
        return movementInputgassy;
    }
}
