package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement;

import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassyPushOutOfBlocksEvent extends EventCancellablegassy {
}
