package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_knockback;

import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassyVelocityUpdateEventgassy extends EventCancellablegassy {

    private double velocityXgassy, velocityY, velocityZ;

    private boolean explosiongassy;

    public GassyVelocityUpdateEventgassy(final double velocityXgassy, final double velocityY, final double velocityZ, final boolean explosiongassy) {
        this.velocityXgassy = velocityXgassy;
        this.velocityY = velocityY;
        this.velocityZ = velocityZ;
        this.explosiongassy = explosiongassy;
    }

    public boolean isExplosiongassy() {
        return explosiongassy;
    }

    public double getVelocityXgassy() {
        return velocityXgassy;
    }

    public double getVelocityYgassy() {
        return velocityY;
    }

    public double getVelocityZgassy() {
        return velocityZ;
    }

    public void setVelocityXgassy(final double velocityXgassy) {
        this.velocityXgassy = velocityXgassy;
    }

    public void setVelocityYgassy(final double velocityY) {
        this.velocityY = velocityY;
    }

    public void setVelocityZgassy(final double velocityZ) {
        this.velocityZ = velocityZ;
    }
}
