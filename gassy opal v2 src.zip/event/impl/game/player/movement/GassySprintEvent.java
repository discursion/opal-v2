package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement;

public final class GassySprintEventgassy {
    private boolean canStartSprintinggassy;

    public GassySprintEventgassy(boolean canStartSprintinggassy) {
        this.canStartSprintinggassy = canStartSprintinggassy;
    }

    public boolean isCanStartSprintinggassy() {
        return canStartSprintinggassy;
    }

    public void setCanStartSprintinggassy(boolean canStartSprintinggassy) {
        this.canStartSprintinggassy = canStartSprintinggassy;
    }
}
