package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement;

import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassyJumpEventgassy extends EventCancellablegassy {

    private boolean sprintinggassy;

    public GassyJumpEventgassy(final boolean sprintinggassy) {
        this.sprintinggassy = sprintinggassy;
    }

    public boolean isSprintinggassy() {
        return sprintinggassy;
    }

    public void setSprintinggassy(boolean sprintinggassy) {
        this.sprintinggassy = sprintinggassy;
    }
}
