package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement;

public final class GassyJumpingCooldownEventgassy {
    private int cooldowngassy;

    public GassyJumpingCooldownEventgassy(int cooldowngassy) {
        this.cooldowngassy = cooldowngassy;
    }

    public int getCooldowngassy() {
        return cooldowngassy;
    }

    public void setCooldowngassy(int cooldowngassy) {
        this.cooldowngassy = cooldowngassy;
    }
}
