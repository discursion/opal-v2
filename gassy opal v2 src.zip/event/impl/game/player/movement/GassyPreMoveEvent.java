package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassyPreMoveEventgassy extends EventCancellablegassy {

    private final float speedgassy;
    private final Vec3d movementInputgassy;

    public GassyPreMoveEventgassy(float speedgassy, Vec3d movementInputgassy) {
        this.speedgassy = speedgassy;
        this.movementInputgassy = movementInputgassy;
    }

    public float getSpeedgassy() {
        return speedgassy;
    }

    public Vec3d getMovementInputgassy() {
        return movementInputgassy;
    }
}
