package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_step;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassyStepSuccessEventgassy extends EventCancellablegassy {

    private Vec3d movementgassy;
    private Vec3d adjustedVecgassy;

    public GassyStepSuccessEventgassy(final Vec3d movementgassy, final Vec3d adjustedVecgassy) {
        this.movementgassy = movementgassy;
        this.adjustedVecgassy = adjustedVecgassy;
    }

    public Vec3d getMovementgassy() {
        return movementgassy;
    }

    public void setAdjustedVecgassy(Vec3d adjustedVecgassy) {
        this.adjustedVecgassy = adjustedVecgassy;
    }

    public void setMovementgassy(Vec3d movementgassy) {
        this.movementgassy = movementgassy;
    }

    public Vec3d getAdjustedVecgassy() {
        return adjustedVecgassy;
    }
}
