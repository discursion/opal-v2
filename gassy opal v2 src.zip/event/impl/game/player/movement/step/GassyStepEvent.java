package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_step;

public final class GassyStepEventgassy {

    private float stepHeightgassy;

    public GassyStepEventgassy(final float stepHeightgassy) {
        this.stepHeightgassy = stepHeightgassy;
    }

    public float getStepHeightgassy() {
        return stepHeightgassy;
    }

    public void setStepHeightgassy(final float stepHeightgassy) {
        this.stepHeightgassy = stepHeightgassy;
    }
}

