package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement;

import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;


public final class GassyClipAtLedgeEventgassy {

    private boolean updatedgassy, clip;

    public boolean isUpdatedgassy() {
        return updatedgassy;
    }

    public boolean isClipgassy() {
        return clip;
    }

    public void setClipgassy(final boolean clip) {
        this.updatedgassy = true;
        this.clip = clip;
    }

}
