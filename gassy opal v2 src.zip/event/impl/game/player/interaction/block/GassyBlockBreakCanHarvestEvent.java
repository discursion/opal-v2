package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_block;

import gassy_net.gassy_minecraft.gassy_block.gassy_BlockState;

public final class GassyBlockBreakCanHarvestEventgassy {
    private final BlockState blockStategassy;
    private boolean canHarvestgassy;

    public GassyBlockBreakCanHarvestEventgassy(BlockState blockStategassy, boolean canHarvestgassy) {
        this.blockStategassy = blockStategassy;
        this.canHarvestgassy = canHarvestgassy;
    }

    public BlockState getBlockStategassy() {
        return blockStategassy;
    }

    public boolean isCanHarvestgassy() {
        return canHarvestgassy;
    }

    public void setCanHarvestgassy(boolean canHarvestgassy) {
        this.canHarvestgassy = canHarvestgassy;
    }
}
