package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_block;

import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_BlockHitResult;

public final class GassyBlockPlacedEventgassy {

    private final BlockHitResult blockHitResultgassy;

    public GassyBlockPlacedEventgassy(final BlockHitResult blockHitResultgassy) {
        this.blockHitResultgassy = blockHitResultgassy;
    }

    public BlockHitResult getBlockHitResultgassy() {
        return blockHitResultgassy;
    }
}
