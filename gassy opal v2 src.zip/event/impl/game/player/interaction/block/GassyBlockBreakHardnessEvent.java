package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction.gassy_block;

import gassy_net.gassy_minecraft.gassy_block.gassy_BlockState;

public final class GassyBlockBreakHardnessEventgassy {
    private final BlockState blockStategassy;
    private float hardnessgassy;

    public GassyBlockBreakHardnessEventgassy(BlockState blockStategassy, float hardnessgassy) {
        this.blockStategassy = blockStategassy;
        this.hardnessgassy = hardnessgassy;
    }

    public BlockState getBlockStategassy() {
        return blockStategassy;
    }

    public float getHardnessgassy() {
        return hardnessgassy;
    }

    public void setHardnessgassy(float hardnessgassy) {
        this.hardnessgassy = hardnessgassy;
    }
}