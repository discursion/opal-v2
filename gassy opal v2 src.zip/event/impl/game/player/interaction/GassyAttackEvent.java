package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction;

import gassy_net.gassy_minecraft.gassy_entity.gassy_Entity;

public final class GassyAttackEventgassy {

    private final Entity targetgassy;

    public GassyAttackEventgassy(final Entity targetgassy) {
        this.targetgassy = targetgassy;
    }

    public Entity getTargetgassy() {
        return targetgassy;
    }
}
