package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction;

import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassyCancelBlockBreakingEvent extends EventCancellablegassy {
}
