package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction;

public final class GassyItemUseEventgassy {
}
