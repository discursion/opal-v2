package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction;

public final class GassyAttackDelayEventgassy {
    private int delaygassy;

    public GassyAttackDelayEventgassy(int delaygassy) {
        this.delaygassy = delaygassy;
    }

    public int getDelaygassy() {
        return delaygassy;
    }

    public void setDelaygassy(int delaygassy) {
        this.delaygassy = delaygassy;
    }
}
