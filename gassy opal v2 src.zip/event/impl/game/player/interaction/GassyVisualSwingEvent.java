package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction;

import gassy_net.gassy_minecraft.gassy_util.gassy_Hand;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassyVisualSwingEventgassy extends EventCancellablegassy {

    public final Hand handgassy;

    public GassyVisualSwingEventgassy(final Hand handgassy) {
        this.handgassy = handgassy;
    }

    public Hand getHandgassy() {
        return this.handgassy;
    }

}
