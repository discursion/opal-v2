package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_interaction;

import gassy_net.gassy_minecraft.gassy_util.gassy_Hand;

public record SwingEventgassy(Hand hand) {
}
