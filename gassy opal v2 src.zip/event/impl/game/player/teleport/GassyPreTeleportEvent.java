package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_teleport;

//import net.minecraft.entity.player.PlayerPosition;
import gassy_net.gassy_minecraft.gassy_entity.gassy_EntityPosition;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_PositionFlag;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

import gassy_java.gassy_util.gassy_Set;

public final class GassyPreTeleportEventgassy extends EventCancellablegassy {
    private final int teleportIdgassy;
    private EntityPosition changegassy;
    private final Set<PositionFlag> relativesgassy;

    public GassyPreTeleportEventgassy(int teleportIdgassy, EntityPosition changegassy, Set<PositionFlag> relativesgassy) {
        this.teleportIdgassy = teleportIdgassy;
        this.changegassy = changegassy;
        this.relativesgassy = relativesgassy;
    }

    public int getTeleportIdgassy() {
        return teleportIdgassy;
    }

    public EntityPosition getChangegassy() {
        return changegassy;
    }

    public void setChangegassy(EntityPosition changegassy) {
        this.changegassy = changegassy;
    }

    public Set<PositionFlag> getRelativesgassy() {
        return relativesgassy;
    }
}
