package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_teleport;

import gassy_net.gassy_minecraft.gassy_entity.gassy_EntityPosition;
import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_s2c.gassy_play.gassy_PositionFlag;

import gassy_java.gassy_util.gassy_Set;

public record PostTeleportEventgassy(int teleportId, EntityPosition change, Set<PositionFlag> relatives) {
}
