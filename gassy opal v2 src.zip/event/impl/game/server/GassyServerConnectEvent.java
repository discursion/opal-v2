package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_server;

import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_ServerAddress;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassyServerConnectEventgassy extends EventCancellablegassy {

    private final ServerAddress serverAddressgassy;

    public GassyServerConnectEventgassy(final ServerAddress serverAddressgassy) {
        this.serverAddressgassy = serverAddressgassy;
    }

    public ServerAddress getServerAddressgassy() {
        return serverAddressgassy;
    }

}
