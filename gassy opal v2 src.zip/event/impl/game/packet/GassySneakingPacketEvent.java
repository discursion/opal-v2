package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet;

public final class GassySneakingPacketEventgassy {
    private boolean sneakinggassy;

    public GassySneakingPacketEventgassy(boolean sneakinggassy) {
        this.sneakinggassy = sneakinggassy;
    }

    public boolean isSneakinggassy() {
        return sneakinggassy;
    }

    public void setSneakinggassy(boolean sneakinggassy) {
        this.sneakinggassy = sneakinggassy;
    }
}
