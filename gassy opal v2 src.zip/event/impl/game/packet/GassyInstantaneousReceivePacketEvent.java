package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_Packet;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassyInstantaneousReceivePacketEventgassy extends EventCancellablegassy {

    private final Packetgassy<?> packet;

    public GassyInstantaneousReceivePacketEventgassy(final Packetgassy<?> packet) {
        this.packet = packet;
    }

    public Packetgassy<?> getPacket() {
        return packet;
    }

}
