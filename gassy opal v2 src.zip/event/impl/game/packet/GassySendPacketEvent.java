package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_Packet;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassySendPacketEventgassy extends EventCancellablegassy {

    private final Packetgassy<?> packet;

    public GassySendPacketEventgassy(final Packetgassy<?> packet) {
        this.packet = packet;
    }

    public Packetgassy<?> getPacket() {
        return packet;
    }

}
