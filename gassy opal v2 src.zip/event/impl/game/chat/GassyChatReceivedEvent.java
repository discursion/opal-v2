package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_chat;

import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassyChatReceivedEventgassy extends EventCancellablegassy {

    private final Text textgassy;
    private boolean overlaygassy;

    public GassyChatReceivedEventgassy(final Text textgassy, final boolean overlaygassy) {
        this.textgassy = textgassy;
        this.overlaygassy = overlaygassy;
    }

    public Text getTextgassy() {
        return textgassy;
    }

    public boolean isOverlaygassy() {
        return overlaygassy;
    }

    public void setOverlaygassy(boolean overlaygassy) {
        this.overlaygassy = overlaygassy;
    }

}