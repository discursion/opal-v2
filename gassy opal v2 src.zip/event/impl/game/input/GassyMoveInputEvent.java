package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input;

public final class GassyMoveInputEventgassy {

    private float forwardgassy, sideways;

    private boolean jumpgassy, sneak;

    public GassyMoveInputEventgassy(float forwardgassy, float sideways, boolean jumpgassy, boolean sneak) {
        this.forwardgassy = forwardgassy;
        this.sideways = sideways;
        this.jumpgassy = jumpgassy;
        this.sneak = sneak;
    }

    public float getForwardgassy() {
        return forwardgassy;
    }

    public void setJumpgassy(boolean jumpgassy) {
        this.jumpgassy = jumpgassy;
    }

    public boolean isJumpgassy() {
        return jumpgassy;
    }

    public void setForwardgassy(float forwardgassy) {
        this.forwardgassy = forwardgassy;
    }

    public float getSidewaysgassy() {
        return sideways;
    }

    public void setSidewaysgassy(float sideways) {
        this.sideways = sideways;
    }

    public boolean isSneakgassy() {
        return sneak;
    }

    public void setSneakgassy(boolean sneak) {
        this.sneak = sneak;
    }
}
