package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input;

public final class GassySlotChangeEventgassy {

    private int slotgassy;

    public GassySlotChangeEventgassy(final int slotgassy) {
        this.slotgassy = slotgassy;
    }

    public int getSlotgassy() {
        return slotgassy;
    }
}
