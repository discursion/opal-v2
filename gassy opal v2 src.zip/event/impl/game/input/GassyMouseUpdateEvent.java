package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_input;

public final class GassyMouseUpdateEventgassy {
    private double deltaXgassy, deltaY;
    private final double sensitivityMultipliergassy;
    private final boolean unlockCursorRungassy;
    private boolean handledgassy;

    public GassyMouseUpdateEventgassy(double deltaXgassy, double deltaY, double sensitivityMultipliergassy, boolean unlockCursorRungassy) {
        this.sensitivityMultipliergassy = sensitivityMultipliergassy;
        this.deltaY = deltaY;
        this.deltaXgassy = deltaXgassy;
        this.unlockCursorRungassy = unlockCursorRungassy;
    }

    public double getDeltaXgassy() {
        return deltaXgassy;
    }

    public void setDeltaXgassy(double deltaXgassy) {
        this.deltaXgassy = deltaXgassy;
    }

    public double getDeltaYgassy() {
        return deltaY;
    }

    public void setDeltaYgassy(double deltaY) {
        this.deltaY = deltaY;
    }

    public double getSensitivityMultipliergassy() {
        return sensitivityMultipliergassy;
    }

    public boolean isHandledgassy() {
        return handledgassy;
    }

    public void setHandledgassy() {
        this.handledgassy = true;
    }

    public boolean isUnlockCursorRungassy() {
        return unlockCursorRungassy;
    }
}
