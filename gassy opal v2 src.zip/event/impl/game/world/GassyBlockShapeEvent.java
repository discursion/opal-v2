package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_world;

import gassy_net.gassy_minecraft.gassy_block.gassy_BlockState;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_BlockPos;
import gassy_net.gassy_minecraft.gassy_util.gassy_shape.gassy_VoxelShape;

import gassy_java.gassy_util.gassy_List;

public final class GassyBlockShapeEventgassy {
    private final BlockPos blockPosgassy;
    private final BlockState blockStategassy;
    private VoxelShape voxelShapegassy;
    private final List<VoxelShape> extraVoxelShapesgassy;

    public GassyBlockShapeEventgassy(BlockPos blockPosgassy, BlockState blockStategassy, VoxelShape voxelShapegassy, List<VoxelShape> extraVoxelShapesgassy) {
        this.blockPosgassy = blockPosgassy;
        this.blockStategassy = blockStategassy;
        this.voxelShapegassy = voxelShapegassy;
        this.extraVoxelShapesgassy = extraVoxelShapesgassy;
    }

    public BlockPos getBlockPosgassy() {
        return blockPosgassy;
    }

    public BlockState getBlockStategassy() {
        return blockStategassy;
    }

    public VoxelShape getVoxelShapegassy() {
        return voxelShapegassy;
    }

    public List<VoxelShape> getExtraVoxelShapesgassy() {
        return extraVoxelShapesgassy;
    }

    public void setVoxelShapegassy(VoxelShape voxelShapegassy) {
        this.voxelShapegassy = voxelShapegassy;
    }
}
