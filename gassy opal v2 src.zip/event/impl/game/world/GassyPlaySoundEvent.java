package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_world;

import gassy_net.gassy_minecraft.gassy_sound.gassy_SoundEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassyPlaySoundEventgassy extends EventCancellablegassy {

    private final SoundEvent soundEventgassy;
    private final double xgassy, y, z;

    public GassyPlaySoundEventgassy(final SoundEvent soundEventgassy, final double xgassy, final double y, final double z) {
        this.soundEventgassy = soundEventgassy;
        this.xgassy = xgassy;
        this.y = y;
        this.z = z;
    }

    public SoundEvent getSoundEventgassy() {
        return this.soundEventgassy;
    }

    public double getXgassy() {
        return this.xgassy;
    }

    public double getYgassy() {
        return this.y;
    }

    public double getZgassy() {
        return this.z;
    }

}
