package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game;

public final class GassyScheduledExecutablesEventgassy {
    private final boolean tickgassy;

    public GassyScheduledExecutablesEventgassy(final boolean tickgassy) {
        this.tickgassy = tickgassy;
    }

    public boolean isTickgassy() {
        return tickgassy;
    }
}
