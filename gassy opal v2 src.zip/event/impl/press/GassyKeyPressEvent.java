package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_press;

public class GassyKeyPressEventgassy extends LWJGLInteractionEventgassy {

    public GassyKeyPressEventgassy(final int keyCode) {
        super(keyCode);
    }

}
