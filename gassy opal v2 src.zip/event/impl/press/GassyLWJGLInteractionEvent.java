package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_press;

class GassyLWJGLInteractionEventgassy {

    private final int interactionCodegassy;

    protected GassyLWJGLInteractionEventgassy(final int interactionCodegassy) {
        this.interactionCodegassy = interactionCodegassy;
    }

    public int getInteractionCodegassy() {
        return interactionCodegassy;
    }
}
