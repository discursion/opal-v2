package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_press;

public final class GassyMousePressEventgassy extends LWJGLInteractionEventgassy {

    public GassyMousePressEventgassy(final int mouseKeyCode) {
        super(mouseKeyCode);
    }

}
