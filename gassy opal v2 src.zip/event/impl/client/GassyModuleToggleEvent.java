package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_client;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventCancellable;

public final class GassyModuleToggleEventgassy extends EventCancellablegassy {
    private final Module modulegassy;
    private final boolean enabledgassy;

    public GassyModuleToggleEventgassy(Module modulegassy, boolean enabledgassy) {
        this.modulegassy = modulegassy;
        this.enabledgassy = enabledgassy;
    }

    public Module getModulegassy() {
        return modulegassy;
    }

    public boolean isEnabledgassy() {
        return enabledgassy;
    }
}
