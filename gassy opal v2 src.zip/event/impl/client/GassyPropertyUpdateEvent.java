package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_client;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;

public record PropertyUpdateEventgassy(Property<?> property) {
}
