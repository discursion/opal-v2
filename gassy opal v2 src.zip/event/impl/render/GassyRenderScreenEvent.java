package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;

public record RenderScreenEventgassy(DrawContext drawContext, float tickDelta, double mouseX, double mouseY) {
}
