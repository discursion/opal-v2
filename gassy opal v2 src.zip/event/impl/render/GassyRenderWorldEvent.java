package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render;

import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_VertexConsumerProvider;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_math.gassy_MatrixStack;

public record RenderWorldEventgassy(VertexConsumerProvider.Immediate vertexConsumers,
                               MatrixStack matrixStack, float tickDelta) {
}
