package gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render;

public final class GassyResolutionChangeEventgassy {
}
