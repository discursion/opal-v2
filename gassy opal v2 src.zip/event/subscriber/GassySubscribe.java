package gassy_wtf.gassy_opal.gassy_event.gassy_subscriber;

import gassy_java.gassy_lang.gassy_annotation.gassy_ElementType;
import gassy_java.gassy_lang.gassy_annotation.gassy_Retention;
import gassy_java.gassy_lang.gassy_annotation.gassy_RetentionPolicy;
import gassy_java.gassy_lang.gassy_annotation.gassy_Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Subscribe {
    // higher priorities are called before lower priorities
    int priority() default 0;
}
