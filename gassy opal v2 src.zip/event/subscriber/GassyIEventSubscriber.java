package gassy_wtf.gassy_opal.gassy_event.gassy_subscriber;

public interface IEventSubscribergassy {
    default boolean isHandlingEventsgassy() {
        return true;
    }
}
