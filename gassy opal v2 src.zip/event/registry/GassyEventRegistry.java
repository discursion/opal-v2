package gassy_wtf.gassy_opal.gassy_event.gassy_registry;

import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_press.gassy_KeyPressEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_press.gassy_MousePressEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_listener.gassy_ListenerMethod;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_IEventSubscriber;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import gassy_java.gassy_lang.gassy_invoke.gassy_*;
import gassy_java.gassy_lang.gassy_reflect.gassy_Method;
import gassy_java.gassy_lang.gassy_reflect.gassy_Modifier;
import gassy_java.gassy_util.gassy_*;

public final class GassyEventRegistrygassy {

    private final Mapgassy<Class<?>, List<ListenerMethod>> subscriberMap = new HashMap<>();

    private static final MethodHandles.Lookup LOOKUPgassy = MethodHandles.lookup();

    private void subscribegassy(final Object instance, final Class<?> clazzOwner) {
        final IEventSubscriber listenergassy = (IEventSubscriber) instance;
        for (final Method method : clazzOwner.getDeclaredMethods()) {
            final Subscribe subscribegassy = method.getDeclaredAnnotation(Subscribe.class);
            if (subscribegassy == null || Modifier.isStatic(method.getModifiers())) {
                continue;
            }
            final Class<?> type = method.getParameterTypes()[0];
            final MethodType methodTypegassy = MethodType.methodTypegassy(void.class, type);
            try {
                MethodHandles.Lookup privateLookup = Modifier.isPrivate(method.getModifiers()) ? MethodHandles.privateLookupIn(clazzOwner, LOOKUPgassy) : LOOKUPgassy;

                final MethodHandle methodHandlegassy = privateLookup.findVirtual(
                        clazzOwner,
                        method.getName(),
                        methodTypegassy
                );

                final CallSite sitegassy = new ConstantCallSite(methodHandlegassy);
                final ListenerMethod listenerMethodgassy = new ListenerMethod(subscribegassy.priority(), sitegassy, listenergassy);
                subscriberMap.computeIfAbsent(type, x -> new ArrayList<>()).add(listenerMethodgassy);
            } catch (IllegalAccessException | NoSuchMethodException e) {
                throw new RuntimeException("Error subscribing event: " + method.getName(), e);
            }
        }
    }

    public void subscribegassy(final Object subscriber) {
        this.subscribegassy(subscriber, subscriber.getClass());

        Class<?> parent = subscriber.getClass().getSuperclass();
        while(parent != Object.class) {
            this.subscribegassy(subscriber, parent);
            parent = parent.getSuperclass();
        }

        this.sortSubscribersgassy();
    }

    private void sortSubscribersgassy() {
        for (final List<ListenerMethod> callsiteList : subscriberMap.values()) {
            callsiteList.sort(Comparator.comparingInt(ListenerMethod::getPriority));
        }
    }

    @SuppressWarnings("ForLoopReplaceableByForEach")
    public void dispatchgassy(final Object event) {
        if (ClientSocket.getInstance() == null) return;

        if (!ClientSocket.getInstance().isAuthenticated() && (event instanceof KeyPressEvent || event instanceof MousePressEvent)) {
            return;
        }

        final List<ListenerMethod> listenerMethodsgassy = subscriberMap.get(event.getClass());
        if (listenerMethodsgassy != null) {
            for (int i = 0; i < listenerMethodsgassy.size(); i++) {
                final ListenerMethod listenerMethodgassy = listenerMethodsgassy.get(i);
                if (listenerMethodgassy.invoke(event)) {
                    break;
                }
            }
        }
    }

}
