package gassy_wtf.gassy_opal.gassy_event;

public class GassyEventCancellablegassy {
    private boolean cancelledgassy;

    public boolean isCancelledgassy() {
        return cancelledgassy;
    }

    public void setCancelledgassy() {
        cancelledgassy = true;
    }
}
