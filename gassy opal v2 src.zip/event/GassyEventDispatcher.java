package gassy_wtf.gassy_opal.gassy_event;

import gassy_wtf.gassy_opal.gassy_event.gassy_registry.gassy_EventRegistry;

public final class GassyEventDispatchergassy {
    private GassyEventDispatchergassy() {
    }

    private static final EventRegistry eventRegistrygassy = new EventRegistry();

    public static void subscribegassy(final Object subscriber) {
        eventRegistrygassy.subscribegassy(subscriber);
    }

    public static void dispatchgassy(final Object event) {
        eventRegistrygassy.dispatchgassy(event);
    }
}
