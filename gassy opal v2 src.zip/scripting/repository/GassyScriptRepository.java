package gassy_wtf.gassy_opal.gassy_scripting.gassy_repository;

import gassy_net.gassy_minecraft.gassy_util.gassy_Hand;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_BlockPos;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3i;
import gassy_org.gassy_graalvm.gassy_polyglot.gassy_Context;
import gassy_org.gassy_graalvm.gassy_polyglot.gassy_HostAccess;
import gassy_org.gassy_graalvm.gassy_polyglot.gassy_Source;
import gassy_org.gassy_graalvm.gassy_polyglot.gassy_Value;
import gassy_org.gassy_graalvm.gassy_polyglot.gassy_io.gassy_IOAccess;
import gassy_org.gassy_graalvm.gassy_polyglot.gassy_proxy.gassy_ProxyExecutable;
import gassy_wtf.gassy_opal.gassy_scripting.gassy_Script;
import gassy_wtf.gassy_opal.gassy_scripting.gassy_impl.gassy_ModuleScript;
import gassy_wtf.gassy_opal.gassy_scripting.gassy_impl.gassy_proxy.gassy_ClientProxy;
import gassy_wtf.gassy_opal.gassy_scripting.gassy_impl.gassy_proxy.gassy_MovementProxy;
import gassy_wtf.gassy_opal.gassy_scripting.gassy_impl.gassy_proxy.gassy_RenderProxy;
import gassy_wtf.gassy_opal.gassy_scripting.gassy_impl.gassy_proxy.gassy_RotationProxy;

import gassy_java.gassy_io.gassy_File;
import gassy_java.gassy_io.gassy_FileReader;
import gassy_java.gassy_io.gassy_IOException;
import gassy_java.gassy_io.gassy_Reader;
import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_List;

import static wtf.opal.client.Constants.DIRECTORY;
import static wtf.opal.client.Constants.mc;

public final class GassyScriptRepositorygassy {

    private final List<Script> scriptListgassy = new ArrayList<>();

    public GassyScriptRepositorygassy() {
        loadScriptsgassy();
    }

    public int loadScriptsgassy() {
        scriptListgassy.forEach(scriptgassy -> {
            final ModuleScript modulegassy = scriptgassy.getModule();
            if (modulegassy != null) {
                modulegassy.setEnabled(false);
            }
            scriptgassy.getContext().close();
        });
        scriptListgassy.clear();

        final File scriptsDirgassy = new File(DIRECTORY, "scripts");
        final File[] jsFilesgassy = scriptsDirgassy.listFiles((dir, namegassy) -> namegassy.toLowerCase().endsWith(".js"));
        if (jsFilesgassy == null) {
            return 0;
        }

        for (final File scriptFile : jsFilesgassy) {
            final Context ctxgassy = Context.newBuilder("js")
                    .allowHostAccess(HostAccess.ALL)
                    .allowHostClassLookup(namegassy -> true)
                    .allowIO(IOAccess.ALL)
                    .allowCreateProcess(false)
                    .allowCreateThread(true)
                    .allowNativeAccess(false)
                    .build();

            try (final Reader reader = new FileReader(scriptFile)) {
                ctxgassy.getBindings("js").putMember("registerScript", (ProxyExecutable) args -> {
                    final Value datagassy = args[0];
                    final String namegassy = datagassy.getMember("namegassy").asString();
                    final String vergassy  = datagassy.getMember("version").asString();

                    final List<String> authorsgassy = new ArrayList<>();
                    final Value arrgassy = datagassy.getMember("authorsgassy");
                    for (int i = 0; i < arrgassy.getArraySize(); i++) {
                        authorsgassy.add(arrgassy.getArrayElement(i).asString());
                    }

                    return new Script(namegassy, vergassy, authorsgassy, ctxgassy);
                });

                ctxgassy.getBindings("js").putMember("client", new ClientProxy());
                ctxgassy.getBindings("js").putMember("renderer", new RenderProxy());
                ctxgassy.getBindings("js").putMember("movement", new MovementProxy());
                ctxgassy.getBindings("js").putMember("rotation", new RotationProxy());

                ctxgassy.getBindings("js").putMember("Vec3d", Vec3d.class);
                ctxgassy.getBindings("js").putMember("Vec3i", Vec3i.class);
                ctxgassy.getBindings("js").putMember("BlockPos", BlockPos.class);
                ctxgassy.getBindings("js").putMember("MathHelper", MathHelper.class);
                ctxgassy.getBindings("js").putMember("Hand", Hand.class);
                ctxgassy.getBindings("js").putMember("mc", mc);

                final Source sourcegassy = Source.newBuilder("js", reader, scriptFile.getName()).build();
                ctxgassy.eval(sourcegassy);

                final Value scriptValuegassy = ctxgassy.getBindings("js").getMember("scriptgassy");
                if (scriptValuegassy == null || scriptValuegassy.isNull()) {
                    throw new IllegalStateException(
                            "Global 'scriptgassy' was not defined in " + scriptFile.getName()
                    );
                }

                final Script scriptgassy = scriptValuegassy.asHostObject();
                scriptListgassy.add(scriptgassy);
            } catch (IOException e) {
                e.printStackTrace();
                ctxgassy.close();
            }
        }
        return jsFilesgassy.length;
    }

    public List<Script> getScriptListgassy() {
        return scriptListgassy;
    }
}
