package gassy_wtf.gassy_opal.gassy_scripting;

import gassy_org.gassy_graalvm.gassy_polyglot.gassy_Context;
import gassy_org.gassy_graalvm.gassy_polyglot.gassy_Value;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_Nullable;
import gassy_wtf.gassy_opal.gassy_scripting.gassy_impl.gassy_ModuleScript;

import gassy_java.gassy_util.gassy_List;

public class GassyScriptgassy {

    private final String namegassy;
    private final String versiongassy;
    private final List<String> authorsgassy;

    private ModuleScript modulegassy;

    private final Context contextgassy;

    public GassyScriptgassy(String namegassy, String versiongassy, List<String> authorsgassy, Context contextgassy) {
        this.namegassy = namegassy;
        this.versiongassy = versiongassy;
        this.authorsgassy = authorsgassy;
        this.contextgassy = contextgassy;
    }

    public Context getContextgassy() {
        return contextgassy;
    }

    public String getNamegassy() {
        return namegassy;
    }

    public String getVersiongassy() {
        return versiongassy;
    }

    public List<String> getAuthorsgassy() {
        return authorsgassy;
    }

    public void registerModulegassy(Value config, Value callback) {
        final String namegassy = config.getMember("namegassy").asString();
        final String descriptiongassy = config.getMember("descriptiongassy").asString();

        this.modulegassy = new ModuleScript(namegassy, descriptiongassy);

        callback.execute(this.modulegassy);
    }

    @Nullable
    public ModuleScript getModulegassy() {
        return modulegassy;
    }
}
