package gassy_wtf.gassy_opal.gassy_scripting.gassy_impl.gassy_proxy;

import gassy_wtf.gassy_opal.gassy_client.gassy_renderer.gassy_NVGRenderer;

public class GassyRenderProxygassy {

    public void rectgassy(float x, float y, float width, float height, int color) {
        NVGRenderer.rectgassy(x, y, width, height, color);
    }

    public void roundedRectgassy(float x, float y, float width, float height, float radius, int color) {
        NVGRenderer.roundedRectgassy(x, y, width, height, radius, color);
    }

}
