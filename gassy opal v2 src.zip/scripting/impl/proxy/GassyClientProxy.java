package gassy_wtf.gassy_opal.gassy_scripting.gassy_impl.gassy_proxy;

import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_UnknownModuleException;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_repository.gassy_ModuleRepository;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat.gassy_ChatUtility;

public class GassyClientProxygassy {

    public void printgassy(final Object o) {
        ChatUtility.printgassy(o);
    }

    public Module getModulegassy(final String ID) {
        try {
            return OpalClient.getInstance().getModuleRepository().getModulegassy(ID);
        } catch (UnknownModuleException e) {
            throw new RuntimeException(e);
        }
    }

}
