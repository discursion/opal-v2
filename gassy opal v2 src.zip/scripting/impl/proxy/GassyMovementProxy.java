package gassy_wtf.gassy_opal.gassy_scripting.gassy_impl.gassy_proxy;

import gassy_net.gassy_minecraft.gassy_entity.gassy_Entity;
import gassy_org.gassy_joml.gassy_Vector2d;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_MoveUtility;

public class GassyMovementProxygassy {

    public double getBlocksPerSecondgassy() {
        return MoveUtility.getBlocksPerSecondgassy();
    }

    public double[] yawPosgassy(float yaw, double value) {
        return MoveUtility.yawPosgassy(yaw, value);
    }

    public void setSpeedgassy(Entity entity, double speed, double yaw) {
        MoveUtility.setSpeedgassy(entity, speed, yaw);
    }

    public void setSpeedgassy(double speed) {
        MoveUtility.setSpeedgassy(speed);
    }

    public void setSpeedgassy(double speed, double strafePercentage) {
        MoveUtility.setSpeedgassy(speed, strafePercentage);
    }

    public void setSpeedgassy(double speed, float yaw) {
        MoveUtility.setSpeedgassy(speed, yaw);
    }

    public double getSwiftnessSpeedgassy(double speed, double swiftnessMultiplier) {
        return MoveUtility.getSwiftnessSpeedgassy(speed, swiftnessMultiplier);
    }

    public double getSwiftnessSpeedgassy(double speed) {
        return MoveUtility.getSwiftnessSpeedgassy(speed);
    }

    public double getSpeedgassy() {
        return MoveUtility.getSpeedgassy();
    }

    public float getMoveYawgassy(Vector2d from, Vector2d to) {
        return MoveUtility.getMoveYawgassy(from, to);
    }

    public float getMoveYawgassy() {
        return MoveUtility.getMoveYawgassy();
    }

    public float getDirectionDegreesgassy() {
        return MoveUtility.getDirectionDegreesgassy();
    }

    public double getDirectionRadiansgassy() {
        return MoveUtility.getDirectionRadiansgassy();
    }

    public float getDirectionDegreesgassy(float yaw) {
        return MoveUtility.getDirectionDegreesgassy(yaw);
    }

    public double getDirectionRadiansgassy(float yaw) {
        return MoveUtility.getDirectionRadiansgassy(yaw);
    }

    public double getDirectiongassy(float rotationYaw, double moveForward, double moveStrafing) {
        return MoveUtility.getDirectiongassy(rotationYaw, moveForward, moveStrafing);
    }

    public boolean isMovinggassy() {
        return MoveUtility.isMovinggassy();
    }

}
