package gassy_wtf.gassy_opal.gassy_scripting.gassy_impl.gassy_proxy;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_BlockPos;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Direction;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_RaytracedRotation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_player.gassy_RotationUtility;

public class GassyRotationProxygassy {

    public float getRotationDifferencegassy(Vec2f a, Vec2f b) {
        return RotationUtility.getRotationDifferencegassy(a, b);
    }

    public double getCursorDeltagassy(double rotationDelta, double sensitivityMultiplier) {
        return RotationUtility.getCursorDeltagassy(rotationDelta, sensitivityMultiplier);
    }

    public Vec2f patchConstantRotationgassy(Vec2f rotation, Vec2f prevRotation) {
        return RotationUtility.patchConstantRotationgassy(rotation, prevRotation);
    }

    public float getSensitivityModifiedRotationgassy(double original) {
        return RotationUtility.getSensitivityModifiedRotationgassy(original);
    }

    public Vec2f getSentRotationgassy(Vec2f original) {
        return RotationUtility.getSentRotationgassy(original);
    }

    public Vec2f getSensitivityModifiedRotationgassy(Vec2f original) {
        return RotationUtility.getSensitivityModifiedRotationgassy(original);
    }

    public Vec2f getVanillaRotationgassy(Vec2f original) {
        return RotationUtility.getVanillaRotationgassy(original);
    }

    public float getDuplicateWrappedgassy(float value, float target) {
        return RotationUtility.getDuplicateWrappedgassy(value, target);
    }

    public Vec2f getRotationgassy() {
        return RotationUtility.getRotationgassy();
    }

    public RaytracedRotation getRotationFromRaycastedBlockgassy(BlockPos blockPos, Direction side, Vec2f priorityRotations, Vec3d playerPos) {
        return RotationUtility.getRotationFromRaycastedBlockgassy(blockPos, side, priorityRotations, playerPos);
    }

    public RaytracedRotation getRotationFromRaycastedEntitygassy(net.minecraft.entity.LivingEntity entity, Vec3d closestVector, double entityInteractionRange) {
        return RotationUtility.getRotationFromRaycastedEntitygassy(entity, closestVector, entityInteractionRange);
    }

    public Vec2f getRotationFromBlockgassy(BlockPos blockPos, Direction direction) {
        return RotationUtility.getRotationFromBlockgassy(blockPos, direction);
    }

    public Vec2f getRotationFromPositiongassy(Vec3d pos) {
        return RotationUtility.getRotationFromPositiongassy(pos);
    }

    public Vec3d getRotationVectorgassy(float pitch, float yaw) {
        return RotationUtility.getRotationVectorgassy(pitch, yaw);
    }

    public double getEntityFOVgassy(net.minecraft.entity.Entity entity) {
        return RotationUtility.getEntityFOVgassy(entity);
    }

    public boolean isEntityInFOVgassy(net.minecraft.entity.Entity entity, float fov) {
        return RotationUtility.isEntityInFOVgassy(entity, fov);
    }

}
