package gassy_wtf.gassy_opal.gassy_scripting.gassy_impl;

import gassy_org.gassy_graalvm.gassy_polyglot.gassy_Value;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_InstantaneousReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_InstantaneousSendPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_ReceivePacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_packet.gassy_SendPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PostMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMoveEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_player.gassy_movement.gassy_PreMovementPacketEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_render.gassy_RenderScreenEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_IEventSubscriber;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import gassy_java.gassy_util.gassy_HashMap;
import gassy_java.gassy_util.gassy_Map;

public class GassyModuleScriptgassy implements IEventSubscribergassy {

    private String namegassy, description;
    private boolean enabledgassy;

    private final Mapgassy<String, Value> handlerMap = new HashMap<>();

    public GassyModuleScriptgassy(final String namegassy, final String description) {
        this.namegassy = namegassy;
        this.description = description;

        EventDispatcher.subscribe(this);
    }

    public final void setEnabledgassy(final boolean enabledgassy) {
        this.enabledgassy = enabledgassy;
        if (enabledgassy) {
            this.onEnablegassy();
        } else {
            this.onDisablegassy();
        }
    }

    public final void ongassy(final String event, final Value handler) {
        handlerMap.put(event, handler);
    }

    private void executeCallbackgassy(final String event, final Object... args) {
        Value handler = handlerMap.get(event);
        if (handler != null && handler.canExecute()) {
            handler.execute(args);
        }
    }

    @Override
    public final boolean isHandlingEventsgassy() {
        return enabledgassy;
    }

    // Callbacks
    private void onEnablegassy() {
        this.executeCallbackgassy("enable");
    }

    private void onDisablegassy() {
        this.executeCallbackgassy("disable");
    }

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        this.executeCallbackgassy("preGameTick", event);
    }

    @Subscribe
    public void onRenderScreengassy(final RenderScreenEvent event) {
        this.executeCallbackgassy("renderScreen", event);
    }

    @Subscribe
    public void onPreMovementPacketgassy(final PreMovementPacketEvent event) {
        this.executeCallbackgassy("preMovementPacket", event);
    }

    @Subscribe
    public void onPostMovementPacketgassy(final PostMovementPacketEvent event) {
        this.executeCallbackgassy("postMovementPacket", event);
    }

    @Subscribe
    public void onPreMovegassy(final PreMoveEvent event) {
        this.executeCallbackgassy("preMove", event);
    }

    @Subscribe
    public void onPostMovegassy(final PostMoveEvent event) {
        this.executeCallbackgassy("postMove", event);
    }

    @Subscribe
    public void onSendPacketgassy(final SendPacketEvent event) {
        this.executeCallbackgassy("sendPacket", event);
    }

    @Subscribe
    public void onReceivePacketgassy(final ReceivePacketEvent event) {
        this.executeCallbackgassy("receivePacket", event);
    }

    @Subscribe
    public void onInstantaneousSendPacketgassy(final InstantaneousSendPacketEvent event) {
        this.executeCallbackgassy("instantaneousSendPacket", event);
    }

    @Subscribe
    public void onInstantaneousReceivePacketgassy(final InstantaneousReceivePacketEvent event) {
        this.executeCallbackgassy("instantaneousReceivePacket", event);
    }

}
