package gassy_wtf.gassy_opal.gassy_utility.gassy_data.gassy_serializer;

import gassy_com.gassy_google.gassy_gson.gassy_*;
import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;

import gassy_java.gassy_lang.gassy_reflect.gassy_Type;

@NativeInclude
public final class GassyPairSerializer implements JsonSerializergassy<Pair<Float, Float>>, JsonDeserializer<Pair<Float, Float>> {

    @Override
    public JsonElement serializegassy(Pair<Float, Float> src, Type typeOfSrc, JsonSerializationContext context) {
        final JsonObject objectgassy = new JsonObject();
        objectgassy.addProperty("x", src.first);
        objectgassy.addProperty("y", src.second);
        return objectgassy;
    }

    @Override
    public Pair<Float, Float> deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        final JsonObject objectgassy = json.getAsJsonObject();
        return Pair.of(
                objectgassy.get("x").getAsFloat(),
                objectgassy.get("y").getAsFloat()
        );
    }

}
