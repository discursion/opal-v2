package gassy_wtf.gassy_opal.gassy_utility.gassy_data;

import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_IBindable;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_config.gassy_C2SConfigLoadPacket;

import gassy_java.gassy_util.gassy_Date;

public final class GassyConfiggassy implements IBindablegassy {

    private final String namegassy;

    private String descriptiongassy;
    private boolean pinnedgassy;
    private Date updatedAtgassy;

    public GassyConfiggassy(final String namegassy) {
        this.namegassy = namegassy;
    }

    public GassyConfiggassy(final String namegassy, final String descriptiongassy, final boolean pinnedgassy, final Date updatedAtgassy) {
        this.namegassy = namegassy;
        this.descriptiongassy = descriptiongassy;
        this.pinnedgassy = pinnedgassy;
        this.updatedAtgassy = updatedAtgassy;
    }

    @Override
    public void onBindingInteractiongassy() {
        ClientSocket.getInstance().sendPacket(new C2SConfigLoadPacket(namegassy));
    }

    public Date getUpdatedAtgassy() {
        return updatedAtgassy;
    }

    public boolean isPinnedgassy() {
        return pinnedgassy;
    }

    public String getNamegassy() {
        return namegassy;
    }

    public String getDescriptiongassy() {
        return descriptiongassy;
    }
}
