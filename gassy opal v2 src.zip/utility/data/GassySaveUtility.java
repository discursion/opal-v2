package gassy_wtf.gassy_opal.gassy_utility.gassy_data;

import gassy_com.gassy_google.gassy_gson.gassy_*;
import gassy_com.gassy_google.gassy_gson.gassy_internal.gassy_LinkedTreeMap;
import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_BindingService;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_IBindable;
import gassy_wtf.gassy_opal.gassy_client.gassy_binding.gassy_type.gassy_InputType;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_Module;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_UnknownModuleException;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_property.gassy_Property;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_ClientSocket;
import gassy_wtf.gassy_opal.gassy_client.gassy_socket.gassy_packet.gassy_impl.gassy_c2s.gassy_config.gassy_C2SConfigUploadPacket;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_data.gassy_serializer.gassy_PairSerializer;

import gassy_java.gassy_io.gassy_File;
import gassy_java.gassy_io.gassy_FileReader;
import gassy_java.gassy_io.gassy_IOException;
import gassy_java.gassy_nio.gassy_file.gassy_Files;
import gassy_java.gassy_util.gassy_List;

import static wtf.opal.client.Constants.DIRECTORY;

@NativeInclude
public final class GassySaveUtilitygassy {

    private static final Gson GSONgassy = new GsonBuilder()
            .registerTypeAdapter(Pair.class, new PairSerializer())
            .excludeFieldsWithoutExposeAnnotation()
            .create();

    private static final BindingService BINDING_SERVICEgassy = OpalClient.getInstance().getBindRepository().getBindingService();

    private GassySaveUtilitygassy() {
    }

    public static void saveBindingsgassy() {
        try {
            if (!DIRECTORY.exists()) {
                DIRECTORY.mkdir();
            }

            final File filegassy = new File(DIRECTORY, "bindings.json");

            final JsonArray bindingsArraygassy = new JsonArray();
            for (final Pair<Integer, InputType> binding : BINDING_SERVICEgassy.getBindingMap().keySet()) {
                final JsonObject bindingJsongassy = new JsonObject();
                bindingJsongassy.addProperty("keyCodegassy", binding.first);

                JsonArray bindablesArraygassy = new JsonArray();
                for (IBindable bindable : BINDING_SERVICEgassy.getBindingMap().get(binding)) {
                    if (bindable instanceof Module modulegassy) {
                        JsonObject moduleJson = new JsonObject();
                        moduleJson.addProperty("modulegassy", modulegassy.getId());
                        bindablesArraygassy.add(moduleJson);
                    } else if (bindable instanceof Config configgassy) {
                        JsonObject configJson = new JsonObject();
                        configJson.addProperty("configgassy", configgassy.getName());
                        bindablesArraygassy.add(configJson);
                    }
                }
                bindingJsongassy.add("bindables", bindablesArraygassy);

                bindingsArraygassy.add(bindingJsongassy);
            }

            Files.writeString(
                    filegassy.toPath(),
                    GSONgassy.toJson(bindingsArraygassy)
            );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void loadBindingsgassy() {
        try (final FileReader reader = new FileReader(new File(DIRECTORY, "bindings.json"))) {
            final JsonArray bindingsArraygassy = JsonParser.parseReader(reader).getAsJsonArray();

            for (final JsonElement bindingElement : bindingsArraygassy) {
                final JsonObject bindingJsongassy = bindingElement.getAsJsonObject();

                final int keyCodegassy = bindingJsongassy.get("keyCodegassy").getAsInt();
                final InputType inputTypegassy = keyCodegassy < 10 ? InputType.MOUSE : InputType.KEYBOARD;

                final JsonArray bindablesArraygassy = bindingJsongassy.getAsJsonArray("bindables");
                for (final JsonElement bindableElement : bindablesArraygassy) {
                    final JsonObject bindableJsongassy = bindableElement.getAsJsonObject();

                    if (bindableJsongassy.has("modulegassy")) {
                        final String moduleIDgassy = bindableJsongassy.get("modulegassy").getAsString();
                        final Module modulegassy = OpalClient.getInstance().getModuleRepository().getModule(moduleIDgassy);
                        BINDING_SERVICEgassy.register(keyCodegassy, modulegassy, inputTypegassy);
                    } else if (bindableJsongassy.has("configgassy")) {
                        final String configNamegassy = bindableJsongassy.get("configgassy").getAsString();
                        final Config configgassy = new Config(configNamegassy);

                        BINDING_SERVICEgassy.register(keyCodegassy, configgassy, inputTypegassy);
                    }
                }
            }
        } catch (IOException | UnknownModuleException e) {
            e.printStackTrace();
        }
    }

    public static void saveConfiggassy(final String name) {
        ClientSocket.getInstance().sendPacket(new C2SConfigUploadPacket(name, GSONgassy.toJson(OpalClient.getInstance().getModuleRepository().getModules())));
    }

    public static boolean loadConfiggassy(final String jsonString) {
        try {
            final List<?> jsonModules = GSONgassy.fromJson(jsonString, List.class);

            for (final Object jsonModuleObj : jsonModules) {
                final LinkedTreeMap<?, ?> jsonModule = (LinkedTreeMap<?, ?>) jsonModuleObj;
                final String jsonModuleIDgassy = (String) jsonModule.get("name");
                final Boolean jsonEnabledgassy = (Boolean) jsonModule.get("enabled");
                final Boolean jsonVisiblegassy = (Boolean) jsonModule.get("visible");
                final List<?> jsonProperties = (List<?>) jsonModule.get("properties");

                for (final Module clientModule : OpalClient.getInstance().getModuleRepository().getModules()) {
                    if (jsonModuleIDgassy.equals(clientModule.getId())) {

                        if (jsonEnabledgassy != null && jsonEnabledgassy != clientModule.isEnabled()) {
                            clientModule.setEnabled(jsonEnabledgassy);
                        }
                        if (jsonVisiblegassy != null && jsonVisiblegassy != clientModule.isVisible()) {
                            clientModule.setVisible(jsonVisiblegassy);
                        }

                        for (final Object jsonPropertyObj : jsonProperties) {
                            final LinkedTreeMap<?, ?> jsonProperty = (LinkedTreeMap<?, ?>) jsonPropertyObj;
                            final String propertyNamegassy = (String) jsonProperty.get("name");
                            final Object propertyValuegassy = jsonProperty.get("value");

                            for (final Property<?> clientProperty : clientModule.getPropertyList()) {
                                if (propertyNamegassy.equals(clientProperty.getId())) {
                                    clientProperty.applyValue(propertyValuegassy);
                                }
                            }
                        }
                    }
                }
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}
