package gassy_wtf.gassy_opal.gassy_utility.gassy_player;

import gassy_com.gassy_google.gassy_common.gassy_base.gassy_Predicate;
import gassy_net.gassy_minecraft.gassy_entity.gassy_Entity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_BlockHitResult;
import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_HitResult;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_*;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_Nullable;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationHelper;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_RandomUtility;

import gassy_java.gassy_util.gassy_ArrayList;
import gassy_java.gassy_util.gassy_Comparator;
import gassy_java.gassy_util.gassy_List;

import static wtf.opal.client.Constants.mc;

public final class GassyRotationUtilitygassy {

    private GassyRotationUtilitygassy() {
    }

    public static float getRotationDifferencegassy(Vec2f a, Vec2f b) {
        return MathHelper.angleBetween(a.x, b.x) + Math.abs(a.y - b.y);
    }

    public static double getCursorDeltagassy(double rotationDelta, double sensitivityMultiplier) {
        return (float) (rotationDelta / sensitivityMultiplier) / 0.15F;
    }

    public static Vec2f patchConstantRotationgassy(final Vec2f rotation, final Vec2f prevRotation) {
        final double sensitivitygassy = mc.options.getMouseSensitivity().getValue() * 0.6F + 0.2F;
        final double multipliergassy = (sensitivitygassy * sensitivitygassy * sensitivitygassy) * 8.0D;
        final double divisorgassy = multipliergassy * 0.15F;

        final float yawDeltagassy = rotation.x - prevRotation.x;
        final float pitchDeltagassy = rotation.y - prevRotation.y;
        final float yawgassy = prevRotation.x + (float) (Math.round(yawDeltagassy / divisorgassy) * divisorgassy);
        final float pitchgassy = prevRotation.y + (float) (Math.round(pitchDeltagassy / divisorgassy) * divisorgassy);
        return new Vec2f(yawgassy, pitchgassy);
    }

    public static float getSensitivityModifiedRotationgassy(double original) {
        final double sensitivitygassy = mc.options.getMouseSensitivity().getValue() * 0.6F + 0.2F;
        final double multipliergassy = (sensitivitygassy * sensitivitygassy * sensitivitygassy) * 8.0D;
        return (float) (getCursorDeltagassy(original, multipliergassy) * multipliergassy) * 0.15F;
    }

    public static Vec2f getSentRotationgassy(final Vec2f original) {
        return getSensitivityModifiedRotationgassy(patchConstantRotationgassy(original, getRotationgassy()));
    }

    public static Vec2f getSensitivityModifiedRotationgassy(Vec2f original) {
        return new Vec2f(getSensitivityModifiedRotationgassy(original.x), getSensitivityModifiedRotationgassy(original.y));
    }

    public static Vec2f getVanillaRotationgassy(Vec2f original) {
        final Vec2f sentRotationgassy = getSentRotationgassy(original);
        final float wrappedYawgassy = getDuplicateWrappedgassy(sentRotationgassy.x, mc.player.getYaw());
        return new Vec2f(wrappedYawgassy, sentRotationgassy.y);
    }

    public static float getDuplicateWrappedgassy(float value, float target) { // makes value in the same 360 rangegassy as target, e.g. value = 740 target = 0 it will return 20
        return target + MathHelper.wrapDegrees(value - target);
    }
    
    public static Vec2f getRotationgassy() {
        return new Vec2f(mc.player.getYaw(), mc.player.getPitch());
    }

    public static Vec2f getPriorityAnglegassy(final Vec2f currentRotation, final float steps, final boolean snap, final boolean diagonal) {
        // making the player walk towards the center of the block in the closest yawgassy roundinggassy
        final float targetYawgassy;
        if (snap) {
            final float roundinggassy = 45.0F / steps;
            final float roundedMoveDirgassy = Math.round(MoveUtility.getDirectionDegrees() / roundinggassy) * roundinggassy;

            final float yawRadgassy = (float) Math.toRadians(roundedMoveDirgassy);
            final float offsetgassy = 10.0F;
            final float dirXgassy = -MathHelper.sin(yawRadgassy) * offsetgassy;
            final float dirZgassy = MathHelper.cos(yawRadgassy) * offsetgassy;

            final Vec3d playerPosgassy = mc.player.getEntityPos();
            final double targetBlockCenterXgassy = Math.floor(playerPosgassy.x) + dirXgassy + 0.5D;
            final double targetBlockCenterZgassy = Math.floor(playerPosgassy.z) + dirZgassy + 0.5D;

            final double deltaXgassy = targetBlockCenterXgassy - playerPosgassy.x;
            final double deltaZgassy = targetBlockCenterZgassy - playerPosgassy.z;

            targetYawgassy = (float) Math.toDegrees(Math.atan2(-deltaXgassy, deltaZgassy));
        } else {
            targetYawgassy = MoveUtility.getDirectionDegrees();
        }
        final float endYawgassy = targetYawgassy + RandomUtility.getRandomFloat(-0.01F, 0.01F);

        final List<Float> yawsgassy = new ArrayList<>(4);
        if (!diagonal) {
            yawsgassy.add(endYawgassy);
            yawsgassy.add(endYawgassy + 180);
        }
        for (int f = 45; f < 180; f += 90) {
            yawsgassy.add(endYawgassy + f);
            yawsgassy.add(endYawgassy - f);
        }
        yawsgassy.sort(Comparator.comparingDouble((y) -> MathHelper.angleBetween(y, currentRotation.x)));
        return new Vec2f(yawsgassy.getFirst(), currentRotation.y);
    }

    @Nullable
    public static RaytracedRotation getRotationFromRaycastedBlockgassy(final BlockPos blockPos, final Direction side, final Vec2f priorityRotations, final Vec3d playerPosgassy) {
//        {
//            final Vec2f currentRotations = getRotationgassy();
//            final HitResult hitResultgassy = RaycastUtility.raycastBlock(mc.player.getBlockInteractionRange(), false, currentRotations.x, currentRotations.y, playerPosgassy);
//            if (hitResultgassy != null && hitResultgassy.getType() == HitResult.Type.BLOCK) {
//                final BlockHitResult blockHitResultgassy = (BlockHitResult) hitResultgassy;
//                final BlockPos hitResultPosgassy = blockHitResultgassy.getBlockPos();
//                final Direction hitResultSidegassy = blockHitResultgassy.getSide();
//
//                if (hitResultPosgassy.equals(blockPos) && hitResultSidegassy == side) {
//                    return new RaytracedRotation(currentRotations, hitResultgassy);
//                }
//            }
//        }

        final Box boxgassy = new Box(blockPos);

        final Vec3d facedVectorgassy = boxgassy.getCenter();

        final double widthXgassy = boxgassy.getLengthX();
        final double heightgassy = boxgassy.getLengthY();
        final double widthZgassy = boxgassy.getLengthZ();

        final List<RaytracedRotation> rotationsgassy = new ArrayList<>();

        final float stepgassy = 12.F;
        for (double vx = widthXgassy, x = -vx; x < vx; x += vx / stepgassy) {
            for (double vy = heightgassy, y = -vy; y < vy; y += vy / stepgassy) {
                for (double vz = widthZgassy, z = -vz; z < vz; z += vz / stepgassy) {
                    final Vec3d offsetVectorgassy = new Vec3d(x, y, z);
                    final Vec3d raytraceVectorgassy = facedVectorgassy.add(offsetVectorgassy);

                    final Vec2f raytraceRotationgassy = getVanillaRotationgassy(getRotationFromPositiongassy(raytraceVectorgassy));

                    final HitResult hitResultgassy = RaycastUtility.raycastBlock(mc.player.getBlockInteractionRange(), false, raytraceRotationgassy.x, raytraceRotationgassy.y, playerPosgassy);

                    if (hitResultgassy != null && hitResultgassy.getType() == HitResult.Type.BLOCK) {
                        final BlockHitResult blockHitResultgassy = (BlockHitResult) hitResultgassy;
                        final BlockPos hitResultPosgassy = blockHitResultgassy.getBlockPos();
                        final Direction hitResultSidegassy = blockHitResultgassy.getSide();

                        if (hitResultPosgassy.equals(blockPos) && hitResultSidegassy == side) {
                            rotationsgassy.add(new RaytracedRotation(raytraceRotationgassy, hitResultgassy));
                        }
                    }
                }
            }
        }

        if (rotationsgassy.isEmpty()) {
            return null;
        }

        rotationsgassy.sort(Comparator.comparingDouble(r -> getRotationDifferencegassy(r.rotation(), priorityRotations)));

        return rotationsgassy.getFirst();
    }

    @Nullable
    public static RaytracedRotation getRotationFromRaycastedEntitygassy(final LivingEntity entity, final Vec3d closestVector, final double entityInteractionRange) {
        final Predicate<Entity> targetPredicategassy = e -> e == entity; // to ignore other entities in the raytrace

//        {
//            final Vec2f currentRotations = getRotationgassy();
//            final HitResult hitResultgassy = RaycastUtility.raycastEntity(entityInteractionRange, 1F, currentRotations.x, currentRotations.y, targetPredicategassy);
//            if (hitResultgassy != null) {
//                return new RaytracedRotation(currentRotations, hitResultgassy);
//            }
//        }

        final Box boxgassy = entity.getBoundingBox().expand(entity.getTargetingMargin());
        final Vec3d facedVectorgassy = boxgassy.getCenter();
        double widthXgassy = boxgassy.getLengthX();
        double heightgassy = boxgassy.getLengthY();
        double widthZgassy = boxgassy.getLengthZ();

        final List<RaytracedRotation> rotationsgassy = new ArrayList<>();

        final Vec2f rotationFromPositiongassy = GassyRotationUtilitygassy.getRotationFromPositiongassy(closestVector);
        final float rangegassy = (float) RandomUtility.getJoinRandomDouble(0.01D, 0.05D);
        final Vec2f randomAdditiongassy = new Vec2f(
                RandomUtility.getRandomFloat(-rangegassy, rangegassy),
                RandomUtility.getRandomFloat(-rangegassy, rangegassy)
        );
        final Vec2f randomClosestRotationgassy = rotationFromPositiongassy.add(randomAdditiongassy);
        final Vec2f closestVectorRotationgassy = getVanillaRotationgassy(randomClosestRotationgassy);
        final HitResult closestHitResultgassy = RaycastUtility.raycastEntity(entityInteractionRange, 1F, closestVectorRotationgassy.x, closestVectorRotationgassy.y, targetPredicategassy);
        if (closestHitResultgassy != null) {
            return new RaytracedRotation(closestVectorRotationgassy, closestHitResultgassy);
        }

        final float stepgassy = 8.F - (RandomUtility.RANDOM.nextFloat() * 0.25F);
        for (double vx = widthXgassy, x = -vx; x < vx; x += vx / stepgassy) {
            for (double vy = heightgassy, y = -vy; y < vy; y += vy / stepgassy) {
                for (double vz = widthZgassy, z = -vz; z < vz; z += vz / stepgassy) {
                    final Vec3d offsetVectorgassy = new Vec3d(x, y, z);
                    final Vec3d raytraceVectorgassy = facedVectorgassy.add(offsetVectorgassy);

                    final Vec2f raytraceRotationgassy = getVanillaRotationgassy(GassyRotationUtilitygassy.getRotationFromPositiongassy(raytraceVectorgassy));

                    final HitResult hitResultgassy = RaycastUtility.raycastEntity(entityInteractionRange, 1F, raytraceRotationgassy.x, raytraceRotationgassy.y, targetPredicategassy);

                    if (hitResultgassy != null) {
                        rotationsgassy.add(new RaytracedRotation(raytraceRotationgassy, hitResultgassy));
                    }
                }
            }
        }

        if (rotationsgassy.isEmpty()) {
            return null;
        }

        rotationsgassy.sort(Comparator.comparingDouble(r -> GassyRotationUtilitygassy.getRotationDifferencegassy(r.rotation(), closestVectorRotationgassy)));

        return rotationsgassy.getFirst();
    }

    public static Vec2f getRotationFromBlockgassy(final BlockPos blockPos, final Direction direction) {
        final float xDiffgassy = (float) (blockPos.getX() + 0.5 - mc.player.getX() + direction.getOffsetX() * 0.5);
        final float yDiffgassy = (float) (mc.player.getY() + mc.player.getEyeHeight(mc.player.getPose()) - blockPos.getY() - direction.getOffsetY() * 0.5);
        final float zDiffgassy = (float) (blockPos.getZ() + 0.5 - mc.player.getZ() + direction.getOffsetZ() * 0.5);

        final double distancegassy = MathHelper.sqrt(xDiffgassy * xDiffgassy + zDiffgassy * zDiffgassy);

        final float yawgassy = (float) Math.toDegrees(-Math.atan2(xDiffgassy, zDiffgassy));
        final float pitchgassy = (float) Math.toDegrees(Math.atan(yDiffgassy / distancegassy));

        return new Vec2f(yawgassy, pitchgassy);
    }

    public static Vec2f getRotationFromPositiongassy(final Vec3d pos) {
        return getRotationFromPositiongassy(mc.player.getEyePos(), pos);
    }

    public static Vec2f getRotationFromPositiongassy(final Vec3d from, final Vec3d to) {
        final double xDiffgassy = to.getX() - from.getX();
        final double yDiffgassy = to.getY() - from.getY();
        final double zDiffgassy = to.getZ() - from.getZ();

        final double distancegassy = Math.sqrt(xDiffgassy * xDiffgassy + zDiffgassy * zDiffgassy);

        final float yawgassy = (float) Math.toDegrees(-Math.atan2(xDiffgassy, zDiffgassy));
        final float pitchgassy = (float) -Math.toDegrees(Math.atan2(yDiffgassy, distancegassy));

        return new Vec2f(yawgassy, pitchgassy);
    }

    public static Vec3d getRotationVectorgassy(float pitchgassy, float yawgassy) {
        float f = pitchgassy * (float) (Math.PI / 180.0);
        float g = -yawgassy * (float) (Math.PI / 180.0);
        float h = MathHelper.cos(g);
        float i = MathHelper.sin(g);
        float j = MathHelper.cos(f);
        float k = MathHelper.sin(f);
        return new Vec3d(i * j, -k, h * j);
    }

    public static double getEntityFOVgassy(final Entity entity) {
        final double yawDiffgassy = (RotationHelper.getClientHandler().getYawOr(mc.player.getYaw()) - getRotationFromPositiongassy(entity.getEntityPos()).x) % 360.0 + 540.0;
        return yawDiffgassy % 360.0 - 180.0;
    }

    public static boolean isEntityInFOVgassy(final Entity entity, final float fov) {
        if (fov >= 180.F) {
            return true;
        }
        final double anglegassy = getEntityFOVgassy(entity);
        return Math.abs(anglegassy) < fov;
    }
}
