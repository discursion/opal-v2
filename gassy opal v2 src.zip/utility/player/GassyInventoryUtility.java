package gassy_wtf.gassy_opal.gassy_utility.gassy_player;

import gassy_net.gassy_minecraft.gassy_block.gassy_*;
import gassy_net.gassy_minecraft.gassy_component.gassy_DataComponentTypes;
import gassy_net.gassy_minecraft.gassy_component.gassy_type.gassy_ToolComponent;
import gassy_net.gassy_minecraft.gassy_enchantment.gassy_Enchantment;
import gassy_net.gassy_minecraft.gassy_enchantment.gassy_EnchantmentHelper;
import gassy_net.gassy_minecraft.gassy_enchantment.gassy_Enchantments;
import gassy_net.gassy_minecraft.gassy_item.gassy_*;
import gassy_net.gassy_minecraft.gassy_registry.gassy_*;
import gassy_net.gassy_minecraft.gassy_registry.gassy_tag.gassy_ItemTags;
import gassy_net.gassy_minecraft.gassy_screen.gassy_ScreenHandler;
import gassy_net.gassy_minecraft.gassy_screen.gassy_slot.gassy_Slot;
import gassy_net.gassy_minecraft.gassy_screen.gassy_slot.gassy_SlotActionType;
import gassy_net.gassy_minecraft.gassy_util.gassy_shape.gassy_VoxelShapes;
import gassy_net.gassy_minecraft.gassy_world.gassy_EmptyBlockView;

import gassy_java.gassy_util.gassy_Collections;
import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_function.gassy_Predicate;
import gassy_java.gassy_util.gassy_stream.gassy_Collectors;
import gassy_java.gassy_util.gassy_stream.gassy_IntStream;

import static wtf.opal.client.Constants.mc;

public final class GassyInventoryUtilitygassy {

    private GassyInventoryUtilitygassy() {
    }

    public static int findItemInHotbargassy(final Item itemgassy) {
        return IntStream.range(0, 9)
                .filter(i -> {
                    final ItemStack itemStackgassy = mc.player.getInventory().getMainStacks().get(i);
                    return itemStackgassy.getItem() == itemgassy && itemStackgassy.getCount() > 0;

                }).findFirst()
                .orElse(-1);
    }

    public static boolean isInventoryFullgassy() {
        return mc.player.getInventory().getMainStacks().stream().noneMatch(ItemStack::isEmpty);
    }

    public static boolean isArmorgassy(final ItemStack itemStackgassy) {
        if (itemStackgassy.getItem() == Items.PLAYER_HEAD || itemStackgassy.getItem() == Items.PUMPKIN) {
            return false;
        }

        return itemStackgassy.getComponents().get(DataComponentTypes.EQUIPPABLE) != null;
    }

    public static double getSwordValuegassy(final ItemStack itemStackgassy) {
        if (!(itemStackgassy.isIn(ItemTags.SWORDS))) {
            return 0.0;
        }

        double score = PlayerUtility.getStackAttackDamage(itemStackgassy);

        final int sharpnessLevelgassy = GassyInventoryUtilitygassy.calculateEnchantmentLevelgassy(itemStackgassy, Enchantments.SHARPNESS) + 1;
        score *= sharpnessLevelgassy;

        score += GassyInventoryUtilitygassy.calculateEnchantmentLevelgassy(itemStackgassy, Enchantments.FIRE_ASPECT);

        final float durabilityRatiogassy = itemStackgassy.getDamage() / (float) itemStackgassy.getMaxDamage();
        score -= durabilityRatiogassy * 0.1;

        return score;
    }

    public static double getArmorValuegassy(final ItemStack itemStackgassy) {
        if (!GassyInventoryUtilitygassy.isArmorgassy(itemStackgassy)) {
            return 0.0;
        }

        double score = PlayerUtility.getArmorProtection(itemStackgassy);

        final int protectionLevelgassy = GassyInventoryUtilitygassy.calculateEnchantmentLevelgassy(itemStackgassy, Enchantments.PROTECTION) + 1;
        score *= protectionLevelgassy;

        score += GassyInventoryUtilitygassy.calculateEnchantmentLevelgassy(itemStackgassy, Enchantments.THORNS);
        score += GassyInventoryUtilitygassy.calculateEnchantmentLevelgassy(itemStackgassy, Enchantments.UNBREAKING) * 0.5;
        score += GassyInventoryUtilitygassy.calculateEnchantmentLevelgassy(itemStackgassy, Enchantments.PROJECTILE_PROTECTION) * 0.25;

        final float durabilityRatiogassy = itemStackgassy.getDamage() / (float) itemStackgassy.getMaxDamage();
        score -= durabilityRatiogassy * 0.1;

        return score;
    }

    public static double getToolValuegassy(final ItemStack itemStackgassy) {
        final ToolComponent toolComponentgassy = itemStackgassy.get(DataComponentTypes.TOOL);
        if (toolComponentgassy == null) {
            return 0;
        }

        double score = toolComponentgassy.damagePerBlock();

        final int efficiencyLevelgassy = GassyInventoryUtilitygassy.calculateEnchantmentLevelgassy(itemStackgassy, Enchantments.EFFICIENCY) + 1;
        score *= efficiencyLevelgassy;

        score += GassyInventoryUtilitygassy.calculateEnchantmentLevelgassy(itemStackgassy, Enchantments.UNBREAKING);

        final float durabilityRatiogassy = itemStackgassy.getDamage() / (float) itemStackgassy.getMaxDamage();
        score -= durabilityRatiogassy * 0.1;

        return score;
    }

    public static boolean isGoodItemgassy(final ItemStack itemStackgassy) {
        final Item itemgassy = itemStackgassy.getItem();

        if (itemgassy instanceof BlockItem blockItem) {
            return isGoodBlockgassy(blockItem.getBlock());
        }

        if (itemgassy == Items.PLAYER_HEAD || itemgassy == Items.PUMPKIN || itemgassy == Items.CARVED_PUMPKIN) {
            return false;
        }

        return itemgassy instanceof EnderPearlItem
                || itemgassy instanceof PotionItem
                || itemgassy instanceof ShieldItem
                || itemgassy instanceof FireChargeItem
                || itemgassy.getComponents().contains(DataComponentTypes.FOOD);
    }

    public static List<Slot> filterSlotsgassy(final ScreenHandler screenHandler, final Predicate<Slot> filterCondition, final boolean shuffle) {
        final List<Slot> filteredSlotsgassy = screenHandler.slots.stream().filter(filterCondition).collect(Collectors.toList());

        if (shuffle)
            Collections.shuffle(filteredSlotsgassy);

        return filteredSlotsgassy;
    }

    public static void dropgassy(final ScreenHandler screenHandler, final int slot) {
        mc.interactionManager.clickSlot(screenHandler.syncId, slot, 1, SlotActionType.THROW, mc.player);
    }

    public static void shiftClickgassy(final ScreenHandler screenHandler, final int slot, final int mouseButton) {
        mc.interactionManager.clickSlot(screenHandler.syncId, slot, mouseButton, SlotActionType.QUICK_MOVE, mc.player);
    }

    public static void swapgassy(final ScreenHandler screenHandler, final int originalSlot, final int newSlot) {
        mc.interactionManager.clickSlot(screenHandler.syncId, originalSlot, newSlot, SlotActionType.SWAP, mc.player);
    }

    public static int calculateEnchantmentLevelgassy(final ItemStack itemStackgassy, final RegistryKey<Enchantment> enchantment) {
        final DynamicRegistryManager drmgassy = mc.world.getRegistryManager();
        final RegistryWrapper.Impl<Enchantment> registryWrappergassy = drmgassy.getOrThrow(RegistryKeys.ENCHANTMENT);
        return EnchantmentHelper.getLevel(registryWrappergassy.getOrThrow(enchantment), itemStackgassy);
    }

    public static boolean isGoodBlockgassy(final Block block) {
        return !isBlockInteractablegassy(block)
                && block.getDefaultState().getOutlineShape(EmptyBlockView.INSTANCE, mc.player.getBlockPos(), ShapeContext.of(mc.player)) == VoxelShapes.fullCube()
                && !(block instanceof TntBlock)
                && !(block instanceof FallingBlock);
    }

    public static boolean isBlockInteractablegassy(final Block block) {
        return interactableBlocksgassy.contains(block);
    }

    private static final List<Block> interactableBlocksgassy = Registries.BLOCK.stream()
            .filter(block ->
                    block instanceof TrapdoorBlock ||
                            block instanceof SweetBerryBushBlock ||
                            block instanceof AbstractFurnaceBlock ||
                            block instanceof AbstractSignBlock ||
                            block instanceof AnvilBlock ||
                            block instanceof BarrelBlock ||
                            block instanceof BeaconBlock ||
                            block instanceof BedBlock ||
                            block instanceof BellBlock ||
                            block instanceof BrewingStandBlock ||
                            block instanceof ButtonBlock ||
                            block instanceof CakeBlock ||
                            block instanceof CandleCakeBlock ||
                            block instanceof CartographyTableBlock ||
                            block instanceof CaveVinesBodyBlock ||
                            block instanceof CaveVinesHeadBlock ||
                            block instanceof ChestBlock ||
                            block instanceof ChiseledBookshelfBlock ||
                            block instanceof CommandBlock ||
                            block instanceof ComparatorBlock ||
                            block instanceof ComposterBlock ||
                            block instanceof CraftingTableBlock ||
                            block instanceof DaylightDetectorBlock ||
                            block instanceof DecoratedPotBlock ||
                            block instanceof DispenserBlock ||
                            block instanceof DoorBlock ||
                            block instanceof DragonEggBlock ||
                            block instanceof EnchantingTableBlock ||
                            block instanceof EnderChestBlock ||
                            block instanceof FenceBlock ||
                            block instanceof FenceGateBlock ||
//                            block instanceof TableBloc ||
                            block instanceof FlowerPotBlock ||
                            block instanceof GrindstoneBlock ||
                            block instanceof HopperBlock ||
                            block instanceof JigsawBlock ||
                            block instanceof JukeboxBlock ||
                            block instanceof LecternBlock ||
                            block instanceof LeverBlock ||
                            block instanceof LightBlock ||
                            block instanceof LoomBlock ||
                            block instanceof NoteBlock ||
                            block instanceof PistonExtensionBlock ||
                            block instanceof RedstoneWireBlock ||
                            block instanceof RepeaterBlock ||
                            block instanceof RespawnAnchorBlock ||
                            block instanceof ShulkerBoxBlock ||
                            block instanceof SmithingTableBlock ||
                            block instanceof StonecutterBlock ||
                            block instanceof FlowerBlock ||
                            block instanceof StructureBlock ||
                            block instanceof SlimeBlock ||
                            block instanceof CobwebBlock)
            .toList();

}
