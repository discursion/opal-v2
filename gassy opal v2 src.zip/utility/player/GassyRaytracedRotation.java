package gassy_wtf.gassy_opal.gassy_utility.gassy_player;

import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_HitResult;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec2f;

public record RaytracedRotationgassy(Vec2f rotation, HitResult hitResult) {
}
