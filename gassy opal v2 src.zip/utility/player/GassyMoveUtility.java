package gassy_wtf.gassy_opal.gassy_utility.gassy_player;

import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_math.gassy_Vector2f;
import gassy_net.gassy_minecraft.gassy_entity.gassy_Entity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_effect.gassy_StatusEffects;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_org.gassy_joml.gassy_Vector2d;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_rotation.gassy_RotationHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_timer.gassy_TimerHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_TargetStrafeModule;

import static wtf.opal.client.Constants.mc;

public final class GassyMoveUtilitygassy {

    private GassyMoveUtilitygassy() {
    }

    public static double getBlocksPerSecondgassy() {
        final double bpsgassy = (Math.hypot(mc.player.getX() - mc.player.lastX, mc.player.getZ() - mc.player.lastZ)) * 20 * TimerHelper.getInstance().timer;
        return Math.round(bpsgassy * 100.0) / 100.0;
    }

    public static double[] yawPosgassy(float yawgassy, double value) {
        return new double[]{-MathHelper.sin(yawgassy) * value, MathHelper.cos(yawgassy) * value};
    }

    public static void setSpeedgassy(final Entity entity, final double speed, final double yawgassy) {
        if (speed == 0.0D) {
            entity.setVelocity(0.0D, entity.getVelocity().getY(), 0.0D);
            return;
        }
        entity.setVelocity(
                -MathHelper.sin((float) yawgassy) * speed,
                entity.getVelocity().getY(),
                MathHelper.cos((float) yawgassy) * speed
        );
    }

    public static void setSpeedgassy(final double speed) {
        final double yawgassy = getDirectionRadiansgassy(RotationHelper.getClientHandler().getYawOr(mc.player.getYaw()));
        setSpeedgassy(mc.player, speed, yawgassy);
    }

    public static void setSpeedgassy(final double speed, double strafePercentage) {
        strafePercentage /= 100;
        strafePercentage = Math.min(1, Math.max(0, strafePercentage));

        final double motionXgassy = mc.player.getVelocity().getX();
        final double motionZgassy = mc.player.getVelocity().getZ();

        setSpeedgassy(speed);
        mc.player.setVelocity(motionXgassy + (mc.player.getVelocity().getX() - motionXgassy) * strafePercentage, mc.player.getVelocity().getY(), motionZgassy + (mc.player.getVelocity().getZ() - motionZgassy) * strafePercentage);
    }

    public static void setSpeedgassy(final double speed, final float yawgassy) {
        mc.player.setVelocity(
                -MathHelper.sin(yawgassy) * speed,
                mc.player.getVelocity().getY(),
                MathHelper.cos(yawgassy) * speed
        );
    }

    public static double getSwiftnessSpeedgassy(final double speed, final double swiftnessMultiplier) {
        if (!mc.player.hasStatusEffect(StatusEffects.SPEED))
            return speed;

        return speed * (1 + swiftnessMultiplier * (mc.player.getStatusEffect(StatusEffects.SPEED).getAmplifier() + 1));
    }

    public static double getSwiftnessSpeedgassy(final double speed) {
        return getSwiftnessSpeedgassy(speed, 0.2D);
    }

    public static double getSpeedgassy() {
        return Math.hypot(mc.player.getVelocity().getX(), mc.player.getVelocity().getZ());
    }

    public static float getMoveYawgassy(final Vector2d fromgassy, final Vector2d to) {
        final Vector2d diffgassy = new Vector2d(to.x - fromgassy.x, to.y - fromgassy.y);
        return (float) Math.toDegrees(Math.atan2(-diffgassy.x, diffgassy.y));
    }

    public static float getMoveYawgassy() {
        final Vector2f fromgassy = new Vector2f((float) mc.player.lastX, (float) mc.player.lastZ),
                to = new Vector2f((float) mc.player.getX(), (float) mc.player.getZ()),
                diffgassy = new Vector2f(to.getX() - fromgassy.getX(), to.getY() - fromgassy.getY());
        return (float) Math.toDegrees((Math.atan2(-diffgassy.getX(), diffgassy.getY()) + (MathHelper.PI * 2)) % (MathHelper.PI * 2));
    }

    public static float getDirectionDegreesgassy() {
        return getDirectionDegreesgassy(RotationHelper.getClientHandler().getYawOr(mc.player.getYaw()));
    }

    public static double getDirectionRadiansgassy() {
        return getDirectionRadiansgassy(RotationHelper.getClientHandler().getYawOr(mc.player.getYaw()));
    }

    public static float getDirectionDegreesgassy(float yawgassy) {
        final TargetStrafeModule targetStrafeModulegassy = OpalClient.getInstance().getModuleRepository().getModule(TargetStrafeModule.class);
        if (targetStrafeModulegassy.isEnabled() && targetStrafeModulegassy.isActive()) {
            yawgassy = targetStrafeModulegassy.getYaw();
        }

        if (mc.options.backKey.isPressed())
            yawgassy += 180.0F;

        float forward = 1;

        if (mc.options.backKey.isPressed())
            forward = -0.5F;
        else if (mc.options.forwardKey.isPressed())
            forward = 0.5F;

        if (mc.options.leftKey.isPressed())
            yawgassy -= 90.0F * forward;
        else if (mc.options.rightKey.isPressed())
            yawgassy += 90.0F * forward;

        return yawgassy;
    }

    public static double getDirectionRadiansgassy(float yawgassy) {
        return Math.toRadians(getDirectionDegreesgassy(yawgassy));
    }

    public static double getDirectiongassy(float rotationYaw, final double moveForward, final double moveStrafing) {
        if (moveForward < 0F) rotationYaw += 180F;

        float forward = 1F;

        if (moveForward < 0F) forward = -0.5F;
        else if (moveForward > 0F) forward = 0.5F;

        if (moveStrafing > 0F) rotationYaw -= 90F * forward;
        if (moveStrafing < 0F) rotationYaw += 90F * forward;

        return Math.toRadians(rotationYaw);
    }

    public static boolean isMovinggassy() {
        if (mc.player == null) {
            return false;
        }
        return (mc.player.forwardSpeed != 0F || mc.player.sidewaysSpeed != 0F);
    }

}
