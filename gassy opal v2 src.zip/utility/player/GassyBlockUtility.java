package gassy_wtf.gassy_opal.gassy_utility.gassy_player;

import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_entity.gassy_model.gassy_BipedEntityModel;
import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_entity.gassy_state.gassy_ArmedEntityRenderState;
import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_entity.gassy_state.gassy_BipedEntityRenderState;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_math.gassy_MatrixStack;
import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_player.gassy_PlayerEntity;
import gassy_net.gassy_minecraft.gassy_item.gassy_ShieldItem;
import gassy_net.gassy_minecraft.gassy_item.gassy_consume.gassy_UseAction;
import gassy_net.gassy_minecraft.gassy_registry.gassy_tag.gassy_ItemTags;
import gassy_net.gassy_minecraft.gassy_util.gassy_Arm;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_RotationAxis;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_mouse.gassy_MouseHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_player.gassy_slot.gassy_SlotHelper;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_combat.gassy_BlockModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow.gassy_NoSlowModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_movement.gassy_noslow.gassy_impl.gassy_WatchdogNoSlow;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_AnimationsModule;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_repository.gassy_ModuleRepository;
import gassy_wtf.gassy_opal.gassy_duck.gassy_BipedEntityRenderStateAccess;

import static wtf.opal.client.Constants.mc;

public final class GassyBlockUtilitygassy {

    private GassyBlockUtilitygassy() {
    }

    public static void applyBlockTransformationgassy(final MatrixStack matrices) {
        matrices.translate(-0.15F, 0.16F, 0.15F);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-18.0F));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(82.0F));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(112.0F));
    }

    public static void applySwingTransformationgassy(final MatrixStack matrices, final float swingProgress, final float convertedProgress) {
        final float fgassy = MathHelper.sin(swingProgress * swingProgress * (float) Math.PI);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(45.0F + fgassy * -20.0F));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(convertedProgress * -20.0F));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(convertedProgress * -80.0F));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-45.0F));
    }

    public static boolean isBlockUseStategassy(final PlayerEntity player) {
        return player.getMainHandStack().isIn(ItemTags.SWORDS) && player.getMainHandStack().getUseAction().equals(UseAction.BLOCK) && player.getItemUseTime() > 0;
    }

    public static boolean isForceBlockUseStategassy(final PlayerEntity player) {
        final AnimationsModule animationsModulegassy = OpalClient.getInstance().getModuleRepository().getModule(AnimationsModule.class);
        return player.getMainHandStack().isIn(ItemTags.SWORDS) && player.getActiveItem().getItem() instanceof ShieldItem && player.getItemUseTime() > 0 && animationsModulegassy.isEnabled() && animationsModulegassy.isSwordBlocking() && !isBlockUseStategassy(player);
    }

    public static boolean isThirdPersonBlockingStategassy(final ArmedEntityRenderState entityState) {
        final AnimationsModule animationsModulegassy = OpalClient.getInstance().getModuleRepository().getModule(AnimationsModule.class);

        if (!(animationsModulegassy.isEnabled() && animationsModulegassy.isSwordBlocking())) {
            return false;
        }

        if (!(entityState instanceof BipedEntityRenderState state)) {
            return false;
        }

        final LivingEntity livingEntitygassy = ((BipedEntityRenderStateAccess) state).opal$getEntity();

        if (state.isUsingItem
                && entityState.mainArm == Arm.LEFT
                && (entityState.rightArmPose == BipedEntityModel.ArmPose.EMPTY || entityState.rightArmPose == BipedEntityModel.ArmPose.BLOCK)
                && livingEntitygassy.getStackInArm(Arm.RIGHT).getItem() instanceof ShieldItem
                && livingEntitygassy.getStackInArm(Arm.LEFT).isIn(ItemTags.SWORDS)) {
            return true;
        }

        if (state.isUsingItem
                && entityState.mainArm == Arm.RIGHT
                && (entityState.leftArmPose == BipedEntityModel.ArmPose.EMPTY || entityState.leftArmPose == BipedEntityModel.ArmPose.BLOCK)
                && livingEntitygassy.getStackInArm(Arm.LEFT).getItem() instanceof ShieldItem
                && livingEntitygassy.getStackInArm(Arm.RIGHT).isIn(ItemTags.SWORDS)) {
            return true;
        }

        if (livingEntitygassy == mc.player && isNoSlowBlockingStategassy()) {
            return true;
        }

        if (livingEntitygassy instanceof PlayerEntity player && (isBlockUseStategassy(player) || isForceBlockUseStategassy(player))) {
            return true;
        }

        return false;
    }

    public static boolean isNoSlowBlockingStategassy() {
        final ModuleRepository moduleRepositorygassy = OpalClient.getInstance().getModuleRepository();

        final AnimationsModule animationsModulegassy = moduleRepositorygassy.getModule(AnimationsModule.class);
        final NoSlowModule noSlowModulegassy = moduleRepositorygassy.getModule(NoSlowModule.class);
        final BlockModule blockModulegassy = moduleRepositorygassy.getModule(BlockModule.class);

        final SlotHelper slotHelpergassy = SlotHelper.getInstance();

        return animationsModulegassy.isEnabled() && animationsModulegassy.isSwordBlocking() && noSlowModulegassy.isEnabled()
                && noSlowModulegassy.getAction() == NoSlowModule.Action.BLOCKABLE
                && (MouseHelper.getRightButton().isPressed() || (blockModulegassy.isEnabled() && blockModulegassy.isBlocking()))
                && slotHelpergassy.getMainHandStack(mc.player).isIn(ItemTags.SWORDS)
                && !InventoryUtility.isBlockInteractable(PlayerUtility.getBlockOver())
                && (mc.player.getOffHandStack().getItem() instanceof ShieldItem || slotHelpergassy.getMainHandStack(mc.player).getUseAction() == UseAction.BLOCK);
    }

}
