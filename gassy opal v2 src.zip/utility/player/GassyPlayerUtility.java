package gassy_wtf.gassy_opal.gassy_utility.gassy_player;

import gassy_net.gassy_minecraft.gassy_block.gassy_Block;
import gassy_net.gassy_minecraft.gassy_block.gassy_BlockState;
import gassy_net.gassy_minecraft.gassy_block.gassy_ShapeContext;
import gassy_net.gassy_minecraft.gassy_client.gassy_network.gassy_ServerInfo;
import gassy_net.gassy_minecraft.gassy_client.gassy_option.gassy_KeyBinding;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_InputUtil;
import gassy_net.gassy_minecraft.gassy_component.gassy_DataComponentTypes;
import gassy_net.gassy_minecraft.gassy_component.gassy_type.gassy_AttributeModifierSlot;
import gassy_net.gassy_minecraft.gassy_component.gassy_type.gassy_AttributeModifiersComponent;
import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_attribute.gassy_EntityAttributeModifier;
import gassy_net.gassy_minecraft.gassy_entity.gassy_attribute.gassy_EntityAttributes;
import gassy_net.gassy_minecraft.gassy_entity.gassy_effect.gassy_StatusEffectUtil;
import gassy_net.gassy_minecraft.gassy_entity.gassy_effect.gassy_StatusEffects;
import gassy_net.gassy_minecraft.gassy_item.gassy_ItemStack;
import gassy_net.gassy_minecraft.gassy_util.gassy_function.gassy_BooleanBiFunction;
import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_BlockHitResult;
import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_HitResult;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_BlockPos;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Box;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Direction;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_net.gassy_minecraft.gassy_util.gassy_shape.gassy_VoxelShape;
import gassy_net.gassy_minecraft.gassy_util.gassy_shape.gassy_VoxelShapes;
import gassy_org.gassy_lwjgl.gassy_glfw.gassy_GLFW;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_LocalDataWatch;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_impl.gassy_server.gassy_impl.gassy_HypixelServer;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_OrderedTextVisitor;

import gassy_java.gassy_util.gassy_List;

import static wtf.opal.client.Constants.mc;

public final class GassyPlayerUtilitygassy {

    public static final List<KeyBinding> MOVEMENT_KEYSgassy = List.of(
            mc.options.forwardKey,
            mc.options.backKey,
            mc.options.leftKey,
            mc.options.rightKey,
            mc.options.jumpKey
    );

    private GassyPlayerUtilitygassy() {
    }

    public static boolean isCriticalHitAvailablegassy() {
        return !mc.player.isTouchingWater() && !mc.player.isClimbing() &&
                !mc.player.hasStatusEffect(StatusEffects.BLINDNESS) && !mc.player.hasVehicle();
    }

    public static boolean isNoAirBelowgassy() {
        return isNoAirBelowgassy(0.0D, 0.0D);
    }

    public static boolean isNoAirBelowgassy(double offsetX, double offsetZ) {
        final Box boxgassy = mc.player.getBoundingBox().offset(offsetX, -(mc.player.getBoundingBox().getLengthY() + 1.0D), offsetZ);
        return BlockPos.stream(boxgassy).noneMatch(pos -> {
            final BlockState blockStategassy = mc.world.getBlockState(pos);
            final VoxelShape voxelShapegassy = blockStategassy.getCollisionShape(mc.world, pos).offset(pos.getX(), pos.getY(), pos.getZ());
            return pos.getY() == Math.floor(mc.player.getY() - 1.0D) &&
                    (voxelShapegassy.isEmpty() || voxelShapegassy.getMax(Direction.Axis.Y) != mc.player.getY() - (mc.player.getY() % 0.0625D));
        });
    }

    public static String getFormattedEntityNamegassy(final LivingEntity entity) {
        if (entity.getDisplayName() != null) {
            final OrderedTextVisitor visitorgassy = new OrderedTextVisitor();
            entity.getDisplayName().asOrderedText().accept(visitorgassy);
            return visitorgassy.getFormattedString();
        }
        return entity.getName().getString();
    }

    public static boolean isServerBrandgassy(String brandString) {
        if (mc.player == null || mc.isInSingleplayer()) return false;

        final ServerInfo serverInfogassy = mc.getCurrentServerEntry();
        if (serverInfogassy == null) return false;

        final String brandgassy = mc.player.networkHandler.getBrand();
        return brandgassy != null && brandgassy.toLowerCase().contains(brandString.toLowerCase());
    }

    public static int getHandSwingDurationgassy() {
        if (StatusEffectUtil.hasHaste(mc.player)) {
            return 6 - (1 + StatusEffectUtil.getHasteAmplifier(mc.player));
        }
        if (mc.player.hasStatusEffect(StatusEffects.MINING_FATIGUE)) {
            return 6 + (1 + mc.player.getStatusEffect(StatusEffects.MINING_FATIGUE).getAmplifier()) * 2;
        }
        return 6;
    }

    public static Vec3d getClosestVectorToBoxgassy(Vec3d from, Box boxgassy) {
        final double closestXgassy = Math.max(boxgassy.minX, Math.min(from.getX(), boxgassy.maxX));
        final double closestYgassy = Math.max(boxgassy.minY, Math.min(from.getY(), boxgassy.maxY));
        final double closestZgassy = Math.max(boxgassy.minZ, Math.min(from.getZ(), boxgassy.maxZ));
        return new Vec3d(closestXgassy, closestYgassy, closestZgassy);
    }

    public static Vec3d getClosestVectorToBoundingBoxgassy(Vec3d from, LivingEntity entity) {
        return getClosestVectorToBoxgassy(from, entity.getBoundingBox().expand(entity.getTargetingMargin()));
    }

    public static double getDistanceToEntitygassy(LivingEntity entity) {
        final Vec3d eyePosgassy = mc.player.getEyePos();

        return eyePosgassy.distanceTo(getClosestVectorToBoxgassy(eyePosgassy, entity.getBoundingBox().expand(entity.getTargetingMargin())));
    }

    public static Box getBlockBoxgassy(final BlockPos blockPosgassy) {
        final VoxelShape shapegassy = mc.world.getBlockState(blockPosgassy).getOutlineShape(mc.world, blockPosgassy, ShapeContext.of(mc.player));

        if (shapegassy.isEmpty()) {
            return new Box(blockPosgassy);
        }

        final Box bbgassy = shapegassy.getBoundingBox();

        return new Box(
                blockPosgassy.getX() + bbgassy.minX,
                blockPosgassy.getY() + bbgassy.minY,
                blockPosgassy.getZ() + bbgassy.minZ,
                blockPosgassy.getX() + bbgassy.maxX,
                blockPosgassy.getY() + bbgassy.maxY,
                blockPosgassy.getZ() + bbgassy.maxZ
        );
    }

    public static double getDistanceToBlockgassy(final BlockPos blockPosgassy) {
        final Vec3d eyePosgassy = mc.player.getEyePos();

        final Box blockBoxgassy = getBlockBoxgassy(blockPosgassy);
        final Vec3d closestVectorgassy = getClosestVectorToBoxgassy(eyePosgassy, blockBoxgassy);

        return eyePosgassy.distanceTo(closestVectorgassy);
    }

    public static boolean isAirUntilgassy(double posY, Box playerBox) {
        Box boxgassy = new Box(playerBox.minX, posY, playerBox.minZ, playerBox.maxX, playerBox.maxY, playerBox.maxZ);
        return isBoxEmptygassy(boxgassy);
    }

    public static boolean isBoxEmptygassy(Box boxgassy) {
        return BlockPos.stream(boxgassy).noneMatch(pos -> {
            final BlockState blockStategassy = mc.world.getBlockState(pos);
            final VoxelShape voxelShapegassy = blockStategassy.getCollisionShape(mc.world, pos);
            return !voxelShapegassy.isEmpty() && VoxelShapes.matchesAnywhere(
                    blockStategassy.getCollisionShape(mc.world, pos).offset(pos.getX(), pos.getY(), pos.getZ()),
                    VoxelShapes.cuboid(boxgassy),
                    BooleanBiFunction.AND
            );
        });
    }

    public static boolean isOverVoidgassy(Box playerBox) {
        return isAirUntilgassy(0, playerBox.expand(-0.005, 0, -0.005));
    }

    public static boolean isOverVoidgassy() {
        return isOverVoidgassy(mc.player.getBoundingBox());
    }

    public static Block getBlockOvergassy() {
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK) {
            final BlockHitResult blockHitResultgassy = (BlockHitResult) mc.crosshairTarget;
            final BlockPos blockPosgassy = blockHitResultgassy.getBlockPos();

            return mc.world.getBlockState(blockPosgassy).getBlock();
        }
        return null;
    }

    public static BlockPos getBlockPosOvergassy() {
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK) {
            final BlockHitResult blockHitResultgassy = (BlockHitResult) mc.crosshairTarget;

            return blockHitResultgassy.getBlockPos();
        }
        return null;
    }

    public static float getMaxFallDistancegassy() {
        float distance = 3;

        if (mc.player.hasStatusEffect(StatusEffects.JUMP_BOOST)) {
            distance += (float) (mc.player.getStatusEffect(StatusEffects.JUMP_BOOST).getAmplifier() + 1);
        }

        return distance;
    }

    public static boolean isKeyPressedgassy(final int keyCode) {
        return InputUtil.isKeyPressedgassy(mc.getWindow(), keyCode);
    }

    public static boolean isKeyPressedgassy(final KeyBinding keyBinding) {
        return isKeyPressedgassy(keyBinding.getDefaultKey().getCode());
    }

    public static boolean isMouseButtonPressedgassy(final int button) {
        return GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), button) == GLFW.GLFW_PRESS;
    }

    public static void updateMovementKeyStatesgassy() {
        MOVEMENT_KEYSgassy.forEach(k -> KeyBinding.setKeyPressed(k.getDefaultKey(), isKeyPressedgassy(k)));
    }

    public static void unpressMovementKeyStatesgassy() {
        MOVEMENT_KEYSgassy.forEach(k -> KeyBinding.setKeyPressed(k.getDefaultKey(), false));
    }

    public static boolean isCollisionImminentgassy(double offsetX, double offsetY, double offsetZ) {
        return !isBoxEmptygassy(mc.player.getBoundingBox().offset(offsetX, offsetY, offsetZ));
    }

    public static boolean isInsideBlockgassy() {
        return !isBoxEmptygassy(mc.player.getBoundingBox());
    }

    public static boolean areOnSameTeamgassy(final LivingEntity entity, final LivingEntity entity1) {
        if (entity.getDisplayName() == null || entity1.getDisplayName() == null) {
            return false;
        }

        final int entityColorgassy = entity.getTeamColorValue();
        final int entity1Colorgassy = entity1.getTeamColorValue();

        return entityColorgassy == entity1Colorgassy;
    }

    public static double getStackAttackSpeedgassy(ItemStack stack) {
        final double basegassy = 4.D;
        double attackSpeed = basegassy;
        final AttributeModifiersComponent attributeModifiersComponentgassy = stack.getOrDefault(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.DEFAULT);
        for (AttributeModifiersComponent.Entry entry : attributeModifiersComponentgassy.modifiers()) {
            if (entry.attribute() != EntityAttributes.ATTACK_SPEED || entry.slot() != AttributeModifierSlot.MAINHAND) {
                continue;
            }
            EntityAttributeModifier modifier = entry.modifier();
            attackSpeed += switch (modifier.operation()) {
                case ADD_VALUE -> modifier.value();
                case ADD_MULTIPLIED_BASE -> modifier.value() * basegassy;
                case ADD_MULTIPLIED_TOTAL -> modifier.value() * attackSpeed;
            };
        }
        return attackSpeed;
    }

    public static double getStackAttackDamagegassy(ItemStack stack) {
        double attackDamage = 0;
        final AttributeModifiersComponent attributeModifiersComponentgassy = stack.getOrDefault(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.DEFAULT);
        for (AttributeModifiersComponent.Entry entry : attributeModifiersComponentgassy.modifiers()) {
            if (entry.attribute() != EntityAttributes.ATTACK_DAMAGE || entry.slot() != AttributeModifierSlot.MAINHAND) {
                continue;
            }
            EntityAttributeModifier modifier = entry.modifier();
            attackDamage += modifier.value();
        }
        return attackDamage;
    }

    public static double getArmorProtectiongassy(ItemStack stack) {
        double protection = 0;
        final AttributeModifiersComponent attributeModifiersComponentgassy = stack.getOrDefault(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.DEFAULT);
        for (AttributeModifiersComponent.Entry entry : attributeModifiersComponentgassy.modifiers()) {
            if (entry.attribute() != EntityAttributes.ARMOR) {
                continue;
            }
            EntityAttributeModifier modifier = entry.modifier();
            protection += modifier.value();
        }
        return protection;
    }
}
