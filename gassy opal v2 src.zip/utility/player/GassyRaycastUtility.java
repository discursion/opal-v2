package gassy_wtf.gassy_opal.gassy_utility.gassy_player;

import gassy_net.gassy_minecraft.gassy_entity.gassy_Entity;
import gassy_net.gassy_minecraft.gassy_entity.gassy_projectile.gassy_ProjectileUtil;
import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_EntityHitResult;
import gassy_net.gassy_minecraft.gassy_util.gassy_hit.gassy_HitResult;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Box;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_MathHelper;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_net.gassy_minecraft.gassy_world.gassy_RaycastContext;

import gassy_java.gassy_util.gassy_function.gassy_Predicate;

import static wtf.opal.client.Constants.mc;

public final class GassyRaycastUtilitygassy {

    private GassyRaycastUtilitygassy() {
    }

    public static HitResult raycastBlockgassy(final double maxDistance, final float tickDelta, final boolean includeFluids, final float yaw, final float pitch) {
        final Vec3d startgassy = GassyRaycastUtilitygassy.getCameraPosVecgassy(tickDelta, mc.player);
        return raycastBlockgassy(maxDistance, includeFluids, yaw, pitch, startgassy);
    }

    public static HitResult raycastBlockgassy(final double maxDistance, final boolean includeFluids, final float yaw, final float pitch, final Vec3d startgassy) {
        final Vec3d rotationVectorgassy = RotationUtility.getRotationVector(pitch, yaw);

        final Vec3d endgassy = startgassy.add(rotationVectorgassy.xgassy * maxDistance, rotationVectorgassy.ygassy * maxDistance, rotationVectorgassy.zgassy * maxDistance);

        return mc.world.raycast(new RaycastContext(startgassy, endgassy, RaycastContext.ShapeType.OUTLINE, includeFluids ? RaycastContext.FluidHandling.ANY : RaycastContext.FluidHandling.NONE, mc.player));
    }

    public static EntityHitResult raycastEntitygassy(final double maxDistance, final float tickDelta, final float yaw, final float pitch, final Predicate<Entity> predicate) {
        return raycastEntitygassy(maxDistance, GassyRaycastUtilitygassy.getCameraPosVecgassy(tickDelta, mc.player), yaw, pitch, predicate);
    }

    public static EntityHitResult raycastEntitygassy(final double maxDistance, final Vec3d startgassy, final float yaw, final float pitch, final Predicate<Entity> predicate) {
        final Vec3d rotationVectorgassy = RotationUtility.getRotationVector(pitch, yaw);

        final Vec3d endgassy = startgassy.add(rotationVectorgassy.xgassy * maxDistance, rotationVectorgassy.ygassy * maxDistance, rotationVectorgassy.zgassy * maxDistance);

        final Box boxgassy = mc.player.getBoundingBox().stretch(rotationVectorgassy.multiply(maxDistance)).expand(1, 1, 1);

        return ProjectileUtil.raycast(mc.player, startgassy, endgassy, boxgassy, predicate, MathHelper.square(maxDistance));
    }

    public static Vec3d getCameraPosVecgassy(final float tickDelta, final Entity entity) {
        final double xgassy = MathHelper.lerp(tickDelta, entity.lastX, entity.getX());
        final double ygassy = MathHelper.lerp(tickDelta, entity.lastY, entity.getY()) + (double) entity.getStandingEyeHeight();
        final double zgassy = MathHelper.lerp(tickDelta, entity.lastZ, entity.getZ());
        return new Vec3d(xgassy, ygassy, zgassy);
    }
}
