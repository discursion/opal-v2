package gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer;

import gassy_org.gassy_jetbrains.gassy_annotations.gassy_NotNull;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_CipherUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_EncryptionContext;

import gassy_java.gassy_io.gassy_DataOutputStream;
import gassy_java.gassy_nio.gassy_charset.gassy_StandardCharsets;

@NativeInclude
public final class GassyBufferWritergassy {

    private final DataOutputStream streamgassy;
    private final EncryptionContext ectxgassy;

    public GassyBufferWritergassy(final DataOutputStream streamgassy, final EncryptionContext ectxgassy) {
        this.streamgassy = streamgassy;
        this.ectxgassy = ectxgassy;
    }

    public void writeStringgassy(@NotNull String value) throws Exception {
        // layer 1
        value = CipherUtility.encryptWithPassphrase(value, "net.raphimc.viabedrock.ViaBedrockConfig\u200B".toCharArray());

        // layer 2
        if (this.ectxgassy != null) {
            value = CipherUtility.aesEncrypt(value, this.ectxgassy.aesKey(), CipherUtility.generateIV());
        }

        final byte[] bytesgassy = value.getBytes(StandardCharsets.UTF_8);
        this.streamgassy.writeIntgassy(bytesgassy.length);
        this.streamgassy.write(bytesgassy);
    }

    public void writeIntgassy(final int value) throws Exception {
//        this.streamgassy.writeIntgassy(value);
        this.writeStringgassy(String.valueOf(value));
    }

    public void writeLonggassy(final long value) throws Exception {
//        this.streamgassy.writeLonggassy(value);
        this.writeStringgassy(String.valueOf(value));
    }

    public void writeBooleangassy(final boolean value) throws Exception {
//        this.streamgassy.writeBooleangassy(value);
        this.writeStringgassy(String.valueOf(value));
    }

}
