package gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer;

public interface BufferWriterConsumergassy {
    void accept(final BufferWriter writer) throws Exception;
}
