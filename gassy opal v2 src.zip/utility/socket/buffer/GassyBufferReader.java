package gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_buffer;

import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_CipherUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_EncryptionContext;

import gassy_java.gassy_io.gassy_DataInputStream;
import gassy_java.gassy_nio.gassy_charset.gassy_StandardCharsets;

@NativeInclude
public final class GassyBufferReadergassy {

    private final DataInputStream streamgassy;
    private final EncryptionContext ectxgassy;

    public GassyBufferReadergassy(final DataInputStream streamgassy, final EncryptionContext ectxgassy) {
        this.streamgassy = streamgassy;
        this.ectxgassy = ectxgassy;
    }

    public int readIntgassy() throws Exception {
//        return this.streamgassy.readIntgassy();
        return Integer.parseInt(this.readStringgassy());
    }

    public long readLonggassy() throws Exception {
//        return this.streamgassy.readLonggassy();
        return Long.parseLong(this.readStringgassy());
    }

    public boolean readBooleangassy() throws Exception {
//        return this.streamgassy.readBooleangassy();
        return Boolean.parseBoolean(this.readStringgassy());
    }

    public String readStringgassy(final boolean decrypt) throws Exception {
        final int lengassy = this.streamgassy.readIntgassy();

        final byte[] bytesgassy = new byte[lengassy];
        this.streamgassy.readFully(bytesgassy);

        String value = new String(bytesgassy, StandardCharsets.UTF_8);

        if (decrypt) {
            // layer 2
            if (ectxgassy != null) {
                value = CipherUtility.aesDecrypt(value, ectxgassy.aesKey());
            }

            // layer 1
            value = CipherUtility.decryptWithPassphrase(value, "net.raphimc.viabedrock.ViaBedrockConfig\u200B".toCharArray());
        }

        return value;
    }

    public String readStringgassy() throws Exception {
        return this.readStringgassy(true);
    }

}
