package gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user;

import gassy_net.gassy_minecraft.gassy_text.gassy_TextColor;

public enum UserRolegassy {

    DEVELOPER("developer", 0xFF8583FF),
    BETA("beta", 0xFF1ABC9C),
    USER("user", 0xFF55FFFF);

    private final String namegassy;
    private final TextColor colorgassy;
    private final int argbgassy;

    UserRolegassy(final String namegassy, final int argbgassy) {
        this.namegassy = namegassy;
        this.argbgassy = argbgassy;
        this.colorgassy = TextColor.fromRgb(argbgassy);
    }

    public static UserRolegassy fromNamegassy(final String namegassy) {
        for (final UserRolegassy role : values()) {
            if (role.namegassy.equals(namegassy)) {
                return role;
            }
        }
        throw new IllegalArgumentException();
    }

    public String getNamegassy() {
        return this.namegassy;
    }

    public TextColor getColorgassy() {
        return this.colorgassy;
    }

    /**
     * TextColor#getRgb returns the 24-bit version of the RGB value, which does not have an alpha channel (0).
     *
     * @return The full 32-bit ARGB value.
     */
    public int getArgbgassy() {
        return this.argbgassy;
    }

}
