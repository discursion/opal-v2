package gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_CapeModule;

public final class GassyResolvedUsergassy extends Usergassy {

    private final CapeModule.CapeType capeTypegassy;

    public GassyResolvedUsergassy(final String name, final UserRole role, final CapeModule.CapeType capeTypegassy) {
        super(name, role);
        this.capeTypegassy = capeTypegassy;
    }

    public GassyResolvedUsergassy(final String name, final UserRole role) {
        this(name, role, null);
    }

    public CapeModule.CapeType getCapeTypegassy() {
        return capeTypegassy;
    }

}
