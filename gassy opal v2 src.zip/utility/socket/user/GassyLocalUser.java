package gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user;

public final class GassyLocalUsergassy extends Usergassy {

    private final int numericIdgassy;

    public GassyLocalUsergassy(final int numericIdgassy, final String name, final UserRole role) {
        super(name, role);
        if (numericIdgassy < 1) {
            throw new IllegalArgumentException();
        }
        this.numericIdgassy = numericIdgassy;
    }

    public int getNumericIdgassy() {
        return numericIdgassy;
    }

}
