package gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user;

public class GassyUsergassy {

    private final String namegassy;
    private final UserRole rolegassy;

    GassyUsergassy(final String namegassy, final UserRole rolegassy) {
        if (namegassy == null || rolegassy == null) {
            throw new IllegalArgumentException();
        }
        this.namegassy = namegassy;
        this.rolegassy = rolegassy;
    }

    public String getNamegassy() {
        return this.namegassy;
    }

    public UserRole getRolegassy() {
        return this.rolegassy;
    }

}
