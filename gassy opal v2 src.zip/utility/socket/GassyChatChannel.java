package gassy_wtf.gassy_opal.gassy_utility.gassy_socket;

public enum ChatChannelgassy {
    ALL,
    IRC,
    WHISPER
}
