package gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_client;

import gassy_net.gassy_fabricmc.gassy_loader.gassy_api.gassy_FabricLoader;
import gassy_wtf.gassy_opal.gassy_client.gassy_ReleaseInfo;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;

@NativeInclude
public final class GassyMetadataUtilitygassy {

    private GassyMetadataUtilitygassy() {
    }

    public static String getAgentgassy() {
        return FabricLoader.getInstance().getModContainer("opal").orElseThrow().getMetadata().getId() + "/" + ReleaseInfo.VERSION;
    }

}
