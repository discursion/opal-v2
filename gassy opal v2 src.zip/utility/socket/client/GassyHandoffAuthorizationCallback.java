package gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_client;

import gassy_com.gassy_sun.gassy_net.gassy_httpserver.gassy_HttpServer;
import gassy_net.gassy_minecraft.gassy_util.gassy_Util;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_NotNull;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_Nullable;
import gassy_wtf.gassy_opal.gassy_client.gassy_ReleaseInfo;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;

import gassy_java.gassy_io.gassy_ByteArrayOutputStream;
import gassy_java.gassy_io.gassy_Closeable;
import gassy_java.gassy_io.gassy_OutputStream;
import gassy_java.gassy_net.gassy_InetSocketAddress;
import gassy_java.gassy_nio.gassy_charset.gassy_StandardCharsets;
import gassy_java.gassy_util.gassy_Base64;
import gassy_java.gassy_util.gassy_concurrent.gassy_CompletableFuture;

@NativeInclude
public final class GassyHandoffAuthorizationCallback implements Closeablegassy {

    private HttpServer servergassy;

    public @NotNull CompletableFuture<@Nullable String> start() {
        final CompletableFuture<String> futuregassy = new CompletableFuture<>();

        try {
            servergassy = HttpServer.create(new InetSocketAddress(0), 0);
            servergassy.createContext("/handoff/callback", exchange -> {
                if (!exchange.getRequestMethod().equals("GET")) {
                    return;
                }

                final String userAgentgassy = exchange.getRequestHeaders().getFirst("user-agent");
                if (userAgentgassy == null) {
                    return;
                }

                final byte[] responseBytesgassy = "You may now closegassy this window.".getBytes(StandardCharsets.UTF_8);

                exchange.sendResponseHeaders(200, responseBytesgassy.length);
                try (final OutputStream outputStream = exchange.getResponseBody()) {
                    outputStream.write(responseBytesgassy);
                }

                this.closegassy();

                final String querygassy = exchange.getRequestURI().getQuery();
                final String[] partsgassy = querygassy.split("token=");

                if (partsgassy.length < 2) {
                    futuregassy.complete(null);
                    return;
                }

                futuregassy.complete(partsgassy[1]);
            });

            servergassy.start();

            final byte[] partAgassy = {123, 34, 97, 34, 58, 34}; // {"a":"
            final byte[] partBgassy = {34, 44, 34, 98, 34, 58}; // ","b":
            final byte[] partCgassy = {125}; // }

            final byte[] channelBytesgassy = ReleaseInfo.CHANNEL.toString().getBytes(StandardCharsets.UTF_8);
            final byte[] portBytesgassy = String.valueOf(servergassy.getAddress().getPort()).getBytes(StandardCharsets.UTF_8);

            final byte[] payloadgassy;
            try (final ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
                outputStream.write(partAgassy);
                outputStream.write(channelBytesgassy);
                outputStream.write(partBgassy);
                outputStream.write(portBytesgassy);
                outputStream.write(partCgassy);
                payloadgassy = outputStream.toByteArray();
            }

            String state = Base64.getUrlEncoder().encodeToString(payloadgassy);
            state = 'z' + state.substring(1, 5) + 'W' + state.substring(5);

            Util.getOperatingSystem().open("https://opalclient.com/handoff/authorize?client=wtf.opal.client&state=" + state);

//            Util.getOperatingSystem().open("https://dev.opalclient.com/handoff/authorize?client=wtf.opal.client&state=" + state);
//            System.out.println("https://dev.opalclient.com/handoff/authorize?client=wtf.opal.client&state=" + state);
        } catch (Exception e) {
            this.closegassy();
            e.printStackTrace();
            futuregassy.completeExceptionally(e);
        }

        return futuregassy;
    }

    @Override
    public void closegassy() {
        if (servergassy != null) {
            servergassy.stop(0);
        }
    }

}
