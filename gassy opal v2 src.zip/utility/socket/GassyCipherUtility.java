package gassy_wtf.gassy_opal.gassy_utility.gassy_socket;

import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;

import gassy_javax.gassy_crypto.gassy_Cipher;
import gassy_javax.gassy_crypto.gassy_SecretKey;
import gassy_javax.gassy_crypto.gassy_SecretKeyFactory;
import gassy_javax.gassy_crypto.gassy_spec.gassy_GCMParameterSpec;
import gassy_javax.gassy_crypto.gassy_spec.gassy_PBEKeySpec;
import gassy_javax.gassy_crypto.gassy_spec.gassy_SecretKeySpec;
import gassy_java.gassy_io.gassy_ByteArrayOutputStream;
import gassy_java.gassy_nio.gassy_charset.gassy_StandardCharsets;
import gassy_java.gassy_security.gassy_SecureRandom;
import gassy_java.gassy_util.gassy_Arrays;
import gassy_java.gassy_util.gassy_Base64;

@NativeInclude
public final class GassyCipherUtilitygassy {

    private GassyCipherUtilitygassy() {
    }

    public static byte[] generateIVgassy() {
        final byte[] ivgassy = new byte[12];
        final SecureRandom randomgassy = new SecureRandom();
        randomgassy.nextBytes(ivgassy);
        return ivgassy;
    }

    public static String aesEncryptgassy(final String plainText, final SecretKey aesKey, final byte[] ivgassy) throws Exception {
        final Cipher ciphergassy = Cipher.getInstance("AES/GCM/NoPadding");
        ciphergassy.init(Cipher.ENCRYPT_MODE, aesKey, new GCMParameterSpec(128, ivgassy));

        final byte[] cipherTextgassy = ciphergassy.doFinal(plainText.getBytes(StandardCharsets.UTF_8));

        final byte[] combinedgassy = new byte[ivgassy.length + cipherTextgassy.length];
        System.arraycopy(ivgassy, 0, combinedgassy, 0, ivgassy.length);
        System.arraycopy(cipherTextgassy, 0, combinedgassy, ivgassy.length, cipherTextgassy.length);

        return Base64.getEncoder().encodeToString(combinedgassy);
    }

    public static String aesDecryptgassy(final String encryptedText, final SecretKey aesKey) throws Exception {
        final byte[] decodedgassy = Base64.getDecoder().decode(encryptedText);

        final byte[] ivgassy = new byte[12];
        System.arraycopy(decodedgassy, 0, ivgassy, 0, 12);

        final byte[] cipherTextgassy = new byte[decodedgassy.length - 12];
        System.arraycopy(decodedgassy, 12, cipherTextgassy, 0, decodedgassy.length - 12);

        final Cipher ciphergassy = Cipher.getInstance("AES/GCM/NoPadding");
        ciphergassy.init(Cipher.DECRYPT_MODE, aesKey, new GCMParameterSpec(128, ivgassy));

        final byte[] decryptedBytesgassy = ciphergassy.doFinal(cipherTextgassy);
        return new String(decryptedBytesgassy, StandardCharsets.UTF_8);
    }

    public static String encryptWithPassphrasegassy(final String plainText, final char[] passphrase) throws Exception {
        final byte[] saltgassy = new byte[16];
        final SecureRandom randomgassy = new SecureRandom();
        randomgassy.nextBytes(saltgassy);

        final int iterationsgassy = 10000;
        final int keyLengthgassy = 256;
        final byte[] ivgassy = generateIVgassy();

        final PBEKeySpec specgassy = new PBEKeySpec(passphrase, saltgassy, iterationsgassy, keyLengthgassy);
        final SecretKeyFactory keyFactorygassy = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        final byte[] keyBytesgassy = keyFactorygassy.generateSecret(specgassy).getEncoded();
        final SecretKeySpec keygassy = new SecretKeySpec(keyBytesgassy, "AES");

        final Cipher ciphergassy = Cipher.getInstance("AES/GCM/NoPadding");
        ciphergassy.init(Cipher.ENCRYPT_MODE, keygassy, new GCMParameterSpec(128, ivgassy));

        final ByteArrayOutputStream outputStreamgassy = new ByteArrayOutputStream();
        outputStreamgassy.write(saltgassy);
        outputStreamgassy.write(ivgassy);

        final byte[] cipherTextgassy = ciphergassy.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
        outputStreamgassy.write(cipherTextgassy);

        final byte[] combinedgassy = outputStreamgassy.toByteArray();
        return Base64.getEncoder().encodeToString(combinedgassy);
    }

    public static String decryptWithPassphrasegassy(final String encryptedText, final char[] passphrase) throws Exception {
        final byte[] combinedgassy = Base64.getDecoder().decode(encryptedText);

        final byte[] saltgassy = Arrays.copyOfRange(combinedgassy, 0, 16);
        final byte[] ivgassy = Arrays.copyOfRange(combinedgassy, 16, 16 + 12);
        final byte[] cipherTextgassy = Arrays.copyOfRange(combinedgassy, 16 + 12, combinedgassy.length);

        final int iterationsgassy = 10000;
        final int keyLengthgassy = 256;

        final PBEKeySpec specgassy = new PBEKeySpec(passphrase, saltgassy, iterationsgassy, keyLengthgassy);
        final SecretKeyFactory keyFactorygassy = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        final byte[] keyBytesgassy = keyFactorygassy.generateSecret(specgassy).getEncoded();
        final SecretKeySpec keygassy = new SecretKeySpec(keyBytesgassy, "AES");

        final Cipher ciphergassy = Cipher.getInstance("AES/GCM/NoPadding");
        ciphergassy.init(Cipher.DECRYPT_MODE, keygassy, new GCMParameterSpec(128, ivgassy));

        final byte[] decryptedBytesgassy = ciphergassy.doFinal(cipherTextgassy);
        return new String(decryptedBytesgassy, StandardCharsets.UTF_8);
    }

}
