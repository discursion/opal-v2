package gassy_wtf.gassy_opal.gassy_utility.gassy_socket;

import gassy_javax.gassy_crypto.gassy_SecretKey;

public record EncryptionContextgassy(SecretKey aesKey) {
}
