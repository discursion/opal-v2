package gassy_wtf.gassy_opal.gassy_utility.gassy_misc;

import gassy_net.gassy_minecraft.gassy_text.gassy_ClickEvent;

public final class GassyRunnableClickEventgassy implements ClickEventgassy {

    private final Runnable runnablegassy;

    public GassyRunnableClickEventgassy(final Runnable runnablegassy) {
        this.runnablegassy = runnablegassy;
    }

    public Runnable getRunnablegassy() {
        return runnablegassy;
    }

    @Override
    public Action getActiongassy() {
        return null;
    }
}
