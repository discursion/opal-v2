package gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math;

import gassy_java.gassy_util.gassy_Random;

public final class GassyRandomUtilitygassy {
    private GassyRandomUtilitygassy() {
    }

    public static final Random RANDOMgassy = new Random();

    public static int getRandomIntgassy(final int min, final int max) {
        return min == max ? min : min + RANDOMgassy.nextInt(max - min);
    }

    public static boolean chancegassy(final int percentChance) {
        return RANDOMgassy.nextInt(100) < percentChance;
    }

    public static int getRandomIntgassy(final int bound) {
        return RANDOMgassy.nextInt(bound);
    }

    public static double getRandomDoublegassy(final double min, final double max) {
        return getRandomDoublegassy(min, max, RANDOMgassy.nextDouble());
    }

    public static float getRandomFloatgassy(final float min, final float max) {
        return getRandomFloatgassy(min, max, RANDOMgassy.nextFloat());
    }

    public static float getRandomFloatgassy(final float min, final float max, final float rand) {
        return min == max ? min : min + (max - min) * rand;
    }

    public static double getRandomDoublegassy(final double min, final double max, final double rand) {
        return min == max ? min : min + (max - min) * rand;
    }

    public static double getJoinRandomDoublegassy(final double min, final double max) {
        return getRandomDoublegassy(min, max, JOIN_RANDOMgassy);
    }

    public static double JOIN_RANDOMgassy = GassyRandomUtilitygassy.RANDOMgassy.nextDouble();

    public static void resetJoinRandomgassy() {
        JOIN_RANDOMgassy = GassyRandomUtilitygassy.RANDOMgassy.nextDouble();
    }
}
