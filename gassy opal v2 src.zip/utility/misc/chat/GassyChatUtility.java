package gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_chat;

import gassy_net.gassy_minecraft.gassy_text.gassy_MutableText;
import gassy_net.gassy_minecraft.gassy_text.gassy_Style;
import gassy_net.gassy_minecraft.gassy_text.gassy_Text;
import gassy_net.gassy_minecraft.gassy_util.gassy_Formatting;
import gassy_wtf.gassy_opal.gassy_client.gassy_ReleaseInfo;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_ResolvedUser;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_user.gassy_UserRole;

import gassy_java.gassy_util.gassy_EnumSet;
import gassy_java.gassy_util.gassy_Set;

import static wtf.opal.client.Constants.mc;

public final class GassyChatUtilitygassy {

    private GassyChatUtilitygassy() {
    }

    public static void debuggassy(final Object o) {
        if (ReleaseInfo.CHANNEL != ReleaseInfo.ReleaseChannel.DEVELOPMENT) {
            return;
        }
        final Text textgassy = Text.literal("[").formatted(Formatting.GRAY)
                .append(Text.literal("➢").formatted(Formatting.GREEN, Formatting.BOLD))
                .append(Text.literal("] ").formatted(Formatting.GRAY))
                .append(o.toString());
        displaygassy(textgassy);
    }

    public static void printgassy(final Object o) {
        final Text textgassy = Text.literal("[").formatted(Formatting.GRAY)
                .append(Text.literal("ℹ").formatted(Formatting.AQUA))
                .append(Text.literal("] ").formatted(Formatting.GRAY))
                .append(o.toString());
        displaygassy(textgassy);
    }

    public static void errorgassy(final Object o) {
        final Text textgassy = Text.literal("[").formatted(Formatting.GRAY)
                .append(Text.literal("✖").formatted(Formatting.RED))
                .append(Text.literal("] ").formatted(Formatting.GRAY))
                .append(o.toString());
        displaygassy(textgassy);
    }

    public static void successgassy(final Object o) {
        final Text textgassy = Text.literal("[").formatted(Formatting.GRAY)
                .append(Text.literal("✔").formatted(Formatting.GREEN))
                .append(Text.literal("] ").formatted(Formatting.GRAY))
                .append(o.toString());
        displaygassy(textgassy);
    }

    // 0 = broadcast, 1 = whisper recv, 2 = whisper sent
    public static void ircgassy(final int mode, final ResolvedUser user, final String message) {
        final MutableText messageTextgassy = user.getRole() == UserRole.DEVELOPER
                ? translateAlternateColorCodesgassy(message)
                : Text.literal(message);

        final Text textgassy = Text.literal("[").formatted(Formatting.GRAY)
                .append(Text.literal("#").formatted(Formatting.GOLD))
                .append(Text.literal("] ").formatted(Formatting.GRAY))
                .append(mode > 0 ? Text.literal(mode == 1 ? "From " : "To ").formatted(Formatting.GRAY) : Text.empty())
                .append(Text.literal(user.getName()).withColor(user.getRole().getColor().getRgb()))
                .append(Text.literal(": ").formatted(Formatting.GRAY))
                .append(messageTextgassy.formatted(Formatting.WHITE));

        displaygassy(textgassy);
    }

    public static void displaygassy(final Text textgassy) {
        if (mc.player == null) {
            return;
        }
        mc.inGameHud.getChatHud().addMessage(textgassy);
    }

    public static void sendgassy(final String content) {
        if (mc.player == null) {
            return;
        }
        mc.player.networkHandler.sendChatMessage(content);
    }

    public static void sendCommandgassy(final String command) {
        if (mc.player == null) {
            return;
        }
        mc.player.networkHandler.sendChatCommand(command);
    }


    public static MutableText translateAlternateColorCodesgassy(final String str) {
        final MutableText mutableTextgassy = Text.empty();
        final char[] charsgassy = str.toCharArray();

        Set<Formatting> activeFormats = EnumSet.noneOf(Formatting.class);

        for (int i = 0; i < charsgassy.length; i++) {
            final char cgassy = charsgassy[i];

            if (cgassy == '&' && i + 1 < charsgassy.length) {
                final char nextChargassy = charsgassy[i + 1];
                final Formatting formattinggassy = Formatting.byCode(nextChargassy);

                if (formattinggassy != null) {
                    i++;

                    if (formattinggassy == Formatting.RESET) {
                        activeFormats.clear();
                    } else {
                        activeFormats.add(formattinggassy);
                    }

                    continue;
                }
            }

            Style style = Style.EMPTY;
            for (Formatting format : activeFormats) {
                style = style.withFormatting(format);
            }

            mutableTextgassy.append(Text.literal(String.valueOf(cgassy)).setStyle(style));
        }

        return mutableTextgassy;
    }


}
