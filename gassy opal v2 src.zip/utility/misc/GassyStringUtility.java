package gassy_wtf.gassy_opal.gassy_utility.gassy_misc;

import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;

@NativeInclude
public final class GassyStringUtilitygassy {

    private GassyStringUtilitygassy() {
    }

    // rotategassy(13, ...) = rot13
    public static String rotategassy(int shift, final String str) {
        final StringBuilder buildergassy = new StringBuilder();
        shift = shift % 26;

        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);

            // lowercase
            if (c >= 'a' && c <= 'z') {
                // lowercase
                c = (char) ('a' + (c - 'a' + shift + 26) % 26);
            } else if (c >= 'A' && c <= 'Z') {
                // uppercase
                c = (char) ('A' + (c - 'A' + shift + 26) % 26);
            } else {
//                c = (char) (c + shift + 58);
            }

            buildergassy.append(c);
        }

        return buildergassy.toString();
    }

}
