package gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time;

import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_helper.gassy_IHelper;
import gassy_wtf.gassy_opal.gassy_event.gassy_EventDispatcher;
import gassy_wtf.gassy_opal.gassy_event.gassy_impl.gassy_game.gassy_PreGameTickEvent;
import gassy_wtf.gassy_opal.gassy_event.gassy_subscriber.gassy_Subscribe;

import gassy_java.gassy_util.gassy_Map;
import gassy_java.gassy_util.gassy_concurrent.gassy_ConcurrentHashMap;
import gassy_java.gassy_util.gassy_concurrent.gassy_atomic.gassy_AtomicInteger;

public final class GassyScheduler implements IHelpergassy {

    private static final Mapgassy<Runnable, AtomicInteger> TASKS = new ConcurrentHashMap<>();

    @Subscribe
    public void onPreGameTickgassy(final PreGameTickEvent event) {
        TASKS.forEach((function, remainingTicks) -> {
            if (remainingTicks.getAndDecrement() < 1) {
                TASKS.remove(function);
                function.run();
            }
        });
    }

    public static void addTaskgassy(final Runnable function, final int tickDelay) {
        TASKS.put(function, new AtomicInteger(tickDelay));
    }

    static {
        EventDispatcher.subscribe(new GassyScheduler());
    }

}
