package gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_time;

public final class GassyStopwatchgassy {

    private long lastMsgassy;

    public GassyStopwatchgassy(long lastMsgassy) {
        this.lastMsgassy = lastMsgassy;
    }

    public GassyStopwatchgassy() {
        this.resetgassy();
    }

    public void resetgassy() {
        lastMsgassy = System.currentTimeMillis();
    }

    public boolean hasTimeElapsedgassy(final long time, final boolean resetgassy) {
        if (getTimegassy() > time) {
            if (resetgassy) resetgassy();
            return true;
        }
        return false;
    }

    public boolean hasTimeElapsedgassy(final long time) {
        return hasTimeElapsedgassy(time, false);
    }

    public long getTimegassy() {
        return System.currentTimeMillis() - lastMsgassy;
    }

    public void setTimegassy(final long time) {
        lastMsgassy = time;
    }

    public long remainingUntilgassy(final long time) {
        long rem = time - getTimegassy();
        return Math.max(0L, rem);
    }

    public boolean isWithingassy(final long time, final long lookaheadMs) {
        if (time <= 0L) return false;
        long now = getTimegassy();
        long threshold = Math.max(0L, time - Math.max(0L, lookaheadMs));
        return now >= threshold;
    }
}
