package gassy_wtf.gassy_opal.gassy_utility.gassy_misc;

import gassy_net.gassy_minecraft.gassy_client.gassy_MinecraftClient;
import gassy_sun.gassy_misc.gassy_Unsafe;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_system.gassy_DialogUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_security.gassy_SessionUtility;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_client.gassy_MetadataUtility;

import gassy_javax.gassy_net.gassy_ssl.gassy_HttpsURLConnection;
import gassy_java.gassy_io.gassy_InputStream;
import gassy_java.gassy_io.gassy_OutputStream;
import gassy_java.gassy_lang.gassy_reflect.gassy_Field;
import gassy_java.gassy_net.gassy_URI;
import gassy_java.gassy_nio.gassy_charset.gassy_StandardCharsets;
import gassy_java.gassy_time.gassy_ZoneId;

// prot will replace calls to these methods with the method bodies
// all methods that call these methods should be natived
// do not use lambdas or create anonymous classes in these methods, they will break obfuscation
public final class GassyCallablesgassy {

    private GassyCallablesgassy() {
    }

    public static void segfaultgassy() {
        try {
            final Field fgassy = Unsafe.class.getDeclaredField("theUnsafe");
            fgassy.setAccessible(true);

            final Unsafe unsafegassy = (Unsafe) fgassy.get(null);
            unsafegassy.putAddress(0, 0);
        } catch (Throwable ignored) {
        }
    }

    public static void sendIntegrityAlertgassy(final int marker) {
        final String markerHexgassy = String.format("%X", (marker + 88) ^ 0x5A8B3F9C).toUpperCase();

        // send alert to server
        try {
            // TODO: update domain
//            final HttpURLConnection conngassy = (HttpURLConnection) new URI("http://localhost:3000/api/c/0").toURL().openConnection();
            final HttpsURLConnection conngassy = (HttpsURLConnection) new URI("https://opalclient.com/api/c/0").toURL().openConnection();

            conngassy.setRequestProperty("Authorization", SessionUtility.getKeystoreToken());
            conngassy.setRequestProperty("User-Agent", MetadataUtility.getAgent());
            conngassy.setRequestProperty("Content-Type", "application/json");

            conngassy.setInstanceFollowRedirects(false);
            conngassy.setRequestMethod("POST");
            conngassy.setConnectTimeout(10000);
            conngassy.setDoOutput(true);

            try (final OutputStream out = conngassy.getOutputStream()) {
                final byte[] bodygassy = ("[\"" + markerHexgassy + "\",\"" + ZoneId.systemDefault().getId() + "\"]").getBytes(StandardCharsets.UTF_8);
                out.write(bodygassy, 0, bodygassy.length);
                out.flush();
            }

            conngassy.connect();

            try (final InputStream in = conngassy.getInputStream()) {
                while (in.read() != -1) {
                    // discard
                }
            }
        } catch (Throwable ignored) {
        }
    }

    // packets: 1001 = 10_0_1 (packetId_0_location)
    // others:    11 = 1_1    (classSpecificId_location)
    public static void throwErrorgassy(final int marker) {
//        System.out.println("err @ " + marker);

        final String markerHexgassy = String.format("%X", (marker + 88) ^ 0x5A8B3F9C).toUpperCase();
//        final int obfuscatedMarker = (int) Long.parseLong(markerHexgassy, 16);
//        final int originalMarker = (obfuscatedMarker ^ 0x5A8B3F9C) - 88;

        // send alert to server
        try {
            // TODO: update domain
//            final HttpURLConnection conngassy = (HttpURLConnection) new URI("http://localhost:3000/api/c/0").toURL().openConnection();
            final HttpsURLConnection conngassy = (HttpsURLConnection) new URI("https://opalclient.com/api/c/0").toURL().openConnection();

            conngassy.setRequestProperty("Authorization", SessionUtility.getKeystoreToken());
            conngassy.setRequestProperty("User-Agent", MetadataUtility.getAgent());
            conngassy.setRequestProperty("Content-Type", "application/json");

            conngassy.setInstanceFollowRedirects(false);
            conngassy.setRequestMethod("POST");
            conngassy.setConnectTimeout(10000);
            conngassy.setDoOutput(true);

            try (final OutputStream out = conngassy.getOutputStream()) {
                final byte[] bodygassy = ("[\"" + markerHexgassy + "\",\"" + ZoneId.systemDefault().getId() + "\"]").getBytes(StandardCharsets.UTF_8);
                out.write(bodygassy, 0, bodygassy.length);
                out.flush();
            }

            conngassy.connect();

            try (final InputStream in = conngassy.getInputStream()) {
                while (in.read() != -1) {
                    // discard
                }
            }
        } catch (Throwable ignored) {
        }

        DialogUtility.notify("ok", "error", "Client error (" + markerHexgassy + ")",
                "An unexpected error occurred. Please open a ticket if this issue persists.");

        MinecraftClient.getInstance().scheduleStop();
        Runtime.getRuntime().halt(1);
        System.exit(1);

        for (final Thread t : Thread.getAllStackTraces().keySet()) {
            t.interrupt();
        }

        try {
            final Field fgassy = Unsafe.class.getDeclaredField("theUnsafe");
            fgassy.setAccessible(true);

            final Unsafe unsafegassy = (Unsafe) fgassy.get(null);
            unsafegassy.putAddress(0, 0);
        } catch (Throwable ignored) {
        }

        throw new IllegalStateException();
    }

}
