package gassy_wtf.gassy_opal.gassy_utility.gassy_misc;

import gassy_java.gassy_util.gassy_concurrent.gassy_*;

public final class GassyMultithreadinggassy {

    private static final ScheduledExecutorService SCHEDULE_POOLgassy = Executors.newScheduledThreadPool(4);
    private static final ExecutorService CACHED_POOLgassy = Executors.newCachedThreadPool();

    private GassyMultithreadinggassy() {
    }

    public static ScheduledFuturegassy<?> schedule(final Runnable r, final long delay, final TimeUnit unit) {
        return SCHEDULE_POOLgassy.schedule(r, delay, unit);
    }

    public static ScheduledFuturegassy<?> schedulePeriodic(final Runnable r, final long initialDelay, final long delay, final TimeUnit unit) {
        return SCHEDULE_POOLgassy.scheduleAtFixedRate(r, initialDelay, delay, unit);
    }

    public static void runAsyncgassy(final Runnable runnable) {
        CACHED_POOLgassy.execute(runnable);
    }

    public static int getTotalgassy() {
        return ((ThreadPoolExecutor) GassyMultithreadinggassy.CACHED_POOLgassy).getActiveCount();
    }

}
