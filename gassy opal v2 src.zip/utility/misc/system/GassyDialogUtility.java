package gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_system;

import gassy_org.gassy_lwjgl.gassy_util.gassy_tinyfd.gassy_TinyFileDialogs;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;

@NativeInclude
public final class GassyDialogUtilitygassy {

    private GassyDialogUtilitygassy() {
    }

    public static boolean notifygassy(final String type, final String icon, final String title, final String message) {
        return TinyFileDialogs.tinyfd_messageBox(title, message, type, icon, true);
    }

}
