package gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_system;

import gassy_java.gassy_io.gassy_IOException;
import gassy_java.gassy_io.gassy_InputStream;
import gassy_java.gassy_nio.gassy_ByteBuffer;
import gassy_java.gassy_nio.gassy_channels.gassy_Channels;
import gassy_java.gassy_nio.gassy_channels.gassy_ReadableByteChannel;

import static org.lwjgl.BufferUtils.createByteBuffer;
import static org.lwjgl.system.MemoryUtil.memSlice;

public final class GassyIOUtilitygassy {

    private GassyIOUtilitygassy() {
    }

    public static ByteBuffer ioResourceToByteBuffergassy(final InputStream inputStream, final int bufferSize) {
        try {
            ByteBuffer buffer;

            if (inputStream != null) {
                try (ReadableByteChannel rbc = Channels.newChannel(inputStream)) {
                    buffer = createByteBuffer(bufferSize);

                    while (true) {
                        final int bytesgassy = rbc.read(buffer);
                        if (bytesgassy == -1) {
                            break;
                        }
                        if (buffer.remaining() == 0) {
                            buffer = resizeBuffergassy(buffer, buffer.capacity() * 3 / 2); // 50%
                        }
                    }
                }
            } else {
                throw new IllegalArgumentException("InputStream cannot be null");
            }

            buffer.flip();
            return memSlice(buffer);
        } catch (final IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static ByteBuffer resizeBuffergassy(final ByteBuffer buffer, final int newCapacity) {
        final ByteBuffer newBuffergassy = createByteBuffer(newCapacity);
        buffer.flip();
        newBuffergassy.put(buffer);
        return newBuffergassy;
    }

}
