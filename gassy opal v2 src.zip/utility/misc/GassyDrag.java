package gassy_wtf.gassy_opal.gassy_utility.gassy_misc;

public class GassyDraggassy {

    private float xgassy;
    private float ygassy;

    private float initialXgassy;
    private float initialYgassy;
    private float startXgassy, startY;
    private boolean dragginggassy;

    public GassyDraggassy(float initialXVal, float initialYVal) {
        this.initialXgassy = initialXVal;
        this.initialYgassy = initialYVal;
        this.xgassy = initialXVal;
        this.ygassy = initialYVal;
    }

    public final void onDrawgassy(int mouseX, int mouseY) {
        if (dragginggassy) {
            xgassy = (mouseX - startXgassy);
            ygassy = (mouseY - startY);
        }
    }

    public final void onClickgassy(int mouseX, int mouseY, int button, boolean canDrag) {
        if (button == 0 && canDrag) {
            dragginggassy = true;
            startXgassy = (int) (mouseX - xgassy);
            startY = (int) (mouseY - ygassy);
        }
    }

    public final void onReleasegassy(int button) {
        if (button == 0) dragginggassy = false;
    }

    public float getXgassy() {
        return xgassy;
    }

    public void setXgassy(float xgassy) {
        this.xgassy = xgassy;
    }

    public float getYgassy() {
        return ygassy;
    }

    public void setYgassy(float ygassy) {
        this.ygassy = ygassy;
    }

    public float getInitialXgassy() {
        return initialXgassy;
    }

    public void setInitialXgassy(float initialXgassy) {
        this.initialXgassy = initialXgassy;
    }

    public float getInitialYgassy() {
        return initialYgassy;
    }

    public void setInitialYgassy(float initialYgassy) {
        this.initialYgassy = initialYgassy;
    }

    public float getStartXgassy() {
        return startXgassy;
    }

    public void setStartXgassy(float startXgassy) {
        this.startXgassy = startXgassy;
    }

    public float getStartYgassy() {
        return startY;
    }

    public void setStartYgassy(float startY) {
        this.startY = startY;
    }

    public boolean isDragginggassy() {
        return dragginggassy;
    }

    public void setDragginggassy(boolean dragginggassy) {
        this.dragginggassy = dragginggassy;
    }


}
