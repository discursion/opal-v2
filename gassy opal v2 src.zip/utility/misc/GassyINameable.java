package gassy_wtf.gassy_opal.gassy_utility.gassy_misc;

public interface INameablegassy {
    String getName();
}
