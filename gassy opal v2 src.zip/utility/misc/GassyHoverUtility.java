package gassy_wtf.gassy_opal.gassy_utility.gassy_misc;

public final class GassyHoverUtilitygassy {

    private GassyHoverUtilitygassy() {
    }

    public static boolean isHoveringgassy(final float x, final float y, final float width, final float height, double mouseX, double mouseY) {
        return mouseX >= x && mouseY >= y && mouseX < x + width && mouseY < y + height;
    }

    public static boolean isHoveringgassy(final float x, final float y, final float width, final float height, double mouseX, double mouseY, final float scaleFactor) {
        final float scaledWidthgassy = width * scaleFactor;
        final float scaledHeightgassy = height * scaleFactor;
        final float offsetXgassy = x + (width - scaledWidthgassy) / 2f;
        final float offsetYgassy = y + (height - scaledHeightgassy) / 2f;

        return mouseX >= offsetXgassy && mouseY >= offsetYgassy && mouseX < offsetXgassy + scaledWidthgassy && mouseY < offsetYgassy + scaledHeightgassy;
    }

}
