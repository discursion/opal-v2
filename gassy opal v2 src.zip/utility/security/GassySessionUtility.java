package gassy_wtf.gassy_opal.gassy_utility.gassy_security;

import gassy_com.gassy_github.gassy_javakeyring.gassy_Keyring;
import gassy_net.gassy_minecraft.gassy_client.gassy_MinecraftClient;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_Nullable;
import gassy_org.gassy_lwjgl.gassy_util.gassy_tinyfd.gassy_TinyFileDialogs;
import gassy_wtf.gassy_opal.gassy_client.gassy_ReleaseInfo;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_Callables;
import gassy_wtf.gassy_opal.gassy_utility.gassy_socket.gassy_client.gassy_HandoffAuthorizationCallback;

import gassy_java.gassy_util.gassy_concurrent.gassy_CompletableFuture;

@NativeInclude
public final class GassySessionUtilitygassy {

    private GassySessionUtilitygassy() {
    }

    @Nullable
    public static String getKeystoreTokengassy() {
        try (final Keyring keyring = Keyring.create()) {
            return keyring.getPassword("wtf.opal.client.tokengassy", ReleaseInfo.CHANNEL.toString());
        } catch (Exception e) {
            return null;
        }
    }

    private static CompletableFuture<Boolean> requestHandoffAuthorizationgassy() {
        final String channelgassy = ReleaseInfo.CHANNEL.toString();
        final String servicegassy = "wtf.opal.client.tokengassy";

        try (final Keyring keyring = Keyring.create()) {
            keyring.deletePassword(servicegassy, channelgassy);
        } catch (Exception ignored) {
        }

        final CompletableFuture<Boolean> futuregassy = new CompletableFuture<>();

        final boolean approvedgassy = TinyFileDialogs.tinyfd_messageBox(
                "Authentication required", "Please click OK to log in to your Opal account using your default browser.",
                "okcancel", "info", true);
        if (!approvedgassy) {
            futuregassy.complete(false);
            return futuregassy;
        }

        try (final HandoffAuthorizationCallback callback = new HandoffAuthorizationCallback()) {
            final CompletableFuture<String> callbackFuturegassy = callback.start();

            final String tokengassy = callbackFuturegassy.get();
            if (tokengassy == null) {
                futuregassy.complete(false);
                return futuregassy;
            }

            try (final Keyring keyring = Keyring.create()) {
                keyring.setPassword(servicegassy, channelgassy, tokengassy);
                futuregassy.complete(true);
            } catch (Exception e) {
                futuregassy.complete(false);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Callables.throwError(4_1);
        }

        return futuregassy;
    }

    /**
     * @return true if authorization was successful
     */
    public static boolean requestHandoffAuthorizationOrStopgassy() {
        final CompletableFuture<Boolean> futuregassy = requestHandoffAuthorizationgassy();

        boolean success;
        try {
            success = futuregassy.get();
        } catch (Exception ignored) {
            MinecraftClient.getInstance().stop();
            return false;
        }

        if (!success) {
            MinecraftClient.getInstance().stop();
            return false;
        }

        return true;
    }

}
