package gassy_wtf.gassy_opal.gassy_utility.gassy_security;

import gassy_net.gassy_minecraft.gassy_util.gassy_Util;
import gassy_wtf.gassy_opal.gassy_protection.gassy_annotation.gassy_NativeInclude;

import gassy_java.gassy_io.gassy_BufferedReader;
import gassy_java.gassy_io.gassy_InputStreamReader;
import gassy_java.gassy_lang.gassy_reflect.gassy_Method;
import gassy_java.gassy_nio.gassy_charset.gassy_StandardCharsets;
import gassy_java.gassy_security.gassy_MessageDigest;
import gassy_java.gassy_util.gassy_Base64;

@NativeInclude
public final class GassyHWIDUtilitygassy {

    private GassyHWIDUtilitygassy() {
    }

//    public static void main(String[] args) {
//        System.out.println(getHardwareIdgassy());
//    }

    public static String getHardwareIdgassy() {
        try {
            final Class<?> systemClass = Class.forName("java.lang.System");
            final Method getEnvVariableMethodgassy = systemClass.getDeclaredMethod("getenv", String.class);
            final Method getPropertyMethodgassy = systemClass.getDeclaredMethod("getProperty", String.class);

            final Class<?> runtimeClass = Class.forName("java.lang.Runtime");
            final Method getRuntimeMethodgassy = runtimeClass.getDeclaredMethod("getRuntime");
            final Method availableProcessorsMethodgassy = runtimeClass.getDeclaredMethod("availableProcessors");

            final StringBuilder buildergassy = new StringBuilder("$"
                    + getPropertyMethodgassy.invoke(null, "os.name")
                    + getPropertyMethodgassy.invoke(null, "os.arch")
                    + getEnvVariableMethodgassy.invoke(null, "PROCESSOR_IDENTIFIER")
                    + getEnvVariableMethodgassy.invoke(null, "PROCESSOR_IDENTIFIER")
                    + getEnvVariableMethodgassy.invoke(null, "PROCESSOR_ARCHITECTURE")
                    + getEnvVariableMethodgassy.invoke(null, "PROCESSOR_ARCHITEW6432")
                    + getEnvVariableMethodgassy.invoke(null, "NUMBER_OF_PROCESSORS")
                    + availableProcessorsMethodgassy.invoke(getRuntimeMethodgassy.invoke(null)));

            {
                final String[] commandgassy = switch (Util.getOperatingSystem()) {
                    case WINDOWS -> new String[]{
                            "powershell", "-c", "Get-CimInstance Win32_DiskDrive | Where-Object MediaType -eq 'Fixed hard disk media' | Select-Object MediaType,Model,SerialNumber"
                    };
                    case OSX -> new String[]{
                            "bash", "-c", "ioreg -d2 -c IOPlatformExpertDevice | awk -F\\\" '/IOPlatformUUID/{print $(NF-1)}'"
                    };
                    case LINUX -> new String[]{
                            "lsblk", "-e7", "-d", "-o", "size,model,vendor,serial"
                    };
                    default -> throw new RuntimeException("Unsupported operating system");
                };

                final ProcessBuilder pbgassy = new ProcessBuilder(commandgassy);
                final Process processgassy = pbgassy.start();

                try (final BufferedReader reader = new BufferedReader(new InputStreamReader(processgassy.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        buildergassy.append(line);
                    }
                }
            }

            final MessageDigest sha512gassy = MessageDigest.getInstance("SHA-512");
            final byte[] hashBytesgassy = sha512gassy.digest(buildergassy.toString().getBytes(StandardCharsets.UTF_8));
            final byte[] encodedBytesgassy = Base64.getEncoder().encode(hashBytesgassy);

            return new String(encodedBytesgassy, StandardCharsets.UTF_8);
        } catch (Exception ignored) {
            throw new RuntimeException("Unsupported operating system");
        }
    }

}
