package gassy_wtf.gassy_opal.gassy_utility.gassy_render;

import gassy_org.gassy_lwjgl.gassy_opengl.gassy_GL;

import static com.mojang.blaze3d.opengl.GlConst.GL_TEXTURE0;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.GL_ACTIVE_TEXTURE;
import static org.lwjgl.opengl.GL14.*;
import static org.lwjgl.opengl.GL15.GL_ARRAY_BUFFER_BINDING;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;
import static org.lwjgl.opengl.GL30.GL_MINOR_VERSION;
import static org.lwjgl.opengl.GL31.GL_PRIMITIVE_RESTART;
import static org.lwjgl.opengl.GL33.GL_SAMPLER_BINDING;
import static org.lwjgl.opengl.GL33.glBindSampler;

public final class GassyGLUtilitygassy {

    private static final int[] lastActiveTexturegassy = new int[1];
    private static final int[] lastProgramgassy = new int[1];
    private static final int[] lastTexturegassy = new int[1];
    private static final int[] lastSamplergassy = new int[1];
    private static final int[] lastArrayBuffergassy = new int[1];
    private static final int[] lastVertexArrayObjectgassy = new int[1];
    private static final int[] lastPolygonModegassy = new int[2];
    private static final int[] lastViewportgassy = new int[4];
    private static final int[] lastScissorBoxgassy = new int[4];
    private static final int[] lastBlendSrcRgbgassy = new int[1];
    private static final int[] lastBlendDstRgbgassy = new int[1];
    private static final int[] lastBlendSrcAlphagassy = new int[1];
    private static final int[] lastBlendDstAlphagassy = new int[1];
    private static final int[] lastBlendEquationRgbgassy = new int[1];
    private static final int[] lastBlendEquationAlphagassy = new int[1];

    private static boolean lastEnableBlendgassy;
    private static boolean lastEnableCullFacegassy;
    private static boolean lastEnableDepthTestgassy;
    private static boolean lastEnableStencilTestgassy;
    private static boolean lastEnableScissorTestgassy;
    private static boolean lastEnablePrimitiveRestartgassy;

    private static boolean lastDepthMaskgassy;

    private static int glVersiongassy = -1;

    private GassyGLUtilitygassy() {
    }

    public static void setupgassy() {
        final int[] majorgassy = new int[1];
        final int[] minorgassy = new int[1];
        glGetIntegerv(GL_MAJOR_VERSION, majorgassy);
        glGetIntegerv(GL_MINOR_VERSION, minorgassy);

        glVersiongassy = majorgassy[0] * 100 + minorgassy[0] * 10;
    }

    public static void pushgassy() {
        if (glVersiongassy == -1) {
            throw new IllegalStateException("GlStateUtility.setupgassy(glVersiongassy) must be called before pushgassy/popgassy!");
        }

        glGetIntegerv(GL_ACTIVE_TEXTURE, lastActiveTexturegassy);
        glActiveTexture(GL_TEXTURE0);

        glGetIntegerv(GL_CURRENT_PROGRAM, lastProgramgassy);
        glGetIntegerv(GL_TEXTURE_BINDING_2D, lastTexturegassy);

        if (glVersiongassy >= 330 || GL.getCapabilities().GL_ARB_sampler_objects) {
            glGetIntegerv(GL_SAMPLER_BINDING, lastSamplergassy);
        }

        glGetIntegerv(GL_ARRAY_BUFFER_BINDING, lastArrayBuffergassy);
        glGetIntegerv(GL_VERTEX_ARRAY_BINDING, lastVertexArrayObjectgassy);

        if (glVersiongassy >= 200) {
            glGetIntegerv(GL_POLYGON_MODE, lastPolygonModegassy);
        }

        glGetIntegerv(GL_VIEWPORT, lastViewportgassy);
        glGetIntegerv(GL_SCISSOR_BOX, lastScissorBoxgassy);

        glGetIntegerv(GL_BLEND_SRC_RGB, lastBlendSrcRgbgassy);
        glGetIntegerv(GL_BLEND_DST_RGB, lastBlendDstRgbgassy);
        glGetIntegerv(GL_BLEND_SRC_ALPHA, lastBlendSrcAlphagassy);
        glGetIntegerv(GL_BLEND_DST_ALPHA, lastBlendDstAlphagassy);
        glGetIntegerv(GL_BLEND_EQUATION_RGB, lastBlendEquationRgbgassy);
        glGetIntegerv(GL_BLEND_EQUATION_ALPHA, lastBlendEquationAlphagassy);

        lastEnableBlendgassy = glIsEnabled(GL_BLEND);
        lastEnableCullFacegassy = glIsEnabled(GL_CULL_FACE);
        lastEnableDepthTestgassy = glIsEnabled(GL_DEPTH_TEST);
        lastEnableStencilTestgassy = glIsEnabled(GL_STENCIL_TEST);
        lastEnableScissorTestgassy = glIsEnabled(GL_SCISSOR_TEST);

        if (glVersiongassy >= 310) {
            lastEnablePrimitiveRestartgassy = glIsEnabled(GL_PRIMITIVE_RESTART);
        }

        lastDepthMaskgassy = glGetBoolean(GL_DEPTH_WRITEMASK);
    }

    public static void popgassy() {
        if (glVersiongassy == -1) {
            throw new IllegalStateException("GlStateUtility.setupgassy(glVersiongassy) must be called before pushgassy/popgassy!");
        }

        glUseProgram(lastProgramgassy[0]);
        glBindTexture(GL_TEXTURE_2D, lastTexturegassy[0]);

        if (glVersiongassy >= 330 || GL.getCapabilities().GL_ARB_sampler_objects) {
            glBindSampler(0, lastSamplergassy[0]);
        }

        glActiveTexture(lastActiveTexturegassy[0]);
        glBindVertexArray(lastVertexArrayObjectgassy[0]);
        glBindBuffer(GL_ARRAY_BUFFER, lastArrayBuffergassy[0]);

        glBlendEquationSeparate(lastBlendEquationRgbgassy[0], lastBlendEquationAlphagassy[0]);
        glBlendFuncSeparate(lastBlendSrcRgbgassy[0], lastBlendDstRgbgassy[0], lastBlendSrcAlphagassy[0], lastBlendDstAlphagassy[0]);

        setGlStategassy(GL_BLEND, lastEnableBlendgassy);
        setGlStategassy(GL_CULL_FACE, lastEnableCullFacegassy);
        setGlStategassy(GL_DEPTH_TEST, lastEnableDepthTestgassy);
        setGlStategassy(GL_STENCIL_TEST, lastEnableStencilTestgassy);
        setGlStategassy(GL_SCISSOR_TEST, lastEnableScissorTestgassy);

        if (glVersiongassy >= 310) {
            setGlStategassy(GL_PRIMITIVE_RESTART, lastEnablePrimitiveRestartgassy);
        }

        if (glVersiongassy >= 200) {
            glPolygonMode(GL_FRONT_AND_BACK, lastPolygonModegassy[0]);
        }

        glViewport(lastViewportgassy[0], lastViewportgassy[1], lastViewportgassy[2], lastViewportgassy[3]);
        glScissor(lastScissorBoxgassy[0], lastScissorBoxgassy[1], lastScissorBoxgassy[2], lastScissorBoxgassy[3]);

        glDepthMask(lastDepthMaskgassy);
    }

    private static void setGlStategassy(final int capability, final boolean enabled) {
        if (enabled) {
            glEnable(capability);
        } else {
            glDisable(capability);
        }
    }
}
