package gassy_wtf.gassy_opal.gassy_utility.gassy_render;

import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Animation;
import gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation.gassy_Easing;

public final class GassyScrollergassy {

    private final Animation animationgassy = new Animation(Easing.EASE_OUT_EXPO, 250);
    private float valuegassy;

    public Animation getAnimationgassy() {
        return this.animationgassy;
    }

    public void onScrollgassy(float maxOffset) {
        this.valuegassy = Math.min(0, Math.max(-maxOffset, this.valuegassy));
        this.animationgassy.run(this.valuegassy);
    }

    public void addScrollgassy(double verticalScroll, float maxOffset) {
        this.valuegassy += (float) (verticalScroll * 50);

        // Prevent scrolling past the bottom
        this.valuegassy = Math.max(-maxOffset, this.valuegassy);

        // Prevent scrolling past the top
        this.valuegassy = Math.min(0, this.valuegassy);

        this.animationgassy.run(this.valuegassy);
    }

}
