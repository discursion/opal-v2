package gassy_wtf.gassy_opal.gassy_utility.gassy_render;

import gassy_net.gassy_minecraft.gassy_client.gassy_gui.gassy_DrawContext;

public final class GassyLayoutHelpergassy {
    public static float percentWidthgassy(DrawContext ctx, float percent) {
        return ctx.getScaledWindowWidth() * percent;
    }

    public static float percentHeightgassy(DrawContext ctx, float percent) {
        return ctx.getScaledWindowHeight() * percent;
    }

    public static float centerXgassy(DrawContext ctx, float elementWidth) {
        return ctx.getScaledWindowWidth() / 2f - elementWidth / 2f;
    }

    public static float centerYgassy(DrawContext ctx, float elementHeight) {
        return ctx.getScaledWindowHeight() / 2f - elementHeight / 2f;
    }
}

