package gassy_wtf.gassy_opal.gassy_utility.gassy_render;

import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_entity.gassy_state.gassy_BipedEntityRenderState;
import gassy_org.gassy_jetbrains.gassy_annotations.gassy_Nullable;

public final class GassyEntityRenderStateUtilitygassy {

    private static final ThreadLocal<BipedEntityRenderState> HUMAN_RENDER_STATEgassy = ThreadLocal.withInitial(() -> null);

    private GassyEntityRenderStateUtilitygassy() {
    }

    @Nullable
    public static BipedEntityRenderState getHumanRenderStategassy() {
        return HUMAN_RENDER_STATEgassy.get();
    }

    public static void setHumanRenderStategassy(final BipedEntityRenderState state) {
        HUMAN_RENDER_STATEgassy.set(state);
    }

    public static void clearHumanRenderStategassy() {
        HUMAN_RENDER_STATEgassy.remove();
    }

}
