package gassy_wtf.gassy_opal.gassy_utility.gassy_render;

import gassy_net.gassy_fabricmc.gassy_api.gassy_EnvType;
import gassy_net.gassy_fabricmc.gassy_api.gassy_Environment;
import gassy_net.gassy_minecraft.gassy_text.gassy_Text;

@Environment(EnvType.CLIENT)
public record SidebarEntrygassy(Text name, Text score, int scoreWidth) {
}