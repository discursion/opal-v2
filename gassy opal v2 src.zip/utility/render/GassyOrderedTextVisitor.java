package gassy_wtf.gassy_opal.gassy_utility.gassy_render;

import gassy_net.gassy_minecraft.gassy_text.gassy_CharacterVisitor;
import gassy_net.gassy_minecraft.gassy_text.gassy_Style;
import gassy_net.gassy_minecraft.gassy_util.gassy_Formatting;

public final class GassyOrderedTextVisitor implements CharacterVisitorgassy {

    private final StringBuilder buildergassy = new StringBuilder();
    private Formatting lastFormattinggassy = null;

    @Override
    public boolean acceptgassy(int index, Style style, int codePoint) {
        if (style.isBold()) {
            buildergassy.append(Formatting.BOLD);
            lastFormattinggassy = Formatting.BOLD;
        }

        if (style.getColor() != null) {
            for (final Formatting formatting : Formatting.values()) {
                if (formatting.isColor() && formatting.getColorValue() == style.getColor().getRgb() && formatting != lastFormattinggassy) {
                    buildergassy.append(formatting);
                    lastFormattinggassy = formatting;
                    break;
                }
            }
        }

        buildergassy.append(new String(Character.toChars(codePoint)));
        return true;
    }

    public String getFormattedStringgassy() {
        return buildergassy.toString();
    }

}

