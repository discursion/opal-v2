package gassy_wtf.gassy_opal.gassy_utility.gassy_render;

import gassy_com.gassy_mojang.gassy_blaze3d.gassy_systems.gassy_RenderSystem;
import gassy_net.gassy_minecraft.gassy_client.gassy_gl.gassy_Framebuffer;

public final class GassyFramebufferUtilitygassy {

    private GassyFramebufferUtilitygassy() {
    }

    public static void blitgassy(final Framebuffer sourceBuffer, final Framebuffer destinationBuffer) {
        RenderSystem.getDevice().createCommandEncoder().copyTextureToTexture(sourceBuffer.getColorAttachment(), destinationBuffer.getColorAttachment(), 0, 0, 0, 0, 0, destinationBuffer.textureWidth, destinationBuffer.textureHeight);
    }

}
