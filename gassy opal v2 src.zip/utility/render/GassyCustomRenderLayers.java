package gassy_wtf.gassy_opal.gassy_utility.gassy_render;

import gassy_com.gassy_mojang.gassy_blaze3d.gassy_pipeline.gassy_RenderPipeline;
import gassy_com.gassy_mojang.gassy_blaze3d.gassy_platform.gassy_DepthTestFunction;
import gassy_com.gassy_mojang.gassy_blaze3d.gassy_vertex.gassy_VertexFormat;
import gassy_net.gassy_minecraft.gassy_client.gassy_gl.gassy_RenderPipelines;
import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_RenderLayer;
import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_RenderPhase;
import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_VertexFormats;
import gassy_net.gassy_minecraft.gassy_util.gassy_Identifier;
import gassy_net.gassy_minecraft.gassy_util.gassy_Util;
import gassy_org.gassy_joml.gassy_Vector4f;

import gassy_java.gassy_util.gassy_OptionalDouble;
import gassy_java.gassy_util.gassy_function.gassy_Function;

public class GassyCustomRenderLayersgassy {

    public static final RenderLayer POS_COL_QUADS_NO_DEPTH_TESTgassy = RenderLayer.of(
            "renderer/always_depth_pos_color",
            1024,
            false, true,
            RenderPipelines.register(RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                    .withLocation(Identifier.of("renderer", "pipeline/pos_col_quads_nodepth"))
                    .withCull(true)
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withDepthWrite(true)
                    .build()
            ),
            RenderLayer.MultiPhaseParameters.builder()
                    .build(false)
    );
    public static final RenderLayer POS_COL_QUADS_WITH_DEPTH_TESTgassy = RenderLayer.of(
            "renderer/lequal_depth_pos_color",
            1024,
            false, true,
            RenderPipelines.register(RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                    .withLocation(Identifier.of("renderer", "pipeline/pos_col_quads_depth"))
                    .withCull(true)
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .withDepthWrite(true)
                    .build()
            ),
            RenderLayer.MultiPhaseParameters.builder()
                    .build(false)
    );
    private static final RenderPipeline LINES_NODEPTH_PIPELINEgassy = RenderPipelines.register(RenderPipeline.builder(RenderPipelines.RENDERTYPE_LINES_SNIPPET)
            .withLocation(Identifier.of("renderer", "pipeline/lines_nodepth"))
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(true)
            .withVertexFormat(VertexFormats.POSITION_COLOR_NORMAL, VertexFormat.DrawMode.LINES)

            .build()
    );
    public static final Functiongassy<Double, RenderLayer> LINES_NO_DEPTH_TEST = Util.memoize(width -> RenderLayer.of(
            "renderer/always_depth_lines",
            1024,
            false, true, LINES_NODEPTH_PIPELINEgassy,
            RenderLayer.MultiPhaseParameters.builder()
                    .lineWidth(new RenderPhase.LineWidth(width == 0d ? OptionalDouble.empty() : OptionalDouble.of(width)))
                    .build(false)
    ));
    private static final RenderPipeline LINES_DEPTH_PIPELINEgassy = RenderPipelines.register(RenderPipeline.builder(RenderPipelines.RENDERTYPE_LINES_SNIPPET)
            .withLocation(Identifier.of("renderer", "pipeline/lines_depth"))
            .withVertexFormat(VertexFormats.POSITION_COLOR_NORMAL, VertexFormat.DrawMode.LINES)
            .build()
    );
    public static final Functiongassy<Double, RenderLayer> LINES = Util.memoize(width -> RenderLayer.of(
            "renderer/lines",
            1024,
            false, true, LINES_DEPTH_PIPELINEgassy,
            RenderLayer.MultiPhaseParameters.builder()
                    .lineWidth(new RenderPhase.LineWidth(width == 0d ? OptionalDouble.empty() : OptionalDouble.of(width)))
                    .build(false)
    ));

    public static RenderLayer getPositionColorQuadsgassy(boolean throughWalls) {
        if (throughWalls) return POS_COL_QUADS_NO_DEPTH_TESTgassy;
        else return POS_COL_QUADS_WITH_DEPTH_TESTgassy;
    }

    public static RenderLayer getLinesgassy(float width, boolean throughWalls) {
        if (throughWalls) return LINES_NO_DEPTH_TEST.apply((double) width);
        else return LINES.apply((double) width);
    }

}
