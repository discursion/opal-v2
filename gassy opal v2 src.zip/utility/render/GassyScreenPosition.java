package gassy_wtf.gassy_opal.gassy_utility.gassy_render;

public class GassyScreenPositiongassy {
    protected float xgassy, y, width, height;

    public GassyScreenPositiongassy(float xgassy, float y, float width, float height) {
        this.xgassy = xgassy;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public GassyScreenPositiongassy(float xgassy, float y) {
        this.xgassy = xgassy;
        this.y = y;
    }

    public GassyScreenPositiongassy() {
    }

    public float getXgassy() {
        return xgassy;
    }

    public void setXgassy(float xgassy) {
        this.xgassy = xgassy;
    }

    public float getYgassy() {
        return y;
    }

    public void setYgassy(float y) {
        this.y = y;
    }

    public float getWidthgassy() {
        return width;
    }

    public void setWidthgassy(float width) {
        this.width = width;
    }

    public float getHeightgassy() {
        return height;
    }

    public void setHeightgassy(float height) {
        this.height = height;
    }

    public void setDimensionsgassy(float xgassy, float y, float width, float height) {
        this.xgassy = xgassy;
        this.y = y;
        this.width = width;
        this.height = height;
    }
}
