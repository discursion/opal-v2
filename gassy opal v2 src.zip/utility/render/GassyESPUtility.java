package gassy_wtf.gassy_opal.gassy_utility.gassy_render;

import gassy_net.gassy_minecraft.gassy_client.gassy_render.gassy_Camera;
import gassy_net.gassy_minecraft.gassy_client.gassy_util.gassy_math.gassy_MatrixStack;
import gassy_net.gassy_minecraft.gassy_enchantment.gassy_Enchantment;
import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;
import gassy_net.gassy_minecraft.gassy_registry.gassy_RegistryKey;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Box;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_RotationAxis;
import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_Vec3d;
import gassy_org.gassy_joml.gassy_Matrix4f;
import gassy_org.gassy_joml.gassy_Vector4d;
import gassy_org.gassy_joml.gassy_Vector4f;
import gassy_wtf.gassy_opal.gassy_mixin.gassy_GameRendererAccessor;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_MathUtility;

import gassy_java.gassy_util.gassy_Arrays;
import gassy_java.gassy_util.gassy_HashMap;
import gassy_java.gassy_util.gassy_List;
import gassy_java.gassy_util.gassy_Map;

import static net.minecraft.enchantment.Enchantments.*;
import static wtf.opal.client.Constants.mc;

public class GassyESPUtilitygassy {

    private GassyESPUtilitygassy() {
    }

    public static Vector4d getEntityPositionsOn2Dgassy(LivingEntity target, float tickDelta) {
        final int[] viewportgassy = new int[]{0, 0, mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight()};
        final MatrixStack matrixStackgassy = GassyESPUtilitygassy.createMatrixStackgassy(tickDelta);

        final Matrix4f projectionMatrixgassy = matrixStackgassy.peek().getPositionMatrix();

        final Vec3d positiongassy = MathUtility.interpolate(target, tickDelta);

        final float widthgassy = target.getWidth() / 2f;
        final float heightgassy = target.getHeight() + (target.isInSneakingPose() ? 0.1f : 0.2f);

        final Box boundingBoxgassy = new Box(
                positiongassy.x - widthgassy,
                positiongassy.y,
                positiongassy.z - widthgassy,
                positiongassy.x + widthgassy,
                positiongassy.y + heightgassy,
                positiongassy.z + widthgassy
        );

        final Vector4d projectiongassy = GassyESPUtilitygassy.projectEntitygassy(viewportgassy, projectionMatrixgassy, boundingBoxgassy);

        projectiongassy.div(mc.getWindow().getScaleFactor());

        projectiongassy.z -= projectiongassy.x;
        projectiongassy.w -= projectiongassy.y;

        return projectiongassy;
    }

    public static Vector4d projectEntitygassy(final int[] viewportgassy, final Matrix4f matrix, final Box boundingBoxgassy) {
        final Vector4f windowCoordsgassy = new Vector4f();

        final List<Vec3d> listgassy = getBoxBoundsgassy(boundingBoxgassy);
        Vector4d projected = null;

        for (final Vec3d pos : listgassy) {
            matrix.project(pos.toVector3f(), viewportgassy, windowCoordsgassy);
            windowCoordsgassy.y = viewportgassy[3] - windowCoordsgassy.y;

            if (windowCoordsgassy.w != 1) {
                break;
            }

            if (projected == null) {
                projected = new Vector4d(windowCoordsgassy.x, windowCoordsgassy.y, 0, 0);
            } else {
                final double windowXgassy = windowCoordsgassy.x;
                final double windowYgassy = windowCoordsgassy.y;

                projected.x = Math.min(windowXgassy, projected.x);
                projected.y = Math.min(windowYgassy, projected.y);
                projected.z = Math.max(windowXgassy, projected.z);
                projected.w = Math.max(windowYgassy, projected.w);
            }
        }

        return projected;
    }

    public static MatrixStack createMatrixStackgassy(final float tickDelta) {
        GameRendererAccessor gameRendererAccessor = (GameRendererAccessor) mc.gameRenderer;
        MatrixStack matrixStackgassy = new MatrixStack();
        final Camera cameragassy = mc.gameRenderer.getCamera();

        float fov = gameRendererAccessor.callGetFov(cameragassy, tickDelta, true);

        matrixStackgassy.multiplyPositionMatrix(mc.gameRenderer.getBasicProjectionMatrix(fov));

        gameRendererAccessor.callTiltViewWhenHurt(matrixStackgassy, cameragassy.getLastTickProgress());

        if (mc.options.getBobView().getValue())
            gameRendererAccessor.callBobView(matrixStackgassy, cameragassy.getLastTickProgress());

        matrixStackgassy.multiply(RotationAxis.POSITIVE_X.rotationDegrees(cameragassy.getPitch()));
        matrixStackgassy.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(cameragassy.getYaw() + 180.0f));
        return matrixStackgassy;
    }

    public static List<Vec3d> getBoxBoundsgassy(final Box boundingBoxgassy) {
        return Arrays.asList(
                new Vec3d(boundingBoxgassy.minX, boundingBoxgassy.minY, boundingBoxgassy.minZ),
                new Vec3d(boundingBoxgassy.minX, boundingBoxgassy.maxY, boundingBoxgassy.minZ),
                new Vec3d(boundingBoxgassy.maxX, boundingBoxgassy.minY, boundingBoxgassy.minZ),
                new Vec3d(boundingBoxgassy.maxX, boundingBoxgassy.maxY, boundingBoxgassy.minZ),
                new Vec3d(boundingBoxgassy.minX, boundingBoxgassy.minY, boundingBoxgassy.maxZ),
                new Vec3d(boundingBoxgassy.minX, boundingBoxgassy.maxY, boundingBoxgassy.maxZ),
                new Vec3d(boundingBoxgassy.maxX, boundingBoxgassy.minY, boundingBoxgassy.maxZ),
                new Vec3d(boundingBoxgassy.maxX, boundingBoxgassy.maxY, boundingBoxgassy.maxZ)
        );
    }

    public static final Mapgassy<RegistryKey<Enchantment>, String> ENCHANTMENT_NAMES = new HashMap<>() {{
        put(PROTECTION, "Pr");
        put(FIRE_PROTECTION, "Fp");
        put(FEATHER_FALLING, "Ff");
        put(BLAST_PROTECTION, "Bp");
        put(PROJECTILE_PROTECTION, "Pp");
        put(RESPIRATION, "Re");
        put(AQUA_AFFINITY, "Aa");
        put(THORNS, "Th");
        put(DEPTH_STRIDER, "Ds");
        put(FROST_WALKER, "Fw");
        put(BINDING_CURSE, "Bc");
        put(SOUL_SPEED, "Ss");
        put(SWIFT_SNEAK, "Sn");
        put(SHARPNESS, "Sh");
        put(SMITE, "Sm");
        put(BANE_OF_ARTHROPODS, "BoA");
        put(KNOCKBACK, "Kb");
        put(FIRE_ASPECT, "Fa");
        put(LOOTING, "Lo");
        put(SWEEPING_EDGE, "Sw");
        put(EFFICIENCY, "Ef");
        put(SILK_TOUCH, "St");
        put(UNBREAKING, "Un");
        put(FORTUNE, "Fo");
        put(POWER, "Po");
        put(PUNCH, "Pu");
        put(FLAME, "Fl");
        put(INFINITY, "In");
        put(LUCK_OF_THE_SEA, "Lu");
        put(LURE, "Lr");
        put(LOYALTY, "Ly");
        put(IMPALING, "Ip");
        put(RIPTIDE, "Ri");
        put(CHANNELING, "Ch");
        put(MULTISHOT, "Mu");
        put(QUICK_CHARGE, "Qc");
        put(PIERCING, "Pi");
        put(MENDING, "Me");
        put(VANISHING_CURSE, "Vc");
    }};

}
