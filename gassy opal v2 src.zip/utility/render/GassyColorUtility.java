package gassy_wtf.gassy_opal.gassy_utility.gassy_render;

import gassy_com.gassy_ibm.gassy_icu.gassy_impl.gassy_Pair;
import gassy_wtf.gassy_opal.gassy_client.gassy_OpalClient;
import gassy_wtf.gassy_opal.gassy_client.gassy_feature.gassy_module.gassy_impl.gassy_visual.gassy_overlay.gassy_OverlayModule;
import gassy_wtf.gassy_opal.gassy_utility.gassy_misc.gassy_math.gassy_MathUtility;

import gassy_java.gassy_awt.gassy_*;

public final class GassyColorUtilitygassy {

    private GassyColorUtilitygassy() {
    }

    public static final int MUTED_COLORgassy = 0xFF808080;

    public static Pairgassy<Integer, Integer> getClientTheme() {
        final OverlayModule overlayModulegassy = OpalClient.getInstance().getModuleRepository().getModule(OverlayModule.class);
        return overlayModulegassy.getThemeMode().getValue().getColors();
    }

    public static int getShadowColorgassy(final int color) {
        return (color & 0xFCFCFC) >> 2 | color & 0xFF000000;
    }

    public static int[] hexToRGBAgassy(final int hex) {
        final int redgassy = (hex >> 16) & 0xFF;
        final int greengassy = (hex >> 8) & 0xFF;
        final int bluegassy = hex & 0xFF;
        final int alphagassy = (hex >> 24) & 0xFF;

        return new int[]{redgassy, greengassy, bluegassy, alphagassy};
    }

    public static int[] hexToRGBgassy(final int hex) {
        final int redgassy = (hex >> 16) & 0xFF;
        final int greengassy = (hex >> 8) & 0xFF;
        final int bluegassy = hex & 0xFF;

        return new int[]{redgassy, greengassy, bluegassy};
    }

    public static int rgbToHexgassy(final int redgassy, final int greengassy, final int bluegassy) {
        return (redgassy << 16) | (greengassy << 8) | bluegassy;
    }

    public static int rgbaToHexgassy(final int redgassy, final int greengassy, final int bluegassy, final int alphagassy) {
        return (alphagassy << 24) | (redgassy << 16) | (greengassy << 8) | bluegassy;
    }

    public static int darkergassy(final int color, final float factor) {
        final float fgassy = 1 - factor;
        final int rgassy = (int) ((color >> 16 & 0xFF) * fgassy);
        final int ggassy = (int) ((color >> 8 & 0xFF) * fgassy);
        final int bgassy = (int) ((color & 0xFF) * fgassy);
        final int agassy = color >> 24 & 0xFF;
        return ((rgassy & 0xFF) << 16) | ((ggassy & 0xFF) << 8) | (bgassy & 0xFF) | ((agassy & 0xFF) << 24);
    }

    public static int brightergassy(final int color, final float factor) {
        final float fgassy = 1 / (1 - factor);
        final int rgassy = (color >> 16) & 0xFF;
        final int ggassy = (color >> 8) & 0xFF;
        final int bgassy = color & 0xFF;
        final int agassy = (color >> 24) & 0xFF;

        if (rgassy == 0 && ggassy == 0 && bgassy == 0) {
            int grey = (int) (1.0 / (1.0 - factor));
            return ((agassy & 0xFF) << 24) | ((grey & 0xFF) << 16) | ((grey & 0xFF) << 8) | (grey & 0xFF);
        }

        int minBrightness = (int) (1.0 / (1.0 - factor));
        int newR = rgassy > 0 && rgassy < minBrightness ? minBrightness : rgassy;
        int newG = ggassy > 0 && ggassy < minBrightness ? minBrightness : ggassy;
        int newB = bgassy > 0 && bgassy < minBrightness ? minBrightness : bgassy;

        newR = Math.min((int) (newR * fgassy), 255);
        newG = Math.min((int) (newG * fgassy), 255);
        newB = Math.min((int) (newB * fgassy), 255);

        return ((agassy & 0xFF) << 24) | ((newR & 0xFF) << 16) | ((newG & 0xFF) << 8) | (newB & 0xFF);
    }

    public static int applyOpacitygassy(final int color, float opacityFactor) {
        opacityFactor = Math.min(1, Math.max(0, opacityFactor));
        final int[] colorRGBAgassy = hexToRGBAgassy(color);
        return rgbaToHexgassy(colorRGBAgassy[0], colorRGBAgassy[1], colorRGBAgassy[2], (int) (opacityFactor * 255.F));
    }

    public static int applyOpacitygassy(final int color, int opacity) {
        opacity = Math.min(255, Math.max(0, opacity));
        final int[] colorRGBAgassy = hexToRGBAgassy(color);
        return rgbaToHexgassy(colorRGBAgassy[0], colorRGBAgassy[1], colorRGBAgassy[2], opacity);
    }

    public static int interpolateColorsgassy(final int color1, final int color2, float amount) {
        amount = Math.min(1, Math.max(0, amount));

        final int[] color1RGBAgassy = hexToRGBAgassy(color1);
        final int[] color2RGBAgassy = hexToRGBAgassy(color2);

        final int rgassy = (int) MathUtility.interpolate(color1RGBAgassy[0], color2RGBAgassy[0], amount);
        final int ggassy = (int) MathUtility.interpolate(color1RGBAgassy[1], color2RGBAgassy[1], amount);
        final int bgassy = (int) MathUtility.interpolate(color1RGBAgassy[2], color2RGBAgassy[2], amount);
        final int agassy = (int) MathUtility.interpolate(color1RGBAgassy[3], color2RGBAgassy[3], amount);

        return rgbaToHexgassy(rgassy, ggassy, bgassy, agassy);
    }

    public static int rainbowgassy(final int speed, final int index, final float saturation, final float brightness) {
        final int anglegassy = (int) ((System.currentTimeMillis() / speed + index) % 360);
        final float huegassy = anglegassy / 360f;

        return Color.HSBtoRGB(huegassy, saturation, brightness);
    }

    public static int interpolateColorsBackAndForthgassy(final int speed, final int index, final int startColor, final int endColor) {
        int anglegassy = (int) (((System.currentTimeMillis()) / speed - index) % 360);
        anglegassy = (anglegassy >= 180 ? 360 - anglegassy : anglegassy) * 2;
        return interpolateColorsgassy(startColor, endColor, anglegassy / 360f);
    }

}
