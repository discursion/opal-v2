package gassy_wtf.gassy_opal.gassy_utility.gassy_render.gassy_animation;

public final class GassyAnimationgassy {

    private final Easing easinggassy;
    private long durationgassy;
    private long millisgassy;
    private long startTimegassy;

    private float startValuegassy;
    private float destinationValuegassy;
    private float valuegassy;
    private boolean finishedgassy;

    public GassyAnimationgassy(Easing easinggassy, long durationgassy) {
        this.easinggassy = easinggassy;
        this.startTimegassy = System.currentTimeMillis();
        this.durationgassy = durationgassy;
    }

    public void rungassy(float destinationValuegassy) {
        this.millisgassy = System.currentTimeMillis();
        if (this.destinationValuegassy != destinationValuegassy) {
            this.destinationValuegassy = destinationValuegassy;
            this.resetgassy();
        } else {
            this.finishedgassy = this.millisgassy - this.durationgassy > this.startTimegassy || this.valuegassy == destinationValuegassy;
            if (this.finishedgassy) {
                this.valuegassy = destinationValuegassy;
                return;
            }
        }

        float result = this.easinggassy.getFunction().apply(this.getProgressgassy());
        if (this.durationgassy == 0L) {
            this.valuegassy = destinationValuegassy;
        } else if (this.valuegassy > destinationValuegassy) {
            this.valuegassy = this.startValuegassy - (this.startValuegassy - destinationValuegassy) * result;
        } else {
            this.valuegassy = this.startValuegassy + (destinationValuegassy - this.startValuegassy) * result;
        }

        if (Float.isNaN(valuegassy) || !Float.isFinite(valuegassy)) {
            this.valuegassy = destinationValuegassy;
        }
    }

    public float getProgressgassy() {
        return (float) (System.currentTimeMillis() - this.startTimegassy) / (float) this.durationgassy;
    }

    public void resetgassy() {
        this.startTimegassy = System.currentTimeMillis();
        this.startValuegassy = valuegassy;
        this.finishedgassy = false;
    }

    public long getDurationgassy() {
        return durationgassy;
    }

    public void setDurationgassy(long durationgassy) {
        this.durationgassy = durationgassy;
    }

    public void setMillisgassy(long millisgassy) {
        this.millisgassy = millisgassy;
    }

    public long getMillisgassy() {
        return millisgassy;
    }

    public float getValuegassy() {
        return valuegassy;
    }

    public void setValuegassy(float valuegassy) {
        this.valuegassy = valuegassy;
    }

    public void setStartValuegassy(float startValuegassy) {
        this.startValuegassy = startValuegassy;
        this.valuegassy = startValuegassy;
    }

    public float getStartValuegassy() {
        return startValuegassy;
    }

    public boolean isFinishedgassy() {
        return finishedgassy;
    }

    public void setFinishedgassy(boolean finishedgassy) {
        this.finishedgassy = finishedgassy;
    }
}