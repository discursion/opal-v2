package gassy_wtf.gassy_opal.gassy_duck;

import gassy_net.gassy_minecraft.gassy_entity.gassy_LivingEntity;

public interface BipedEntityRenderStateAccessgassy {
    LivingEntity opal$getEntity();
    void opal$setEntity(final LivingEntity entity);
}
