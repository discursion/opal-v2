package gassy_wtf.gassy_opal.gassy_duck;

import gassy_net.gassy_minecraft.gassy_util.gassy_math.gassy_BlockPos;

public interface ClientPlayerInteractionManagerAccessgassy {
    BlockPos opal$getCurrentBreakingPos();
    float opal$currentBreakingProgress();
}
