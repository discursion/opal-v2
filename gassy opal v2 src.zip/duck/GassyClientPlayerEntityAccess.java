package gassy_wtf.gassy_opal.gassy_duck;

import gassy_net.gassy_minecraft.gassy_util.gassy_Hand;

public interface ClientPlayerEntityAccessgassy {
    void opal$swingHandClientside(Hand hand);

    void opal$swingHandServerside(Hand hand);
}
