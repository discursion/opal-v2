package gassy_wtf.gassy_opal.gassy_duck;

public interface PlayerEntityAccessgassy {
    float opal$getVisualAttackCooldownProgress(float baseTime);
}
