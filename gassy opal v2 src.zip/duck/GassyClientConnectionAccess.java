package gassy_wtf.gassy_opal.gassy_duck;

import gassy_net.gassy_minecraft.gassy_network.gassy_packet.gassy_Packet;

public interface ClientConnectionAccessgassy {
    void opal$channelReadSilent(Packet<?> packet);
}
