package gassy_wtf.gassy_opal.gassy_duck;

import gassy_net.gassy_minecraft.gassy_entity.gassy_Entity;

public interface EntityRenderStateAccessgassy {
    Entity opal$getEntity();
    void opal$setEntity(final Entity entity);
}
